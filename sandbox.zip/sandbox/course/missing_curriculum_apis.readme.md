# Course Module — Missing Curriculum-Semester Field

> **Audience:** Backend developer (qhub_backend_api / NestJS Course module).
> **Status:** The frontend has a "Curriculum Planner" screen (admin: pick a program, see its
> courses grouped by level and by term-within-level) that needs one field the real
> `Course` model doesn't have yet. This document specifies exactly what to add so the
> frontend's grouping — currently done client-side over the real, already-scoped
> `GET /courses/programs/:programId` response — reflects real data instead of showing
> every course as "unassigned."

---

## Background

`sandbox/schema.prisma` confirms `Course` has `levelId` (which level the course belongs
to) but nothing that says *which term of that level* — Nigerian university curricula
conventionally define a fixed 2-semester course load per level (e.g. "CSC201 is a 200
Level, First Semester course"), and there's currently no field anywhere in the schema
that expresses this. It's a property of the course's place in the curriculum, distinct
from `CourseOffering.semesterId` — the latter is *when a specific session's class actually
runs*, which can legitimately differ from the curriculum slot (carry-over students, elective
scheduling, etc.).

An earlier frontend implementation invented a whole parallel `Level → CurriculumSemester`
entity graph to fake this, entirely disconnected from the real `Level`/`Course` models and
running on mock data. That's been removed — this document proposes the real, minimal fix
instead.

---

## Proposed Schema Change

Add one nullable column directly to `Course`:

```prisma
model Course {
  // ...existing fields
  curriculumSemester Int? @map("curriculum_semester")
  // ...existing relations
}
```

- `1` = First Semester of the course's level, `2` = Second Semester, `null` = not yet
  assigned to a term (e.g. a newly-created course, or a genuinely either-semester elective).
- No new table needed — a course belongs to exactly one level (`levelId`) already, so a
  scalar term number on the same row is sufficient; there's no case in the existing schema
  where the same course needs multiple curriculum-semester slots.
- No FK, no cascade behavior to define — it's a plain small int, like `creditUnits`.

---

## Endpoint Changes

No new endpoints are needed. Add the field to the existing Course DTOs and every response
that already returns a `Course`:

### `POST /courses` (`CreateCourseDto`) — add optional field

```ts
{
  // ...existing fields (code, title, description, creditUnits, courseType, levelId, owningDepartmentId, syllabus)
  curriculumSemester?: number;   // 1 or 2, optional
}
```

### `PATCH /courses/:id` (`UpdateCourseDto`) — add optional field

```ts
{
  // ...existing optional fields
  curriculumSemester?: number;
}
```

### Every Course response — add the field

`GET /courses`, `GET /courses/:id`, `GET /courses/programs/:programId`, and the
Create/Update responses should all include:

```ts
{
  // ...existing Course fields
  curriculumSemester: number | null;
}
```

`GET /courses/programs/:programId` in particular is the endpoint the new frontend screen
already calls for real (it lists every course mapped to a program via `ProgramCourse`) —
once this field is present on those objects, the frontend's client-side grouping by
`levelId` → `curriculumSemester` becomes real data instead of an always-"unassigned" bucket.

---

## Validation

- `curriculumSemester`, when provided, should be restricted to `1` or `2` at the DTO level
  (`@IsIn([1, 2])` or equivalent) — reject anything else with a 400.
- No uniqueness constraint needed; multiple courses share the same `(levelId,
  curriculumSemester)` pair by design (that's the whole point — it's the course *load* for
  that term).

---

## Notes

- This is additive and backward-compatible — existing `Course` rows get `curriculumSemester
  = null` and simply show as "unassigned" in the planner until an admin sets them, no
  migration/backfill required to ship it.
- Once this ships, add a corresponding `.bru` request (or extend `Course - Update.bru`'s
  example body) to `bruno/course/` documenting the field, per this collection's existing
  convention of every endpoint's real shape being reflected there.
