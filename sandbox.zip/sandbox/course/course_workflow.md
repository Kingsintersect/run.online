# Course Module — Implementation Workflow

This document explains the internal implementation flow for the Course module. It is intended for developers building or maintaining this module.

---

## Module Dependencies

```
CourseModule
├── PrismaService          (database access)
├── AcademicModule         (session, semester, level, department, program lookups)
├── AuditModule            (log course changes)
└── UserModule             (lecturer validation for assignments)
```

---

## Data Flow Overview

```
Course (catalog definition)
  │
  ├── ProgramCourse (which programs use this course)
  │     └── isRequired: true/false
  │
  ├── CoursePrerequisite (which courses must be passed first)
  │
  └── CourseOffering (offered this semester)
        │
        ├── CourseOfferingLecturer (who teaches it)
        │
        └── ClassSchedule (when & where)
```

---

## 1. Course Lifecycle

### Creating a Course

```
Admin creates a new course in the catalog
         │
         ▼
┌──────────────────────────────────────────────────┐
│  CourseService.createCourse(dto)                 │
│  1. Validate code uniqueness                     │
│     - Duplicate → 409                            │
│  2. Validate levelId exists                      │
│  3. Validate owningDepartmentId (if provided)    │
│     - null = university-wide (GST)               │
│  4. Create Course record                         │
│     - isActive: true (default)                   │
│  5. Log via AuditService                         │
└──────────────────────────────────────────────────┘
```

### Assigning Course to Program

```
Admin maps a course to a program curriculum
         │
         ▼
┌──────────────────────────────────────────────────┐
│  CourseService.assignToProgram(programId, dto)    │
│  1. Verify program exists                        │
│  2. Verify course exists                         │
│  3. Check if mapping already exists              │
│     - Found → 409 "Already assigned"             │
│  4. Create ProgramCourse:                        │
│     - programId, courseId                         │
│     - isRequired (compulsory/elective)           │
└──────────────────────────────────────────────────┘
```

---

## 2. Course Offering Flow (Per Semester)

This is the main workflow each semester:

```
Step 1: Create offerings for the semester
──────────────────────────────────────────
POST /courses/offerings
{
  courseId: 5, academicSessionId: 1,
  semesterId: 1, maxCapacity: 200, status: "PLANNED"
}
         │
         ▼
Step 2: Assign lecturers to offerings
──────────────────────────────────────
POST /courses/offerings/:id/lecturers
{ lecturerId: 3, role: "primary" }

POST /courses/offerings/:id/lecturers
{ lecturerId: 7, role: "tutorial" }
         │
         ▼
Step 3: Create class schedules
──────────────────────────────
POST /courses/offerings/:id/schedules
{
  lecturerId: 3, dayOfWeek: "Monday",
  startTime: "09:00", endTime: "11:00",
  venue: "LT1", classType: "lecture"
}
         │
         ▼
Step 4: Open for enrollment
───────────────────────────
PATCH /courses/offerings/:id
{ status: "OPEN" }
→ Students can now enroll (Enrollment Module)
```

### Offering Status Machine

```
PLANNED ──▶ OPEN ──▶ CLOSED (semester ends / manually)
              │
              └──▶ CANCELLED (cancelled before completion)
```

---

## 3. Prerequisite Validation

Prerequisites are checked at enrollment time (Enrollment Module calls this):

```ts
async checkPrerequisites(studentId: number, courseId: number): Promise<boolean> {
  // Get all prerequisite courses for this course
  const prerequisites = await this.prisma.coursePrerequisite.findMany({
    where: { courseId },
    select: { prerequisiteId: true },
  });

  if (prerequisites.length === 0) return true;

  // Check if student has a passing grade in all prerequisites
  for (const prereq of prerequisites) {
    const grade = await this.prisma.grade.findFirst({
      where: {
        studentId,
        courseId: prereq.prerequisiteId,
        status: 'PUBLISHED',
        // gradePoint > 0 means passed (customize threshold)
      },
    });
    if (!grade || grade.gradePoint <= 0) return false;
  }

  return true;
}
```

---

## 4. Schedule Conflict Detection

```ts
async checkScheduleConflict(
  dayOfWeek: string, startTime: string, endTime: string,
  venue: string, semesterId: number, excludeId?: number
): Promise<boolean> {
  // Check venue conflict: same day, same venue, overlapping time
  const conflict = await this.prisma.classSchedule.findFirst({
    where: {
      id: excludeId ? { not: excludeId } : undefined,
      dayOfWeek,
      venue,
      offering: { semesterId },
      OR: [
        { startTime: { lt: endTime }, endTime: { gt: startTime } },
      ],
    },
  });
  return !!conflict;
}

// Also check lecturer conflict (same lecturer, overlapping time, different venue)
```

---

## 5. GST (General Studies) Handling

GST courses are university-wide courses (e.g., GST101, GST201). They have special handling:

```
Course.owningDepartmentId = null    ← marks it as university-wide
Course.courseType = "GENERAL"       ← visible to all programs

Offering:
- One offering per semester, but potentially thousands of students
- Multiple lecturers assigned
- Each lecturer handles specific departments' students
  (managed at application layer, not schema level)
```

**Lecturer-to-department routing:** This is NOT a database relation. Implement as service logic:

```ts
// When recording attendance for GST:
// Lecturer X handles departments [CSC, MTH, PHY]
// Filter enrolled students by their program's department
```

---

## 6. Files to Create

```
src/modules/course/
├── course.module.ts
├── course.controller.ts          # All course routes
├── course.service.ts             # Business logic
├── dto/
│   ├── create-course.dto.ts
│   ├── assign-program-course.dto.ts
│   ├── add-prerequisite.dto.ts
│   ├── create-offering.dto.ts
│   ├── assign-lecturer.dto.ts
│   └── create-schedule.dto.ts
└── course.service.spec.ts
```

---

## 7. Cross-Module Integration Points

| Direction | Module | Interaction |
| --------- | ------ | ----------- |
| **Consumes** | AcademicModule | Session, Semester, Level, Department, Program lookups |
| **Consumed by** | EnrollmentModule | Offering lookup, capacity check, prerequisite check |
| **Consumed by** | ResultModule | Course info for grade entry |
| **Consumed by** | MoodleModule | Course mapping for Moodle sync |
