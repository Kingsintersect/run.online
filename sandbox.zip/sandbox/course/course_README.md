# Course Module

Manages course definitions, program-course mappings, course offerings per semester, lecturer assignments, prerequisites, and class schedules.

## Models Owned

- **Course** — course catalog entries
- **ProgramCourse** — which courses belong to which programs (required vs. elective)
- **CourseOffering** — course offered in a specific semester
- **CourseOfferingLecturer** — lecturer assignments to offerings
- **CoursePrerequisite** — prerequisite relationships between courses
- **ClassSchedule** — weekly timetable entries for offerings

---

## Endpoints

### Courses

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/courses` | List all courses (filterable by type, level, department) | noAuth |
| `GET` | `/courses/:id` | Get course details with prerequisites | noAuth |
| `POST` | `/courses` | Create a course | Admin |
| `PATCH` | `/courses/:id` | Update a course | Admin |
| `DELETE` | `/courses/:id` | Deactivate a course | Admin |

### Program-Course Mapping

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/courses/programs/:programId` | List courses for a program | noAuth |
| `POST` | `/courses/programs/:programId` | Assign a course to a program | Admin |
| `DELETE` | `/courses/programs/:programId/:courseId` | Remove course from program | Admin |

### Course Prerequisites

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/courses/:id/prerequisites` | List prerequisites for a course | noAuth |
| `POST` | `/courses/:id/prerequisites` | Add a prerequisite to a course | Admin |
| `DELETE` | `/courses/:courseId/prerequisites/:prerequisiteId` | Remove a prerequisite | Admin |

### Course Offerings

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/courses/offerings` | List offerings (filterable by semester, session) | Authenticated |
| `GET` | `/courses/offerings/:id` | Get offering with lecturers & schedule | Authenticated |
| `POST` | `/courses/offerings` | Create a course offering | Admin |
| `PATCH` | `/courses/offerings/:id` | Update an offering (status, capacity) | Admin |
| `DELETE` | `/courses/offerings/:id` | Cancel an offering | Admin |

### Offering Lecturers

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `POST` | `/courses/offerings/:offeringId/lecturers` | Assign lecturer to offering | Admin |
| `DELETE` | `/courses/offerings/:offeringId/lecturers/:lecturerId` | Remove lecturer from offering | Admin |

### Class Schedules

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/courses/offerings/:offeringId/schedules` | List schedules for an offering | Authenticated |
| `POST` | `/courses/offerings/:offeringId/schedules` | Create a class schedule | Admin |
| `PATCH` | `/courses/schedules/:id` | Update a schedule | Admin |
| `DELETE` | `/courses/schedules/:id` | Delete a schedule | Admin |

---

## Request & Response Types

### `POST /courses`

**Request Body (`CreateCourseDto`):**

```ts
{
  code: string;              // unique, max 15 chars (e.g. "CSC301")
  title: string;             // max 200 chars
  description?: string;
  creditUnits: number;
  courseType: "GENERAL" | "FACULTY" | "DEPARTMENTAL" | "ELECTIVE";
  levelId: number;
  owningDepartmentId?: number;  // null for university-wide (e.g. GST)
  syllabus?: string;
}
```

**Response: `201 Created`**

```ts
{
  id: number;
  code: string;
  title: string;
  description: string | null;
  creditUnits: number;
  courseType: string;
  levelId: number;
  owningDepartmentId: number | null;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}
```

---

### `POST /courses/programs/:programId`

**Request Body (`AssignProgramCourseDto`):**

```ts
{
  courseId: number;
  isRequired: boolean;    // true = compulsory, false = elective
}
```

**Response: `201 Created`** — returns the program-course mapping.

---

### `POST /courses/:id/prerequisites`

**Request Body (`AddPrerequisiteDto`):**

```ts
{
  prerequisiteId: number;   // ID of the prerequisite course
}
```

**Response: `201 Created`** — returns the prerequisite record.

---

### `POST /courses/offerings`

**Request Body (`CreateCourseOfferingDto`):**

```ts
{
  courseId: number;
  academicSessionId: number;
  semesterId: number;
  maxCapacity?: number;
  status?: "PLANNED" | "OPEN" | "CLOSED" | "CANCELLED";  // default PLANNED
}
```

**Response: `201 Created`**

```ts
{
  id: number;
  courseId: number;
  academicSessionId: number;
  semesterId: number;
  maxCapacity: number | null;
  status: string;
  createdAt: string;
  updatedAt: string;
  course: { code: string; title: string };
}
```

---

### `GET /courses/offerings` and `GET /courses/offerings/:id`

The list returns `{ data: Offering[] }` (`{ data, meta }` if paginated); `:id` returns a
single `Offering` plus `lecturers` and `schedule`.

Each `Offering` is being **enriched** with term display names, credit units, the programme(s)
the course belongs to, and the Faculty → Department → Level category path — plus a `role` /
`assignedAt` pair when filtered by `?lecturerId=`. Full target shape and rationale:
**`sandbox/course/missing_course_offering_enrichment.readme.md`**. The frontend
(tutor course-assignment panel, tutor "My Assigned Courses") is already built against it and
degrades gracefully until it ships.

```ts
{
  id: number;
  courseId: number;
  academicSessionId: number;
  semesterId: number;
  maxCapacity: number | null;
  enrolledCount: number;
  status: "PLANNED" | "OPEN" | "CLOSED" | "CANCELLED";
  createdAt: string;
  updatedAt: string;
  session: { id: number; name: string };
  semester: { id: number; name: string };
  course: {
    id: number;
    code: string;
    title: string;
    creditUnits: number;
    courseType: "GENERAL" | "FACULTY" | "DEPARTMENTAL" | "ELECTIVE";
    level: { id: number; name: string; numericValue: number };
    owningDepartment: {
      id: number; name: string; code: string;
      faculty: { id: number; name: string; code: string };
    } | null;
    programs: {
      id: number; name: string; code: string; degreeType: string;
      isRequired: boolean;
      department: { id: number; name: string; code: string };
      faculty: { id: number; name: string; code: string };
    }[];
    categoryPath: {
      entityType: "faculty" | "department" | "program" | "level";
      entityId: number;
      name: string;
      moodleCategoryId: number | null;
    }[];
  };
  role?: "primary" | "assistant" | "tutorial";   // only with ?lecturerId=
  assignedAt?: string;                            // only with ?lecturerId=
}
```

---

### `POST /courses/offerings/:offeringId/lecturers`

**Request Body (`AssignLecturerDto`):**

```ts
{
  lecturerId: number;
  role?: string;   // "primary" (default), "assistant", "tutorial"
}
```

**Response: `201 Created`** — returns the assignment record.

---

### `POST /courses/offerings/:offeringId/schedules`

**Request Body (`CreateClassScheduleDto`):**

```ts
{
  lecturerId: number;
  dayOfWeek: string;      // e.g. "Monday", max 10 chars
  startTime: string;      // "HH:MM" format, e.g. "09:00"
  endTime: string;        // "HH:MM" format, e.g. "11:00"
  venue: string;          // max 100 chars
  classType: string;      // "lecture", "tutorial", "lab", max 20 chars
}
```

**Response: `201 Created`** — returns the created schedule.

---

## Notes for Developers

- `CourseType` determines scope: `GENERAL` = GST (university-wide), `FACULTY` = shared across departments in a faculty, `DEPARTMENTAL` = owned by one department, `ELECTIVE` = optional.
- When `owningDepartmentId` is `null`, the course is university-wide (e.g. GST courses).
- `CourseOffering` has a unique constraint on `[courseId, semesterId]` — a course can only be offered once per semester.
- GST lecturer-to-student-group routing (assigning which lecturer handles which departments' students) is handled at the **application layer**, not in the schema.
- Class schedules are per offering+lecturer. Check for time/venue conflicts in the service layer.
