# Course Module — Course Offering response enrichment

> **Audience:** Backend developer (qhub_backend_api).
> **Status:** Both frontend consumer paths for `GET /courses/offerings` are already built
> against the enriched shape below, via one shared mapper
> (`src/lib/academic/course-offering-enrichment.ts`):
>
> - `@/services/usersApi` → tutor course-assignment panel (`admin/users/tutors` → "Manage
>   Courses") and the tutor "My Assigned Courses" page (`/tutor/courses`)
> - `@/services/courseOfferingApi` → admin Offerings manager (`academics` → course
>   management), the bulk-grade offering picker, and the offering lookups used by the
>   timetable and enrollment services
>
> Until the backend ships this, every screen degrades gracefully — each new field is read
> defensively (`?.` + `?? null` / `?? []`), the mapper falls back to `GET /academic-calendar`
> for the term names, and the UI hides the parts that aren't there yet (credit units,
> category breadcrumb, programme chips). Nothing 404s.
>
> This supersedes the two older, narrower asks about this same endpoint in
> `sandbox/MISSING_BACKEND_APIS.md` (§2.10 `enrolledCount`, and §"Course Offering — lecturerId
> filter") — both are folded into the single response shape here.

---

## Why

`GET /courses/offerings` currently returns (per `course_README.md`):

```ts
{
  id, courseId, academicSessionId, semesterId, maxCapacity, status,
  createdAt, updatedAt,
  course: { code: string; title: string }
}
```

Every screen that lists offerings has to render more than "code — title":

| Field needed | Where it's shown | Currently |
| ------------ | ---------------- | --------- |
| `course.creditUnits` | Course cards, "total credits" tallies, assign dialog | Not returned — shown blank / omitted |
| `session.name`, `semester.name` | "First Semester, 2025/2026" line on every offering | Only ids returned — frontend does a second `GET /academic-calendar` call to resolve names, and only for the *active* term |
| Programme(s) the course belongs to | "Which programmes will see this course" — real registrar need when assigning a tutor | Not returned at all |
| Department / Faculty | Grouping & filtering tutors' courses by faculty | Not returned |
| Academic category path (Faculty › Department › Programme › Level) | Breadcrumb on the course card; matches the Moodle category tree | Not returned |
| `enrolledCount` | "X students registered" | §2.10 — may already be shipped, included here for completeness |

The second `GET /academic-calendar` round-trip the frontend does today is a workaround, not a
design choice — it can't name a *past* session/semester, and it's an extra request per screen.

---

## Enriched response — `GET /courses/offerings` (list) and `GET /courses/offerings/:id`

Every offering object (in the `data[]` array for the list, or the single object for `:id`):

```ts
{
  id: number;
  courseId: number;
  academicSessionId: number;
  semesterId: number;
  maxCapacity: number | null;
  enrolledCount: number;                 // count of StudentEnrollment rows for this offering
  status: "PLANNED" | "OPEN" | "CLOSED" | "CANCELLED";
  createdAt: string;
  updatedAt: string;

  // ── NEW: term display names (not just ids) ──────────────────────────────
  session: { id: number; name: string };      // AcademicSession, e.g. "2025/2026"
  semester: { id: number; name: string };     // Semester, e.g. "First Semester"

  course: {
    id: number;
    code: string;
    title: string;
    creditUnits: number;                                              // NEW
    courseType: "GENERAL" | "FACULTY" | "DEPARTMENTAL" | "ELECTIVE";   // NEW
    level: { id: number; name: string; numericValue: number };        // NEW — from Course.levelId

    // NEW — the department that owns the course, with its faculty.
    // null for university-wide courses (GST etc. — Course.owningDepartmentId is null).
    owningDepartment: {
      id: number;
      name: string;
      code: string;
      faculty: { id: number; name: string; code: string };
    } | null;

    // NEW — every programme this course is mapped to (ProgramCourse), with
    // whether it's required/elective for that programme and that programme's
    // own department → faculty chain. Empty array if not yet mapped to any.
    programs: {
      id: number;
      name: string;
      code: string;
      degreeType: string;          // "B.Sc", "B.Eng", …
      isRequired: boolean;         // ProgramCourse.isRequired
      department: { id: number; name: string; code: string };
      faculty: { id: number; name: string; code: string };
    }[];

    // NEW — the academic "category tree" this course sits in, root → leaf.
    // Mirrors the Faculty → Department → Programme → Level nesting that
    // MoodleSyncCategory tracks (`entityType` uses the same enum). When the
    // course has an owningDepartment, the path is
    //   [faculty, department, level]
    // For a university-wide course with no owningDepartment, fall back to
    //   [level]
    // `moodleCategoryId` is the mapped Moodle category once that node has been
    // pushed (MoodleSyncCategory.moodleCategoryId), null otherwise.
    categoryPath: {
      entityType: "faculty" | "department" | "program" | "level";
      entityId: number;
      name: string;
      moodleCategoryId: number | null;
    }[];
  };

  // ── Only on GET /courses/offerings?lecturerId=<lecturerId> ──────────────
  // (the per-lecturer filtered list — supersedes MISSING_BACKEND_APIS.md
  //  §"Course Offering — lecturerId filter")
  role?: "primary" | "assistant" | "tutorial";   // CourseOfferingLecturer.role for that lecturer
  assignedAt?: string;                            // CourseOfferingLecturer.createdAt
}
```

### The `?lecturerId=` filter

`GET /courses/offerings?lecturerId=<Lecturer.id>&semesterId=&sessionId=`

- Filters the list to offerings that lecturer is assigned to (via `CourseOfferingLecturer`).
- Adds `role` + `assignedAt` to each item, populated from that join row.
- `lecturerId` is the **`Lecturer` record's id**, not the underlying `User.id`.
- Without `lecturerId`, behaves exactly as today (all offerings, optionally
  session/semester-filtered, no `role`/`assignedAt`).

### List envelope

```ts
// GET /courses/offerings
{ data: Offering[] }          // add `meta: { total, page, limit }` if this list is paginated;
                              // the frontend handles both { data } and { data, meta }.
```

---

## Notes for the backend team

- All new fields are **additive** — no request-shape or existing-field changes. A client that
  ignores them keeps working.
- `session`/`semester`/`course.level`/`course.creditUnits`/`course.courseType` are cheap
  eager-loads on relations that already exist (`CourseOffering.academicSessionId`,
  `.semesterId`, `Course.levelId`).
- `course.programs` comes from `ProgramCourse` → `Program` → `Department` → `Faculty`.
- `course.owningDepartment` is `Course.owningDepartmentId` → `Department` → `Faculty`.
- `course.categoryPath` is a small computed helper — it's the same faculty/department/level
  chain, just pre-ordered root→leaf with `MoodleSyncCategory.moodleCategoryId` joined in so the
  frontend can render one breadcrumb without walking three relations itself.
- When this ships, please update `bruno/course/Offering - List.bru` / `Offering - Get.bru` and
  the `GET /courses/offerings` response block in `course_README.md` so bruno stays the source
  of truth.
