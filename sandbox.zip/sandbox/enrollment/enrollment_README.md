# Enrollment Module

Manages student course enrollment and attendance tracking.

## Models Owned

- **StudentEnrollment** — student enrollment in a course offering for a semester
- **Attendance** — per-student, per-class-schedule attendance records

---

## Endpoints

### Enrollments

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/enrollments` | List enrollments (filterable by semester, student, offering) | Admin, Staff |
| `GET` | `/enrollments/:id` | Get enrollment details | Admin, Staff, Self |
| `GET` | `/enrollments/student/:studentId` | List all enrollments for a student | Admin, Staff, Self |
| `GET` | `/enrollments/offering/:offeringId` | List students enrolled in an offering | Admin, Lecturer |
| `POST` | `/enrollments` | Enroll a student in a course offering | Admin, Student (self) |
| `POST` | `/enrollments/bulk` | Bulk enroll students in multiple offerings | Admin |
| `PATCH` | `/enrollments/:id/drop` | Drop/withdraw from a course | Admin, Student (self) |

### Attendance

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/enrollments/attendance/schedule/:scheduleId` | Get attendance for a class date | Lecturer, Admin |
| `GET` | `/enrollments/attendance/student/:studentId` | Get a student's attendance records | Admin, Student (self) |
| `POST` | `/enrollments/attendance` | Record attendance for a class | Lecturer |
| `POST` | `/enrollments/attendance/bulk` | Record bulk attendance for a class | Lecturer |
| `PATCH` | `/enrollments/attendance/:id` | Update an attendance record | Lecturer |

---

## Request & Response Types

### `POST /enrollments`

**Request Body (`CreateEnrollmentDto`):**

```ts
{
  studentId: number;
  offeringId: number;
  semesterId: number;
}
```

**Response: `201 Created`**

```ts
{
  id: number;
  studentId: number;
  offeringId: number;
  semesterId: number;
  status: "ENROLLED";
  enrolledAt: string;
  createdAt: string;
  offering: {
    id: number;
    course: { code: string; title: string; creditUnits: number };
  };
}
```

---

### `POST /enrollments/bulk`

**Request Body (`BulkEnrollDto`):**

```ts
{
  studentId: number;
  offeringIds: number[];
  semesterId: number;
}
```

**Response: `201 Created`**

```ts
{
  enrolled: { id: number; offeringId: number; status: string }[];
  errors: { offeringId: number; message: string }[];
}
```

---

### `PATCH /enrollments/:id/drop`

**Request Body (`DropEnrollmentDto`):**

```ts
{
  reason?: string;
}
```

**Response: `200 OK`**

```ts
{
  id: number;
  status: "DROPPED" | "WITHDRAWN";
  droppedAt: string;
}
```

---

### `POST /enrollments/attendance`

**Request Body (`RecordAttendanceDto`):**

```ts
{
  studentId: number;
  scheduleId: number;
  attendanceDate: string;        // ISO 8601 date
  status: string;                // "present", "absent", "late", "excused"
  remarks?: string;
}
```

**Response: `201 Created`** — returns the attendance record.

---

### `POST /enrollments/attendance/bulk`

**Request Body (`BulkAttendanceDto`):**

```ts
{
  scheduleId: number;
  attendanceDate: string;
  records: {
    studentId: number;
    status: string;              // "present", "absent", "late", "excused"
    remarks?: string;
  }[];
}
```

**Response: `201 Created`**

```ts
{
  recorded: number;   // count of records created
  errors: { studentId: number; message: string }[];
}
```

---

### `GET /enrollments/student/:studentId`

**Query Parameters:**

```ts
{
  semesterId?: number;
  status?: "ENROLLED" | "DROPPED" | "WITHDRAWN";
}
```

**Response: `200 OK`**

```ts
{
  data: {
    id: number;
    offeringId: number;
    semesterId: number;
    status: string;
    enrolledAt: string;
    droppedAt: string | null;
    offering: {
      course: { code: string; title: string; creditUnits: number };
      lecturers: { lecturer: { staffNumber: string; user: { firstName: string; lastName: string } } }[];
    };
  }[];
}
```

---

## Notes for Developers

- A student can only enroll in an offering once (`@@unique([studentId, offeringId])`).
- Attendance has a unique constraint on `[studentId, scheduleId, attendanceDate]` — one record per student per class per day.
- Validate prerequisites before enrollment: check that the student has a passing grade in all prerequisite courses.
- Validate that the offering status is `OPEN` before allowing enrollment.
- Check max capacity on the offering — reject enrollment if full.
- Dropping a course should set `status = DROPPED` and `droppedAt = now()`. Withdrawal may have a different policy.
- Registration window: check `semester.registrationStart` and `semester.registrationEnd` before allowing enrollment.
- **Moodle sync**: Each `StudentEnrollment` has an optional `MoodleSyncEnrollment` relation. When a student's tuition payment is verified, the `MoodleSyncModule` automatically creates Moodle enrollments for all their selected courses. Manual enrollment changes (drop/withdraw) should also propagate to Moodle via the sync module.
