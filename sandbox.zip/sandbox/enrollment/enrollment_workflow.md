# Enrollment Module — Implementation Workflow

This document explains the internal implementation flow for the Enrollment module. It is intended for developers building or maintaining this module.

---

## Module Dependencies

```
EnrollmentModule
├── PrismaService          (database access)
├── CourseModule            (offering lookup, capacity, prerequisite checks)
├── AcademicModule          (active semester, registration window)
├── AuditModule             (log enrollment events)
└── MoodleSyncModule        (trigger enrollment sync to Moodle LMS)
```

---

## 1. Student Enrollment Flow

**Endpoint:** `POST /enrollments`

```
Student or admin initiates enrollment
         │
         ▼
┌──────────────────────────────────────────────────┐
│  EnrollmentService.enrollStudent(dto)             │
│                                                  │
│  Validation Chain:                               │
│  ┌────────────────────────────────────────────┐  │
│  │ 1. Verify student exists and is ACTIVE     │  │
│  │    - Not ACTIVE → 400                      │  │
│  │                                            │  │
│  │ 2. Verify offering exists                  │  │
│  │    - Not found → 404                       │  │
│  │                                            │  │
│  │ 3. Check offering status == "OPEN"         │  │
│  │    - Not OPEN → 400 "Enrollment closed"    │  │
│  │                                            │  │
│  │ 4. Check registration window:              │  │
│  │    semester.registrationStart ≤ now         │  │
│  │    ≤ semester.registrationEnd              │  │
│  │    - Outside window → 400                  │  │
│  │                                            │  │
│  │ 5. Check duplicate enrollment:             │  │
│  │    @@unique([studentId, offeringId])        │  │
│  │    - Already enrolled → 409                │  │
│  │                                            │  │
│  │ 6. Check max capacity:                     │  │
│  │    - Count current ENROLLED for offering   │  │
│  │    - >= maxCapacity → 400 "Course full"    │  │
│  │                                            │  │
│  │ 7. Check prerequisites:                    │  │
│  │    - Call CourseService.checkPrerequisites  │  │
│  │    - Not met → 400 "Prerequisites not met" │  │
│  └────────────────────────────────────────────┘  │
│                                                  │
│  Create:                                         │
│  ┌────────────────────────────────────────────┐  │
│  │ - StudentEnrollment record                 │  │
│  │   status: ENROLLED                         │  │
│  │   enrolledAt: now                          │  │
│  └────────────────────────────────────────────┘  │
│                                                  │
│  Post-enrollment:                                │
│  - Trigger MoodleModule enrollment sync          │
│  - Log via AuditService (action: "ENROLL")       │
│  - Return enrollment with course details         │
└──────────────────────────────────────────────────┘
```

---

## 2. Bulk Enrollment Flow

**Endpoint:** `POST /enrollments/bulk`

```
Student enrolls in multiple courses at once
         │
         ▼
┌──────────────────────────────────────────────────┐
│  EnrollmentService.bulkEnroll(dto)               │
│  1. For each offeringId in dto.offeringIds:      │
│     - Run the same validation chain as above     │
│     - On success → add to "enrolled" list        │
│     - On failure → add to "errors" list          │
│     (continue processing remaining, don't abort) │
│  2. Return:                                      │
│     { enrolled: [...], errors: [...] }           │
│                                                  │
│  NOTE: Each enrollment is independent.           │
│  If one fails, others still proceed.             │
└──────────────────────────────────────────────────┘
```

**Credit unit validation (optional but recommended):**

```ts
// Total credit units for the semester should not exceed max (e.g. 24)
const currentCredits = await this.getStudentSemesterCredits(studentId, semesterId);
const courseCredits = offering.course.creditUnits;
if (currentCredits + courseCredits > MAX_CREDIT_UNITS_PER_SEMESTER) {
  throw new BadRequestException('Maximum credit units exceeded');
}
```

---

## 3. Drop/Withdraw Course

**Endpoint:** `PATCH /enrollments/:id/drop`

```
Student or admin drops a course
         │
         ▼
┌──────────────────────────────────────────────────┐
│  EnrollmentService.dropCourse(id, dto)           │
│  1. Find enrollment by ID                        │
│     - Not found → 404                            │
│  2. Check current status == "ENROLLED"           │
│     - Already DROPPED/WITHDRAWN → 400            │
│  3. Determine drop type:                         │
│     - Within registration window → DROPPED       │
│       (no academic penalty)                      │
│     - After window → WITHDRAWN                   │
│       (may appear on transcript)                 │
│  4. Update enrollment:                           │
│     - status: DROPPED or WITHDRAWN               │
│     - droppedAt: now                             │
│  5. Trigger Moodle un-enrollment (if synced)     │
│  6. Log via AuditService                         │
└──────────────────────────────────────────────────┘
```

---

## 4. Attendance Recording Flow

**Endpoint:** `POST /enrollments/attendance`

```
Lecturer records attendance for a class
         │
         ▼
┌──────────────────────────────────────────────────┐
│  EnrollmentService.recordAttendance(dto)         │
│  1. Verify scheduleId exists                     │
│  2. Verify studentId is enrolled in the          │
│     offering that this schedule belongs to       │
│     - Not enrolled → 400                         │
│  3. Check unique constraint:                     │
│     [studentId, scheduleId, attendanceDate]       │
│     - Duplicate → 409                            │
│  4. Create Attendance record:                    │
│     - status: present/absent/late/excused        │
│     - remarks (optional)                         │
│  5. Return created record                        │
└──────────────────────────────────────────────────┘
```

### Bulk Attendance (more common)

```
Lecturer submits attendance for entire class at once
         │
         ▼
┌──────────────────────────────────────────────────┐
│  EnrollmentService.recordBulkAttendance(dto)     │
│  1. Validate schedule exists                     │
│  2. For each student in dto.records:             │
│     - Verify student is enrolled                 │
│     - Check for duplicate attendance record      │
│     - Create or skip                             │
│  3. Return { recorded: count, errors: [...] }    │
└──────────────────────────────────────────────────┘
```

---

## 5. Enrollment Status Machine

```
ENROLLED ──▶ DROPPED     (within registration window, no penalty)
         ──▶ WITHDRAWN   (after window, appears on transcript)
         ──▶ COMPLETED   (semester ends, grade assigned — set by Result Module)
```

---

## 6. Attendance Summary (for display)

```ts
// Calculate attendance percentage for a student in a course
async getAttendancePercentage(
  studentId: number, offeringId: number
): Promise<number> {
  const schedules = await this.prisma.classSchedule.findMany({
    where: { offeringId },
  });

  const totalClasses = await this.prisma.attendance.count({
    where: {
      studentId,
      scheduleId: { in: schedules.map(s => s.id) },
    },
  });

  const presentClasses = await this.prisma.attendance.count({
    where: {
      studentId,
      scheduleId: { in: schedules.map(s => s.id) },
      status: { in: ['present', 'late'] },
    },
  });

  return totalClasses > 0
    ? Math.round((presentClasses / totalClasses) * 100)
    : 0;
}
```

---

## 7. Files to Create

```
src/modules/enrollment/
├── enrollment.module.ts
├── enrollment.controller.ts      # Enrollment + attendance routes
├── enrollment.service.ts         # Business logic
├── dto/
│   ├── create-enrollment.dto.ts
│   ├── bulk-enroll.dto.ts
│   ├── drop-enrollment.dto.ts
│   ├── record-attendance.dto.ts
│   ├── bulk-attendance.dto.ts
│   └── query-enrollment.dto.ts
└── enrollment.service.spec.ts
```

---

## 8. Cross-Module Integration Points

| Direction | Module | Interaction |
| --------- | ------ | ----------- |
| **Consumes** | CourseModule | Offering lookup, capacity, prerequisites |
| **Consumes** | AcademicModule | Active semester, registration window |
| **Consumes** | MoodleModule | Trigger enrollment sync |
| **Consumed by** | ResultModule | Enrollment lookup for grade entry |
| **Consumed by** | AttendanceReports | Attendance percentage calculation |
