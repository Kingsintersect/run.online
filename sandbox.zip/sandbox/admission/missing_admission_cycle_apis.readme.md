# Admission Module — Missing "Admission Cycle" (Open/Close Admissions) Feature

> **Audience:** Backend developer (qhub_backend_api).
> **Status (2026-08-21):** The frontend has a fully-built admin/manager screen — "Admissions
> Management" at `admin/academics/admissions` and `manager/academics/admissions` — for opening
> and closing admissions per academic session, setting an application window, a
> late-application fee, a maximum applicant cap, required-document lists, and per-program entry
> requirements (min/max age, min credit units, required subjects). **The in-memory mock has now
> been removed** — `src/services/admissionSetupApi.ts` calls the exact endpoints specified below
> (`/admissions/cycles`, `/admissions/cycles/:id`, `/admissions/cycles/:id/status`,
> `/admissions/cycles/:cycleId/requirements`, `/admissions/cycles/requirements/:id`) and maps
> their responses onto the frontend's existing types. **These endpoints don't exist yet, so the
> screen currently 404s on every request** — this is now a blocking gap, not a cosmetic one.
> Once built exactly per the schema/endpoints/response shapes below, the frontend needs no
> further changes.

---

## Background

`sandbox/schema.prisma` was audited end-to-end for anything resembling an admission
window/cycle concept and **there is none**. `AdmissionApplication` links directly to
`AcademicSession` via `sessionId`, with no gating concept anywhere — today, per
`admission_workflow.md`, the only checks `POST /admissions/applications` performs are (1)
the application fee is paid, and (2) the user doesn't already have an application. There is
no way today to actually **close** admissions for a session, cap how many applications it
accepts, or require session/program-specific documents beyond what's hardcoded in the form.

This is a real, needed feature — "open and close admission for every session" — not a
fabricated one; it just needs a real backing model. It's genuinely new, additive work: no
existing table needs to change.

---

## Proposed Schema

Two new models, both scoped under the existing Admission module section of the schema:

```prisma
model AdmissionCycle {
  id                    Int       @id @default(autoincrement())
  sessionId             Int       @map("session_id")
  status                AdmissionCycleStatus @default(DRAFT)
  applicationStartDate  DateTime  @map("application_start_date")
  applicationEndDate    DateTime? @map("application_end_date") // null = no deadline
  lateApplicationAllowed Boolean  @default(false) @map("late_application_allowed")
  lateApplicationFee    Decimal?  @db.Decimal(10, 2) @map("late_application_fee")
  maxApplications       Int       @default(0) @map("max_applications") // 0 = unlimited
  requireDocuments      Boolean   @default(true) @map("require_documents")
  requiredDocuments     Json?     @map("required_documents") // string[], e.g. ["O'Level Result"]
  notificationEmail     String?   @db.VarChar(255) @map("notification_email")
  instructions          String?   @db.Text
  createdAt             DateTime  @default(now()) @map("created_at")
  updatedAt             DateTime  @updatedAt @map("updated_at")

  // Relations
  session      AcademicSession        @relation(fields: [sessionId], references: [id])
  requirements AdmissionCycleRequirement[]

  @@index([sessionId])
  @@index([status])
  @@map("admission_cycles")
}

enum AdmissionCycleStatus {
  DRAFT
  OPEN
  CLOSED
}

model AdmissionCycleRequirement {
  id               Int      @id @default(autoincrement())
  admissionCycleId Int      @map("admission_cycle_id")
  programId        Int?     @map("program_id") // null = applies to all programs in the cycle
  minAge           Int      @default(0) @map("min_age") // 0 = no minimum
  maxAge           Int      @default(0) @map("max_age") // 0 = no maximum
  minCredits       Int      @default(5) @map("min_credits")
  requiredSubjects Json?    @map("required_subjects") // string[]
  description      String?  @db.Text
  createdAt        DateTime @default(now()) @map("created_at")

  // Relations
  cycle   AdmissionCycle @relation(fields: [admissionCycleId], references: [id], onDelete: Cascade)
  program Program?       @relation(fields: [programId], references: [id])

  @@index([admissionCycleId])
  @@index([programId])
  @@map("admission_cycle_requirements")
}
```

Also add the inverse relations:
- `AcademicSession.admissionCycles AdmissionCycle[]`
- `Program.cycleRequirements AdmissionCycleRequirement[]`

A session can have more than one cycle (e.g. a UG cycle and a PG cycle in the same session) —
the frontend already lists cycles per session as an array, not a single record, so no
uniqueness constraint on `sessionId` alone.

---

## Endpoints

Mirrors the CRUD shape the frontend's dummy service already assumes, adjusted to this
backend's real conventions (`{data: ...}` envelope, camelCase, numeric ids):

| Method | Endpoint | Description | Auth |
| --- | --- | --- | --- |
| `GET` | `/admissions/cycles?sessionId=:id` | List cycles for a session | Admin, Staff |
| `GET` | `/admissions/cycles/:id` | Get a single cycle | Admin, Staff |
| `POST` | `/admissions/cycles` | Create a cycle (defaults to `DRAFT`) | Admin |
| `PATCH` | `/admissions/cycles/:id` | Update a cycle's settings | Admin |
| `PATCH` | `/admissions/cycles/:id/status` | `{ status: "DRAFT" \| "OPEN" \| "CLOSED" }` — dedicated status toggle | Admin |
| `DELETE` | `/admissions/cycles/:id` | Delete a cycle (only if it has no applications tied to its session/program combination — see enforcement note below) | Admin |
| `GET` | `/admissions/cycles/:cycleId/requirements` | List a cycle's requirements | Admin, Staff |
| `POST` | `/admissions/cycles/:cycleId/requirements` | Create a requirement | Admin |
| `DELETE` | `/admissions/cycles/requirements/:id` | Delete a requirement | Admin |

### `POST /admissions/cycles` request body (`CreateAdmissionCycleDto`)

```ts
{
  sessionId: number;
  applicationStartDate: string;       // ISO date
  applicationEndDate?: string;        // ISO date, omit for no deadline
  lateApplicationAllowed?: boolean;   // default false
  lateApplicationFee?: number;        // required if lateApplicationAllowed
  maxApplications?: number;           // default 0 (unlimited)
  requireDocuments?: boolean;         // default true
  requiredDocuments?: string[];
  notificationEmail?: string;
  instructions?: string;
}
```

`PATCH /admissions/cycles/:id` accepts the same shape, all fields optional (minus `sessionId`,
which shouldn't be changeable after creation — matches how `facultyId`/`departmentId` are
immutable post-creation elsewhere in this API).

### `POST /admissions/cycles/:cycleId/requirements` request body

```ts
{
  programId?: number;        // omit or null = applies to every program in the cycle
  minAge?: number;           // default 0
  maxAge?: number;           // default 0
  minCredits?: number;       // default 5
  requiredSubjects?: string[];
  description?: string;
}
```

### Every cycle response

```ts
{
  id: number;
  sessionId: number;
  status: "DRAFT" | "OPEN" | "CLOSED";
  applicationStartDate: string;
  applicationEndDate: string | null;
  lateApplicationAllowed: boolean;
  lateApplicationFee: number | null;
  maxApplications: number;
  requireDocuments: boolean;
  requiredDocuments: string[] | null;
  notificationEmail: string | null;
  instructions: string | null;
  createdAt: string;
  updatedAt: string;
}
```

---

## Enforcement: wiring this into `POST /admissions/applications`

This is the actual point of the feature — right now nothing stops an application from being
submitted regardless of any cycle's status. Once `AdmissionCycle` exists,
`AdmissionService::submitApplication()` should add these checks, in addition to the existing
application-fee-paid and no-duplicate-application checks in `admission_workflow.md` §1:

1. Find an `AdmissionCycle` where `sessionId = dto.sessionId` and `status = "OPEN"`. If none
   exists → `403 "Admissions are not currently open for this session."`
2. If `applicationEndDate` is set and has passed:
   - If `lateApplicationAllowed` is `false` → `403 "The application deadline for this session has passed."`
   - If `true` → allow, but the caller should be charged `lateApplicationFee` in addition to
     the normal application fee (exact mechanism — e.g. a second invoice line, or added to the
     application-fee invoice amount — is left to the backend team's judgement; the frontend
     doesn't yet have UI for this billing side, only the cycle-config side).
3. If `maxApplications > 0`, count existing `AdmissionApplication` rows for that `sessionId`
   and reject with `403 "This session has reached its application capacity."` once the count
   is met.
4. If an `AdmissionCycleRequirement` exists for `(cycle.id, dto.programId)` or
   `(cycle.id, programId: null)` (program-specific takes precedence over the all-programs
   one), validate the applicant's age (derived from `dob`) against `minAge`/`maxAge` (`0` =
   no bound) and reject with a `400` listing which requirement failed if not met.
   `minCredits`/`requiredSubjects` validation against the applicant's declared exam sittings
   is best-effort — flag rather than hard-block if the data is ambiguous, since Steps 5-6 of
   the form don't structurally separate "subjects passed" from the raw exam-sitting fields
   today.

---

## Notes

- `DELETE /admissions/cycles/:id` should probably soft-fail or 409 if any
  `AdmissionApplication` already references its `sessionId` while that cycle was the only
  `OPEN` one for that session — exact guard is a backend judgement call; not enforced by the
  current mock frontend (which allows unconditional delete), but worth adding for real data
  integrity.
- Field mapping from the current frontend mock (`AdmissionCycle` type in
  `src/types/school.d.ts`) is 1:1 once ids become numeric — `academic_session_id` →
  `sessionId`, `application_start_date` → `applicationStartDate`, etc. The frontend service
  layer (`src/services/admissionSetupApi.ts`) will be updated to match this doc's real
  camelCase/numeric contract once these endpoints ship; no further frontend field renaming
  should be needed beyond that.
- Once built, please add corresponding `.bru` files under `bruno/admission/` documenting the
  real request/response shapes, per this collection's existing convention.
