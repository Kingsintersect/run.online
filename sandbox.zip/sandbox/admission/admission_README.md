# Admission Module

Manages the entire admission lifecycle: application fee payment, multi-step application form submission (submitted as a single request with files), document uploads, application review, admission offers, acceptance fee, and tuition payment leading to student record creation.

## Models Owned

- **AdmissionApplication** — applicant data, academic background, and review status (linked to authenticated user)
- **ApplicationDocument** — uploaded documents for an application
- **Admission** — the formal admission offer linked to an accepted application

---

## Complete Admission Flow

```
1. User registers (Auth Module)            → User record created
2. User pays ₦10,000 application fee        → Invoice (userId) created & paid
3. User fills 8-step application form      → AdmissionApplication (userId) created
4. Admin reviews application               → SUBMITTED → UNDER_REVIEW → ADMITTED / REJECTED
5. Admin creates admission offer           → Admission record (OFFERED)
6. Applicant accepts offer                 → Admission status = ACCEPTED
7. Applicant pays ₦30,000 acceptance fee    → Invoice (userId) created & paid
8. Applicant pays ₦195,000 tuition          → Invoice (userId) created & paid (installments supported)
9. Payment verified                        → Student record auto-created (Payment Module triggers)
```

> **Important:** The application form (`POST /admissions/applications`) is only accessible after the application fee is verified as paid. The backend must check the user's application fee invoice status before allowing form submission.

---

## Endpoints

### Applications

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/admissions/applications` | List applications (filterable by session, status, program) | Admin, Staff |
| `GET` | `/admissions/applications/:id` | Get application details with documents | Admin, Staff, Self |
| `POST` | `/admissions/applications` | Submit a complete application (multipart/form-data) | Authenticated (application fee must be paid) |
| `PATCH` | `/admissions/applications/:id` | Update application (only if SUBMITTED) | Authenticated (applicant) |
| `GET` | `/admissions/applications/track/:applicationNumber` | Track application status | Public |
| `GET` | `/admissions/applications/my` | Get current user's application | Authenticated |

### Application Documents (standalone)

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/admissions/applications/:applicationId/documents` | List documents for an application | Admin, Staff |
| `POST` | `/admissions/applications/:applicationId/documents` | **NOT YET IMPLEMENTED — required, see "Frontend Contract Changes Required" below.** Add a new document to an existing application | Authenticated (applicant, own application) |
| `PATCH` | `/admissions/applications/:applicationId/documents/:docId` | **NOT YET IMPLEMENTED — required, see "Frontend Contract Changes Required" below.** Replace a document's file | Authenticated (applicant, own application) |
| `DELETE` | `/admissions/applications/:applicationId/documents/:docId` | Delete a document | Authenticated (applicant, own application) — **corrected from "Public"; see note below** |

### Application Review

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `PATCH` | `/admissions/applications/:id/review` | Review an application (admit/reject) | Admin, Staff |
| `POST` | `/admissions/applications/bulk-review` | Bulk review applications | Admin |

### Admissions

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/admissions` | List all admissions (filterable by session, status, program) | Admin |
| `GET` | `/admissions/:id` | Get admission details | Admin |
| `POST` | `/admissions` | Create an admission offer from an application | Admin |
| `POST` | `/admissions/bulk` | Bulk create admission offers | Admin |
| `PATCH` | `/admissions/:id/accept` | Accept an admission offer | Authenticated (applicant) |
| `PATCH` | `/admissions/:id/decline` | Decline an admission offer | Authenticated (applicant) |

---

## Frontend Multi-Step Form → Single Submission

The frontend presents an 8-step form, but all data (including files) is submitted as **one `multipart/form-data` request** to `POST /admissions/applications` after the applicant completes all steps.

### Form Steps Overview

| Step | Name | Fields |
| ---- | ---- | ------ |
| 1 | Personal Information | lga, religion, dob, gender, hometown, addresses, disability |
| 2 | Sponsor Information | conditional sponsor details (if `has_sponsor = true`) |
| 3 | Next of Kin | name, relationship, phone, address, email, occupation |
| 4 | Documents | passport, first_school_leaving, o_level, other_documents |
| 5 | Qualification Fields | combined_result type, awaiting_result flag |
| 6 | Exam Sitting | first/second sitting type, year, exam number |
| 7 | Qualification Documents | first_sitting_result, second_sitting_result (files) |
| 8 | Program Selection | startTerm, studyMode, agreeToTerms |

---

## Request & Response Types

### `POST /admissions/applications`

**Request: `multipart/form-data`**

The entire application (text fields + files) is submitted in one request.

**Text Fields (`CreateApplicationDto`):**

```ts
{
  // ─── Step 1: Personal Information ──────────────────────────────────
  lga: string;                          // Local Government Area
  religion: "Christianity" | "Islam" | "Traditional" | "Other";
  dob: string;                          // ISO 8601 date (date of birth)
  gender: "MALE" | "FEMALE";
  hometown: string;
  hometown_address: string;             // min ~10 chars
  contact_address: string;              // min ~10 chars
  has_disability: boolean;              // default false
  disability?: string;                  // required if has_disability=true, describe the disability

  // ─── Step 2: Sponsor Information (conditional) ─────────────────────
  has_sponsor: boolean;                 // default false
  sponsor_name?: string;               // required if has_sponsor=true
  sponsor_relationship?: string;       // required if has_sponsor=true
  sponsor_email?: string;              // valid email, required if has_sponsor=true
  sponsor_contact_address?: string;    // min 10 chars, required if has_sponsor=true
  sponsor_phone_number?: string;       // min 10 chars, required if has_sponsor=true

  // ─── Step 3: Next of Kin ───────────────────────────────────────────
  next_of_kin_name: string;             // full name
  next_of_kin_relationship: "Parent" | "Sibling" | "Spouse" | "Guardian" | "Uncle" | "Aunt" | "Other";
  next_of_kin_phone_number: string;     // valid phone
  next_of_kin_address: string;          // min ~10 chars
  next_of_kin_email?: string;           // optional, valid email
  is_next_of_kin_primary_contact?: boolean;  // default false
  next_of_kin_alternate_phone_number?: string;
  next_of_kin_occupation?: string;
  next_of_kin_workplace?: string;

  // ─── Step 5: Qualification Fields ──────────────────────────────────
  combined_result?: "single_result" | "combined_result" | "";
  // required if awaiting_result=false
  awaiting_result: boolean;             // default false

  // ─── Step 6: Exam Sitting ──────────────────────────────────────────
  // Required if awaiting_result=false
  first_sitting_type?: string;          // "WAEC" | "NECO" | "NABTEB" | "GCE"
  first_sitting_year?: string;          // e.g. "2023"
  first_sitting_exam_number?: string;
  // Required only if combined_result="combined_result"
  second_sitting_type?: string;         // "WAEC" | "NECO" | "NABTEB" | "GCE"
  second_sitting_year?: string;
  second_sitting_exam_number?: string;

  // ─── Step 8: Program Selection ─────────────────────────────────────
  startTerm: string;                    // selected academic term/session
  studyMode: "online" | "offline";      // default "online"
  agreeToTerms: boolean;                // must be true
}
```

**File Fields (sent as multipart file uploads):**

```ts
{
  // ─── Step 4: Documents ─────────────────────────────────────────────
  passport?: File;                       // passport photograph
  first_school_leaving?: File;           // first school leaving certificate
  o_level?: File;                        // O-Level certificate
  other_documents?: File[];              // additional supporting documents

  // ─── Step 7: Qualification Documents ───────────────────────────────
  first_sitting_result?: File;           // required if awaiting_result=false
  second_sitting_result?: File;          // required if combined_result="combined_result"
}
```

**File Constraints:**

| Constraint | Value |
| ---------- | ----- |
| Max file size | **5 MB** per file |
| Accepted MIME types | `image/jpeg`, `image/jpg`, `image/png`, `image/webp`, `application/pdf`, `application/msword`, `application/vnd.openxmlformats-officedocument.wordprocessingml.document` |

**Response: `201 Created`**

```ts
{
  id: number;
  applicationNumber: string;           // auto-generated (e.g. "APP-2025-00001")
  status: "SUBMITTED";
  // echoed personal info
  gender: string;
  dob: string;
  lga: string;
  hometown: string;
  studyMode: string;
  startTerm: string;
  // documents summary
  documents: {
    id: number;
    documentType: string;
    fileName: string;
    fileSize: number;
  }[];
  createdAt: string;
}
```

---

### Conditional Validation Rules

The backend must enforce the same conditional validation as the frontend:

| Condition | Required Fields |
| --------- | --------------- |
| `has_disability = true` | `disability` must be non-empty and not `"None"` |
| `has_sponsor = true` | `sponsor_name`, `sponsor_relationship`, `sponsor_email` (valid), `sponsor_contact_address` (min 10), `sponsor_phone_number` (min 10) |
| `awaiting_result = false` | `combined_result` must be selected, `first_sitting_type`, `first_sitting_year`, `first_sitting_exam_number`, `first_sitting_result` (file) |
| `combined_result = "combined_result"` | `second_sitting_type`, `second_sitting_year`, `second_sitting_exam_number`, `second_sitting_result` (file) |
| Always | `agreeToTerms` must be `true` |

---

### `GET /admissions/applications/:id`

**Response: `200 OK`**

```ts
{
  id: number;
  applicationNumber: string;
  status: string;
  // Step 1
  lga: string;
  religion: string;
  dob: string;
  gender: string;
  hometown: string;
  hometown_address: string;
  contact_address: string;
  has_disability: boolean;
  disability: string | null;
  // Step 2
  has_sponsor: boolean;
  sponsor_name: string | null;
  sponsor_relationship: string | null;
  sponsor_email: string | null;
  sponsor_contact_address: string | null;
  sponsor_phone_number: string | null;
  // Step 3
  next_of_kin_name: string;
  next_of_kin_relationship: string;
  next_of_kin_phone_number: string;
  next_of_kin_address: string;
  next_of_kin_email: string | null;
  is_next_of_kin_primary_contact: boolean;
  next_of_kin_alternate_phone_number: string | null;
  next_of_kin_occupation: string | null;
  next_of_kin_workplace: string | null;
  // Step 5-6
  combined_result: string | null;
  awaiting_result: boolean;
  first_sitting_type: string | null;
  first_sitting_year: string | null;
  first_sitting_exam_number: string | null;
  second_sitting_type: string | null;
  second_sitting_year: string | null;
  second_sitting_exam_number: string | null;
  // Step 8
  startTerm: string;
  studyMode: string;
  // Documents (Steps 4 & 7)
  documents: {
    id: number;
    documentType: string;   // "passport" | "first_school_leaving" | "o_level" | "other" | "first_sitting_result" | "second_sitting_result"
    fileName: string;
    filePath: string;
    fileSize: number;
    mimeType: string;
    uploadedAt: string;
  }[];
  // Review (if reviewed)
  reviewedBy: number | null;
  reviewedAt: string | null;
  reviewComments: string | null;
  createdAt: string;
  updatedAt: string;
}
```

---

### `PATCH /admissions/applications/:id/review`

**Request Body (`ReviewApplicationDto`):**

```ts
{
  status: "UNDER_REVIEW" | "ADMITTED" | "REJECTED";
  reviewComments?: string;
}
```

**Response: `200 OK`**

```ts
{
  id: number;
  applicationNumber: string;
  status: string;
  reviewedBy: number;
  reviewedAt: string;
  reviewComments: string | null;
}
```

---

### `POST /admissions`

**Request Body (`CreateAdmissionDto`):**

```ts
{
  applicationId: number;
  admissionNumber: string;         // unique, max 30 chars
  programId: number;
  levelId: number;
  sessionId: number;
  admissionDate: string;           // ISO 8601 date
  admissionType: string;           // e.g. "merit", "catchment", max 20 chars
  expiryDate?: string;             // ISO 8601 date
}
```

> **Note:** `matricNumber` is NOT assigned at admission offer time. It is generated when the Student record is created after tuition payment verification.

**Response: `201 Created`** — returns the admission record.

---

### `PATCH /admissions/:id/accept`

Applicant accepts the admission offer. After acceptance, they must pay the acceptance fee (₦30,000) and tuition fee (₦195,000).

**Response: `200 OK`**

```ts
{
  id: number;
  admissionNumber: string;
  status: "ACCEPTED";
  message: "Admission accepted. Please proceed to pay the acceptance fee.";
}
```

---

## Application Workflow

```
SUBMITTED → UNDER_REVIEW → ADMITTED → [Admission Offer Created]
                         ↘ REJECTED
```

## Admission Workflow

```
OFFERED → ACCEPTED → [Pay acceptance fee → Pay tuition → Student record auto-created]
        ↘ DECLINED
        ↘ EXPIRED (auto, if past expiryDate)
```

---

## Document Types Reference

Documents are stored as `ApplicationDocument` records. The `documentType` field identifies the file's purpose:

| documentType | Source Step | Required? |
| ------------ | ---------- | --------- |
| `passport` | Step 4 | Optional |
| `first_school_leaving` | Step 4 | Optional |
| `o_level` | Step 4 | Optional |
| `other` | Step 4 | Optional (array) |
| `first_sitting_result` | Step 7 | Required if `awaiting_result=false` |
| `second_sitting_result` | Step 7 | Required if `combined_result="combined_result"` |

---

## Schema Considerations

The current Prisma `AdmissionApplication` model may need additional columns to store the frontend fields not yet in the schema. Fields to add or map:

| Frontend Field | Prisma Column Suggestion | Notes |
| -------------- | ------------------------ | ----- |
| `hometown` | `hometown` | New column, `VarChar(100)` |
| `hometown_address` | `hometown_address` | New column, `Text` |
| `contact_address` | `contact_address` | New column, `Text` |
| `religion` | `religion` | New column, `VarChar(30)` |
| `has_disability` | `has_disability` | New column, `Boolean` default `false` |
| `disability` | `disability` | New column, `VarChar(200)` nullable |
| `has_sponsor` | `has_sponsor` | New column, `Boolean` default `false` |
| `sponsor_name` | `sponsor_name` | New column, `VarChar(200)` nullable |
| `sponsor_relationship` | `sponsor_relationship` | New column, `VarChar(30)` nullable |
| `sponsor_email` | `sponsor_email` | New column, `VarChar(255)` nullable |
| `sponsor_contact_address` | `sponsor_contact_address` | New column, `Text` nullable |
| `sponsor_phone_number` | `sponsor_phone_number` | New column, `VarChar(20)` nullable |
| `next_of_kin_name` | Reuse `guardian_name` or new column | Map to existing or add new |
| `next_of_kin_relationship` | Reuse `guardian_relationship` or new column | Map to existing or add new |
| `next_of_kin_phone_number` | Reuse `guardian_phone` or new column | Map to existing or add new |
| `next_of_kin_address` | `next_of_kin_address` | New column, `Text` |
| `next_of_kin_email` | `next_of_kin_email` | New column, `VarChar(255)` nullable |
| `is_next_of_kin_primary_contact` | `is_next_of_kin_primary_contact` | New column, `Boolean` default `false` |
| `next_of_kin_alternate_phone_number` | `next_of_kin_alt_phone` | New column, `VarChar(20)` nullable |
| `next_of_kin_occupation` | `next_of_kin_occupation` | New column, `VarChar(100)` nullable |
| `next_of_kin_workplace` | `next_of_kin_workplace` | New column, `VarChar(100)` nullable |
| `combined_result` | `combined_result` | New column, `VarChar(20)` nullable |
| `awaiting_result` | `awaiting_result` | New column, `Boolean` default `false` |
| `first_sitting_type` | `first_sitting_type` | New column, `VarChar(10)` nullable |
| `first_sitting_year` | `first_sitting_year` | New column, `VarChar(4)` nullable |
| `first_sitting_exam_number` | `first_sitting_exam_number` | New column, `VarChar(30)` nullable |
| `second_sitting_type` | `second_sitting_type` | New column, `VarChar(10)` nullable |
| `second_sitting_year` | `second_sitting_year` | New column, `VarChar(4)` nullable |
| `second_sitting_exam_number` | `second_sitting_exam_number` | New column, `VarChar(30)` nullable |
| `startTerm` | `start_term` | New column, `VarChar(30)` |
| `studyMode` | `study_mode` | New column, `VarChar(10)` — `"online"` or `"offline"` |
| `agreeToTerms` | `agreed_to_terms` | New column, `Boolean` |

> **Note:** Existing fields like `guardianName`, `guardianPhone`, `guardianRelationship` can be repurposed for next-of-kin data, or kept alongside if both concepts are needed.

---

## Notes for Developers

- **Authentication required**: The application form endpoint requires an authenticated user. The `userId` is extracted from the JWT token — it is NOT sent in the request body.
- **Payment gate**: Before allowing `POST /admissions/applications`, the backend must verify that the authenticated user has a **PAID** application fee invoice (₦10,000). Return `403` if not paid.
- **Single submission**: The frontend collects data across 8 steps but submits everything in one `multipart/form-data` POST. The backend must parse both text fields and file uploads from the same request.
- **File handling**: Use `@UseInterceptors(FileFieldsInterceptor(...))` or similar to extract named file fields (`passport`, `first_school_leaving`, `o_level`, `first_sitting_result`, `second_sitting_result`) plus an array field (`other_documents`).
- **Conditional validation**: Use `class-validator` conditional decorators (e.g. `@ValidateIf(o => o.has_sponsor)`) to mirror the frontend's `superRefine` logic.
- `applicationNumber` should be auto-generated (e.g. `APP-2025-00001`).
- `Admission` has a unique constraint on `applicationId` — one admission per application.
- **No manual matriculation**: Student records are NOT created via `/admissions/:id/matriculate`. Instead, the Payment Module automatically creates the Student record when tuition payment is verified. The student data (bio-data, program, etc.) is pulled from the `AdmissionApplication` and `Admission` records.
- Documents are stored in object storage. Each file becomes an `ApplicationDocument` row with the appropriate `documentType`.
- `agreeToTerms` is validated but can be stored as a boolean column for audit trail or simply validated and discarded.

---

## ⚠️ Frontend Contract Changes Required (Application Review Module)

The **admission-officer review UI** (`manager/review-applications`, `manager/review-applications/:id`) and the **applicant's self-service edit page** (`student/my-application`) were built against a contract drafted before this backend was finalized. That frontend is now live and is the shape both screens actually use — **the backend needs to adopt it**, not the other way around. This section is the spec for that adoption. It only affects the four endpoints below; every other endpoint in this document is unaffected.

Endpoints in scope: `GET /admissions/applications`, `GET /admissions/applications/:id`, `GET /admissions/applications/my`, `PATCH /admissions/applications/:id`, `PATCH /admissions/applications/:id/review`, plus two new document endpoints.

### 1. Response body shape — nested, not flat

`GET /admissions/applications`, `GET /admissions/applications/:id`, and `GET /admissions/applications/my` must all return the application in this nested shape (TypeScript, exact frontend contract — see `src/types/school.d.ts`):

```ts
interface AdmissionApplication {
  id: string;
  applicant_id: string;              // = current AdmissionApplication.userId
  admission_cycle_id: string;        // = current AdmissionApplication.sessionId (or a dedicated admission-cycle id if one is introduced)
  session: string;                   // e.g. "2025/2026" — AcademicSession.name
  status: ApplicationReviewStatus;   // see enum rename below
  personal_info: ApplicantPersonalInfo;
  academic_records: ApplicantAcademicRecord[];
  program_choice: ApplicantProgramChoice;
  documents: ApplicantDocument[];
  submitted_at: string;              // = current createdAt
  reviewed_at: string | null;
  reviewed_by: string | null;
  denial_reason: string | null;      // = current reviewComments, only when status = "denied"
  created_at: string;
  updated_at: string;
}

interface ApplicantPersonalInfo {
  first_name: string;
  last_name: string;
  middle_name: string;
  date_of_birth: string;             // ISO 8601 date
  gender: "male" | "female" | "other";
  nationality: string;
  state_of_origin: string;
  lga: string;
  phone: string;                     // = current phoneNumber
  email: string;
  address: string;                   // = current contactAddress
  passport_url: string;              // resolved URL of the "passport" ApplicationDocument
}

interface ApplicantAcademicRecord {
  institution: string;
  qualification: string;
  year_obtained: string;
  grade: string;
  certificate_url: string;
}

interface ApplicantDocument {
  id: string;
  name: string;                      // = current fileName
  type: string;                      // = current documentType
  url: string;                       // = current filePath, resolved to a fetchable URL
  uploaded_at: string;                // = current uploadedAt
}

interface ApplicantProgramChoice {
  first_choice_program_id: string;
  first_choice_program_name: string; // resolved from Program
  second_choice_program_id: string;
  second_choice_program_name: string;
  entry_mode: "utme" | "direct_entry" | "transfer"; // lowercase, snake_case version of the current EntryMode enum
  jamb_reg_no: string;                // = current jambRegNumber
  jamb_score: number;                 // = current jambScore
}
```

**`academic_records[]` is a required schema addition, not optional.** The officer review screen and the applicant's self-edit screen both render/edit this as a repeatable list, and there is currently no repeatable "academic record" concept anywhere in the schema — only single first/second exam-sitting fields plus the legacy `previousSchool`/`previousQualification`/`qualifications` fields, none of which support more than one prior qualification. Please add a real one-to-many table and drop/migrate the legacy fields into it:

```prisma
model ApplicationAcademicRecord {
  id            Int                  @id @default(autoincrement())
  applicationId Int                  @map("application_id")
  institution   String               @db.VarChar(200)
  qualification String               @db.VarChar(100)
  yearObtained  String               @map("year_obtained") @db.VarChar(4)
  grade         String               @db.VarChar(50)
  certificateUrl String?             @map("certificate_url")
  createdAt     DateTime             @default(now()) @map("created_at")
  updatedAt     DateTime             @updatedAt @map("updated_at")

  application   AdmissionApplication @relation(fields: [applicationId], references: [id], onDelete: Cascade)

  @@index([applicationId])
  @@map("application_academic_records")
}
```

Add the inverse relation (`academicRecords ApplicationAcademicRecord[]`) to `AdmissionApplication`, and serialize it as `academic_records[]` in every response shape in §1. `POST /admissions/applications` (initial submission) should accept an optional array of these records too, so an applicant can list prior qualifications at submission time, not just after.

### 2. Status enum rename

Rename the `ApplicationStatus` enum values (and the equivalent everywhere they appear in requests/responses — this document, `ReviewApplicationDto`, etc.) to match the frontend's `ApplicationReviewStatus`:

| Current value | New value |
| --- | --- |
| `SUBMITTED` | `pending` |
| `UNDER_REVIEW` | `under_review` |
| `ADMITTED` | `approved` |
| `REJECTED` | `denied` |

### 3. `PATCH /admissions/applications/:id/review` — payload rename + relaxed transition rule

**New request body (`ReviewApplicationDto`):**

```ts
{
  status: "approved" | "denied";
  denial_reason?: string;   // renamed from reviewComments; required when status = "denied"
}
```

**Transition rule change:** the officer's UI has a single Approve/Deny action with no separate "start review" step. The backend must allow `pending → approved` and `pending → denied` directly (not force a `pending → under_review` hop first). `under_review` remains a valid status the backend can set on its own (e.g. when an officer opens the application), but the review endpoint itself must not reject a decision made straight from `pending`.

**Response** stays `{ data: AdmissionApplication, message?: string }` (see envelope below), where `AdmissionApplication` is the nested shape from §1, and `reviewed_by`/`reviewed_at` are populated same as before.

### 4. `PATCH /admissions/applications/:id` — accept nested partial payload

The applicant's self-edit screen (`student/my-application`) sends partial updates to any of the four nested groups:

```ts
type UpdateApplicationPayload = {
  personal_info?: Partial<ApplicantPersonalInfo>;
  academic_records?: ApplicantAcademicRecord[];   // full replacement array
  program_choice?: Partial<ApplicantProgramChoice>;
  documents?: ApplicantDocument[];                // full replacement array — see §5 for why this may not be the right mechanism for documents specifically
};
```

Auth/status guard is unchanged (applicant only, own application, only while `status = "pending"`). Response is the updated `AdmissionApplication` in the §1 shape.

**Admin note:** we deliberately did **not** give admission officers a way to edit an applicant's fields or documents — the officer's review screen (`manager/review-applications/:id`) is read-only apart from the Approve/Deny action in §3. Please do not add an admin-facing update path; the applicant-only auth on this endpoint is correct as-is and should stay that way.

### 5. New document endpoints (add / replace)

The applicant's self-edit screen needs to add a new document and replace an existing one, not just delete. Today only list + delete exist. Please add:

| Method | Endpoint | Request | Response | Auth |
| --- | --- | --- | --- | --- |
| `POST` | `/admissions/applications/:applicationId/documents` | `multipart/form-data`: `file` (required), `type` (string, e.g. `"passport"`, `"other"`) | `201` — the new `ApplicantDocument` (§1 shape) | Authenticated (applicant, own application, `status = "pending"`) |
| `PATCH` | `/admissions/applications/:applicationId/documents/:docId` | `multipart/form-data`: `file` (required) — replaces the stored file, keeps the same `id`/`type` | `200` — the updated `ApplicantDocument` | Authenticated (applicant, own application, `status = "pending"`) |

Same file-size/MIME constraints as the initial application submission (5MB max, `image/jpeg|jpg|png|webp`, `application/pdf`, `application/msword`, `application/vnd.openxmlformats-officedocument.wordprocessingml.document`).

**Also correcting a spec typo:** `DELETE /admissions/applications/:applicationId/documents/:docId` is documented above as `Public (applicant)` — that should read `Authenticated (applicant, own application)`. There is no legitimate public/unauthenticated use of this endpoint; the current wording was a documentation error, not an intentional design choice.

### 6. Response envelope

All four endpoints in scope must wrap their payload as:

```ts
// single-resource responses (get by id, get my, update, review):
interface ApiSingleResponse<T> {
  data: T;
  message?: string;
}

// list responses — following this backend's existing { data, meta } pagination pattern:
interface ApiPaginatedResponse<T> {
  data: T[];
  meta: {
    total: number;
    page: number;
    limit: number;
  };
}
```

This matches the `{ data, meta }` envelope already used by every other paginated list endpoint in this API — no change needed on the backend side here. The frontend's `applicationReviewApi.list()` now types its response as `ApiPaginatedResponse<AdmissionApplication>` to match.
