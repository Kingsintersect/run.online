# Admission Module — Backend Gaps Found In Production

> **Audience:** Backend developer (qhub_backend_api).
> **Status (2026-08-30):** Found while building the "already has an offer?"
> state on the admin Review Applications detail page. Confirmed via a live
> capture of `GET /admissions/applications/:id`'s response. Same category of
> doc as `moodle_sync/moodle_sync_BACKEND_GAPS.md` — this is an existing,
> working endpoint that's missing a field, not a missing endpoint.
>
> **The frontend is already built and shipped with a working interim
> solution** (see "Frontend status" below) — this isn't blocking, but the
> interim solution has a known correctness gap that only the backend fix can
> close.

---

## 1. `GET /admissions/applications/:id` doesn't say whether the application already has an admission offer

Once an application is `approved`, the admin Review Applications page shows
a "Create Admission Offer" button that calls `POST /admissions` (see
`Admissions - Create Offer.bru`). After that offer exists, the page needs to
show a different, disabled state instead of "Create Admission Offer" again —
but there is no field anywhere on the application response that says an
offer exists, and no `GET /admissions?applicationId=...` filter to ask
separately. Live capture of `GET /admissions/applications/2` (an approved
application that already has an offer) confirms it — no `admission`/`offer`
key anywhere in the response:

```json
{
  "id": "2",
  "applicant_id": "14",
  "admission_cycle_id": "1",
  "session": "2026/2027",
  "status": "approved",
  "personal_info": { "...": "..." },
  "academic_records": [],
  "program_choice": { "...": "..." },
  "documents": [ "...": "..." ],
  "submitted_at": "2026-08-29T22:16:58.000000Z",
  "reviewed_at": "2026-08-29T22:29:05.000000Z",
  "reviewed_by": "17",
  "denial_reason": null,
  "created_at": "2026-08-29T22:16:58.000000Z",
  "updated_at": "2026-08-29T22:29:05.000000Z"
}
```

**Ask:** add an `admission` field to this response (and to
`GET /admissions/applications` list items, if cheap to include there too) —
`null` when no offer exists yet, or the offer's own shape once one's been
created:

```json
{
  "...": "...",
  "admission": {
    "id": 7,
    "admissionNumber": "ADM-2026-00001",
    "programId": 1,
    "levelId": 1,
    "sessionId": 1,
    "admissionDate": "2026-08-29",
    "admissionType": "merit",
    "status": "OFFERED",
    "expiryDate": null
  }
}
```

This is additive — no existing field changes shape, and `Admission` already
has a unique constraint on `applicationId` (per
`admissionOfferApi.ts`'s existing comment), so the relation to embed already
exists on the backend; it just isn't surfaced on this endpoint yet.

**Frontend status:** shipped an interim workaround in
`src/app/(dashboard)/manager/(routes)/review-applications/[id]/page.tsx` —
since there's no `applicationId` filter on `GET /admissions` either, it
queries that endpoint scoped to the application's own `programId`/
`sessionId` (a bounded query, not a full-table scan) and matches
`applicationId` client-side, combined with the offer just created in the
current session (captured directly from the create-offer mutation's
response, so the button updates instantly without waiting on a refetch).

This covers every offer created the normal way through this same dialog
(which defaults to the application's own program/session). **It has one
known gap the backend fix would close:** an offer deliberately created under
a *different* program or session than the application originally requested
(e.g. admitting someone into their second-choice program) would fall
outside the bounded query and the button would incorrectly still show
"Create Admission Offer," risking a duplicate-create attempt (which the
backend already rejects with a 400, so it fails safely — it's just a
confusing UX, not a data-integrity risk).

Once `admission` is added to this response, the frontend's bounded
program/session query and the "just created" local-state capture can both
be deleted — the button state becomes a direct read of
`application.admission`.
