# Student Admission Progress — Backend Build Spec

> **Update:** Everything this document originally asked for has since been built and confirmed
> live via `bruno/admission/` and `bruno/fee/` — `admissionService.ts` now calls all of it for
> real (see §7 for the item-by-item status). The one thing still outstanding is **§4a**: the
> tuition-payment-initiate endpoint needs to accept an optional `amount` for partial/installment
> payments. Everything else below is kept as historical record of how each endpoint's shape was
> derived, in case it's useful context.
>
> **Known issue (2026-08-25, live on the sandbox deployment):** `POST
> /fees/payments/application/initiate` returns `500 {"message": "Server Error"}` for a real
> applicant account (`chi@gmail.com`, id 12, role `applicant`). Reproduced directly against
> `https://qhub.backend.api.qverselearning.org`, bypassing the frontend entirely, with the exact
> payload bruno documents (`{"method": "GATEWAY"}`) — so this is **not** a frontend wiring bug.
> Diagnostic trail: `GET /admission/student` and `GET /fees/invoices/my` both succeed and show
> the "Application Fee" invoice already exists (`id: 1`, `INV-2026-00001`, `PENDING`,
> `amount: 10000.00`, `amountPaid: 0.00`) — so the find-or-create-invoice step is fine. `GET
> /fees/payments/invoice/1` returns an empty list — no `Payment` row was ever created. That
> narrows the failure to the `Payment` creation and/or the Credo checkout-session call inside the
> initiate handler (most likely an unhandled exception calling Credo — e.g. missing/invalid
> gateway credentials in this deployment's config — rather than anything DB-related, since no
> partial row was left behind). The two frontend bugs found alongside this (the `/admission/student`
> response not being unwrapped from its `data` envelope, and the fee `slug` fields being checked
> with underscores instead of the real hyphenated values) have been fixed in `admissionService.ts`
> and the three `*PaymentSection.tsx` components — this 500 is the one remaining blocker, and it's
> server-side.
>
> Also note: `GET /fees/types?scope=admission` currently returns only the "Application Fee" fee
> type on this deployment — "Acceptance Fee" and "Tuition Fee" don't exist yet, so
> `initiateAcceptanceFeePayment()`/`initiateTuitionPayment()` will need those `FeeType` rows
> seeded before they can succeed either, independent of the 500 above.

`src/app/(admission)/services/admissionService.ts` on the frontend drives the **student-facing** admission journey screens (`process-admission`, `verify-payments`) — application fee → application form → admission offer → acceptance fee → tuition → completed. It was originally built "mock-ready," with every method's real call sketched out in a comment above its mock implementation, waiting for the backend to exist.

I searched the full Bruno collection (`bruno/admission/`, `bruno/payment/`) for a matching endpoint for each method. **At the time this was written, none of `admissionService.ts`'s methods had a direct real endpoint.** A few were close matches once composed from existing endpoints; the rest — the fee schedule aggregate, the student-progress aggregate, and the Credo payment-gateway initiate/verify calls — were net-new work. This document was the build spec for that net-new work, plus how to wire the parts that already had a real equivalent.

---

## 1. Method-by-method status

| `admissionService.ts` method | Bruno match? | Resolution |
| --- | --- | --- |
| `fetchFees()` | Partial — `GET /payments/fee-types` exists (payment_README.md "Fee Types" table) and returns all fee types, unfiltered, no session field | §2 below |
| `fetchStudentAdmission()` | No match | §3 below — new aggregate endpoint, composed from three existing/new sources |
| `initiateApplicationPayment()` / `initiateAcceptanceFeePayment()` / `initiateTuitionPayment()` | No match | §4 below — net-new Credo gateway integration |
| `verifyApplicationPayment()` / `verifyAcceptanceFeePayment()` / `verifyTuitionPayment()` | Partial — `POST /payments/verify/:referenceNumber` exists but is Admin/Staff-only | §5 below — auth needs to open up to the paying student |
| `declineAdmission()` | **Full match** — `PATCH /admissions/:id/decline` (admission_README.md "Admissions" table) already does exactly this | No new endpoint; see §6 for what's blocking the frontend from calling it today |
| `devSimulate*()` / `devResetAll()` | N/A | Frontend-only dev fixtures, gated on `NODE_ENV === "development"`. Not real API calls — do not build backend support for these, they get deleted before this screen ships. |

---

## 2. Fee schedule — `fetchFees()`

**Frontend contract (`FeeSchedule`, `src/app/(admission)/types/admission.ts`):**

```ts
interface FeeItem {
  id: string;
  name: string;
  slug: string;
  amount: number;
  currency: string;
  description?: string;
}

interface FeeSchedule {
  session: string;   // e.g. "2025/2026"
  fees: FeeItem[];    // exactly the admission-relevant fees: application, acceptance, tuition
}
```

**Recommendation: extend the existing `GET /payments/fee-types` rather than add a new route.** Add an optional `?scope=admission` query param that filters server-side to just the fee types named `"Application Fee"`, `"Acceptance Fee"`, `"Tuition Fee"` (the three named exactly this way per `admission_README.md`/`payment_README.md`), and include the active `AcademicSession.name` as a top-level `session` field alongside the existing `data` array. `FeeType` has no `slug` or `currency` column today — add `slug` (`VarChar(50)`, unique) and default `currency` to `"NGN"` in the response (no column needed if this deployment is Naira-only).

If a dedicated route is preferred instead, `GET /admission/fees` (Authenticated) returning `{ data: FeeSchedule }` is an acceptable alternative — just keep the response shape identical.

---

## 3. Student progress aggregate — `fetchStudentAdmission()`

**Frontend contract (`AdmissionStudent`, same file):**

```ts
interface AdmissionStudent {
  id: string;
  name: string;
  email: string;
  department: string;
  faculty: string;
  application_payment_status: "unpaid" | "pending" | "partial" | "paid" | "failed";
  application_status: "not_started" | "submitted" | "under_review";
  admission_status: "pending" | "offered" | "rejected" | "accepted" | "declined" | "expired";
  acceptance_payment_status: "unpaid" | "pending" | "partial" | "paid" | "failed";
  tuition_payment_status: "unpaid" | "pending" | "partial" | "paid" | "failed";
  tuition_amount_paid: number;
  has_applied: boolean;
  is_admitted: boolean;
  session: string;
  offer_expiry_date: string | null;
}
```

This needs a new **aggregate** endpoint — `GET /admission/student` (Authenticated) returning `{ data: AdmissionStudent }` — because no single existing endpoint returns this. It should be computed server-side from:

- `application_payment_status`, `acceptance_payment_status`, `tuition_payment_status`, `tuition_amount_paid` — from the user's invoices/payments for the "Application Fee" / "Acceptance Fee" / "Tuition Fee" fee types (same data `GET /payments/invoices/my` already exposes — just re-derive per fee type instead of adding a new payments query).
- `has_applied`, `application_status` — from whether `GET /admissions/applications/my` returns a record, and its `status` (`SUBMITTED → "submitted"`, `UNDER_REVIEW → "submitted"` still, since the frontend enum has no under-review-specific distinction here — map both to `"submitted"` unless you'd rather the frontend enum gain a fourth value).
- `admission_status`, `is_admitted`, `offer_expiry_date` — from the user's own `Admission` record. **This requires the new `GET /admissions/my` endpoint below**, since applicants currently have no way to look up their own admission offer at all.
- `name`, `email`, `department`, `faculty`, `session` — resolved from the `User`/`AdmissionApplication`/`Program`/`Department`/`Faculty`/`AcademicSession` relations.

### New prerequisite: `GET /admissions/my`

The whole accept/decline step (§6) and this aggregate both need the applicant to be able to look up their own admission offer. Today `GET /admissions` and `GET /admissions/:id` are Admin-only (per `admission_README.md`'s "Admissions" table) — there is no self-service equivalent, mirroring how `GET /admissions/applications/my` already works for applications. Please add:

| Method | Endpoint | Description | Auth |
| --- | --- | --- | --- |
| `GET` | `/admissions/my` | Get the current user's own admission offer (404 if none / not yet offered) | Authenticated |

Response: the same `Admission` shape `GET /admissions/:id` returns.

---

## 4. Payment initiation (Credo gateway) — `initiate*Payment()`

**Frontend contract (`PaymentInitiationResponse`):**

```ts
interface PaymentInitiationResponse {
  success: boolean;
  reference: string;
  gateway_url: string;   // Credo checkout URL, e.g. https://app.credodemo.com/pay?ref=...&amount=...
  message?: string;
}
```

**Status: shipped.** All three endpoints now exist for real, at `/fees/payments/{application,acceptance,tuition}/initiate` (not the `/payments/...` prefix originally proposed below — see `bruno/fee/Payments - Initiate Application.bru` / `- Initiate Acceptance.bru` / `- Initiate Tuition.bru`), each doing exactly what was asked: find-or-create the relevant Invoice, create a `PENDING` `GATEWAY` Payment, call Credo, and return `{success, reference, gateway_url}` — matching `PaymentInitiationResponse` exactly. `admissionService.ts` now calls these directly. The original ask, kept below for reference:

<details>
<summary>Original ask (now built)</summary>

Nothing in `payment_README.md`/Bruno integrates a payment gateway; today `POST /payments` just *records* a payment a staff member or student already made (bank transfer, USSD, etc.), it doesn't *initiate* one. Please add three endpoints (or one parameterized by fee type):

| Method | Endpoint | Auth |
| --- | --- | --- |
| `POST` | `/payments/application/initiate` | Authenticated |
| `POST` | `/payments/acceptance/initiate` | Authenticated |
| `POST` | `/payments/tuition/initiate` | Authenticated |

Each should, for the calling user:
1. Find or create the relevant `Invoice` (`"Application Fee"` / `"Acceptance Fee"` / `"Tuition Fee"`) if one doesn't already exist and is unpaid.
2. Create a `PENDING` `Payment` row against it with `method: "GATEWAY"` and a generated unique `referenceNumber`.
3. Call Credo's checkout-session API and return its redirect URL as `gateway_url`, alongside our own `referenceNumber` as `reference`.

</details>

### 4a. Still needed: `amount` on the tuition variant, for installment payments

`bruno/fee/Payments - Initiate Tuition.bru`'s example body is `{"method": "GATEWAY"}` — no `amount` field. That's fine for Application/Acceptance, which are always paid in full, but **Tuition Fee is documented elsewhere (`fee_README.md`'s `FeeType.allowInstallments`, and this same admission flow's `AdmissionStudent.tuition_amount_paid`) as explicitly supporting partial payment**, and the frontend's tuition step (`TuitionPaymentSection.tsx`) already has a real "Full / Half / Custom amount" picker built for it — an applicant can choose to pay half now and the rest later.

Today `admissionService.ts`'s `initiateTuitionPayment(amount)` sends `{method: "GATEWAY", amount}` to `POST /fees/payments/tuition/initiate` defensively, on the chance the field is silently accepted. **Please confirm/add real support for it:**

- `POST /fees/payments/tuition/initiate` should accept an optional `amount: number` in the request body.
- If provided, and the caller's `Tuition Fee` `FeeType.allowInstallments` is `true`, create the `PENDING` `GATEWAY` `Payment` for that `amount` instead of the full outstanding balance — same partial-amount rule the generic `POST /fees/payments/initiate` already enforces (`fee_README.md`: "If the feeType doesn't allowInstallments, amount must equal the full outstanding balance").
- If omitted, default to the full outstanding balance (today's behavior), so existing full-payment callers aren't affected.
- Validation: reject (400) if `amount` is provided but `allowInstallments` is `false` and `amount` doesn't equal the full outstanding balance — same guard as the generic initiate endpoint, applied here too.

No schema change needed — this is purely a DTO/service-logic addition mirroring behavior the generic initiate endpoint already has.

---

## 5. Payment verification — `verify*Payment()` and the `/verify-payments` redirect page

**Frontend contract (`PaymentVerificationResponse`):**

```ts
interface PaymentVerificationResponse {
  success: boolean;
  status: "unpaid" | "pending" | "partial" | "paid" | "failed";
  reference: string;
  amount: number;
  message?: string;
}
```

Credo redirects the paying student **directly back to `/verify-payments`** with the transaction reference in the query string — so this must be callable by the student themselves immediately after payment, not just an admin.

The existing `POST /payments/verify/:referenceNumber` is currently Admin/Staff-only (per its Bruno docblock — deliberately scoped that way because there's no gateway webhook-signature verification yet, see `PROJECT_TRACKER.md`'s Payment row). **Please relax this to also allow the payment's owner**, i.e.: `Admin/Staff` OR `payment.invoice.userId === JWT user`. That keeps the existing endpoint doing double duty (webhook-less staff verification for bank transfers, and self-serve verification for gateway payments) without duplicating the verify logic into a separate route. If a webhook-signature/API-key mechanism is added for Credo later, this endpoint is also where it'd plug in.

No separate `/payments/application/verify` etc. endpoints are needed — the frontend can call the existing `POST /payments/verify/:referenceNumber` with the `reference` Credo redirected back with, once the auth change above ships.

---

## 6. Decline admission — `declineAdmission()`

This one already has a real, matching endpoint: `PATCH /admissions/:id/decline` (`admission_README.md` "Admissions" table). **No backend work needed here** — the only reason the frontend can't call it today is that it doesn't know the `admissionId` (see §3's `GET /admissions/my` — once that exists, the frontend reads `id` off it and calls decline directly).

---

## 7. Summary of new/changed backend work

Items 1-6 below are all **shipped** — confirmed live via bruno and now called directly by `admissionService.ts`. Item 7 is the one thing still outstanding.

1. ✅ `GET /fees/types?scope=admission` — filtered fee schedule with `session`. *(§2)*
2. ✅ `GET /admissions/my` — self-service admission-offer lookup. *(§3)*
3. ✅ `GET /admission/student` — aggregate student progress, composed server-side from application/admission/invoice data. *(§3)*
4. ✅ `POST /fees/payments/{application,acceptance,tuition}/initiate` — Credo checkout-session creation. *(§4)*
5. ✅ `POST /fees/payments/verify/:reference` — relaxed auth to also allow the payment's own owner, not just Admin/Staff. *(§5)*
6. ✅ `PATCH /admissions/:id/decline` — no change was needed; #2 unblocked calling it from the frontend.
7. ⬜ `POST /fees/payments/tuition/initiate` — accept an optional `amount`, so the frontend's half/custom tuition-installment picker can actually pay a partial amount instead of always the full balance. *(§4a, new)*
