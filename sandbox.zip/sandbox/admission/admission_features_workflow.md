# Admission Step Registry — Frontend Feature Workflow

This documents `src/services/admissionStepsApi.ts` on the frontend: a full CRUD admin feature at `/admin/configurations/admission-config` for creating, editing, deleting, reordering, and enabling/disabling the individual steps that make up:

- the applicant's **admission process** (`src/app/(admission)/(routes)/process-admission/page.tsx`), and
- the **application form** (`src/app/(admission)/(routes)/admission-application-form/page.tsx`).

**Status (2026-08-21): the in-memory dummy store has been removed.** `admissionStepsApi.ts` now calls the exact endpoints specified below (`GET/POST/PATCH/DELETE /admissions/config/steps`, `POST /admissions/config/steps/reorder`). **These endpoints don't exist yet, so both the admin panel and the two student-facing pages (`process-admission`, `admission-application-form`) currently 404 on load** — this is now a blocking gap for all three surfaces, not a cosmetic one. `DEFAULT_ADMISSION_STEPS` in `src/lib/admissionConfig.ts` is kept only as the source for `KNOWN_PROCESS_STEP_KEYS`/`KNOWN_FORM_STEP_KEYS` (the "Custom" badge lookup) — it no longer seeds a mock store. Once the endpoints below are built exactly as specified, the frontend needs no further changes.

This supersedes the earlier `admission_step_config` approach (a single JSON blob in the Settings module) described in a previous draft of this doc — that could only toggle a fixed, hardcoded list of steps on/off. This version makes the list itself data, not code.

---

## Data model

```ts
type AdmissionStepGroup = "PROCESS" | "FORM";

interface AdmissionStepDefinition {
  id: string;
  group: AdmissionStepGroup;
  key: string;            // stable identifier, immutable after creation
  label: string;
  description: string;
  icon: string;            // one of a fixed set of icon names — see "Icons" below
  enabled: boolean;
  required: boolean;       // non-negotiable — can't be disabled or deleted
  order: number;           // display/navigation order within its group, ascending
}
```

- **`group: "PROCESS"`** — the applicant's admission-dashboard stages. Seeded with the 6 built-in ones: `APPLICATION_PAYMENT`, `APPLICATION_FORM` (required), `ADMISSION_STATUS` (required), `ACCEPTANCE_FEE`, `TUITION_PAYMENT`, `COMPLETED` (required).
- **`group: "FORM"`** — steps inside the application form. Seeded with the 9 built-in ones: `PERSONAL_INFO` (required), `SPONSOR_INFO`, `NEXT_OF_KIN` (required), `DOCUMENTS` (required), `QUALIFICATION_FIELDS` (required), `EXAM_SITTING`, `QUALIFICATION_DOCUMENTS`, `PROGRAM_SELECTION` (required), `REVIEW` (required).

A `required` step's `enabled` is always forced `true` — both client-side (the admin UI locks its switch) and server-side (`admissionStepsApi.update()` overwrites `enabled` back to `true` for any required row, regardless of what's passed in). A real backend implementation should keep that same guard.

---

## Proposed real endpoints

One table, one CRUD controller — mirrors how `FeatureRegistry` already works in this schema (single table, category/group column), rather than introducing a parallel "definition vs. current state" split.

```prisma
enum AdmissionStepGroup {
  PROCESS
  FORM
}

model AdmissionStepDefinition {
  id          Int                 @id @default(autoincrement())
  group       AdmissionStepGroup
  key         String              @db.VarChar(50)
  label       String              @db.VarChar(100)
  description String?             @db.Text
  icon        String?             @db.VarChar(50)
  required    Boolean             @default(false)
  enabled     Boolean             @default(true)
  order       Int                 @default(0)
  createdAt   DateTime            @default(now())
  updatedAt   DateTime            @updatedAt

  @@unique([group, key])
  @@index([group])
  @@map("admission_step_definitions")
}
```

| Method | Endpoint | Description | Auth |
| --- | --- | --- | --- |
| `GET` | `/admissions/config/steps?group=PROCESS\|FORM` | List steps for a group, ordered by `order` | Authenticated (students need this to render their own pages) |
| `POST` | `/admissions/config/steps` | Create a step — `{ group, key, label, description, icon, required, enabled }` | Admin |
| `PATCH` | `/admissions/config/steps/:id` | Update any field except `group`/`key` | Admin |
| `DELETE` | `/admissions/config/steps/:id` | Delete — must `400` if the target row has `required = true` | Admin |
| `PATCH` | `/admissions/config/steps/reorder` | Bulk reorder — `{ group, orderedIds: number[] }`, assigns `order` by array position | Admin |

> **Status (2026-08-26, superseding an earlier same-day note): live, one deliberate deviation
> remains.** The backend appears to have been redeployed/reseeded between two rounds of testing
> the same day — an earlier check found `stepKey`/`stepOrder`/no `group`/no `icon`/a no-op
> `?group=` filter; a later round of testing (full create → list → patch → delete round trips
> against `https://qhub.backend.api.qverselearning.org`, cleaned up after) found all of that
> fixed **except the two boolean fields**:
> - `group`, `key`, `order`, `label`, `description`, `icon` are unrenamed on both read and write,
>   matching this doc's contract exactly. `group` is a real column and the `?group=` filter now
>   actually filters.
> - `required`/`enabled` are still named `isRequired`/`isActive` on **both** read and the
>   POST/PATCH body (not just the response) — sending `required`/`enabled` on create is silently
>   ignored (new rows default to `isRequired: true, isActive: true` regardless of what's sent
>   under those names) and is a no-op on update. `src/services/admissionStepsApi.ts` maps this
>   one pair both directions (`fromRaw`/`toRawPayload`); everything else passes through as-is.
> - `POST` genuinely requires `order` in the body (confirmed via a 422 — `"order field is
>   required"`) — it isn't server-assigned. `CreateAdmissionStepPayload` (`admissionConfig.d.ts`)
>   now includes it, and `AdmissionConfigPage.handleFormSubmit` computes it as
>   `max(existing orders in that group) + 1`.
> - `DELETE` correctly 400s on the last remaining step in a group ("Cannot delete the last
>   remaining step in the 'PROCESS' group") — matches this doc's validation note below.
>
> One test artifact from this round is still sitting in the PROCESS group: id 16,
> key `ZZZ_PROBE_DELETE_ME`, `isRequired: false` — it's the only PROCESS-group row, so the
> last-row guard above blocks deleting it. Create a real PROCESS step first, then delete it
> (or just overwrite its label instead of deleting).

> **Correction (2026-08-27):** the reorder endpoint is `PATCH`, not `POST` as originally
> documented above — the live backend returned a 405 ("The POST method is not supported for
> route api/v1/admissions/config/steps/reorder. Supported methods: PATCH.") when the frontend's
> `admissionStepsApi.ts` called it with POST from the admin config page's reorder buttons. Fixed
> in `admissionStepsApi.ts`'s `reorder()`; the table above is updated to match.

Validation the backend should enforce (the dummy service already enforces these client-side, but a real backend must not trust the client):
- `key` unique within `(group, key)` — reject `POST` with a duplicate.
- Reject `DELETE`/`PATCH .enabled = false` on a `required = true` row.
- `POST` should probably also reject an empty group entirely (i.e. don't allow deleting the last step in a group) — not currently enforced by the dummy service; worth adding.

---

## Icons

Icon is stored as a plain string naming a Lucide icon (e.g. `"CreditCard"`), not the component itself — see `src/lib/admissionStepIcons.ts` for the fixed set of ~20 names the admin can pick from (`ADMISSION_STEP_ICON_NAMES`) and the lookup (`getStepIcon(name)`). Backend just needs to store/return the string; it doesn't need to know or validate the icon set beyond "it's a string."

---

## An important limitation: custom steps have no matching UI yet

Creating a **new** step (a `key` outside the 6 built-in `PROCESS` keys or 9 built-in `FORM` keys) is fully supported by the CRUD API and shows up in the admin's panels, the live-preview strip, and the enabled/total counts. **It will not, however, appear on the actual student-facing pages**, because:

- Each `FormStep` in the application form (`Personal Info`, `Sponsor Info`, etc.) is a hand-built React component with its own fields, validation schema, and file uploads (`src/app/(admission)/(routes)/admission-application-form/components/steps/*.tsx`). There's no generic renderer for an arbitrary custom step — `getActiveFormSteps()` (`form-types.ts`) only ever maps the 9 known keys onto real `FormStep` enum values; an unknown key simply can't be included in that array because the type doesn't have a slot for it.
- Similarly, each `AdmissionStep` stage on the process dashboard is a hand-built section component, and `admissionStore.ts`'s `deriveStep()` is a fixed if/else chain over the 6 known keys — it has no logic for a custom stage's gating condition (e.g. "is this stage satisfied?").

So today, "Create Step" is genuinely useful for: pre-staging steps ahead of a dev cycle, and for full CRUD over the 15 built-in steps (edit label/description/icon/required/order, or delete/disable the non-required ones). Making a **truly new custom step show real content to an applicant** is a separate, larger feature — it needs either a generic form-builder (configurable fields per step) or a matching hand-built component shipped in the same release as the step definition. The admin UI marks any non-built-in key with a "Custom" badge so this isn't a silent surprise.

---

## Reordering

Only the **Application Form Steps** panel offers reordering (up/down arrows, calling `POST /admissions/config/steps/reorder`). The **Admission Process Steps** panel does not, deliberately: process-stage order encodes real payment-gate dependencies in `admissionStore.ts`'s `deriveStep()` (you can't pay the acceptance fee before being admitted, etc.) — reordering the display without also rearchitecting that gating logic would create a mismatch between what's shown and what's actually enforced. Form-step order, by contrast, is just presentation sequence with no such dependency, so reordering there is safe.

---

## Consumers

- **`src/app/(admission)/(routes)/process-admission/page.tsx`** — fetches `admissionStepsQueryOptions.config()`, feeds the enabled `PROCESS` keys into `admissionStore.ts`'s `setStepConfig()`, which gates `deriveStep()`. `AdmissionStepIndicator` renders the 6 known stages using each one's live `label`/`icon` from the registry (so admin edits to those fields show up immediately), filtered to enabled/required only.
- **`src/app/(admission)/(routes)/admission-application-form/hooks/useAdmissionForm.ts`** — fetches the same `config()` query, computes `activeSteps` via `getActiveFormSteps()` (sorted by the registry's `order`, known keys only), and navigates along that array. `FormStepIndicator` and `ReviewStep` render/omit sections accordingly.

Both pages use React Query with a 5-minute `staleTime` — a change an admin saves takes effect for a student on their next page load or natural cache revalidation, not instantly on an already-open tab.
