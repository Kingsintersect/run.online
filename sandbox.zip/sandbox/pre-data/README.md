# Pre-Launch Seed Data — Audit

**Yes, you're correct.** A fresh instance for a new institution needs its business/transactional
tables genuinely empty (no other institution's students, courses, applications, grades, invoices
should exist) — but a handful of tables hold **system-level configuration the frontend code was
built against by name/key**, not institution-specific business data. If those are *also* empty,
the app doesn't just look empty — parts of it stop working, because the frontend has real string
constants and gating logic that expect specific rows to exist. This folder is the audit of which
tables those are, ranked by how badly things break without them, plus best-effort JSON seed files
for the ones I could source with real confidence.

## The core distinction

| | Empty on a fresh install | Why |
|---|---|---|
| **Business/transactional data** | ✅ Should be empty | Students, Applications, Courses, Enrollments, Invoices, Grades, Timetables, Notifications, Moodle sync mappings — this is exactly the data that's specific to running students/staff, and empty is the correct starting state. |
| **System configuration data** (this folder) | ❌ Must NOT be empty | Rows the frontend references by exact `key`/`resource`/`action` string, or that an entire feature has no data to operate on without (a dropdown with zero options, a step registry with zero steps). |

## Severity ranking

### 🔴 Launch-blocking — the app is unusable for real users without these

| Table / endpoint | File in this folder | Why it's blocking |
|---|---|---|
| Admission Step Registry (`GET/POST /admissions/config/steps`) | `admission-step-registry.json` | Empty → `process-admission` shows "Admission process isn't configured yet" and the application form has zero steps. No applicant can apply, at all, until an admin manually recreates all 16 steps with byte-exact key strings (`PERSONAL_INFO`, `CHOICE_PROGRAM`, etc.) — a single typo silently breaks that step's gating with no error shown. |
| Country reference data (`GET /demographics/countries`) | `demographics-starter.json` (partial) | The application form's Nationality field is a required dropdown sourced entirely from this table, no fallback. Empty table → empty dropdown → the form cannot be completed by anyone. |
| Grade Scale (`POST /results/grade-scales`) | `grade-scale-starter.json` | Every submitted score needs a matching band to get a letter grade / GPA point. Empty → no grade can ever be classified, GPA/CGPA computation has nothing to sum. |
| At least one `SUPER_ADMIN` user | *(not a JSON file — see below)* | There is **no frontend path** to create an admin account — public signup only produces `APPLICANT`/`STUDENT`-tier users (confirmed: `BackendRegisterPayload` has no `role` field). Without a seeded first admin, nobody can log in to configure anything else in this list. This has to be a backend seeder / artisan command with a real, changed-on-first-login password — not something this frontend can create for itself. |

### 🟡 Degrades gracefully, but should still be seeded

| Table / endpoint | File in this folder | What happens if empty |
|---|---|---|
| Feature Registry + default flags (`/portal-settings/registry`, `/portal-settings/features`) | `feature-registry.json` | Already defensive: `useFeature.ts` falls back to each feature's own coded `defaultEnabled` when the backend has no row. Nothing breaks — but the admin's Feature Registry/Feature Flags screens show nothing instead of the real catalog, so seed it for a coherent admin experience from day one. |
| Academic Unit Types (`/academic-structure/unit-types`) | `academic-unit-types.json` | The generic `AcademicUnit` tree (used by Moodle category sync + the Structure Builder admin UI) has nothing to anchor Faculty/Department/Program/Level/Semester nodes to. The 5 base types are cheap to seed and unblock this immediately. |
| Permission Registry + Role→Permission assignments | `permission-registry.json`, `role-permission-assignments.json` | If a role has zero assigned permissions, every `PermissionGate`/`useRoleGuard` check for that role fails closed — that role's users see "access denied" everywhere. See the caveats below; these two are the least certain files in this folder. |

### Not addressed here — genuinely institution-specific, correctly empty

Programs, Faculties, Departments, Fee Types and amounts, Clearance Types, Hostel blocks/rooms,
Notification templates, Admission Cycles. These vary per institution by design (that's the whole
point of the Multi-Program Platform work — see `sandbox/multi-program-platform/`) and an admin
configures them through the app's own UI after first login. Nothing to pre-seed.

---

## File-by-file notes and confidence

### `admission-step-registry.json` — HIGH confidence
Extracted verbatim from `src/lib/admissionConfig.ts`'s `DEFAULT_ADMISSION_STEPS` — this is the
exact same data the frontend uses as its own "known step" catalog (for the admin config UI's
"Custom" badge, and the create-step type picker), not something I derived or guessed. 16 rows: 7
`PROCESS` group, 9 `FORM` group.

### `feature-registry.json` — HIGH confidence
Extracted verbatim from `src/config/featureRegistry.ts`'s `FEATURE_REGISTRY` — the live catalog
every feature-gated route/nav item checks against. 24 rows. Note there's also an older,
**stale** `src/lib/utils/deafault.features.json` in the repo with different keys/categories
(`"password_authentication"` vs the live `"password_auth"`, `"Public"/"Core"` category casing vs
live lowercase) — don't use that file, it doesn't match the code that actually runs.

### `academic-unit-types.json` — HIGH confidence for the 5 base types
The 5 base types (`FACULTY, DEPARTMENT, PROGRAM, LEVEL, SEMESTER`) are explicitly named as the
minimum seed in `sandbox/schema-moodel-sync-refactor/BACKEND_REQUIRED_ENDPOINTS.md` §2. The extra
optional types (`SCHOOL, SECTION, STREAM, TERM`) are only needed for non-Degree structures
(postgraduate, secondary-school-shaped, or a Foundational program that skips levels) — don't seed
those unless this institution actually needs them at launch.

### `grade-scale-starter.json` — MEDIUM confidence, please read the note in the file
This is the standard, widely-used Nigerian university 5-point scale — not fabricated — but I
could not confirm whether *this specific institution's* real grading policy matches this simple
5-band shape, or the finer 8-band half-letter scheme (`A/AB/B/BC/C/CD/D/F`) that the frontend's
own `GRADE_CHIP` color map (`StudentResultsPage.tsx`) is already built to display. I found no
documented cutoffs for that 8-band variant anywhere in `sandbox/`, and grade boundaries directly
determine every student's GPA — not something to guess at. **Treat this as a placeholder that
unblocks a fresh install, and have the registrar confirm or replace it before any real result is
published.**

### `demographics-starter.json` — HIGH confidence for Nigeria itself, deliberately incomplete for States/LGAs
Nigeria has 36 states + FCT and 774 Local Government Areas — real, precise reference data I did
not attempt to hand-type here, because a wrong LGA name actively misinforms every applicant
picking from that list. **Do not fabricate this list from memory** (mine or anyone's) — import it
from an authoritative source (Nigeria's National Bureau of Statistics / NIMC LGA codes, or a
maintained open dataset) through the real `/demographics/states` and
`/demographics/local-governments` endpoints. Same reasoning applies to the international country
list — it's not Nigeria-only, but a short authoritative list beats a long guessed one.

### `permission-registry.json` / `role-permission-assignments.json` — CAVEAT, read before use
These are **relocated copies** of `src/lib/utils/permissions.json` and
`Roles.Permissions.assignment.json`, which already existed in the repo as apparent reference
dumps — I did not author their contents fresh. Two things worth knowing before trusting them as
the real seed:

1. **I could not live-verify them.** `GET /auth/permissions` (the real catalog endpoint) is
   admin-gated and 403'd for the only test account available this session (a student). These
   files may be accurate, or may have drifted from what the backend actually enforces today — this
   session has already found, elsewhere, permissions referenced in similar docs that turned out to
   be fictional (e.g. `"users:manage"` never existed as a real permission — see the pinned session
   notes). Cross-check against the backend's actual permissions table before seeding blind.
2. **`role-permission-assignments.json` is missing the `APPLICANT` role entirely.** The real
   `UserRole` enum (`src/config/nav.config.ts`) has 11 values; this file only covers 10 (no
   `APPLICANT`). `APPLICANT` is the role every fresh signup gets before becoming a `STUDENT`, and
   it's exactly the role that needs `my-application:view`/`submit`-type permissions to get through
   `/process-admission` and the application form at all. **If you seed roles from this file
   as-is, every new applicant will have zero permissions and be locked out of applying** — add an
   `APPLICANT` entry (mirroring `GUEST`'s scope plus admission-specific permissions) before using
   this file for real.

## Live verification (2026-09-11, with a real SUPER_ADMIN token)

The user supplied a live `SUPER_ADMIN` login (`control@qverse.engine`) so the caveats above
could be checked against the real backend instead of guessed. Findings:

### 🔴 SUPER_ADMIN seeding — already resolved
This environment already has a working `SUPER_ADMIN` account (`user.id: 7`,
`username: qverse_control`, `role: super_admin`). The 🔴 blocking item above is a
non-issue *here* — it only applies the first time a brand-new institution instance is
provisioned.

### Permission Registry — 110/112 exact match, HIGH confidence confirmed
Live `GET /auth/permissions` (paginated, 112 total — note this endpoint silently caps
`limit` at 100 per page same as `GET /users`, so it took 2 requests) diffed almost
perfectly against `permission-registry.json`:
- **`result.view.own`** (id 2, module "academics") exists live but isn't in the local file.
  This looks like a legacy/superseded permission — the live catalog also has
  **`my-results.view`** (id 83, module "student portal"), which the local file already
  correctly includes and which matches the `my-X` self-view naming convention every other
  student-facing permission in this system uses. **No fix needed** — the local file's
  omission of `result.view.own` looks like the correct call, not a gap.
- **`my-hostel.view`** is in the local file but does **not** exist in the live permission
  catalog — every other `my-X` self-view permission the student portal uses does exist live
  (`my-application`, `my-assessments`, `my-courses`, `my-documents`, `my-grades`,
  `my-payments`, `my-results`, `my-timetable`) except this one. This is a genuine backend
  catalog gap. **It is not currently causing a live bug**, though: checked
  `src/app/(dashboard)/student/hostel/page.tsx` directly and it has no `PermissionGate` or
  `useRoleGuard` at all — the frontend doesn't actually gate hostel access on any permission
  string yet, so nothing is broken today. Still worth the backend team adding
  `my-hostel.view` to the catalog before hostel access ever gets a permission gate.

### Roles — all 11 confirmed live, including APPLICANT
`GET /auth/roles` returns all 11 roles (`admin, applicant, bursary, dean, director, guest,
hod, staff, student, super_admin, tutor`) — **`APPLICANT` (role id 13) already exists live
and already has 11 permissions assigned** (`dashboard.view`, `profile.view/update`,
`account-settings.view/update`, `my-application.view/submit`, `my-documents.view/upload`,
`my-payments.view/make`). The README's earlier warning that
`role-permission-assignments.json` is "missing the APPLICANT role entirely, so every new
applicant will have zero permissions" describes a gap in **this local reference file only**
— the real backend already has it right. `role-permission-assignments.json` should still
get an `APPLICANT` entry added (mirroring the 11 permissions above) so the file is a
complete seed, but this is a documentation fix, not a live blocking issue.

### Role → Permission assignments — fetched live per-role (`GET /auth/roles/:id`), diffed against the local file
| Role | Result |
|---|---|
| TUTOR, HOD, DEAN, BURSARY, DIRECTOR, STAFF | **Exact match** — local file is accurate as-is. |
| STUDENT | Near match. Local-only: `my-hostel.view` (expected — see above, doesn't exist live). Live-only: `result.view.own` (the legacy permission, harmless), `my-application.submit` (real gap in the local file — live students can submit an application, e.g. for a program change; local file is missing this row). |
| GUEST | Local file has 4 extra rows live doesn't have: `enrollment.view.own/create.own/drop.own`, `attendance.view.own`. Live `guest` only has the 5 baseline rows (`dashboard.view`, `profile.view/update`, `account-settings.view/update`) — same as `applicant`. The local file's guest scope looks aspirational/wrong; **defer to live** unless the user wants guests able to self-enroll before being accepted. |
| ADMIN | Live has 3 extra rows the local file is missing: `assessments.view`, `assessments.manage`, `assessments.sync`. Minor gap in the local file — admin can already manage assessments live. |
| **SUPER_ADMIN** | ⚠️ **Fixed live.** The live role had 96 permissions vs. the local file's 106 — missing all `clearance.*`, `hostels.*`, and `documents.*`/`my-documents.*` permissions, directly contradicting this project's standing rule that SUPER_ADMIN must have unrestricted access to every feature. With the user's explicit go-ahead, called the live `POST /auth/roles/7/permissions` (`Role Permissions - Assign.bru`, `syncWithoutDetaching` — additive, nothing was removed) with the 11 assignable permission ids (`clearance.view`=103, `clearance.approve`=105, `clearance.manage`=106, `hostels.view`=109, `hostels.manage`=110, `hostels.allocate`=111, `my-documents.view`=99, `my-documents.upload`=100, `documents.verify`=107, `documents.manage`=108, `documents.view`=112). Re-fetched `GET /auth/roles/7` afterward and confirmed 107 permissions, diffing to exactly the expected remainder: only `my-hostel.view` still missing (can't be assigned — doesn't exist in the catalog at all, see above) and only `result.view.own`/`results.view.all` as harmless live extras. **The live SUPER_ADMIN role now has full access to clearance, hostel, and document management**, matching the project rule. |

### Clearance admin queue endpoint — now confirmed, frontend firmed up
`GET /clearance` (previously 403'd with a student token, handled defensively) now confirmed
live with the admin token: `{"data": [], "meta": {"total": 0, "page": 1, "limit": 15}}` —
wrapped, matching every other list endpoint in this module.
`src/modules/clearance/services/clearance.service.ts`'s `list()` has been firmed up from its
defensive "accept either shape" implementation to a direct `res.data` unwrap, and the file's
header comment updated to record all four confirmed endpoint shapes with no more
"couldn't confirm" caveats.

## What I did not do

- Did not touch or propose changes to the actual backend/database — per this project's standing
  rule (`CLAUDE.md` §13), this is frontend-side reconnaissance only. These JSON files are a
  proposal for the backend team to review and seed, not something this session executed.
- Did not fabricate States, Local Government Areas, or a full country list (see above).
- Did not attempt Fee Types, Hostel data, Clearance Types, or Notification templates — these are
  genuinely per-institution and correctly start empty; an admin configures them through the app.
