# Pre-Launch — Tables That MUST Be Empty on a Fresh Instance

Companion to [`README.md`](./README.md), which audits the opposite side of this same
question: system-configuration tables that **must be seeded** or the app breaks. This file
is the other half — the business/transactional tables that must start with **zero rows**
for a new institution, because every row in them is specific to the *previous* tenant's
real students, staff, money, and records. Carrying any of them over into a new instance
isn't a "looks empty" problem, it's a data-leak/correctness problem: another university's
applicant would show up in this one's admin queue, another university's invoice would show
up in this one's revenue report.

Grouped by module, in the rough order an admin would populate them after first login.

---

## 1. Identity & Access

| Table / entity | Why it must be empty |
|---|---|
| Users (Students, Staff, Applicants, and any Admin/Director/HOD/Dean/Bursary/Tutor accounts beyond the one seeded `SUPER_ADMIN`) | Every real person who will log in belongs to exactly one institution. The `SUPER_ADMIN` bootstrap account is the sole exception — see `README.md`'s 🔴 section — everyone else is created by that admin after launch, either directly or via the applicant→student pipeline. |
| Auth sessions / refresh tokens / password-reset tokens | Transient by nature; naturally empty on a fresh deploy, listed here only for completeness. |
| `UserRole` **assignments** (the join between a specific user and a role) | The role *catalog* itself (`ADMIN`, `STUDENT`, `super_admin`, …) is seed data and stays — see `README.md`. What must be empty is which real user has which role, since that's per-person. |

## 2. Admissions

| Table / entity | Why it must be empty |
|---|---|
| `AdmissionCycle` | Institution-specific intake windows (e.g. "2026/2027 First Semester Intake") with real open/close dates and quotas — configured per institution after launch. |
| `AdmissionApplication` (the applications themselves) | Real applicant data — bio-data, program choice, submitted documents, decision status. The **Admission Step Registry** (which steps exist) is seed data and stays (`README.md`); the applications flowing through those steps are not. |
| `AdmissionFormField` **submitted values** (a specific applicant's answer to a dynamic field) | Per-applicant data. The field *definitions* (what dynamic fields exist, from the Multi-Program Platform work — see `sandbox/multi-program-platform/`) are institution config, configured by that institution's admin, not carried over from another tenant. |
| Documents uploaded during application (transcripts, WAEC results, passport photos, etc.) | Real applicant files — obviously per-institution, per-person. |

## 3. Academic Structure (the actual instances, not the unit *types*)

| Table / entity | Why it must be empty |
|---|---|
| `Faculty`, `Department`, `Program` (real rows — e.g. "Faculty of Engineering", "B.Sc Computer Science") | Every institution's faculty/department/program list is unique. Only `academic-unit-types.json`'s 5 base *type codes* (`FACULTY`, `DEPARTMENT`, …) are seed — the actual tree nodes are built by the admin through the Structure Builder UI after launch. |
| `AcademicSession`, `Semester`, `Level` (real rows — e.g. "2026/2027", "First Semester") | Same reasoning — the calendar is per-institution and per-year, configured fresh each cycle. |
| `AcademicUnit` generic-tree rows | Mirrors whatever Faculty/Department/Program/Session rows exist — empty until those are created. |

## 4. Courses & Curriculum

| Table / entity | Why it must be empty |
|---|---|
| `Course` (the course catalog — e.g. "CSC301: Data Structures") | Every institution's course catalog and credit-unit values are their own; nothing here is shared/global. |
| `CourseOffering` (a course scheduled for a specific session/semester) | Derived from Course + Session, both of which are per-institution and empty at launch. |
| Curriculum / Program↔Course mapping (which courses a program requires per level) | Institution- and program-specific curriculum design. |

## 5. Enrollment & Timetable

| Table / entity | Why it must be empty |
|---|---|
| `StudentEnrollment` | A specific student's registration for a specific session/semester — doesn't exist until real students exist. |
| Course registration (a student's chosen `CourseOffering`s for a semester) | Same reasoning, one level down. |
| `TimetableEntry` / Schedule rows | Built per institution around its own room/staff/course realities. |

## 6. Assessments, Grades & Results

| Table / entity | Why it must be empty |
|---|---|
| `Assessment` (a specific CA/exam/quiz instance tied to a `CourseOffering`) | Created by tutors per real course offering; none exist until courses and enrollments do. |
| Submissions / attempts | Per-student, per-assessment — obviously empty. |
| `Grade` / `Result` rows (a student's actual score/letter-grade/GPA for a course) | The real, sensitive output of the grading process — must never be another tenant's academic records. |
| `GradingScheme` assignments (which scheme a program actually uses) | The *bands* (`grade-scale-starter.json`, A/B/C/D/E/F cutoffs) are seed reference data and stay — see `README.md`'s caveat there. Which program uses which scheme, and any institution-specific scheme variants, are configured after launch. |

## 7. Fee Management

| Table / entity | Why it must be empty |
|---|---|
| `FeeType` (e.g. "Tuition", "Acceptance Fee", "Hostel Fee" — with real amounts) | Explicitly called out in `README.md`'s "Not addressed here" section — fee names and especially amounts are entirely institution-specific and set by that institution's Bursary/Admin after launch. |
| `Invoice` | Generated per student per fee cycle — none exist until students and fee types do. |
| `Payment` / transaction records | Real money movement, obviously never shared or carried over between tenants. |

## 8. Clearance

| Table / entity | Why it must be empty |
|---|---|
| `ClearanceType` (e.g. "Library", "Bursary", "Hostel", "Department") | Also explicitly in `README.md`'s "Not addressed here" list — which clearance stages exist and who approves them is an institution-specific workflow decision. |
| `StudentClearance` records | A specific student's progress through those stages — empty until both students and clearance types exist. |

## 9. Hostel

| Table / entity | Why it must be empty |
|---|---|
| `HostelBlock`, `HostelRoom` (real inventory — e.g. "Block A, Room 204, 4 beds") | Physical inventory is obviously unique per campus. |
| `HostelAllocation` | A specific student assigned to a specific room — empty until both exist. |

## 10. Notifications

| Table / entity | Why it must be empty |
|---|---|
| `Notification` instances (an actual sent notification) | Per-user, per-event — none exist until users and events do. |
| `NotificationTemplate` rows | Borderline: templates are *configuration*, not a per-user record, but they're still institution-authored content (the wording, branding, and tone an institution wants in its emails/SMS) rather than a fixed system catalog the frontend hardcodes against by key the way `feature-registry.json` or `admission-step-registry.json` are. Unlike those, nothing in the frontend breaks if this table is empty — it just means the admin writes their own templates through the Notification Templates UI after launch, which is the intended flow. |

## 11. Moodle Sync

| Table / entity | Why it must be empty |
|---|---|
| `MoodleSyncCategory` mappings (portal Faculty/Department ↔ Moodle category `idnumber`) | Ties a specific institution's structure to a specific Moodle instance's category tree — meaningless across tenants, and actively wrong if copied (would point at another institution's Moodle categories). |
| `MoodleSyncCourse` mappings | Same reasoning, one level down (CourseOffering ↔ Moodle course). |
| `MoodleSyncCohort` mappings (new, from the Multi-Program Platform work) | Same reasoning again (program intake ↔ Moodle cohort). See `sandbox/multi-program-platform/MOODLE_COHORT_SYNC.md`. |
| Moodle SSO account links | Per-user link between a portal account and a Moodle account — empty until both sides have real users. |

## 12. Documents & Content

| Table / entity | Why it must be empty |
|---|---|
| `Document` records (uploaded files outside the admission flow — e.g. staff credentials, ID uploads) | Per-person uploaded files. |
| Content/Announcement posts | Institution-authored communications; nothing generic to carry over. |

## 13. Gamification (if the `gamification` feature is enabled for this instance)

| Table / entity | Why it must be empty |
|---|---|
| Points, badges earned, leaderboard entries | Per-student engagement history — obviously starts at zero for a new cohort. Note this feature defaults to **disabled** (`feature-registry.json`: `defaultEnabled: false`), so this table may simply never populate unless the institution turns it on. |

## 14. Audit

| Table / entity | Why it must be empty |
|---|---|
| `AuditLog` entries | A history of actions taken in *this* instance. A fresh instance has no history yet — the very first row should be whatever the newly-seeded `SUPER_ADMIN` does on first login, not another tenant's activity trail. |

---

## Explicitly NOT in this list — see `README.md` instead

`README.md` covers the other side of this same audit: tables that must be **seeded**, not
emptied — Admission Step Registry, Feature Registry, Academic Unit *Types* (the 5 codes,
not the real Faculty/Department/Program instances above), Grade Scale bands, Country/
demographics reference data, and the Permission Registry / Role→Permission assignments.
Don't empty those — the app degrades or breaks without them.

## What I did not do

- Did not name exact database table names or write any migration/seeder/truncate script —
  per this project's standing rule (`CLAUDE.md` §13), backend implementation is out of
  scope here. This is a frontend-side audit of which *domains* of data are tenant-specific,
  for the backend team to map onto their actual schema and provisioning process.
- Did not include transient/derived tables (job queues, cache rows, websocket presence,
  computed report caches) — those aren't "seed vs. business data" questions, they're
  infrastructure that resets itself regardless of tenant.
