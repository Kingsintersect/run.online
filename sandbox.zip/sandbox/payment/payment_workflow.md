# Fee Module — Implementation Workflow

This document explains the internal implementation flow for the Fee module. It is
intended for developers building or maintaining this module.

---

## Module Dependencies

```
FeeModule
├── PrismaService              (database access)
├── ConfigurationModule        (payment gateway keys, settings)
├── AuditModule                (log all fee/invoice/payment events)
├── BullModule / Queue         (async bulk invoice generation)
├── UserModule                 (user data — invoices can exist pre-Student)
├── StudentModule              (student profile: program, level, type)
├── AcademicModule             (session/program/level for eligibility matching)
├── PaymentGatewayModule       (Paystack/Flutterwave adapter)
├── MoodleSyncModule           (consumed by — tuition PAID triggers onTuitionVerified)
└── NotificationModule         (payment confirmations, overdue reminders)
```

---

## Core Concept — Two-Layer Model

```
      Admin defines                    Student owes
      ─────────────                    ────────────

  ┌──────────────┐    resolves ──▶   ┌──────────────┐
  │  FeeType     │ ─────────────────▶│  Invoice     │
  │  (the rule)  │   eligible        │  (the fact)  │
  └──────────────┘   students        └──────┬───────┘
                                             │
                                        student pays
                                             │
                                             ▼
                                      ┌──────────────┐
                                      │  Payment     │
                                      └──────┬───────┘
                                             │
                                        gateway logs
                                             │
                                             ▼
                                      ┌──────────────┐
                                      │ PaymentTxn   │
                                      └──────────────┘
```

`FeeType` never changes once students start being billed against it except for
non-financial fields (description, due-date extension) — amount changes should
create a *new* `FeeType` for the next session rather than mutate history.

---

## 1. Fee Type Creation Flow

**Trigger:** Admin creates a fee type from the admin panel.

```
Admin creates a fee type (e.g. "2026/2027 Tuition — Economics, Level 100")
         │
         ▼
┌──────────────────────────────────────────────────────┐
│  FeeTypeService.create(dto)                          │
│                                                      │
│  Step 1: Validate scope combination                  │
│  ┌────────────────────────────────────────────┐      │
│  │  If category = TUITION/HOSTEL/CLEARANCE:   │      │
│  │    sessionId is required                    │      │
│  │  If category = APPLICATION/ACCEPTANCE:      │      │
│  │    sessionId, programId, levelId ignored     │      │
│  │    (these bill per-applicant, not per-cohort)│     │
│  └────────────────────────────────────────────┘      │
│                                                      │
│  Step 2: Create FeeType record (isActive: false)      │
│  Step 3: Log via AuditService (action: "CREATE")      │
└──────────────────────────────────────────────────────┘

Fee type is created INACTIVE by default. No invoices generated yet.
Admin reviews, then explicitly activates it (see Flow 2).
```

---

## 2. Bulk Invoice Generation Flow (Activation → Cohort Fees)

**Trigger:** Admin activates a `TUITION`, `HOSTEL` (mandatory), or `CLEARANCE` fee type.

```
Admin clicks "Activate" on a fee type
         │
         ▼
┌──────────────────────────────────────────────────────┐
│  FeeTypeService.activate(feeTypeId)                  │
│                                                      │
│  Step 1: Set isActive = true                          │
│  Step 2: If category requires cohort billing:         │
│  ┌────────────────────────────────────────────┐      │
│  │  Enqueue GenerateInvoicesJob(feeTypeId)     │      │
│  │  via Bull queue (async, non-blocking)       │      │
│  └────────────────────────────────────────────┘      │
│  Step 3: Return job ID + estimated cohort count       │
│           immediately (don't block the request)       │
└────────────────┬───────────────────────────────────────┘
                 │
                 ▼  (background worker)
┌──────────────────────────────────────────────────────┐
│  GenerateInvoicesProcessor.process(feeTypeId)         │
│                                                      │
│  Step 1: Load FeeType eligibility criteria             │
│  Step 2: Query matching student roster                 │
│  ┌────────────────────────────────────────────┐      │
│  │  WHERE student.status = ACTIVE               │      │
│  │    AND (feeType.programId IS NULL            │      │
│  │         OR student.programId = feeType.programId) │
│  │    AND (feeType.levelId IS NULL               │      │
│  │         OR student.currentLevelId = feeType.levelId) │
│  │    AND (feeType.studentType = ALL              │      │
│  │         OR student matches NEW/RETURNING)      │      │
│  └────────────────────────────────────────────┘      │
│                                                      │
│  Step 3: For each matching student, in batches:        │
│  ┌────────────────────────────────────────────┐      │
│  │  FeeGeneratorService.createInvoiceIfMissing(  │     │
│  │    userId, feeTypeId, sessionId)              │     │
│  │  - Try create with unique constraint           │     │
│  │  - On conflict (already exists) → skip, no error │  │
│  └────────────────────────────────────────────┘      │
│                                                      │
│  Step 4: Track progress (processed / total) for the   │
│           /fees/types/:id/generation-status endpoint   │
│  Step 5: Log via AuditService (action: "GENERATE")     │
└──────────────────────────────────────────────────────┘
```

---

## 3. Individual Milestone Generation Flow

**Trigger:** Application-fee and acceptance-fee invoices are generated on a single
event, not a cohort job.

```
Applicant starts an application
         │
         ▼
┌──────────────────────────────────────────────────────┐
│  AdmissionApplicationService.create(...)              │
│  → after saving the application, calls:                │
│    FeeGeneratorService.createInvoiceIfMissing(         │
│      userId, applicationFeeTypeId, sessionId: null)    │
└──────────────────────────────────────────────────────┘

Admin makes an admission offer
         │
         ▼
┌──────────────────────────────────────────────────────┐
│  AdmissionService.offer(applicationId)                │
│  → after creating the Admission record, calls:          │
│    FeeGeneratorService.createInvoiceIfMissing(          │
│      userId, acceptanceFeeTypeId, sessionId: null)      │
└──────────────────────────────────────────────────────┘
```

Both call the same `createInvoiceIfMissing` used by the bulk job — one generation
function, two call sites. No duplicated eligibility logic.

---

## 4. On-Demand Resolution Flow (Self-Healing Check)

**Trigger:** Student opens "My Fees," or attempts to pay, or the frontend calls
`/fees/invoices/resolve` proactively on dashboard load.

```
Student's dashboard calls POST /fees/invoices/resolve
         │
         ▼
┌──────────────────────────────────────────────────────┐
│  FeeGeneratorService.resolveForUser(userId)           │
│                                                      │
│  Step 1: Load user's current profile                   │
│  ┌────────────────────────────────────────────┐      │
│  │  If Student exists: program, level, type    │      │
│  │  Else: user-level only (pre-admission)      │      │
│  └────────────────────────────────────────────┘      │
│                                                      │
│  Step 2: Query all ACTIVE FeeTypes matching profile     │
│  Step 3: For each match, createInvoiceIfMissing(...)    │
│  Step 4: Return { created: N, invoices: [...] }         │
└──────────────────────────────────────────────────────┘

Purpose: catches students promoted mid-session, fee types activated after the
bulk job ran, or program transfers — without needing to re-run the cohort job.
Cheap operation; safe to call on every dashboard load.
```

---

## 5. Payment Initiation Flow

**Trigger:** Student clicks "Pay" on an invoice.

```
Student initiates payment
         │
         ▼
┌──────────────────────────────────────────────────────┐
│  PaymentService.initiate(userId, invoiceId, amount)   │
│                                                      │
│  Step 1: Load Invoice, verify ownership                │
│  Step 2: Validate amount                                │
│  ┌────────────────────────────────────────────┐      │
│  │  If !feeType.allowInstallments:              │      │
│  │    amount must equal outstanding balance      │      │
│  │  Else:                                        │      │
│  │    amount must be > 0 and <= outstanding      │      │
│  └────────────────────────────────────────────┘      │
│                                                      │
│  Step 3: Create Payment record (status: PENDING)        │
│  Step 4: Call PaymentGatewayModule.initializeCheckout(   │
│            amount, referenceNumber, callbackUrl)         │
│  Step 5: Return { paymentId, referenceNumber,             │
│                    checkoutUrl }                          │
│  Step 6: Log via AuditService (action: "PAYMENT_INITIATE")│
└──────────────────────────────────────────────────────┘
```

---

## 6. Payment Verification Flow (Webhook — Primary Path)

**This is the source of truth.** Client-side redirect confirmation is a UX nicety,
never trusted for actually marking a payment complete.

```
Gateway sends webhook on payment completion
         │
         ▼
┌──────────────────────────────────────────────────────┐
│  PaymentController.webhook(payload, signature)         │
│                                                      │
│  Step 1: Verify webhook signature against gateway secret │
│  ┌────────────────────────────────────────────┐      │
│  │  Reject (401) if signature invalid — do NOT  │      │
│  │  process unverified payloads                  │      │
│  └────────────────────────────────────────────┘      │
│                                                      │
│  Step 2: Look up Payment by referenceNumber              │
│  Step 3: Create PaymentTransaction record                 │
│  ┌────────────────────────────────────────────┐      │
│  │  transactionRef, amount, status, gatewayResponse │
│  │    (raw payload, for audit/debugging)         │      │
│  └────────────────────────────────────────────┘      │
│                                                      │
│  Step 4: If gateway confirms success:                    │
│  ┌────────────────────────────────────────────┐      │
│  │  a. Payment.status = COMPLETED                │      │
│  │  b. Invoice.amountPaid += payment.amount       │      │
│  │  c. Recompute Invoice.status:                  │      │
│  │     amountPaid >= amount → PAID                │      │
│  │     0 < amountPaid < amount → PARTIALLY_PAID    │      │
│  │  d. If Invoice.feeType.category = TUITION       │      │
│  │     AND Invoice.status = PAID:                  │      │
│  │       → call existing                           │      │
│  │         MoodleSyncService.onTuitionVerified(     │      │
│  │           userId) hook                           │      │
│  │  e. Trigger NotificationService                  │      │
│  │     (payment confirmation)                       │      │
│  └────────────────────────────────────────────┘      │
│  Step 5: If gateway reports failure:                     │
│  ┌────────────────────────────────────────────┐      │
│  │  Payment.status = FAILED                       │      │
│  │  Invoice unchanged                              │      │
│  └────────────────────────────────────────────┘      │
│                                                      │
│  Step 6: Log via AuditService (action: "PAYMENT_VERIFY") │
└──────────────────────────────────────────────────────┘
```

### Client-Side Verification (Secondary — UX Only)

```
Student redirected back from gateway to /fees/payments/verify/:reference
         │
         ▼
┌──────────────────────────────────────────────────────┐
│  PaymentService.verify(reference)                     │
│  → Calls gateway's server-to-server verify API          │
│  → Idempotent: if webhook already processed this        │
│    reference, returns the already-updated state          │
│  → Never marks a payment COMPLETED based solely on       │
│    the client's redirect — always re-checks with the     │
│    gateway server-side                                    │
└──────────────────────────────────────────────────────┘
```

---

## 7. Waiver Flow

**Trigger:** Admin waives an invoice (scholarship, billing error correction).

```
Admin waives an invoice
         │
         ▼
┌──────────────────────────────────────────────────────┐
│  InvoiceService.waive(invoiceId, reason)               │
│                                                      │
│  Step 1: Verify invoice is not already PAID              │
│  Step 2: Set status = WAIVED                              │
│  Step 3: Store reason in a waiver note (audit trail)       │
│  Step 4: Log via AuditService (action: "WAIVE")            │
│           — includes admin ID + reason in newValues        │
└──────────────────────────────────────────────────────┘

Note: waiving does NOT delete or cancel the invoice — it remains visible on the
student's fee history with WAIVED status, distinct from PAID or CANCELLED, so
reporting can still distinguish "forgiven" from "collected" from "voided."
```

---

## 8. Overdue Marking (Cron)

```
Daily cron job
         │
         ▼
┌──────────────────────────────────────────────────────┐
│  InvoiceService.markOverdue()                          │
│                                                      │
│  UPDATE invoices                                          │
│  SET status = 'OVERDUE'                                    │
│  WHERE status IN ('PENDING', 'PARTIALLY_PAID')             │
│    AND dueDate < NOW()                                     │
│                                                      │
│  → Triggers NotificationService for overdue reminders     │
│    (batched, respects notification preferences)            │
└──────────────────────────────────────────────────────┘
```

---

## 9. Error Handling & Retry Strategy

```
Payment or generation attempt fails
         │
         ▼
┌──────────────────────────────────────────────────────┐
│  Bulk generation job failure (per-student):             │
│  1. Log the specific student/feeType pairing that failed │
│  2. Continue processing remaining students (don't abort   │
│     the whole batch for one failure)                       │
│  3. Surface failures via generation-status endpoint         │
│                                                      │
│  Payment gateway call failure:                            │
│  1. Payment.status remains PENDING                         │
│  2. Retry webhook processing: max 3 attempts,               │
│     exponential backoff (5s, 30s, 2min)                     │
│  3. Dead-letter queue for persistent failures — surfaced    │
│     to admin via a "payments needing reconciliation" view    │
│                                                      │
│  Admin can:                                                │
│  - View failed generations: GET /fees/types/:id/generation-status │
│  - Manually retry: re-trigger activate() (idempotent)        │
│  - Manually reconcile a stuck payment via gateway dashboard  │
│    + POST /fees/payments/verify/:reference                    │
└──────────────────────────────────────────────────────┘
```

---

## 10. Cross-Module Integration Points

| Direction | Module | Interaction |
|---|---|---|
| **Consumes** | UserModule | Reads user data for invoice ownership (pre-Student) |
| **Consumes** | StudentModule | Reads program/level/type for eligibility matching |
| **Consumes** | AcademicModule | Reads session/program/level for scoping |
| **Consumes** | ConfigurationModule | Reads payment gateway keys/settings |
| **Consumes** | AuditModule | Logs all fee/invoice/payment operations |
| **Consumed by** | AdmissionModule | Triggers application-fee and acceptance-fee invoice generation |
| **Triggers** | MoodleSyncModule | Calls existing `onTuitionVerified(userId)` when a tuition invoice reaches `PAID` |
| **Triggers** | NotificationModule | Payment confirmations, overdue reminders |
