# Fee Module

Manages all student-facing fees — application, acceptance, tuition, hostel, clearance,
and other admin-defined fees — using a two-layer model: admin-defined **fee structures**
(rules) and per-student **invoices** (billed facts), settled via a **payment** and
**payment transaction** (gateway log) chain.

## Purpose

Admins define fee structures once, scoped to a session/program/level/student-type
combination (or left unscoped to apply broadly). The system resolves which students
are eligible and generates an `Invoice` per matching student — either in bulk on
activation (for cohort-wide mandatory fees like tuition) or on a triggering event
(application submitted, admission offered) for individual-milestone fees. Students
pay against their invoices through a payment gateway; partial payments, waivers, and
overdue tracking are all first-class.

## Models Owned

- **FeeType** — the fee structure / rule. Defines amount, fee category, and eligibility
  scope (session, program, level, student type). This is the admin-facing template.
- **Invoice** — the student fee record / ledger entry. One row per billed obligation:
  who owes it, how much, how much has been paid, and its status.
- **Payment** — a payment attempt against an invoice (supports partial payment; an
  invoice can have multiple payments).
- **PaymentTransaction** — the gateway-level log for a payment: transaction reference,
  raw gateway response, processing status. Many rows per payment (covers retries and
  webhook re-fires).

> **Schema note:** this document assumes the `FeeType`/`Invoice` additions from the
> architecture discussion have been applied: `FeeType.sessionId/programId/levelId/
> studentType/isMandatory/allowInstallments/defaultDueDate`, `Invoice.sessionId/
> amountPaid`, `InvoiceStatus.WAIVED`, and the `@@unique([userId, feeTypeId, sessionId])`
> constraint on `Invoice`. If these haven't been migrated yet, do that first — the
> endpoints below depend on them.

---

## Fee Category

FeeType is not a fixed enum of fee names — it's a flexible structure. In practice these
categories are the ones the university actually charges:

| Category | Session-bound? | Typical trigger |
|---|---|---|
| Application | No | Applicant starts an application |
| Acceptance | No | Admission offer is made |
| Tuition | Yes | Session activation, per program/level cohort |
| Hostel | Yes | Session activation (if mandatory) or student opt-in |
| Clearance | Usually tied to a milestone, not every session | Admin-triggered at a checkpoint (e.g. final year) |
| Other | Varies | Admin-defined, ad hoc |

## Invoice Status

| Status | Meaning |
|---|---|
| `PENDING` | Invoiced, nothing paid yet |
| `PARTIALLY_PAID` | Some payment received, balance remains |
| `PAID` | Fully paid |
| `OVERDUE` | Past `dueDate`, still unpaid or partially paid (set by cron) |
| `CANCELLED` | Invoice voided (e.g. issued in error) |
| `WAIVED` | Admin has forgiven the balance (scholarship, correction) |

---

## Endpoints

### Fee Types (Fee Structures)

| Method | Endpoint | Description | Auth |
|---|---|---|---|
| `GET` | `/fees/types` | List fee types (filterable: session, program, level, active, category) | Admin |
| `GET` | `/fees/types/:id` | Get a single fee type | Admin |
| `POST` | `/fees/types` | Create a fee type | Admin |
| `PATCH` | `/fees/types/:id` | Update a fee type (amount, dates, scope) | Admin |
| `POST` | `/fees/types/:id/activate` | Activate — triggers bulk invoice generation for mandatory/cohort fees | Admin |
| `POST` | `/fees/types/:id/deactivate` | Deactivate (does not delete existing invoices) | Admin |
| `DELETE` | `/fees/types/:id` | Delete a fee type (blocked if invoices reference it — deactivate instead) | Admin |
| `GET` | `/fees/types/:id/generation-status` | Progress of bulk invoice generation job (queued/running/done, counts) | Admin |

### Invoices (Student Fee Records)

| Method | Endpoint | Description | Auth |
|---|---|---|---|
| `GET` | `/fees/invoices` | List all invoices (filterable: status, feeTypeId, sessionId, studentId) | Admin |
| `GET` | `/fees/invoices/:id` | Get a single invoice | Admin, Owner |
| `GET` | `/fees/invoices/my` | Current user's invoices | Authenticated |
| `GET` | `/fees/invoices/student/:studentId` | All invoices for a specific student | Admin |
| `GET` | `/fees/invoices/overdue` | Overdue invoices report | Admin |
| `POST` | `/fees/invoices/resolve` | Get-or-create check — resolves active fee types against the current user's profile, creates any missing invoice | Authenticated |
| `POST` | `/fees/invoices/:id/waive` | Waive an invoice's remaining balance | Admin |
| `POST` | `/fees/invoices/:id/cancel` | Cancel an invoice | Admin |

### Payments

| Method | Endpoint | Description | Auth |
|---|---|---|---|
| `POST` | `/fees/payments/initiate` | Start a payment for an invoice (body: `invoiceId`, `amount`, `method`) — returns gateway checkout reference/URL | Authenticated |
| `POST` | `/fees/payments/verify/:reference` | Verify a payment reference with the gateway (called after redirect back) | Authenticated |
| `POST` | `/fees/payments/webhook` | Gateway webhook receiver (Paystack/Flutterwave signature-verified) | Public (signed) |
| `GET` | `/fees/payments/:id` | Get a single payment | Admin, Owner |
| `GET` | `/fees/payments/invoice/:invoiceId` | Payment history for an invoice | Admin, Owner |

### Reports

| Method | Endpoint | Description | Auth |
|---|---|---|---|
| `GET` | `/fees/reports/summary` | Collections summary (filterable by session, fee type) | Admin |
| `GET` | `/fees/reports/outstanding` | Total outstanding balance, grouped by fee type / program | Admin |

---

## Request & Response Types

### `POST /fees/types`

**Request Body (`CreateFeeTypeDto`):**
```ts
{
  name: string;
  description?: string;
  category: "APPLICATION" | "ACCEPTANCE" | "TUITION" | "HOSTEL" | "CLEARANCE" | "OTHER";
  amount: number;
  sessionId?: number;          // omit for non-session-bound fees (application, acceptance)
  programId?: number;          // omit = applies to all programs
  levelId?: number;            // omit = applies to all levels
  studentType?: "NEW" | "RETURNING" | "ALL"; // default ALL
  isMandatory?: boolean;       // default true
  allowInstallments?: boolean; // default false
  defaultDueDate?: string;     // ISO date
}
```

**Response: `201 Created`**
```ts
{
  id: number;
  name: string;
  category: string;
  amount: string;              // Decimal serialized as string
  sessionId: number | null;
  programId: number | null;
  levelId: number | null;
  studentType: "NEW" | "RETURNING" | "ALL";
  isMandatory: boolean;
  allowInstallments: boolean;
  isActive: boolean;
  createdAt: string;
}
```

---

### `POST /fees/types/:id/activate`

**Response: `202 Accepted`** (generation runs as a background job)
```ts
{
  feeTypeId: number;
  jobId: string;
  eligibleStudentCount: number;  // estimated cohort size at trigger time
  status: "QUEUED";
}
```

---

### `GET /fees/invoices/my`

**Response: `200 OK`**
```ts
{
  data: {
    id: number;
    invoiceNumber: string;
    feeType: { id: number; name: string; category: string };
    amount: string;
    amountPaid: string;
    dueDate: string;
    status: "PENDING" | "PARTIALLY_PAID" | "PAID" | "OVERDUE" | "CANCELLED" | "WAIVED";
    session: { id: number; name: string } | null;
  }[];
}
```

---

### `POST /fees/invoices/resolve`

**Response: `200 OK`**
```ts
{
  created: number;    // how many new invoices were generated by this check
  invoices: InvoiceResponse[]; // full current list of the user's invoices
}
```

---

### `POST /fees/payments/initiate`

**Request Body:**
```ts
{
  invoiceId: number;
  amount: number;              // supports partial payment if feeType.allowInstallments
  method: "BANK_TRANSFER" | "CARD" | "USSD" | "GATEWAY";
}
```

**Response: `201 Created`**
```ts
{
  paymentId: number;
  referenceNumber: string;
  checkoutUrl: string | null;  // gateway redirect URL, null for offline methods
  status: "PENDING";
}
```

---

### `POST /fees/payments/verify/:reference`

**Response: `200 OK`**
```ts
{
  paymentId: number;
  status: "COMPLETED" | "FAILED" | "PENDING";
  invoice: {
    id: number;
    amountPaid: string;
    status: "PENDING" | "PARTIALLY_PAID" | "PAID" | "OVERDUE";
  };
}
```

---

### `GET /fees/reports/outstanding`

**Response: `200 OK`**
```ts
{
  data: {
    feeTypeId: number;
    feeTypeName: string;
    totalInvoiced: string;
    totalPaid: string;
    totalOutstanding: string;
    studentCount: number;
  }[];
}
```

---

## Fee Category → Trigger Mapping

| Fee category | Generation trigger | Bulk or individual |
|---|---|---|
| Application | Applicant starts an application | Individual (event-triggered) |
| Acceptance | Admission offer created | Individual (event-triggered) |
| Tuition | Fee type activated by admin | Bulk (cohort-matched) |
| Hostel (mandatory) | Fee type activated by admin | Bulk (cohort-matched) |
| Hostel (optional) | Student requests a room | Individual (event-triggered) |
| Clearance | Admin triggers at a milestone | Bulk, scoped to milestone cohort |
| Other | Depends on admin configuration | Either — configurable per fee type |

> **Important:** Students are only invoiced for a fee once eligibility criteria are
> met. Tuition, for instance, should never be generated for a student before they
> have an active `Student` record (i.e. before admission is accepted) — the
> eligibility resolver must check this, not just program/level/session match.

---

## Notes for Developers

- **Idempotency**: invoice generation (bulk or individual) must never create a
  duplicate. Enforce this at the DB level via `@@unique([userId, feeTypeId, sessionId])`
  on `Invoice`, and treat constraint violations during generation as "already exists,
  skip" rather than an error.
- **Partial payments**: `Invoice.amountPaid` is a denormalized roll-up, updated
  transactionally whenever a `Payment` completes. Don't compute it live from
  `SUM(Payment.amount)` on every read — that doesn't scale to list views.
- **Background jobs**: bulk generation on fee-type activation runs via the same
  Bull queue pattern used elsewhere in this codebase (see Moodle Sync module).
  Max retries: 3, exponential backoff, dead-letter queue for persistent failures.
- **Payment gateway integration**: `Payment.referenceNumber` is the portal-side
  reference; `PaymentTransaction.transactionRef` is what the gateway returns.
  Always verify via the gateway's server-to-server API on webhook receipt — never
  trust a client-side "payment successful" redirect alone.
- **Audit logging**: all fee type CRUD, invoice waivers/cancellations, and payment
  status changes are logged via `AuditService` with `entityType` set to `"FeeType"`,
  `"Invoice"`, or `"Payment"` respectively.
- **Downstream triggers**: a `PAID` tuition invoice for a `Student` fires
  `MoodleSyncService.onTuitionVerified(userId)` — this integration point already
  exists (see `moodle_sync_workflow.md` §5). Don't duplicate that trigger logic in
  this module; call the existing hook.
- **Overdue marking**: a cron job (frequency matches your existing cron pattern,
  e.g. daily) flags `PENDING`/`PARTIALLY_PAID` invoices past `dueDate` as `OVERDUE`.
  This does not block payment — an overdue invoice can still be paid.
