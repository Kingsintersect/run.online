# Fee Module — Frontend UI Implementation Guide

> **Audience:** UI developer + Claude (Claude Code / claude.ai).
> **Purpose:** Instructs Claude on the exact UI features, structure, and conventions
> to implement the `fee-management` frontend module. Read in full before generating
> any code. Follows the rules in the repo's root `CLAUDE.md` without restatement.
>
> **Backend reference docs this is derived from:** `fee_module_README.md` (endpoint
> reference) and `fee_module_workflow.md` (internal backend flow). This document is
> the frontend counterpart — UI structure, features, and interaction design only.

---

## Table of Contents

1. [Module Summary](#1-module-summary)
2. [UI Features by Audience](#2-ui-features-by-audience)
3. [Directory Structure](#3-directory-structure)
4. [Zod Schemas & Types](#4-zod-schemas--types)
5. [API Service Layer](#5-api-service-layer)
6. [React Query Hooks & Query Keys](#6-react-query-hooks--query-keys)
7. [Zustand UI Store](#7-zustand-ui-store)
8. [Routes & Pages](#8-routes--pages)
9. [Components — Detailed Feature Spec](#9-components--detailed-feature-spec)
10. [Payment Flow (Critical UX Path)](#10-payment-flow-critical-ux-path)
11. [Auth & Permission Gating](#11-auth--permission-gating)
12. [Error Handling & Loading States](#12-error-handling--loading-states)
13. [Naming Conventions Recap](#13-naming-conventions-recap)
14. [Implementation Checklist](#14-implementation-checklist)
15. [Open Questions / Assumptions to Confirm](#15-open-questions--assumptions-to-confirm)

---

## 1. Module Summary

The `fee-management` module has two distinct UI surfaces built on the same data:

- **Admin surface** — define fee types (the rule/template), activate them (triggers
  generation), monitor generation progress, view collections/outstanding reports,
  waive or cancel individual invoices.
- **Student surface** — view "My Fees" (all invoices with status), pay outstanding
  balances (full or partial where allowed), view payment history/receipts.

This module lives at `src/modules/fee-management/`, per `CLAUDE.md` §4 (Global vs
Module scope). Nothing here belongs in global `/lib`, `/hooks`, or `/components`
unless reused by 2+ modules.

**Two backend resources, two frontend feature sets, one module:** fee types and
invoices are different objects with different audiences, but they're tightly
coupled (an invoice always references a fee type) — keeping them in one module with
sub-folders (rather than splitting into `fee-types` and `invoices` modules) avoids
awkward cross-module imports for what's fundamentally one domain.

---

## 2. UI Features by Audience

### Admin features (the actual UI work to build)

1. **Fee type builder** — form to create a fee type: name, category, amount, scope
   (session/program/level dropdowns), student type, mandatory toggle, installments
   toggle, due date. This is the highest-value screen — get the scope-selection UX
   right (see §9.1).
2. **Fee type list/table** — all fee types, filterable by session/category/active
   status, with an Activate/Deactivate action and a link into generation status.
3. **Generation status view** — after activating a fee type, show live progress
   (queued → running → done, with counts). Poll or use a progress indicator.
4. **Invoice management table (admin)** — all invoices, filterable by status, fee
   type, session, searchable by student. Row actions: view detail, waive, cancel.
5. **Collections/outstanding report** — summary view, grouped by fee type, showing
   total invoiced / paid / outstanding / student count. This is what an admin opens
   to answer "how much have we collected this session."
6. **Overdue report** — dedicated view filtered to `OVERDUE` invoices, for follow-up.

### Student features

7. **"My Fees" page** — list of the student's own invoices, grouped or filterable
   by status, each showing amount, amount paid, balance, due date, and a Pay button
   for anything not `PAID`/`WAIVED`/`CANCELLED`.
8. **Payment flow** — click Pay → (if partial allowed) enter amount → redirect to
   gateway checkout → return → verification state → success/failure feedback.
9. **Payment history / receipt view** — past payments per invoice, with reference
   numbers and dates (a lightweight "receipt" — not a formal PDF unless requested).

---

## 3. Directory Structure

```
src/
├── modules/
│   └── fee-management/
│       ├── types/
│       │   └── index.ts                          # z.infer<> types only
│       ├── schemas/
│       │   ├── common.schema.ts                   # FeeCategory, InvoiceStatus, StudentType enums
│       │   ├── fee-type.schema.ts                  # CreateFeeTypeDto, FeeTypeResponse
│       │   ├── invoice.schema.ts                   # InvoiceResponse, ResolveResponse
│       │   └── payment.schema.ts                   # InitiatePaymentDto, PaymentResponse, VerifyResponse
│       ├── services/
│       │   └── fee-management.service.ts           # ALL endpoints, via apiClient, one file
│       ├── hooks/
│       │   ├── query-keys.ts
│       │   ├── use-fee-types.ts                     # list, detail
│       │   ├── use-invoices.ts                      # my invoices, admin list, by-student, overdue
│       │   ├── use-fee-reports.ts                   # summary, outstanding
│       │   ├── use-fee-mutations.ts                 # create/update/activate/waive/cancel
│       │   └── use-payment.ts                       # initiate, verify (separate — different lifecycle)
│       ├── store/
│       │   └── fee-management-ui.store.ts           # active tab, table filters, payment modal state
│       └── components/
│           ├── shared/
│           │   ├── invoice-status-badge.tsx          # PENDING/PARTIALLY_PAID/PAID/OVERDUE/CANCELLED/WAIVED
│           │   ├── fee-category-badge.tsx
│           │   └── currency-display.tsx              # consistent ₦ formatting
│           ├── admin/
│           │   ├── fee-type-form.tsx                 # create/edit, includes scope selector
│           │   ├── fee-type-scope-selector.tsx        # session/program/level/student-type combo — see §9.1
│           │   ├── fee-type-table.tsx
│           │   ├── generation-status-panel.tsx
│           │   ├── invoice-admin-table.tsx
│           │   ├── invoice-detail-drawer.tsx          # view + waive/cancel actions
│           │   ├── waive-invoice-dialog.tsx
│           │   ├── collections-report.tsx
│           │   └── overdue-report.tsx
│           └── student/
│               ├── my-fees-list.tsx
│               ├── invoice-card.tsx                   # single invoice with Pay button
│               ├── payment-modal.tsx                   # amount entry (if installments) + confirm
│               ├── payment-status-panel.tsx            # post-redirect verification state
│               └── payment-history.tsx
│
└── app/
    ├── (dashboard)/
    │   └── admin/
    │       └── (routes)/
    │           └── fees/
    │               ├── page.tsx                        # overview: quick stats + links
    │               ├── types/
    │               │   ├── page.tsx                     # fee type list
    │               │   ├── new/
    │               │   │   └── page.tsx                 # fee type builder
    │               │   └── [id]/
    │               │       ├── page.tsx                 # edit + generation status
    │               │       └── generation-status/
    │               │           └── page.tsx
    │               ├── invoices/
    │               │   └── page.tsx                      # admin invoice table
    │               └── reports/
    │                   ├── collections/
    │                   │   └── page.tsx
    │                   └── overdue/
    │                       └── page.tsx
    │
    └── (root)/
        └── fees/
            ├── page.tsx                                  # student "My Fees"
            ├── [invoiceId]/
            │   └── page.tsx                               # invoice detail + pay
            └── payment/
                └── callback/
                    └── page.tsx                            # gateway redirect landing page
```

---

## 4. Zod Schemas & Types

### 4.1 `common.schema.ts`

```ts
import { z } from 'zod'

export const FeeCategorySchema = z.enum([
  'APPLICATION', 'ACCEPTANCE', 'TUITION', 'HOSTEL', 'CLEARANCE', 'OTHER',
])

export const InvoiceStatusSchema = z.enum([
  'PENDING', 'PARTIALLY_PAID', 'PAID', 'OVERDUE', 'CANCELLED', 'WAIVED',
])

export const StudentTypeSchema = z.enum(['NEW', 'RETURNING', 'ALL'])

export const PaymentMethodSchema = z.enum(['BANK_TRANSFER', 'CARD', 'USSD', 'GATEWAY'])
export const PaymentStatusSchema = z.enum(['PENDING', 'COMPLETED', 'FAILED', 'REFUNDED'])
```

### 4.2 `fee-type.schema.ts`

```ts
import { z } from 'zod'
import { FeeCategorySchema, StudentTypeSchema } from './common.schema'

export const CreateFeeTypeDtoSchema = z.object({
  name: z.string().min(3).max(100),
  description: z.string().max(1000).optional(),
  category: FeeCategorySchema,
  amount: z.coerce.number().positive(),
  sessionId: z.number().int().positive().optional(),
  programId: z.number().int().positive().optional(),
  levelId: z.number().int().positive().optional(),
  studentType: StudentTypeSchema.default('ALL'),
  isMandatory: z.boolean().default(true),
  allowInstallments: z.boolean().default(false),
  defaultDueDate: z.string().datetime().optional(),
}).superRefine((data, ctx) => {
  const cohortCategories = ['TUITION', 'HOSTEL', 'CLEARANCE']
  if (cohortCategories.includes(data.category) && !data.sessionId) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      path: ['sessionId'],
      message: 'Session is required for tuition, hostel, and clearance fees',
    })
  }
})

export const FeeTypeResponseSchema = z.object({
  id: z.number(),
  name: z.string(),
  description: z.string().nullable(),
  category: FeeCategorySchema,
  amount: z.string(), // Decimal serialized as string — parse with Number() only for display math
  sessionId: z.number().nullable(),
  session: z.object({ id: z.number(), name: z.string() }).nullable(),
  programId: z.number().nullable(),
  program: z.object({ id: z.number(), name: z.string() }).nullable(),
  levelId: z.number().nullable(),
  level: z.object({ id: z.number(), name: z.string() }).nullable(),
  studentType: StudentTypeSchema,
  isMandatory: z.boolean(),
  allowInstallments: z.boolean(),
  isActive: z.boolean(),
  createdAt: z.string().datetime(),
})

export const ActivateFeeTypeResponseSchema = z.object({
  feeTypeId: z.number(),
  jobId: z.string(),
  eligibleStudentCount: z.number(),
  status: z.literal('QUEUED'),
})

export const GenerationStatusResponseSchema = z.object({
  feeTypeId: z.number(),
  jobId: z.string(),
  status: z.enum(['QUEUED', 'RUNNING', 'DONE', 'FAILED']),
  processed: z.number(),
  total: z.number(),
  failures: z.number(),
})
```

### 4.3 `invoice.schema.ts`

```ts
import { z } from 'zod'
import { InvoiceStatusSchema } from './common.schema'

export const InvoiceResponseSchema = z.object({
  id: z.number(),
  invoiceNumber: z.string(),
  feeType: z.object({ id: z.number(), name: z.string(), category: z.string() }),
  amount: z.string(),
  amountPaid: z.string(),
  dueDate: z.string().datetime(),
  status: InvoiceStatusSchema,
  session: z.object({ id: z.number(), name: z.string() }).nullable(),
  student: z.object({
    id: z.number(),
    matricNumber: z.string(),
    fullName: z.string(),
  }).optional(), // present on admin list/detail views, absent on /my
})

export const InvoiceListResponseSchema = z.object({ data: z.array(InvoiceResponseSchema) })

export const ResolveInvoicesResponseSchema = z.object({
  created: z.number(),
  invoices: z.array(InvoiceResponseSchema),
})

export const WaiveInvoiceDtoSchema = z.object({
  reason: z.string().min(5).max(500),
})
```

### 4.4 `payment.schema.ts`

```ts
import { z } from 'zod'
import { PaymentMethodSchema, PaymentStatusSchema } from './common.schema'

export const InitiatePaymentDtoSchema = z.object({
  invoiceId: z.number().int().positive(),
  amount: z.coerce.number().positive(),
  method: PaymentMethodSchema,
})

export const InitiatePaymentResponseSchema = z.object({
  paymentId: z.number(),
  referenceNumber: z.string(),
  checkoutUrl: z.string().url().nullable(),
  status: z.literal('PENDING'),
})

export const VerifyPaymentResponseSchema = z.object({
  paymentId: z.number(),
  status: PaymentStatusSchema,
  invoice: z.object({
    id: z.number(),
    amountPaid: z.string(),
    status: z.enum(['PENDING', 'PARTIALLY_PAID', 'PAID', 'OVERDUE']),
  }),
})

export const PaymentHistoryResponseSchema = z.object({
  data: z.array(z.object({
    id: z.number(),
    amount: z.string(),
    method: PaymentMethodSchema,
    referenceNumber: z.string(),
    status: PaymentStatusSchema,
    paidAt: z.string().datetime(),
  })),
})
```

### 4.5 `types/index.ts`

```ts
import { z } from 'zod'
import * as Common from '../schemas/common.schema'
import * as FeeType from '../schemas/fee-type.schema'
import * as Invoice from '../schemas/invoice.schema'
import * as Payment from '../schemas/payment.schema'

export type FeeCategory = z.infer<typeof Common.FeeCategorySchema>
export type InvoiceStatus = z.infer<typeof Common.InvoiceStatusSchema>
export type StudentType = z.infer<typeof Common.StudentTypeSchema>

export type CreateFeeTypeDto = z.infer<typeof FeeType.CreateFeeTypeDtoSchema>
export type FeeTypeResponse = z.infer<typeof FeeType.FeeTypeResponseSchema>
export type GenerationStatusResponse = z.infer<typeof FeeType.GenerationStatusResponseSchema>

export type InvoiceResponse = z.infer<typeof Invoice.InvoiceResponseSchema>
export type ResolveInvoicesResponse = z.infer<typeof Invoice.ResolveInvoicesResponseSchema>

export type InitiatePaymentDto = z.infer<typeof Payment.InitiatePaymentDtoSchema>
export type InitiatePaymentResponse = z.infer<typeof Payment.InitiatePaymentResponseSchema>
export type VerifyPaymentResponse = z.infer<typeof Payment.VerifyPaymentResponseSchema>
```

---

## 5. API Service Layer

```ts
import { apiClient } from '@/lib/clients/apiClient'
import type {
  CreateFeeTypeDto, FeeTypeResponse, GenerationStatusResponse,
  InvoiceResponse, ResolveInvoicesResponse,
  InitiatePaymentDto, InitiatePaymentResponse, VerifyPaymentResponse,
} from '../types'

const BASE = '/fees'

export const feeManagementService = {
  // ---------- Fee Types ----------
  listFeeTypes: (filters?: { sessionId?: number; category?: string; isActive?: boolean }) =>
    apiClient.get<FeeTypeResponse[]>(`${BASE}/types`, { params: filters }),
  getFeeType: (id: number) => apiClient.get<FeeTypeResponse>(`${BASE}/types/${id}`),
  createFeeType: (dto: CreateFeeTypeDto) => apiClient.post<FeeTypeResponse>(`${BASE}/types`, dto),
  updateFeeType: (id: number, dto: Partial<CreateFeeTypeDto>) => apiClient.patch<FeeTypeResponse>(`${BASE}/types/${id}`, dto),
  activateFeeType: (id: number) => apiClient.post(`${BASE}/types/${id}/activate`),
  deactivateFeeType: (id: number) => apiClient.post(`${BASE}/types/${id}/deactivate`),
  deleteFeeType: (id: number) => apiClient.delete(`${BASE}/types/${id}`),
  getGenerationStatus: (id: number) => apiClient.get<GenerationStatusResponse>(`${BASE}/types/${id}/generation-status`),

  // ---------- Invoices ----------
  listInvoices: (filters?: { status?: string; feeTypeId?: number; sessionId?: number; studentId?: number }) =>
    apiClient.get<{ data: InvoiceResponse[] }>(`${BASE}/invoices`, { params: filters }),
  getInvoice: (id: number) => apiClient.get<InvoiceResponse>(`${BASE}/invoices/${id}`),
  getMyInvoices: () => apiClient.get<{ data: InvoiceResponse[] }>(`${BASE}/invoices/my`),
  getStudentInvoices: (studentId: number) => apiClient.get<{ data: InvoiceResponse[] }>(`${BASE}/invoices/student/${studentId}`),
  getOverdueInvoices: () => apiClient.get<{ data: InvoiceResponse[] }>(`${BASE}/invoices/overdue`),
  resolveInvoices: () => apiClient.post<ResolveInvoicesResponse>(`${BASE}/invoices/resolve`),
  waiveInvoice: (id: number, reason: string) => apiClient.post(`${BASE}/invoices/${id}/waive`, { reason }),
  cancelInvoice: (id: number) => apiClient.post(`${BASE}/invoices/${id}/cancel`),

  // ---------- Payments ----------
  initiatePayment: (dto: InitiatePaymentDto) => apiClient.post<InitiatePaymentResponse>(`${BASE}/payments/initiate`, dto),
  verifyPayment: (reference: string) => apiClient.post<VerifyPaymentResponse>(`${BASE}/payments/verify/${reference}`),
  getPayment: (id: number) => apiClient.get(`${BASE}/payments/${id}`),
  getInvoicePaymentHistory: (invoiceId: number) => apiClient.get(`${BASE}/payments/invoice/${invoiceId}`),

  // ---------- Reports ----------
  getCollectionsSummary: (filters?: { sessionId?: number; feeTypeId?: number }) =>
    apiClient.get(`${BASE}/reports/summary`, { params: filters }),
  getOutstandingReport: () => apiClient.get(`${BASE}/reports/outstanding`),
}
```

> Validate responses against their Zod schema at the service boundary before
> returning, per `CLAUDE.md` §4.

---

## 6. React Query Hooks & Query Keys

### 6.1 `query-keys.ts`

```ts
export const feeKeys = {
  all: ['fee-management'] as const,

  feeTypes: (filters?: Record<string, unknown>) => [...feeKeys.all, 'fee-types', filters] as const,
  feeType: (id: number) => [...feeKeys.all, 'fee-types', id] as const,
  generationStatus: (id: number) => [...feeKeys.all, 'fee-types', id, 'generation-status'] as const,

  invoices: (filters?: Record<string, unknown>) => [...feeKeys.all, 'invoices', filters] as const,
  invoice: (id: number) => [...feeKeys.all, 'invoices', id] as const,
  myInvoices: () => [...feeKeys.all, 'invoices', 'my'] as const,
  studentInvoices: (studentId: number) => [...feeKeys.all, 'invoices', 'student', studentId] as const,
  overdueInvoices: () => [...feeKeys.all, 'invoices', 'overdue'] as const,

  paymentHistory: (invoiceId: number) => [...feeKeys.all, 'payments', 'invoice', invoiceId] as const,

  collectionsSummary: (filters?: Record<string, unknown>) => [...feeKeys.all, 'reports', 'collections', filters] as const,
  outstandingReport: () => [...feeKeys.all, 'reports', 'outstanding'] as const,
} as const
```

### 6.2 `use-fee-types.ts`

```ts
import { useQuery } from '@tanstack/react-query'
import { feeManagementService } from '../services/fee-management.service'
import { feeKeys } from './query-keys'

export function useFeeTypes(filters?: { sessionId?: number; category?: string; isActive?: boolean }) {
  return useQuery({
    queryKey: feeKeys.feeTypes(filters),
    queryFn: () => feeManagementService.listFeeTypes(filters),
  })
}

export function useFeeType(id: number) {
  return useQuery({
    queryKey: feeKeys.feeType(id),
    queryFn: () => feeManagementService.getFeeType(id),
    enabled: !!id,
  })
}

export function useGenerationStatus(id: number, enabled: boolean) {
  return useQuery({
    queryKey: feeKeys.generationStatus(id),
    queryFn: () => feeManagementService.getGenerationStatus(id),
    enabled,
    refetchInterval: (query) => {
      const status = query.state.data?.status
      return status === 'QUEUED' || status === 'RUNNING' ? 2000 : false // poll while in-flight, stop when done/failed
    },
  })
}
```

### 6.3 `use-invoices.ts`

```ts
import { useQuery } from '@tanstack/react-query'
import { feeManagementService } from '../services/fee-management.service'
import { feeKeys } from './query-keys'

export function useMyInvoices() {
  return useQuery({
    queryKey: feeKeys.myInvoices(),
    queryFn: feeManagementService.getMyInvoices,
  })
}

export function useInvoices(filters?: { status?: string; feeTypeId?: number; sessionId?: number; studentId?: number }) {
  return useQuery({
    queryKey: feeKeys.invoices(filters),
    queryFn: () => feeManagementService.listInvoices(filters),
  })
}

export function useOverdueInvoices() {
  return useQuery({
    queryKey: feeKeys.overdueInvoices(),
    queryFn: feeManagementService.getOverdueInvoices,
  })
}
```

### 6.4 `use-fee-mutations.ts`

```ts
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { feeManagementService } from '../services/fee-management.service'
import { feeKeys } from './query-keys'
import type { CreateFeeTypeDto } from '../types'

export function useCreateFeeType() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (dto: CreateFeeTypeDto) => feeManagementService.createFeeType(dto),
    onSuccess: () => qc.invalidateQueries({ queryKey: feeKeys.feeTypes() }),
  })
}

export function useActivateFeeType() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: number) => feeManagementService.activateFeeType(id),
    onSuccess: (_data, id) => {
      qc.invalidateQueries({ queryKey: feeKeys.feeType(id) })
      qc.invalidateQueries({ queryKey: feeKeys.generationStatus(id) })
    },
  })
}

export function useWaiveInvoice() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ id, reason }: { id: number; reason: string }) => feeManagementService.waiveInvoice(id, reason),
    onSuccess: (_data, { id }) => {
      qc.invalidateQueries({ queryKey: feeKeys.invoice(id) })
      qc.invalidateQueries({ queryKey: feeKeys.invoices() })
    },
  })
}

export function useCancelInvoice() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: number) => feeManagementService.cancelInvoice(id),
    onSuccess: (_data, id) => {
      qc.invalidateQueries({ queryKey: feeKeys.invoice(id) })
      qc.invalidateQueries({ queryKey: feeKeys.invoices() })
    },
  })
}
```

### 6.5 `use-payment.ts` (separate file — different lifecycle from CRUD mutations)

```ts
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { feeManagementService } from '../services/fee-management.service'
import { feeKeys } from './query-keys'

export function useInitiatePayment() {
  return useMutation({
    mutationFn: feeManagementService.initiatePayment,
    // No cache invalidation here — invoice status only changes after verification,
    // not initiation. See useVerifyPayment.
  })
}

export function useVerifyPayment() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (reference: string) => feeManagementService.verifyPayment(reference),
    onSuccess: (data) => {
      qc.invalidateQueries({ queryKey: feeKeys.myInvoices() })
      qc.invalidateQueries({ queryKey: feeKeys.invoice(data.invoice.id) })
      qc.invalidateQueries({ queryKey: feeKeys.paymentHistory(data.invoice.id) })
    },
  })
}
```

---

## 7. Zustand UI Store

```ts
import { create } from 'zustand'

interface FeeManagementUiState {
  // Admin table filters (UI state, not server data)
  invoiceTableFilters: { status?: string; feeTypeId?: number; sessionId?: number }
  setInvoiceTableFilters: (filters: { status?: string; feeTypeId?: number; sessionId?: number }) => void

  feeTypeTableFilters: { sessionId?: number; category?: string; isActive?: boolean }
  setFeeTypeTableFilters: (filters: { sessionId?: number; category?: string; isActive?: boolean }) => void

  // Payment modal (student flow)
  paymentModalInvoiceId: number | null
  openPaymentModal: (invoiceId: number) => void
  closePaymentModal: () => void
}

export const useFeeManagementUiStore = create<FeeManagementUiState>((set) => ({
  invoiceTableFilters: {},
  setInvoiceTableFilters: (filters) => set({ invoiceTableFilters: filters }),

  feeTypeTableFilters: {},
  setFeeTypeTableFilters: (filters) => set({ feeTypeTableFilters: filters }),

  paymentModalInvoiceId: null,
  openPaymentModal: (invoiceId) => set({ paymentModalInvoiceId: invoiceId }),
  closePaymentModal: () => set({ paymentModalInvoiceId: null }),
}))
```

---

## 8. Routes & Pages

All `app/` files are thin shells — import module components, compose, nothing else.

| Route | Purpose | Guard |
|---|---|---|
| `/admin/fees` | Overview — quick stats, links to sub-sections | Admin |
| `/admin/fees/types` | Fee type list | Admin |
| `/admin/fees/types/new` | Fee type builder (create) | Admin |
| `/admin/fees/types/:id` | Fee type edit + generation status | Admin |
| `/admin/fees/invoices` | Admin invoice management table | Admin |
| `/admin/fees/reports/collections` | Collections summary report | Admin |
| `/admin/fees/reports/overdue` | Overdue report | Admin |
| `/fees` | Student: "My Fees" | `useRoleGuard([STUDENT])` or existing student-dashboard permission |
| `/fees/:invoiceId` | Invoice detail + pay | Student, owner-checked |
| `/fees/payment/callback` | Gateway redirect landing page — calls verify, shows result | Authenticated |

### Example — `app/(root)/fees/page.tsx`

```tsx
'use client'

import { useEffect } from 'react'
import { MyFeesList } from '@/modules/fee-management/components/student/my-fees-list'
import { feeManagementService } from '@/modules/fee-management/services/fee-management.service'

export default function MyFeesPage() {
  // Fire the self-healing resolve check on page load (see fee_module_workflow.md §4)
  useEffect(() => {
    feeManagementService.resolveInvoices()
  }, [])

  return <MyFeesList />
}
```

### Example — `app/(root)/fees/payment/callback/page.tsx`

```tsx
'use client'

import { useSearchParams } from 'next/navigation'
import { PaymentStatusPanel } from '@/modules/fee-management/components/student/payment-status-panel'

export default function PaymentCallbackPage() {
  const reference = useSearchParams().get('reference')
  return <PaymentStatusPanel reference={reference} />
}
```

---

## 9. Components — Detailed Feature Spec

### 9.1 `fee-type-scope-selector.tsx` — the highest-care component in this module

This is what makes the fee dynamic-by-level workflow actually usable for the admin.
Get this right and the rest of the module is straightforward CRUD.

**Behavior:**
- Category dropdown first (`APPLICATION` / `ACCEPTANCE` / `TUITION` / `HOSTEL` /
  `CLEARANCE` / `OTHER`).
- If category is `TUITION`, `HOSTEL`, or `CLEARANCE` → show Session select
  (**required**, per the backend validation in `CreateFeeTypeDtoSchema`).
- If category is `APPLICATION` or `ACCEPTANCE` → hide Session/Program/Level entirely;
  these fees are billed per-applicant on an event, not per-cohort (see
  `fee_module_workflow.md` §3). Showing scope fields for these would mislead the
  admin into thinking they need to configure a cohort match that doesn't apply.
- Program select — always optional, labeled "All programs" when empty.
- Level select — always optional, labeled "All levels" when empty. Only enable
  after a Program is chosen if levels are program-scoped in this schema (confirm
  against `Level` model — currently global in the Prisma schema, so Level is
  independently selectable, not nested under Program).
- Student Type — segmented control or select: New / Returning / All (default All).
- After scope is set, show a **live eligible-student-count preview** — call a
  lightweight count endpoint (or reuse `/fees/invoices/resolve`-style logic
  server-side, exposed as a preview) so the admin sees "≈340 students" before
  submitting. This is optional if the backend doesn't expose a preview endpoint —
  flag it as a nice-to-have in that case (see §15).

### 9.2 `generation-status-panel.tsx`

- Shown after activation. Polls `useGenerationStatus` (2s interval while
  `QUEUED`/`RUNNING`, stops on `DONE`/`FAILED`).
- Progress bar: `processed / total`.
- On `FAILED` or `failures > 0`, show a warning with the failure count and a link
  to `AuditLog` filtered to this fee type (if an audit log viewer exists elsewhere
  in the codebase — otherwise just show the count with a "contact backend" note).

### 9.3 `invoice-card.tsx` (student-facing)

- Shows: fee type name + category badge, amount, amount paid (if partial), balance
  remaining, due date, status badge.
- Pay button: hidden entirely for `PAID`, `WAIVED`, `CANCELLED`. Shown for
  `PENDING`, `PARTIALLY_PAID`, `OVERDUE`.
- `OVERDUE` gets a visually distinct treatment (not just the badge color) — e.g. a
  left border accent or subtle background tint — since this is the state that most
  needs the student's attention.

### 9.4 `payment-modal.tsx`

- If `feeType.allowInstallments === false`: no amount input, just a confirm showing
  the full outstanding balance.
- If `true`: amount input, validated client-side against
  `0 < amount <= outstandingBalance` before calling `useInitiatePayment` (per
  `CLAUDE.md` §4 — Zod validation on every payload; reuse `InitiatePaymentDtoSchema`
  with a dynamic `.max()` refinement for the balance check).
- On success: redirect the browser to `checkoutUrl` (full navigation, not a fetch —
  this is a gateway-hosted page). If `checkoutUrl` is null (offline method like bank
  transfer), show instructions inline instead of redirecting.

### 9.5 `payment-status-panel.tsx`

- Reads `reference` from the URL query param.
- Calls `useVerifyPayment` on mount.
- Three states: verifying (spinner), success (checkmark + updated balance + link
  back to "My Fees"), failed (clear message + retry-pay link, not a dead end).

### 9.6 `collections-report.tsx` / `overdue-report.tsx`

- Standard table/summary views. No special interaction — read-only reporting.
  Reuse `sync-status-badge`-style patterns from other modules for consistency if a
  shared badge component convention already exists in `/components`.

---

## 10. Payment Flow (Critical UX Path)

```
Student clicks "Pay" on invoice-card
         │
         ▼
Open payment-modal (Zustand: openPaymentModal(invoiceId))
         │
         ▼
[If installments allowed] Student enters amount → client-side Zod validation
         │
         ▼
useInitiatePayment.mutate({ invoiceId, amount, method })
         │
         ▼
Response: { checkoutUrl }
         │
         ├── checkoutUrl present → window.location.href = checkoutUrl
         │                          (full redirect to gateway-hosted page)
         │
         └── checkoutUrl null → show offline payment instructions inline
                                  (e.g. bank transfer details), no redirect

[Student completes payment on gateway]
         │
         ▼
Gateway redirects back to /fees/payment/callback?reference=xxx
         │
         ▼
payment-status-panel mounts → useVerifyPayment.mutate(reference)
         │
         ▼
Backend re-checks with gateway server-side (see fee_module_workflow.md §6)
         │
         ▼
Show success/failure → invalidate myInvoices + invoice + paymentHistory queries
         │
         ▼
Student navigates back to /fees — sees updated status without a manual refresh
```

**Do not** mark anything paid client-side based on the redirect alone — the panel
must wait for `useVerifyPayment`'s response, which reflects the backend's
server-to-server gateway check, not the URL params.

---

## 11. Auth & Permission Gating

Per `CLAUDE.md` §5 — check permission, not role, for UI-level gating.

**Proposed permission resource:** `fee-management`, actions: `view`, `manage`
(covers create/update/activate/waive/cancel — a single admin-level action is
reasonable here since these are all "back office" operations without meaningfully
different risk levels, unlike moodle-sync's push/pull split).

```tsx
useRoleGuard([UserRole.ADMIN, UserRole.BURSARY, UserRole.SUPER_ADMIN]) // route level

<PermissionGate require={{ resource: 'fee-management', action: 'manage' }}>
  <WaiveInvoiceDialog />
</PermissionGate>
```

Student-facing routes (`/fees`, `/fees/:invoiceId`, `/fees/payment/callback`) are
gated by whatever governs general student dashboard access — not a `fee-management`
permission, since students only ever view/pay their own invoices, never manage
fee types.

**Ownership check:** `/fees/:invoiceId` must verify the invoice belongs to the
logged-in user (or their linked student record) before rendering payment
actions — don't rely solely on the backend to reject; show a clear "not found" state
client-side too, to avoid a confusing blank page if a student navigates to someone
else's invoice ID.

---

## 12. Error Handling & Loading States

- **Fee type builder**: surface `superRefine` validation errors (e.g. missing
  session for tuition) inline next to the relevant field, not as a generic toast —
  the scope selector is complex enough that field-level errors matter here.
- **Generation status**: if polling reveals `FAILED`, don't silently stop — show
  a persistent error state with failure count, not just a frozen progress bar.
- **Payment initiation failure**: show inline in the modal (don't close it) so the
  student can retry without re-navigating.
- **Payment verification failure**: this is the most consequential failure state in
  the module — a student who paid but sees "failed" will be anxious. Show a message
  that's honest but not alarming: e.g. "We're confirming your payment — if you were
  charged, this will update shortly. Contact support if it doesn't resolve in a few
  minutes." Never claim payment definitely failed if the gateway response is
  ambiguous/timeout — distinguish `FAILED` from "verification inconclusive" if the
  backend response allows it.
- **Admin invoice table**: standard skeleton + retry pattern, consistent with other
  admin tables in the codebase.

---

## 13. Naming Conventions Recap

(Inherited from `CLAUDE.md` §8.)

| Artifact | Convention | Example |
|---|---|---|
| Components | `kebab-case.tsx` | `fee-type-scope-selector.tsx` |
| Hooks | `use-*.ts` | `use-fee-types.ts` |
| Service | `[domain].service.ts` | `fee-management.service.ts` |
| Module store | `[domain]-ui.store.ts` | `fee-management-ui.store.ts` |
| Query keys | `query-keys.ts` | — |
| Schemas & types | split files in `schemas/`, `index.ts` in `types/` | `fee-type.schema.ts` |
| Pages | `page.tsx` | — |

---

## 14. Implementation Checklist

Build order — vertical slices, each testable on its own:

- [ ] `schemas/common.schema.ts` + `schemas/fee-type.schema.ts`
- [ ] `types/index.ts` (fee-type types first)
- [ ] `services/fee-management.service.ts` — fee type section only
- [ ] `hooks/query-keys.ts` — fee type keys only
- [ ] `hooks/use-fee-types.ts`, `hooks/use-fee-mutations.ts` (create/activate only)
- [ ] `components/shared/*` badges
- [ ] `components/admin/fee-type-scope-selector.tsx` (§9.1 — build carefully, this
      is the module's core UX)
- [ ] `components/admin/fee-type-form.tsx`, `fee-type-table.tsx`
- [ ] `components/admin/generation-status-panel.tsx`
- [ ] `app/(dashboard)/admin/(routes)/fees/types/*` pages
- [ ] **Invoice slice:** schemas → service section → hooks → `invoice-admin-table.tsx`,
      `invoice-detail-drawer.tsx`, `waive-invoice-dialog.tsx` → admin invoices page
- [ ] **Reports slice:** `use-fee-reports.ts` → `collections-report.tsx`,
      `overdue-report.tsx` → report pages
- [ ] **Student slice:** `payment.schema.ts` → service payment section →
      `use-payment.ts` → `my-fees-list.tsx`, `invoice-card.tsx`, `payment-modal.tsx`,
      `payment-status-panel.tsx`, `payment-history.tsx`
- [ ] Student pages: `/fees`, `/fees/:invoiceId`, `/fees/payment/callback`
- [ ] Admin overview `app/(dashboard)/admin/(routes)/fees/page.tsx` (built last —
      aggregates stats from the other slices)

---

## 15. Open Questions / Assumptions to Confirm

1. **Eligible-student-count preview** (§9.1) — does the backend expose (or plan to
   expose) a lightweight count endpoint for the scope selector, or should this be
   deferred to a v2? Without it, the admin submits a fee type "blind" to how many
   students it will hit.
2. **Permission granularity** — is a single `fee-management: view/manage` resource
   right, or should invoice waiving specifically require a stricter permission than
   fee-type creation (financial controls often want this separated, e.g. only
   Bursary can waive, but any Admin can create fee types)?
3. **Currency formatting** — confirm the existing convention for Naira formatting
   (symbol placement, thousands separators) so `currency-display.tsx` matches
   whatever's used elsewhere (e.g. the admissions/payment areas already in the
   codebase) rather than inventing a new format.
4. **Bank transfer / offline payment instructions** — for `checkoutUrl: null`
   responses, what should actually render? Static bank details from `Setting`? A
   reference number to quote? Confirm the content source before building
   `payment-modal.tsx`'s offline branch.
5. **Receipt/PDF generation** — `payment-history.tsx` is scoped as a lightweight
   list per §2 item 9. Confirm whether a downloadable PDF receipt is actually needed
   for this iteration (if so, that's a `pdf` skill task on the backend or an
   additional endpoint, not something to improvise client-side).
