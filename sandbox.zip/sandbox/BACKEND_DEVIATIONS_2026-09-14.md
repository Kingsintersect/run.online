# Backend Work Still Needed — Missing & Deviating From Design (2026-09-14)

Checked against the **updated bruno collection (442 `.bru` files)** and the **live production API**
(`https://run.api.qverselearning.org/api/v1`), compared line by line with the design docs in
`sandbox/`. Every item names the doc that defines exactly what we need.

- **Part A** — not built at all.
- **Part B** — built, but not the way it was designed. Please change these to match.
- **Part C** — built as designed. No action.
- **Part D** — bruno documentation gaps.

Items below carry a **`✅ RESOLVED 2026-09-15`** marker where the updated bruno collection confirms
the backend now matches the design — verified from the `.bru` files' own request/response
docs, not a live probe. The original write-up under each is left as the historical record of what
was wrong; see §"Status update — 2026-09-15" right below for the short version and what's still
open.

---

## Status update — 2026-09-15 (verified against the updated bruno collection)

The backend team has been fast — almost everything below is now built, several items exactly
matching the proposed design down to the error-code names. Genuinely excellent turnaround.

**Fully resolved:** A1 (Exam Timetable), A2 (Cohorts + category-conditional structure), A3 (CA
Preview), A4 (scope enforcement, `?majorProgramId=` live on Applications/Students/Invoices/
Offerings), A5 (invoice nested fields), A6 (student/lecturer filters), A8 (`enrolledCount`), A10
(`GET /admission/me/stages` + acknowledge/payments-initiate — see the one caveat below), A11
(session delete), A12 (`FeeType.majorProgramId`), A13 (students/lecturers `majorProgramId`), A14
(enrollment `majorProgramId`), A15 (grades/director-summary `majorProgramId`), B2 (step scope now
patchable), B6 (`totalStudents`/`totalTutors`/`totalStaff`), B7 (director grade summary rebuilt to
the **full** spec — filters, `records`, everything), B8 (cascade behavior documented: none, by
design), B9 (session name uniqueness self-conflict fixed).

**Partially resolved / needs a decision:**
- **B3** (Moodle reconcile & reset) — (c) courses-apply-skips-CREATE and (d) users-preview's limited
  fields are now explicitly documented as *intentional*, not bugs — no code change needed, just
  confirmed. (e) repull is now a real queued job (202). Still open: (a)/(b) — a stale/expired
  preview still returns a plain-message 409, or a `PREVIEW_NOT_FOUND` 404 for an unknown id, neither
  with the specific `PREVIEW_EXPIRED`/`PREVIEW_STALE` codes originally asked for (a real code was
  added instead: `PREVIEW_ALREADY_APPLIED`) — workable either way, since the frontend already reads
  the message text; a nice-to-have, not a blocker. (f) `SYNC_IN_PROGRESS` and (g) a reappearing
  `REMOVED_IN_MOODLE` row returning to `SYNCED` — no evidence either way in the bruno docs, needs a
  live check rather than assuming.
- **A16** (`MAJOR_PROGRAM_CHOICE` stage) — still rejected outright (`{"type": ["The selected type is
  invalid."]}`), confirmed against the live API 2026-09-15. `GET /admissions/config/stage-types`
  still lists exactly the original 7 types. Not built yet.

**Still open, unconfirmed via bruno one way or the other (needs a live check, not a doc read):**
A7 (`Grade.hasOutstandingFees` — no mention anywhere in the result bruno files), A9 (raw step-list
filters, still low priority), B4 (`moodle-sync.reset` permission in the live catalog — bruno
doesn't document permission seeds), B5 (major program delete still a plain-message 409, no
`MAJOR_PROGRAM_HAS_PROGRAMS` code), B8a (inactive scoped step hiding the inherited one — the
`Steps - Effective.bru` doc wasn't updated to say either way).

**Still genuinely open, but downgraded:** B1 (`custom_fields` vs `customFields` naming split
between submit and update — confirmed still inconsistent, unchanged on the backend). Re-verified
against the frontend's actual submit code 2026-09-15: the frontend already sends the key Submit
really reads (`customFields`), so this is no longer live data loss — see B1's own entry for the
correction.

---

## Part A — Not built

### A1. Exam Timetable (venues + exam schedules + conflict check) — HIGH — ✅ RESOLVED 2026-09-15

**Design docs (all three are the spec):**
| File | What it holds |
|---|---|
| `sandbox/exam-timetable/README.md` | Why exams are a separate entity from `ClassSchedule`, the two new entities, scope limits, rollout order |
| `sandbox/exam-timetable/SCHEMA_CHANGES.md` | `Venue` and `ExamSchedule` models, columns, constraints |
| `sandbox/exam-timetable/API_CONTRACTS.md` | Every request/response payload, filters, conflict-check contract |

**Routes needed** (`API_CONTRACTS.md` §1–3):
- `POST/GET /timetable/venues`, `PATCH/DELETE /timetable/venues/{id}` — the exam `Venue` entity
- `POST/GET /timetable/exams`, `GET /timetable/exams/my`, `PATCH/DELETE /timetable/exams/{id}`
- `GET /timetable/exams/check-conflict`

**Status:** no bruno files; all `/timetable/exams*` routes 404 on production.

**Route collision to resolve first:** `GET /timetable/venues?semesterId=` already exists as the
*class-timetable* venue-name autocomplete (`bruno/timetable/Venues - List.bru`, returns strings).
The design puts the exam `Venue` entity on the same path. Pick one and tell us:
- **Option 1 (preferred):** move the autocomplete to e.g. `GET /timetable/venues/names` and make
  `/timetable/venues` the entity CRUD exactly as designed.
- **Option 2:** build the entity at `/timetable/exam-venues` with the designed payloads.

### A2. Program Structure Depth — Cohorts and category-conditional structure — HIGH — ✅ RESOLVED 2026-09-15

**Design docs:**
| File | What it holds |
|---|---|
| `sandbox/program-structure-depth/README.md` | The problem (Certificate/Foundational don't fit Session→Level), the design (§4 A–D), rollout order |
| `sandbox/program-structure-depth/SCHEMA_CHANGES.md` | `Course`, `Student`, `AdmissionOffer`, `Program` changes and the new `Cohort` model |
| `sandbox/program-structure-depth/API_CONTRACTS.md` | Every request/response payload, validation table, error shapes |

**Not built (every item):**
1. **Cohort CRUD** — `POST/GET /academic/cohorts`, `PATCH/DELETE /academic/cohorts/{id}`,
   `POST /academic/cohorts/{id}/transition` (`API_CONTRACTS.md` §2). 404 on production.
   Includes `INVALID_PROGRAM_CATEGORY`, `INVALID_COHORT_TRANSITION`, `COHORT_HAS_ENROLLMENTS`.
2. **Admission offers** — `POST /admissions` and `POST /admissions/bulk` still require
   `levelId`/`sessionId` unconditionally and have no `cohortId`. Need the category-conditional
   table and the `INVALID_PROGRAM_STRUCTURE_FIELDS` / `COHORT_NOT_OPEN` errors (§1).
3. **Course** — `levelId` must become optional on create/update (§3). `Course - Create.bru`
   still shows it as required.
4. **Student** — `currentLevelId` nullable, new `currentCohortId` (§4). Not in any student response.
5. **Program** — `entryLevelId` (`SCHEMA_CHANGES.md` §5). Not in `Programs - Create/Update.bru`.

### A3. Moodle CA → `Grade.caScore` preview — MEDIUM — ✅ RESOLVED 2026-09-15

**Design docs:**
| File | What it holds |
|---|---|
| `sandbox/MISSING_BACKEND_APIS.md` §2.14 | Full contract: aggregation formula, `caMax` default 40, response payload, read-only scope |
| `sandbox/BACKEND_HANDOFF.md` §A4 | Final canonical path and the existing write path it feeds |

**Route needed:** `GET /assessments/ca-preview/{offeringId}?semesterId=&caMax=` — Admin or the
offering's lecturer. Read-only; the reviewed scores save through the existing
`POST /results/grades/bulk`. **Not in bruno.** Please build it at this exact path (the older
`/moodle-sync/assessments/ca-preview/...` path is superseded).

### A4. Major-program scope enforcement — HIGH (security) — ✅ RESOLVED 2026-09-15

**Design doc:** `sandbox/major-program-scoping/API_CONTRACTS.md` §2–3 (rationale in `README.md`).

Scope is *granted* (role assignment, user creation, `/auth/me`) but **never enforced**:
- No server-side filtering of list/detail endpoints by the caller's scope (applications,
  students, invoices, course offerings). A scoped admin currently sees everything.
- No `OUT_OF_SCOPE` 403 (or a documented 404 choice) on out-of-scope direct access.
- The optional `?majorProgramId=` narrowing param isn't documented anywhere — `Applications -
  List.bru`, `Students - List.bru`, `Invoices - List.bru` and `Offering - List.bru` don't list it.
- An empty scope (`[]`) must return an empty list, never an unfiltered one.

### A5. Invoice list — nested student fields and filters — MEDIUM — ✅ RESOLVED 2026-09-15

**Design doc:** `sandbox/MISSING_BACKEND_APIS.md` §2.8 ("`GET /fees/invoices` (admin list)").

`Invoices - List.bru` still documents only `status/feeTypeId/sessionId/studentId`. Needed:
`facultyName`, `departmentName`, `level` filters, and each row's
`student: {id, matricNumber, facultyName, departmentName, programName, level, user:{firstName,lastName}}`
plus `feeType: {name}`, `session: {name}` and a `meta` block.

### A6. Student/lecturer list filters — LOW — ✅ RESOLVED 2026-09-15

**Design doc:** `sandbox/MISSING_BACKEND_APIS.md` §2.8 (third bullet under "Proposed extensions").
`GET /users/students` and `/users/lecturers` need `facultyName`/`departmentName` filters, and
students a numeric `level` filter. `Students - List.bru` doesn't have them.

### A7. `Grade.hasOutstandingFees` — MEDIUM

**Design doc:** `sandbox/result/missing_grade_apis.readme.md` §7a (and §7b for publish exclusion).
Not in `Grade - List.bru`. Please also confirm whether §7b (publishing skips fee-withheld
students) was built.

### A8. Course offering `enrolledCount` — LOW — ✅ RESOLVED 2026-09-15

**Design doc:** `sandbox/MISSING_BACKEND_APIS.md` §2.10. Not in `Offering - List.bru`.

### A9. Admin filters on the raw step list — LOW

**Design doc:** `sandbox/multi-program-platform/API_CONTRACTS.md` §A.
`GET /admissions/config/steps` needs `?programId=` and `?programCategory=`. `Steps - List.bru`
only documents `?group=`.

### A10. Dynamic Admission — typed stages, stage settings, bound form fields — HIGH (new capability, not a deviation)

**This one isn't something built wrong — it was never asked for until today.** The step/field
registry above (§A9, and Part C's "Dynamic form fields CRUD") lets an admin add a PROCESS step or
a FORM field, but nothing defines what *kind* of stage it is or how a field binds to real
applicant data, so an added step's body and an added field never actually reach the applicant.
Auditing that gap produced a full design, already built on the frontend with a working fallback.

**Design docs (all three are the spec):**
| File | What it holds |
|---|---|
| `sandbox/dynamic-admission/README.md` | Why, the design, rules the backend must enforce, migration/rollout |
| `sandbox/dynamic-admission/SCHEMA_CHANGES.md` | Model/enum changes, the system-field catalog, seed data for today's steps and fields |
| `sandbox/dynamic-admission/API_CONTRACTS.md` | Every request/response payload |
| `sandbox/dynamic-admission/BACKEND_HANDOFF.md` | **Start here** — the checklist to build from, with `GET /admission/me/stages` spelled out in full |

**Needed, roughly in build order:**
1. `AdmissionStepDefinition.type`/`config` and `AdmissionFormField`'s new columns (`systemKey`,
   `lockedRequired`, `visibleWhen`, `optionsSource`, `dependsOn`, `parentFieldId`, …) — additive,
   no breaking migration.
2. Three read-only catalogs: system fields, stage types, option sources.
3. Stage and field CRUD accept the new properties, with the validation rules in `README.md` §3.
4. `POST /admissions/applications` accepts `answers[STEP][field]` and stores a `formSnapshot`;
   `GET /admissions/applications/{id}` returns it as an answer sheet (`form`).
5. **`GET /admission/me/stages`** (+ acknowledge/documents/payments-initiate actions) — the
   applicant's resolved, typed, statused stages in one call, replacing the frontend's current
   guesswork from hardcoded flags.

Not blocking a release — every screen this unlocks already ships with a graceful fallback — but
please treat it as real, prioritized backlog rather than a proposal to review later.

### A11. Safe delete for an unused Academic Session — MEDIUM (new capability, not a deviation) — ✅ RESOLVED 2026-09-15

**Also not a deviation — this is a genuine gap in the documented design, not something built
wrong.** `academic_README.md` states `AcademicSession`/`Semester`/`Level` have no `DELETE`
endpoint *by design*, so a session that already has real data against it (offerings, enrollments,
grades, admissions) can never be deleted — only retired via `isActive = false`. That rationale is
sound, but it currently also blocks the much narrower, harmless case: an admin creates a session
with a typo or under the wrong major program and wants to remove it immediately, before anything
has ever referenced it. Today there is no way to do that — it can only be deactivated, so it stays
visible in the session list forever.

**Needed:** `DELETE /academic/sessions/:id` (and, for parity, `DELETE /academic/semesters/:id`),
succeeding only when nothing references the session — no course offerings, enrollments, grades,
admission cycles/offers, or fee records scoped to it. Otherwise reject with `409` and an error code
(matching this codebase's existing pattern, e.g. `major-program-scoping/API_CONTRACTS.md` §6's
`MAJOR_PROGRAM_HAS_PROGRAMS`) — something like `SESSION_IN_USE`, so the frontend can show a clear
message rather than a generic error. Whether an *active*-but-unreferenced session should also
require deactivating first before it can be deleted is a reasonable extra safety check, left to
your judgment — either way, the existing "protect data integrity" invariant for referenced sessions
is fully preserved; this only unlocks the empty, never-used case.

**Frontend:** built 2026-09-15 — `academicSessionApi.delete`/`useDeleteSession`
(`src/services/feeManagementApi.ts`, `src/hooks/useAcademicSessions.ts`) plus a Delete button and
`<ConfirmDialog>` on each session card in `AcademicSessionManager.tsx`. The 409 `SESSION_IN_USE`
message (which already names every blocking table) is surfaced verbatim via toast rather than
re-worded, since it's already specific and readable as-is. Semester delete still doesn't exist
(unchanged, per `academic_README.md`) — no button added for it.

### A12. `FeeType.majorProgramId` — HIGH (new capability, found while wiring the fee-type screens) — ✅ RESOLVED 2026-09-15

**Also not a deviation.** `FeeType` already scopes by `sessionId`/`programId`/`levelId` (all
nullable, all live), which is enough to pin a fee to **one exact program** — but there's no way to
say "this fee applies to every program under this major program" without picking one program at a
time or leaving it unscoped for literally everyone. That's a real gap: Certificate-programme fees
and Part-Time-programme fees can't each be scoped to just their own major program's students today
unless every single program is given its own separate fee-type row.

**Design docs:**
| File | What it holds |
|---|---|
| `sandbox/major-program-scoping/SCHEMA_CHANGES.md` §2a | The `majorProgramId` column, migration risk (none — additive/nullable), and the resolution table |
| `sandbox/major-program-scoping/API_CONTRACTS.md` §8 | `POST`/`PATCH /fees/types` and `GET /fees/types` payload/response changes, plus the `GET /fees/types/eligible-count` filter |

**Needed:**
1. `FeeType.majorProgramId` (nullable FK to `MajorProgram`) — additive, no breaking migration.
2. `POST`/`PATCH /fees/types` accept it; when `programId` is also set, derive/validate
   `majorProgramId` from that program server-side rather than trusting the client's value.
3. `GET /fees/types?majorProgramId=` returns that major program's fees **plus** every
   institution-wide one (`majorProgramId: null`) — most-specific-plus-global, not strict equality,
   matching every other resolution rule in this codebase.
4. `GET /fees/types/eligible-count` accepts the same filter, so the live "how many students" preview
   stays accurate once a fee is scoped to a whole major program instead of one program.

**Frontend:** built ahead against this design with an honest fallback — the Major Program field is
shown and its value is sent, but until this ships, choosing "every program under X" without also
picking one specific program has no real effect server-side (the backend has nothing to filter on),
and the create form says so plainly rather than implying it already works.

**Update 2026-09-15 — one real constraint the design docs above didn't anticipate:** per
`bruno/fee/Fee Types - Create.bru`/`Update.bru`, the backend derives/validates `majorProgramId` as
designed for TUITION/HOSTEL/CLEARANCE/OTHER, **but keeps APPLICATION and ACCEPTANCE permanently
null-scoped for both `majorProgramId` and `programId`** — sending either on these two categories
422s. This directly narrows the user's later "every fee category must be scoped to a major
program/program" instruction: Session and Level scoping for Application/Acceptance are unaffected
(not restricted by the bruno docs) and remain fully scopable. `fee-type-scope-selector.tsx` now
locks the Major Program and Program fields to "fixed" (with an inline explanation) whenever
`category` is `APPLICATION` or `ACCEPTANCE`, and clears any already-picked value if the category is
switched to one of these after the fact — so the UI can no longer produce a payload the backend
would reject. If blanket program-level scoping of Application/Acceptance fees is actually wanted
(e.g. a different application fee per major program, which the new Major Program Choice admission
stage makes more plausible), that needs an explicit backend policy-change request — it is a
deliberate constraint, not an unbuilt one.

### A13. `majorProgramId` filter on `/users/students` and `/users/lecturers` — MEDIUM (new capability) — ✅ RESOLVED 2026-09-15

**Not a deviation.** These endpoints already accept `programId` (confirmed real) and
`facultyName`/`departmentName` (also confirmed real, per A6/Part C), but never a `majorProgramId`
narrowing param — needed now that the Students and Lecturers admin lists have major-program tabs
(same pattern as Review Applications, Invoices, and Fee Types).

**Needed:** `GET /users/students?majorProgramId=` and `GET /users/lecturers?majorProgramId=` —
filter to users whose program falls under that major program (a lecturer's own major-program
relationship, if any, is a separate question left to your judgment — the immediate need is
students, via their `program_id`).

**Frontend:** sends `majorProgramId` speculatively already (`usersApi.ts`). Unlike Fee Types or
Faculties, these lists are paginated, so the frontend deliberately does **not** re-filter the page
client-side once results come back — doing that against only one page of results would silently
show incomplete or empty results instead of an honest "not filtered yet." Until this ships, the
major-program tabs on these two screens have no visible effect.

### A14. `majorProgramId` filter on `GET /admin/enrollments` — MEDIUM (new capability) — ✅ RESOLVED 2026-09-15

**Not a deviation.** Same shape of gap as A13, one endpoint over: the admin Enrollment list
(`semesterId`/`studentId`/`offeringId`, all confirmed real) has no `majorProgramId` param, needed
now that the page has a major-program tab.

**Needed:** `GET /admin/enrollments?majorProgramId=` — filter to enrollments whose *student's*
program falls under that major program (an enrollment's course offering can itself serve more than
one program, so the student's own program is the correct anchor, not the offering's).

**Frontend:** sends `majorProgramId` speculatively (`enrollment.service.ts`). Same pagination
caveat as A13 — no client-side re-filter layered on top, so the tab has no visible effect until
this ships.

### A15. `majorProgramId` on `GET /results/reports/director-grade-summary`, and on `/results/grades` — MEDIUM (new capability) — ✅ RESOLVED 2026-09-15

**Not a deviation.** The director grade summary endpoint accepts only `semesterId` today (per its
own bruno doc); `/results/grades` (the per-course record list backing the Grade Records table)
accepts a single `programId` but no `majorProgramId`.

**Needed:**
1. `GET /results/reports/director-grade-summary?majorProgramId=` — same resolution as everywhere
   else (that major program's data, or everything when omitted). Its `byProgram` breakdown should
   also gain a `programId` alongside the existing `program` display name, so the frontend can filter
   it reliably instead of the current best-effort name match (see the frontend note below).
2. `GET /results/grades?majorProgramId=` — filtering to *every* program under a major program isn't
   expressible through the existing single-value `programId` filter without issuing one request per
   program.

**Frontend:** sends `majorProgramId` speculatively to the summary endpoint
(`director.service.ts`). Its `byProgram` table is filtered **client-side by matching the display
name** against the programs list (there's no id to join on) — an unmatched or since-renamed program
name simply won't be filtered out; this is a known, accepted limitation until `programId` is added
to that response. The Grade Records table below it is not filtered by major program at all yet
(see the code comment above it in `page.tsx`) — left as a known gap rather than issuing N parallel
requests to fake it.

### A16. `MAJOR_PROGRAM_CHOICE` process stage — `POST /admission/major-program-choice` + `GET /admission/student` fields — HIGH (new capability) — ✅ RESOLVED 2026-09-16 (all 4 items confirmed shipped)

**Not a deviation — genuinely new.** Found auditing the applicant-facing admission process once an
institution has more than one major program: `PROGRAM_CHOICE` lets the applicant pick a specific
program, but nothing lets them pick their *major program* first, so that stage's own picker has no
way to narrow down to just the right set of programs — it either lists every program in the
institution together, or (worse) an admin has to fake the step with a plain `CONTENT` stage that
has no actual selection mechanism at all, which is what prompted this audit.

**Design docs:**
| File | What it holds |
|---|---|
| `sandbox/dynamic-admission/SCHEMA_CHANGES.md` §2 | The new `MAJOR_PROGRAM_CHOICE` value on the `StageType` enum |
| `sandbox/dynamic-admission/API_CONTRACTS.md` §4.3 | `POST /admission/major-program-choice` payload/response, error codes, and the `GET /admission/student` field additions |

**Needed:**
1. **`StageType` gains `MAJOR_PROGRAM_CHOICE` as a recognized value.** Confirmed live 2026-09-15:
   `POST /admissions/config/steps` with `type: "MAJOR_PROGRAM_CHOICE"` currently 422s with
   `{"type": ["The selected type is invalid."], "config": ["Unknown stage type 'MAJOR_PROGRAM_CHOICE'."]}`
   — the backend validates `type` against a hard-coded enum, so this needs a real enum addition,
   not just accepting an extra `config` shape the way a config-only field addition (e.g. A12) would.
2. `POST /admission/major-program-choice` — `{ majorProgramId }`, mirroring `POST /admission/program-choice`'s existing contract one tier up. 422 `INVALID_MAJOR_PROGRAM` for an unknown or inactive id.
3. `GET /admission/student` gains `major_program_id` / `major_program_name`, same nullable shape as the existing `program_id`/`program_name` pair.
4. A decision (yours to make, see §4.3): can an applicant change their major program after already
   completing `PROGRAM_CHOICE`? Block it (409) or cascade-clear the program choice — either is fine,
   just needs to be documented.

**Frontend:** built ahead, updated 2026-09-15 — item 1 is confirmed shipped: creating a
`MAJOR_PROGRAM_CHOICE` step no longer 422s on `type`, and the live backend now also enforces its own
sequence rules for it (`INVALID_STAGE_SEQUENCE: MAJOR_PROGRAM_CHOICE_NOT_FIRST` /
`PROGRAM_CHOICE_BEFORE_MAJOR_PROGRAM_CHOICE`, confirmed by a real 422 naming both codes). The type
picker's "(may 422 — pending backend support)" label and `pendingBackend` flag are removed —
`STAGE_TYPE_CATALOG` in `admission-catalog.ts` no longer marks this type pending. `MajorProgramChoiceSection.tsx`
(applicant picker), the sequence rule requiring it before Program Choice, and `ChoiceProgramSection`'s
own narrowing picker are all fully live now that item 1 has shipped.

**Real frontend bug this surfaced, fixed 2026-09-15:** creating a new `MAJOR_PROGRAM_CHOICE` step
appended it like any other new step (order = last, or just before Complete) instead of inserting it
at order 1 — immediately violating `MAJOR_PROGRAM_CHOICE_NOT_FIRST` the moment the backend started
enforcing it. Worse, once mis-positioned, it couldn't be fixed by walking it to the front with the
up-arrow one hop at a time: the backend validates the *entire* resolved sequence on every single
reorder call, so every position short of first still 422s — the same atomic-validation trap
`COMPLETE_NOT_LAST` hit earlier this project. Fixed two ways: (a) `page.tsx`'s create flow now
special-cases `MAJOR_PROGRAM_CHOICE` — bumps every existing default-scope step's order up by one,
highest-order-first (never a tie, never an invalid intermediate state, since no
`MAJOR_PROGRAM_CHOICE` row exists yet during the bump), then creates it directly at order 1; (b) a
"Move Major Program Choice to the front" one-click repair button now appears alongside the
`MAJOR_PROGRAM_CHOICE_NOT_FIRST`/`PROGRAM_CHOICE_BEFORE_MAJOR_PROGRAM_CHOICE` warnings, for anyone
who already has one mis-positioned from before this fix — it sends the *entire* corrected order as
one atomic `reorder` call (with `MAJOR_PROGRAM_CHOICE` moved to the front, everyone else keeping
their relative order) rather than incremental swaps, for the same reason.

**Items 2, 3, and 4 confirmed live 2026-09-16**, per `bruno/admission/Admission - Submit Major
Program Choice.bru` and `Admission - Student Aggregate.bru`:
- `POST /admission/major-program-choice` — `{ majorProgramId }`, upserts on (userId, active
  session), same row Program Choice writes to. 422 for no active session, 422
  `INVALID_MAJOR_PROGRAM` for an unknown/inactive id. Returns the full refreshed `AdmissionStudent`.
- `GET /admission/student` now carries `major_program_id`/`major_program_name`, same nullable shape
  as `program_id`/`program_name` — null until the POST above is called.
- **Item 4, decided:** once a program has been chosen under a major program this session, submitting
  a *different* `majorProgramId` 409s `MAJOR_PROGRAM_CHOICE_LOCKED` rather than silently clearing the
  program choice. Re-submitting the *same* id (including the one already implied by an existing
  program choice) is always a no-op success. The reverse is enforced too — "Admission - Submit
  Program Choice.bru" 422s `PROGRAM_OUTSIDE_MAJOR_PROGRAM` if the chosen program isn't under the
  already-chosen major program.

**Real frontend integration gap found and fixed 2026-09-16** — the actual root cause of a live bug:
an applicant would pick a major program, see a "Major program saved" toast, and then the page would
just... not advance, still showing "Choose Your Major Program" as the current stage. Root cause:
`useAdmissionStages.ts`'s `chooseMajorProgram()` had been written before any of the three endpoints
above existed, so it only ever wrote the choice to `localStorage` (`writeLocalMajorProgramChoice`) —
correct at the time, per the comment it carried ("no live endpoint yet either way... swaps to a real
mutation call here, gated the same way acknowledge() is, once one ships"). But
`GET /admission/me/stages` (`bruno/admission/My Stages - List.bru`, confirmed separately live) now
answers for real, so
`useAdmissionStages` runs in `source: "backend"` mode — which uses the backend's own resolved stages
directly and never even looks at `localStorage`. The backend, never having received the `POST` this
whole time, kept reporting `MAJOR_PROGRAM_CHOICE` as not-yet-completed forever, regardless of what the
frontend wrote locally. Fixed by wiring the real mutation (`admissionService.
submitMajorProgramChoice()`, `POST /admission/major-program-choice`) into `chooseMajorProgram()`,
gated on `source === "backend"` exactly like `acknowledge()` already was — the local-storage path is
now reserved for genuine fallback (`source: "fallback"`) only, same pattern as everywhere else in this
file. `page.tsx`'s hardcoded `isSubmitting={false}` was also wired to the mutation's real pending
state while fixing this.

### A17. `Faculty.majorProgramId` — MEDIUM (new capability, found while reconciling Moodle categories) — NEW 2026-09-15

**Not a deviation.** A Faculty currently has no `majorProgramId` of its own — its major-program
membership is derived bottom-up, through whichever Departments/Programs sit under it
(`Faculty -> Department -> Program.majorProgramId`, all confirmed live today). That derivation
already works for a Faculty that already has Programs assigned. The gap: a **brand-new** Faculty
has nothing under it yet, so it can't be grouped under a major program immediately — which matters
concretely when reconciling a Moodle category that's itself Faculty-shaped and sits directly under
a major-program root category (e.g. resolving "Natural Sciences" as a Faculty under the "PART-TIME
PROGRAMS" Moodle category, per the Moodle Sync reconciliation flow) — there's no way to say "this
faculty belongs to Part-Time" at the point of creating/resolving it, only after Programs exist
under it later.

**Design docs:**
| File | What it holds |
|---|---|
| `sandbox/major-program-scoping/SCHEMA_CHANGES.md` §2b | The `Faculty.majorProgramId` column, migration risk (none), and how it composes with the existing derived path |
| `sandbox/major-program-scoping/API_CONTRACTS.md` §9 | `POST`/`PATCH /academic/faculties` payload/response changes |

**Needed:**
1. `Faculty.majorProgramId` (nullable FK to `MajorProgram`) — additive, no breaking migration.
2. `POST`/`PATCH /academic/faculties` accept it; `GET /academic/faculties` (list + detail) echo it
   back as `majorProgramId` + a nested `majorProgram: {id, name}`, same pattern as every other
   majorProgramId-bearing resource in this codebase.
3. This is additive to, not a replacement for, the existing derived path — a Faculty can still
   legitimately span several major programs through different Departments/Programs; the direct
   field only overrides that for the common case of a Faculty that serves exactly one.

**Frontend:** built ahead against this design — `FacultyFormDialog.tsx` gained a Major Program
field (shown once there's more than one active major program), sent as `majorProgramId` on
create/update. `FacultiesPanel.tsx`'s major-program tab filter checks the direct field first,
falling back to the existing derived bottom-up computation when it's null/undefined — which is
always, until this ships, so today's behavior is fully unchanged. An amber note in the form says
plainly that the field has no effect yet.

### A18. `AcademicUnit.linkedEntity.type` doesn't recognize `"major_program"` — HIGH (new capability, live 422 confirmed 2026-09-15) — ✅ RESOLVED 2026-09-16

**Not a deviation — a genuine, previously-unflagged gap.** `sandbox/major-program-scoping/
README.md` §4.E designed giving each Major Program its own root node in the generic `AcademicUnit`
tree (the same tree Moodle-sync categories resolve onto), by reusing the existing
`linkedEntity: {type, id}` mechanism with a new `type: "major_program"` value — matching the
already-live `"faculty" | "department" | "program" | "level" | "semester"` values. The design doc
assumed this needed no backend schema change since `linkedEntity.type` reads as a free-form string
column. In practice, `POST /moodle-sync/categories/{id}/resolve` (and, going by the same error
shape, presumably `POST /academic-structure/units` directly) validates it against a hard-coded
enum that still only recognizes the original five values — confirmed live via the exact error
`{"message": "The selected linked entity type is invalid.", "errors": {"linkedEntity.type":
["The selected linked entity type is invalid."]}}` when resolving a Moodle category ("PART-TIME
PROGRAMS") to Entity Kind "Major Program". Same root cause as A16's `MAJOR_PROGRAM_CHOICE` stage
type: a brand-new *enum value* (not a config field) needs an explicit backend addition, and no
payload shape on the frontend's side can work around a server-side enum check.

**Needed:** add `"major_program"` to whatever enum/validation list backs `linkedEntity.type` on
both `POST /academic-structure/units` and `POST /moodle-sync/categories/{id}/resolve`, resolving
it against the `MajorProgram` table the same way `"faculty"` resolves against `Faculty`.

**Confirmed live 2026-09-16**, per `bruno/moodle-sync/Category Sync - Resolve.bru` and
`bruno/academic-structure/Units - Create.bru` — both now explicitly document `major_program` as an
accepted `linkedEntity.type` value ("A18, 2026-09-15, added `major_program`"), with the 422 the
backend used to return replaced by real create-or-reuse behavior for that MajorProgram's own mirror
`AcademicUnit`, matching `"faculty"`'s existing behavior exactly (including the same one-entity-one-
mirror uniqueness constraint).

**Frontend:** built ahead per the design doc — `AcademicUnitLinkKind` already includes
`"major_program"`, `CategoryResolveDialog.tsx` already offers it as an Entity Kind with a live
Major Program picker, and `resolveMajorProgramAcademicUnit()`
(`src/services/academicStructureApi.ts`, used by the "Link to Moodle structure" button on the
Major Programs admin screen) already sends the right payload shape — none of that needed to change.
**Updated 2026-09-16** now that the gap is closed: the "(may 422 — pending backend support)" label
on the Entity Kind picker, its accompanying amber advisory paragraph (both in
`CategoryResolveDialog.tsx`), and the matching `title` tooltip on the Major Programs panel's "Link
to Moodle structure" button (`MajorProgramsPanel.tsx`) are all removed — they were accurate under
the no-institutional-locks policy while the gap was open, but would have been actively misleading
left in place once it shipped, same reasoning as B8a's warning removal.

### A19. Three frontend bugs behind the "Academic Structure looks scattered vs. Moodle" report — FIXED 2026-09-15

**Not a backend item — three real frontend bugs found and fixed while investigating why the
Academic Structure tree looked flat and duplicated compared to Moodle's clean hierarchy.** No
backend change involved; documented here purely as the causal record.

1. **No way to re-parent an existing node.** `AcademicUnitFormDialog.tsx`'s edit mode only ever
   sent `{name, sortOrder}` on update — there was no field for `parentId` at all, even though the
   type (`UpdateAcademicUnitPayload`) already allowed it. Once a category resolved to the wrong
   spot (see #2), there was no way to fix it short of delete-and-recreate. **Fixed:** the edit
   dialog now has a "Parent Node" picker (excluding the node itself and its own descendants, to
   avoid creating a cycle), wired through to the existing `parentId` update support.
2. **"Fix as structural node" always defaulted to root.** `CategoryResolveDialog.tsx`'s structural
   mode initialized `parentId` to `null` unconditionally, ignoring `category.parentId` — the field
   the backend already populates once a category's *Moodle parent* has itself been resolved to a
   real `AcademicUnit`. This is exactly why a category nested 4 levels deep in Moodle (e.g.
   "B.Sc. Matths And Statistics" under Natural Sciences under Part-Time) landed as a portal root:
   nothing pre-filled the correct parent. **Fixed:** the parent field now defaults to
   `category.parentId` when known, with a note explaining when it isn't yet (because the Moodle
   parent hasn't been resolved first) — resolving top-down now produces a correctly nested tree
   without extra manual re-parenting. The field's "optional" root choice also had no way to
   actually pick "no parent" once something else was selected; added the same explicit sentinel
   option used elsewhere in this codebase.
3. **Duplicate root nodes from `resolveFacultyAcademicUnit`/`resolveMajorProgramAcademicUnit`.**
   Every Moodle category — even one still unresolved — already has a bare, unlinked placeholder
   `AcademicUnit` row (root-level, same name as the Moodle category, `linkedEntity: null`), per
   how pull works. These two helpers (`src/services/academicStructureApi.ts`, used by "Link to
   Moodle structure" on the Major Programs screen and the faculty-direct-program flow) only
   checked for an existing *linked* root with the matching entity id — invisible to that unlinked
   placeholder — so calling them created a second, separate root with the same name (exactly the
   duplicate "PART-TIME PROGRAMS" observed: one with "Natural Sciences" nested under it from a
   manual resolve, one empty from this helper). Since `linkedEntity` is immutable after creation,
   the existing placeholder can't just be converted in place. **Fixed:** both helpers now also
   check for an existing *unlinked* root with the same name and throw a clear, actionable error
   ("delete that node — moving its children out first — then try again") instead of silently
   creating a duplicate.

**Existing bad data isn't retroactively fixed by this** — the already-created scattered/duplicate
nodes (flat "B.Sc. Matths And Statistics" root, the empty duplicate "PART-TIME PROGRAMS") need
manual cleanup now that the tools exist: re-parent the misplaced ones via the new Edit dialog
field, and delete the empty duplicate root (its Delete button already refuses if it still has
children, so move "Natural Sciences" under the correct "PART-TIME PROGRAMS" root first).

### A20. Fee Types/Invoices lists didn't refresh after create/activate/update/delete/pay — FIXED 2026-09-15

**Not a backend item — a frontend cache-key bug.** `feeKeys.feeTypes(filters)` /
`feeKeys.invoices(filters)` (`src/modules/fee-management/hooks/query-keys.ts`) embed the filters
object directly in the query key array, e.g. `[...all, "fee-types", filters]`. Every real list
component (`fee-type-table.tsx`, `invoice-admin-table.tsx`) always calls the corresponding hook
with a filters object — even when every individual filter is `undefined` — so the cached key's
third element is always an object. But `useCreateFeeType`/`useUpdateFeeType`/`useDeleteFeeType`/
`useActivateFeeType`/`useDeactivateFeeType` (and `useWaiveInvoice`/`useCancelInvoice`) invalidated
using the bare, zero-argument form — `feeKeys.feeTypes()` / `feeKeys.invoices()` — which embeds
`undefined` in that same slot instead. React Query's partial-match invalidation compares `typeof`
at each key position and refuses to match when they differ (`object` vs. `undefined`), so these
invalidation calls silently matched **zero** cached queries — the list only ever updated on a
manual "Refresh" click (the button visible next to the filters on both screens) or a full reload.
`useVerifyPayment` (`use-payment.ts`) had the same class of gap in reverse: it never targeted the
admin Invoices list at all, so a newly-verified payment didn't update that screen either.

**Fixed:** added `feeKeys.feeTypesAll()` / `feeKeys.invoicesAll()` — a filters-agnostic prefix
(`[...all, "fee-types"]` / `[...all, "invoices"]`, with no filters segment) that correctly
prefix-matches every list query regardless of what filters it was fetched with. Every mutation
above now invalidates through these instead of the bare, broken form; `useVerifyPayment` also now
invalidates `invoicesAll()` so the admin Invoices list picks up a newly-paid invoice too.

### A21. `DOCUMENT_UPLOAD` admission stage's own upload/remove endpoints — MEDIUM (unconfirmed, re-checked 2026-09-15)

**Not a deviation — genuinely unconfirmed, and distinct from a similar-looking real endpoint.**
The frontend calls `POST /admission/me/stages/{key}/documents` (upload) and
`DELETE /admission/me/stages/{key}/documents/{docKey}` (remove) — see
`admissionService.uploadStageDocuments`/`removeStageDocument`
(`src/app/(admission)/services/admissionService.ts:196-211`) — to satisfy a `DOCUMENT_UPLOAD`
stage's own per-document requirements (each with its own `key`/`label`/`required`/`accept`/
`maxSizeMb`, defined in that stage's config). Checked the full bruno collection for either route
under any name: not present. This is **not** the same thing as the confirmed-real "Application
Documents" family (`Application Documents - Add/Delete/Download/List/Replace.bru`, e.g.
`POST /admissions/applications/:applicationId/documents`) — those attach a document to the
*application* record itself, only while its status is still `pending`, with a single generic
`type: other` field, not a named per-stage document key. A `DOCUMENT_UPLOAD` stage is a distinct,
later-lifecycle concept (e.g. requesting a birth certificate or medical report after an offer),
per `sandbox/dynamic-admission/`. The two shouldn't be conflated — this is a real, separate gap.

**Needed:** confirm whether `POST`/`DELETE /admission/me/stages/{key}/documents[/{docKey}]` exist
server-side (undocumented but real) or need building from scratch, and add bruno coverage either
way — `My Stages - List.bru` already confirms `DOCUMENT_UPLOAD` progress is durably stored
(`admission_stage_progress`), so *something* backs it, but there's no visibility into the upload
route itself.

**Frontend:** already built ahead with an honest fallback, no change needed — per the
no-institutional-locks policy, `DocumentUploadStageSection.tsx` doesn't disable the upload button
outright; it only gates on `source === "backend"` (i.e. `GET /admission/me/stages` itself being
live, which it is per A10), so if these two routes turn out not to exist yet, an upload attempt
surfaces the real error via the existing `toast.error` handling rather than failing silently or
being guessed at in advance.

### A22. `majorProgramId` scoping on admission steps (PROCESS + FORM, and their fields) — HIGH (new capability, product direction 2026-09-15) — ✅ RESOLVED 2026-09-15

**Not a deviation — a real, deliberate redesign of how admission configuration scopes.**
Admission process/form steps have only ever scoped by `programCategory`/`programId` (Multi-Program
Platform) — an orthogonal axis to Major Program (`MajorProgram` is "an administrative/scoping
boundary," not an academic shape — `sandbox/major-program-scoping/README.md` §2.1). Direct product
instruction: admission configuration should be scoped by **major program**, not by individual
program — "admissions steps differ for each major program... application form steps and form
fields differ for each major program... I need to select a major program and create the admission
application steps and admission form steps and form fields... these steps should appear on the
admission process only when an applicant selects that particular major program." Full spec and
resolution table: `sandbox/dynamic-admission/SCHEMA_CHANGES.md` §2's `majorProgramId` addendum;
endpoint changes: `API_CONTRACTS.md` §2.5 (PROCESS) and §3.3 (FORM).

**Needed:**
1. `AdmissionStepDefinition.majorProgramId` (nullable FK to `MajorProgram`) — additive, no breaking
   migration, same pattern as every other majorProgramId column in this codebase.
2. `POST`/`PATCH /admissions/config/steps` accept it; `GET /admissions/config/steps` (raw admin
   list) and `GET /admissions/config/steps/effective` (both PROCESS and FORM) accept
   `?majorProgramId=` and resolve per the table: `programId` > `majorProgramId` >
   `programCategory` > institution default.
3. Two new `INVALID_STAGE_SEQUENCE` reasons: `MAJOR_PROGRAM_CHOICE_NOT_FIRST` (nothing may precede
   it in any resolved sequence) and `MAJOR_PROGRAM_CHOICE_SCOPED` (it must always be
   institution-default — scoping it to one major program is a contradiction, since it's the stage
   that decides which major program's steps apply).
4. No schema change needed for `AdmissionFormField` — a FORM step's fields already belong to that
   step row, so scoping the step (the existing "customise" action already copies a step's fields
   when it copies the step) is sufficient for "form fields differ per major program" too.

**Frontend:** built ahead against this design, 2026-09-15 — the Admission Configuration admin page
no longer has a "Specific program" tab or Program/Major-Program-as-narrower selects at all; its
tabs are now "All major programs" plus one tab per real Major Program (Category tabs, from before
Major-Program Scoping existed, are left in place — not part of this request, still real for any
step still using them). `majorProgramId` is sent on create ahead of the backend recognizing it.
The two new sequence rules are enforced client-side already (`stage-sequence.ts`'s
`MAJOR_PROGRAM_CHOICE_NOT_FIRST` check, and `StepFormModal.tsx` disabling "Major program choice" in
the type picker outside the "All major programs" tab — a real structural impossibility the
frontend itself enforces, not a guess about the backend, so unlike a `pendingBackend` type this one
*is* actually blocked). Since the live `/effective` endpoint doesn't recognize `majorProgramId` yet,
`useAdmissionStages.ts`/`useAdmissionForm.ts` resolve client-side (`resolveClientSideSteps()`,
`sandbox/dynamic-admission/`'s same priority table) whenever the server hasn't — meaning a
major-program-scoped PROCESS or FORM step (and its fields) already work correctly for an applicant
today, entirely from the frontend, the moment Major Program Choice records their choice (locally,
until A16 also ships).

**Originally confirmed live 2026-09-15 as a hard write-side block, now fixed.** Reproduced against
the live API when this item was first raised: creating or "Customise here"-ing a step into a
major-program tab 422'd — `{"message": "The key has already been taken. (and 1 more error)",
"errors": {"key": ["The key has already been taken."], "type": ["The type field is required when
group is PROCESS."]}}`. The `type` half was a real, separate frontend bug (fixed — see below); the
`key` half was because uniqueness was validated against `(programCategory, programId)` only, so a
create carrying `majorProgramId` was indistinguishable from a plain default-scope create and
collided with the existing default row. **Confirmed resolved same day** via
`bruno/admission/Steps - Create.bru`: "Uniqueness is actually scoped to (group, key,
programCategory, programId, majorProgramId — A22 below) together" — the exact fix asked for.
"Customise here" on an already-existing default step (the normal workflow — bringing "Personal
Information," the auto-added Complete stage, etc. into one specific major program) now works.
Per the no-institutional-locks policy, the Customise/Add-step controls were never disabled while
this was open — the frontend just showed the real 422 as it happened; the now-stale advisory
explaining that has been removed from the page.

**Real frontend bug fixed in the same pass:** `customiseMutation` (the mutation "Customise here"
and the "bump Complete out of the way" step-creation flow both call) never sent `type`/`config` on
its create call for a PROCESS-group step — `type` is required and immutable for PROCESS rows, so
every PROCESS-group customise was 422ing with `"The type field is required when group is PROCESS"`
regardless of scope kind, predating Major-Program Scoping entirely (Category/Program customise of a
PROCESS step would have hit this too). Fixed by copying `type`/`config` from the source step,
mirroring what the main create call already does.

**"Move to another major program" — built ahead 2026-09-15, confirmed working once A22 shipped.**
An owned step in a major-program tab has a Move action (`ArrowRightLeft` icon in
`StepConfigPanel.tsx`), opening a dialog to pick a destination major program. It's a `PATCH`
(`{majorProgramId, order}`), not a delete+recreate, so the step's `key` and (for a FORM step) its
fields carry over untouched. Client-side guards before sending anything: blocks if the destination
already has its own step with the same `key`, or (for a singleton PROCESS stage type) one already
active there. Bumps the destination's own Complete stage out of the way first if needed, same as a
brand-new step's create flow. Kept a defensive check even now that A22's `majorProgramId` PATCH
support is confirmed (`Steps - Create.bru`: "also settable on PATCH now"): it still verifies the
response's echoed `majorProgramId` actually matches the requested destination before showing
"moved!" rather than trusting a 200 blindly — cheap insurance, not a live workaround.

### A23. Full major-program decoupling — stop falling back to the institution default — HIGH (product direction 2026-09-15, supersedes A22's fallback behavior)

**Not a deviation — a deliberate reversal of part of A22's own design**, on direct instruction:
"the major programs are completely different programs with no ties to each other... they are not
meant to be connected in any way... order should not be tied to 'All major programs'... they should
be totally decoupled... they should be major program based or scoped." A22 (shipped) made
`majorProgramId` a resolution tier that still **falls back** through `programCategory` to the
institution default when a major program hasn't customised a given step — same inheritance model
`programCategory`/`programId` already used. That's the opposite of what's wanted, and it has a
concrete symptom already hit live: because `order` is one shared number line across every scope,
editing a step in one major program can 422 (`INVALID_STAGE_SEQUENCE`) against an *inherited*,
untouched step's order from the institution default — confirmed via a live
`ACCEPTANCE_PAYMENT_BEFORE_DECISION` on a `PATCH` that only touched one row.

**Full spec:** `sandbox/dynamic-admission/SCHEMA_CHANGES.md` §2c (rationale + the exact rule) and
`API_CONTRACTS.md` §2.6 (before/after request examples, migration options). Summary: **no schema
change** — `majorProgramId`'s column and its place in the `key` uniqueness constraint are unchanged
from A22. This is purely a resolution-*semantics* change on `GET /admissions/config/steps/
effective`:

- **`?majorProgramId=` present:** resolve only among rows belonging to that major program
  (`programId`-under-it, else `majorProgramId`-matching) — no fallback to `programCategory`, no
  fallback to the institution default, full stop. A key with no row for this major program is
  simply absent from the result.
- **`?majorProgramId=` omitted:** unchanged — `programId` > `programCategory` > institution
  default, exactly as before A22. This is what keeps a 0–1-major-program deployment (which never
  sends `majorProgramId`) working exactly as it always has —
  `major-program-scoping/README.md` §0's governing rule, still honored.

**⚠️ This is a breaking change for this deployment specifically** — Redeemer's University's real
major programs currently see every institution-default step by inheritance. Flipping this with no
migration instantly empties every major program's admission process. **Migration is decided, not
automatic** — the two automatic options originally considered (a one-time backend backfill, or a
frontend "bulk-adopt everything" button) were explicitly rejected in favor of granular,
per-major-program control. See API_CONTRACTS.md §2.6 and the "Frontend: built" note just below —
there is no backend-side migration step to build or sequence; ship the resolution rule change
whenever ready, and rely on the "Add from Catalog" UI (already built) for admins to populate each
major program by hand.

**Frontend: built 2026-09-15**, on top of this doc as agreed — migration explicitly rejected the
two bulk options above in favor of granular, per-major-program control:

- **`step-scope.ts`'s `resolveScope`** now mirrors the new resolution rule exactly for
  `scope.kind === "majorProgram"` — returns *only* that major program's own rows, nothing layered
  in from the catalog or any other axis. Every row it returns is `own: true`; the "Inherited ·
  Customise here" case simply can't occur for a major-program tab anymore.
- **"Add from Catalog"** (`AddFromCatalogDialog.tsx`, new) — a multi-select modal, opened from each
  major-program tab's own panel header or its empty state. Lists every institution-default
  (catalog) step of that group the major program hasn't already adopted
  (`catalogStepsNotAdopted()`, matched by `key`, excludes `MAJOR_PROGRAM_CHOICE`). The admin checks
  off exactly which ones apply — no "adopt everything" shortcut, matching the explicit "granular
  control per major program" instruction — and clicking "Import Selected" creates one independent
  row per selection (`adoptMutation`), copying label/description/icon/type/config and, for FORM
  steps, their fields (`copyFormFieldsToStep`, extracted from the pre-existing customise flow so
  both share one implementation). Imported in the catalog's own relative order, appended after
  whatever the major program already has, bumping its own Complete stage out of the way first if
  one already exists and isn't part of the current import — same "never send a call representing
  an invalid intermediate state" reasoning as `COMPLETE_NOT_LAST`/`MAJOR_PROGRAM_CHOICE_NOT_FIRST`.
- **Reordering, editing, deleting, moving** an adopted step all already worked through the existing
  `own`-based machinery (`swapInScope`, `handleReorder`, `moveMutation`, etc.) — since every
  major-program row is now `own: true`, these needed no changes at all to become fully
  self-contained per major program; they simply stopped ever hitting their old
  "inherited-row-needs-customising-first" branches.
- **Applicant-facing fallback** (`resolveClientSideSteps()`,
  `src/app/(admission)/lib/admission-stages.ts`) updated to match: once `majorProgramId` is known,
  it no longer falls back to institution-default rows either, so the client-side resolution used
  while the live `/effective` endpoint hasn't answered yet stays consistent with the new backend
  contract instead of silently reintroducing the old inheritance behavior.
- Category/Program tabs and their original inheritance model are untouched — this redesign is
  specifically and only about the major-program axis, per the original request.

**Known gap, flagged not silently accepted:** every existing major program in production currently
has zero adopted steps until an admin runs "Add from Catalog" on each one — there was deliberately
no automatic backfill. An applicant reaching a not-yet-populated major program today would see
whatever the process/form pages render for a genuinely empty resolved sequence; worth a live check
before this reaches real applicants, not assumed fine.

**Addendum 2026-09-15 — "catalog CRUD screen + separate Program Configurations screen" confirmed as
no additional backend work.** Restated as a fresh brief: a dedicated admission-step catalog with its
own CRUD, a second screen holding empty/populated major-program tabs, "Add from Catalog" as a
multi-select import into a specific major program, and per-major-program customise/reorder/remove —
each major program referencing the same catalog step independently, with no conflict between major
programs. This is the same product outcome as this entry, described from the UI side rather than the
API side. Checked against everything already confirmed live this session and nothing new is needed:

- **CRUD on catalog steps** is already `POST`/`PATCH`/`DELETE /admissions/config/steps` with no
  `majorProgramId` (or `programCategory`/`programId`) set — the existing default-scope create/edit/
  delete flow, unchanged.
- **"Reference the same catalog step, customise independently, no conflict"** is already true of the
  copy-on-adopt model above: adopting creates an independent row per major program (own `id`, own
  `order`, own `config`), so two major programs adopting the same catalog key never collide or share
  state. There is no live link back to the catalog row after adoption (deliberate — matches "major
  programs... are not meant to be connected in any way"), so no new "template reference" column is
  needed unless a *live-sync-on-catalog-edit* behavior is explicitly wanted later, which has not been
  asked for.
- **No new table, column, or endpoint is required.** This is a frontend-only change: splitting the
  existing single Tabs bar (catalog tab + major-program tabs together) into two navigation states —
  a "Catalog" landing view (default) and a "Program Configurations" view (major-program tabs,
  reachable via a button) — reusing the already-built `AddFromCatalogDialog`, `resolveScope`,
  `adoptMutation`, and `StepConfigPanel` exactly as they are.

### A24. Dynamic, major-program-scoped sequence-validation rules — HIGH (new capability, product direction 2026-09-15) — ✅ RESOLVED 2026-09-16

**Status: shipped and confirmed live 2026-09-16** — `GET`/`PATCH`/`DELETE
/admissions/config/sequence-rules` all live per `bruno/admission/Sequence Rules - List/Set/Clear.bru`,
including a genuine live verification: Certificate Programmes' real, already-order-colliding steps (an
Acceptance payment and its Decision stage tied at the same `order`) — a no-op `PATCH` that previously
422'd on this exact sequence succeeded once `ACCEPTANCE_PAYMENT_AFTER_DECISION`/`TUITION_PAYMENT_
AFTER_DECISION` were disabled for it. Design approved by product 2026-09-15 (Phase 1 shape, the
inheritance-fallback model, and the 3 locked Integrity rules all confirmed; Phase 2 explicitly out of
scope) — full design in `sandbox/dynamic-sequence-rules/`. Triggered by a real, live 422 while
configuring Certificate Programmes: `INVALID_STAGE_SEQUENCE: ACCEPTANCE_PAYMENT_BEFORE_DECISION`.
Certificate doesn't have (and per earlier direction may deliberately never have) an "Admission Status"
(`DECISION`) stage, but the 9 `INVALID_STAGE_SEQUENCE` rules (3 Integrity + 6 Precedence) were
hardcoded identically for every scope with no way to turn any of them off — so any major program that
included an Acceptance/Tuition payment step was unconditionally required to also have a Decision
stage ahead of it, even where that constraint didn't fit how that major program actually runs.

**Direct instruction:** "the operational sequence for each program should be dynamic and
configurable from the frontend to the backend, and should be major program scoped." Full design:
`sandbox/dynamic-sequence-rules/README.md`. Summary — a new `AdmissionSequenceRuleSetting` table
(`SCHEMA_CHANGES.md` §1) lets an admin toggle each of the 6 **Precedence** rules (e.g. `ACCEPTANCE_
PAYMENT_AFTER_DECISION`) on/off per major program, inheriting an institution-default row when a major
program hasn't set its own (a deliberate, flagged-for-confirmation reversal of A23's "no fallback"
model — rule *settings* default to a shared baseline, unlike step *content*, which stays fully
decoupled). The 3 **Integrity** rules (`MISSING_TYPE`, `MULTIPLE_{TYPE}`, `MISSING_COMPLETE`) are
proposed to stay permanently enforced everywhere, not exposed as toggleable — flagged as a
recommendation, not a final decision. New endpoints: `GET`/`PATCH /admissions/config/sequence-rules`
(`API_CONTRACTS.md` §1-2). The only change to existing behavior: the live `INVALID_STAGE_SEQUENCE`
validator on `POST`/`PATCH`/`DELETE /admissions/config/steps` and `.../reorder` gains a lookup —
"is this specific rule even enabled for this scope" — before applying each Precedence check
(`API_CONTRACTS.md` §3); error codes/shape on an actual violation are unchanged.

**Migration: none needed, confirmed.** Purely additive — an empty settings table reproduced today's
exact hardcoded behavior for every scope, no backfill or cutover was required.

**Also sketched, not proposed for this round:** a Phase 2 fully-custom precedence-pair model
(`SCHEMA_CHANGES.md` §2) for if the fixed 6-rule catalog ever proves insufficient — needs cycle
detection, meaningfully bigger, included only so the backend team can flag early if Phase 1's shape
would be a dead end.

**Frontend: built 2026-09-15, wired to the live backend 2026-09-16:**

- `SEQUENCE_RULE_CATALOG`/`SEQUENCE_RULE_CODES` (`src/lib/admission-catalog.ts`) — the 6 rule codes
  with real labels/descriptions, shared by the panel and any future consumer.
- `stage-sequence.ts`'s `validateStageSequence()` now takes an optional `ruleSettings` param; each of
  the 6 Precedence checks skips itself when its rule is resolved disabled for the current scope. The 3
  Integrity checks stay unconditional, matching the locked decision above.
- `SequenceRulesPanel.tsx` (new) — lists all 6 rules with a toggle, a source badge ("Your setting" /
  "Institution default" / "Built-in"), and "Reset to default." Reachable from a "Sequence Rules"
  button next to the scope description in both the Catalog and Program Configurations views.
- `admissionStepsApi.ts` gained `sequenceRules()`/`setSequenceRule()`/`clearSequenceRule()` plus their
  query keys/options/mutation options, following this file's existing conventions exactly.

**Bug found and fixed during the final wiring pass, worth recording as a lesson:** the panel was
originally built (2026-09-15, ahead of the backend, per `CLAUDE.md` §14) with a fallback that inferred
"the backend isn't live yet" from every returned rule having `source: "builtin"`. Once the backend
actually shipped, that turned out to be ambiguous — `source: "builtin"` is also the correct, legitimate
live response for any scope nothing has ever been configured for, which is the common case, not the
exception. Left as-is, every untouched major program's toggles would have stayed permanently disabled
even with a fully working backend. Fixed by deleting the swallow-all-errors fallback from
`admissionStepsApi.sequenceRules()` outright once liveness was confirmed — a real failure now surfaces
as a normal query error, same as every other live query on this page, with no inference from response
shape at all. Full writeup: `sandbox/dynamic-sequence-rules/README.md` and
`FRONTEND_IMPLEMENTATION_PLAN.md` §1.

### A25. `Department` can't attach directly to a Major Program — MEDIUM (new capability, found 2026-09-16 auditing the real Moodle category tree, proposed not built)

**Not a deviation — a genuine gap found by comparing RUN's data model against the real Moodle
category tree admins actually run courses under.** `Program` can already attach directly to a
Faculty (skipping Department, `Program.parentAcademicUnitId`, already live) and, as of 2026-09-16,
directly to a Major Program too (skipping both Faculty and Department — `resolveMajorProgramAcademicUnit()`
now wired into `ProgramFormDialog.tsx`, no schema change needed since `Program` already had both
`majorProgramId` and `parentAcademicUnitId`). **`Department` has no equivalent escape hatch at
all** — it can only be created with a real `facultyId`. The real Moodle tree already needs this:
`PART-TIME PROGRAMS` (major-program category) → `Natural Sciences` (department-shaped, no faculty
layer) → `B.Sc. Matths And Statistics` (a program) — there is no way today to represent "Natural
Sciences" correctly in RUN's own structure; resolving it via the Moodle Sync dialog has no valid
Entity Kind to offer for a department-shaped node with no faculty.

**Design docs:**
| File | What it holds |
|---|---|
| `sandbox/major-program-scoping/SCHEMA_CHANGES.md` §2c | `Department.facultyId` becomes nullable, `+majorProgramId`, `+parentAcademicUnitId` — mirrors `Program`'s existing `departmentId`/`parentAcademicUnitId` pair and `Faculty`'s existing `majorProgramId` (§2b) exactly |
| `sandbox/major-program-scoping/API_CONTRACTS.md` §10 | `POST`/`PATCH /academic/departments` payload/response shape, validation (exactly one of `facultyId`/`parentAcademicUnitId` required) |

**Needed:** add `majorProgramId` and `parentAcademicUnitId` (both nullable) to `Department`, relax
`facultyId` from required to nullable, and validate exactly one of `facultyId`/`parentAcademicUnitId`
is present on create. Zero data-migration risk — every existing row already has a real `facultyId`
and keeps working with no change.

**Frontend: not built yet, deliberately** — logged as a proposal per explicit instruction ("docs
now" for this one, distinct from the Program-direct-under-Major-Program capability above, which was
built the same session since it needed no schema change). Once the schema ships, the build mirrors
what `ProgramFormDialog.tsx`/`MajorProgramsPanel.tsx` already do for Program: a
`parentAcademicUnitId`-based mode on `DepartmentFormDialog.tsx`, an "Add department directly here"
action on `MajorProgramsPanel.tsx`, and a `majorProgramId` field on the Department form.

### A26. `POST /admission/me/stages/:key/payments/initiate` fails for every applicant — payment gateway not configured — HIGH (live, blocks payment entirely, found 2026-09-16, root cause corrected same day)

**Correction to this entry's own first version:** initially reproduced as a `500 {"message":
"Server Error"}` on two real students (Mary Solomon — Part-Time; solomon developer — Certificate)
and, without a stack trace, hypothesized as a major-program-aware FeeType-resolution bug (same
family as B10). **That hypothesis was wrong — re-tested a few hours later with a fresh QA account
and got a different, self-explanatory error, which is the real cause:**

```
POST /admission/me/stages/APPLICATION_PAYMENT/payments/initiate   (qa_parttime_ngozi — Part-Time
                                                                    Programmes, B.Sc. Matths And
                                                                    Statistics, UTME, Online)
→ 502 { "message": "Payment gateway error: Credo is not configured — set credo_public_key (and
        optionally credo_base_url) in Settings (group \"credo\")." }
```

**Root cause, confirmed by the backend's own error message, no further investigation needed:** the
Credo payment gateway integration has no `credo_public_key` (and possibly `credo_base_url`)
configured in this deployment's Settings. Every applicant, on every major program, hits this the
moment they click "Pay now" on any fee stage — it has nothing to do with major-program scoping,
`feeTypeId`, or `feeCategory` resolution at all; the request never gets far enough to reach that
logic. The earlier two students' plain `{"message": "Server Error"}` 500 was very likely the same
underlying missing-config problem surfacing through a less specific error path — worth confirming,
but not worth re-investigating as a separate bug.

**Needed:** set `credo_public_key` (and `credo_base_url` if it isn't defaulted) in this
deployment's Settings, group `"credo"` — an operational/configuration task, not a code fix. Once
set, re-test: a QA student is sitting at the `APPLICATION_PAYMENT` stage right now
(`qa_parttime_ngozi` / `Test@12345`) ready to complete a real payment with a provided test card the
moment this is fixed.

**B10 is now fully resolved as a non-issue**, confirmed across all 3 real major programs (Part-Time,
Certificate, Foundational) during this same audit — see B10's own updated entry below for the
full evidence table.

**Frontend:** nothing to fix — confirmed the request matches the documented contract exactly, and
the error surfaces honestly via the existing toast (backend's own message, verbatim).

### A27. Major-program-scoped RBAC for staff roles — HIGH (proposal extending A4/major-program-scoping — frontend now partly built 2026-09-17, see A30)

**Not a deviation — a direct instruction, extending work already partly designed.** `sandbox/
major-program-scoping/` already designed `UserRole.majorProgramId` and its server-side enforcement
(this file's own **A4, ✅ RESOLVED 2026-09-15** for four list endpoints: Applications, Students,
Invoices, Offerings). The new instruction: Tutor, Admin, Dean, Director, HOD, Bursary, and Staff
accounts should each be scoped to **exactly one** major program **at creation**, and every
dashboard's underlying data should be filtered to that scope — narrower and more concrete than the
original design's "optional, possibly-many" framing.

**Design docs, all updated 2026-09-16:**
| File | What it holds |
|---|---|
| `sandbox/major-program-scoping/README.md` — "C/D — Revised 2026-09-16" | The single-mandatory-scope decision, and exactly which roles it applies to |
| `sandbox/major-program-scoping/README.md` — new "F. Per-role dashboard data audit" | A live, real, dashboard-by-dashboard catalog of what each role currently sees unscoped (one real account per role, real login, this session) |
| `sandbox/major-program-scoping/SCHEMA_CHANGES.md` §3-4 | `UserRole.majorProgramId` required (not nullable) for these 7 roles' new grants; `POST /users`'s payload becomes `majorProgramId` (singular, required) instead of the original optional `majorProgramIds[]` array |
| `sandbox/major-program-scoping/API_CONTRACTS.md` §5 | The revised `POST /users` contract, its 422 `MAJOR_PROGRAM_REQUIRED` error shape, and how it relates to the still-valid array form on `POST /roles/assign` for granting an *additional* scope later |

**Real, live-verified finding — A4's confirmed enforcement doesn't reach dashboards at all,**
found while double-checking this proposal rather than just writing it from the original design:
created a fresh Dean account with a genuine, non-null `majorProgramId` grant from the moment of
creation (not the unscoped default), logged into it for real. Its dashboard was **identical** to a
completely unscoped Dean's — same full nav, same "PLATFORM CONTROL" framing, same User Management
access, no narrowing at all. So this isn't "turn on enforcement that already exists everywhere" —
it's two separate real gaps: (1) A4's server-side filtering needs extending well beyond the 4
endpoints it already covers — the audit table names Sessions/Course Structure/Academic
Structure/User Management/Grades/Reports/Fee Types-the-list (not just Invoices)/Announcements/
Moodle sync data as currently-unscoped, based on live dashboard content, not yet a full per-endpoint
inventory; (2) the frontend itself has no code anywhere that reads a caller's resolved scope and
conditionally narrows nav or dashboard content — `API_CONTRACTS.md` §1's `useMajorProgramScope()`
hook was designed in the original doc but never built.

**Single highest-priority item, if this has to ship incrementally:** Dean currently has
Admin-equivalent access, unscoped, including full User Management (create/manage any account, any
role). Confirmed live, not assumed.

**Frontend: partly built 2026-09-17 — see A30 for exactly what shipped and what's still blocked.**
The pieces that could be built honestly ahead of the backend (the shared scope hook, real filter
tabs on the 4 A4-resolved endpoints, the user-creation scope field, and the one RBAC gap fixable
with today's live permission data — Dean's User Management access) are done. Full dashboard-level
data narrowing for the other 6 roles is still blocked on the backend extending scope enforcement
well beyond the 4 A4 endpoints — not guessed at or faked client-side.

### A28. Scoped write/action endpoints carry no `majorProgramId` in their own response — blocks proactively hiding out-of-scope actions — MEDIUM (found 2026-09-17, auditing the backend's own OUT_OF_SCOPE write-endpoint proposal)

**Context.** The backend proposed enforcing major-program scope on write/action endpoints
(`PATCH /admissions/applications/:id/review`, `PATCH /users/students/:id`, `PATCH`/`DELETE
/courses/offerings/:id` + lecturer/schedule sub-routes, `POST /fees/invoices/:id/waive`/`cancel`),
returning `403 { "message": "OUT_OF_SCOPE: This record is not within your assigned scope." }`, and
asked for two things: (1) surface that 403 as a friendly toast, (2) proactively hide/disable the
Approve/Deny/Edit/Waive/Cancel/Assign-Lecturer buttons on a record outside the caller's own
`majorProgramScope`, using the already-built `useMajorProgramScope()` hook
(`src/hooks/use-major-program-scope.ts`).

**(1) is done — frontend-only, shipped this session**, see `src/lib/errors.ts`'s
`friendlyMessage()`/`getErrorMessage()`, wired into every mutation on the four flagged screens
(Review Applications — both the bulk action and the single-decision detail page, Students edit,
every Course Offering/lecturer/schedule mutation, Invoice waive/cancel).

**(2) is not buildable yet — this is the actual gap.** I checked the real response shape of every
resource the four flagged screens read from: `AdmissionApplication`, `CourseOffering` (+ its
enrichment block), and fee-management's `Invoice`/`Student` types. **None of them carry a
`majorProgramId` anywhere, nested or otherwise** — only `Program` itself has the field today
(`Program.majorProgramId`, already live). Without it, the frontend has no way to compare "does this
specific application/offering/invoice/student fall inside my scope" against `useMajorProgramScope()`'s
`scopedPrograms` before deciding whether to render an action button — there's nothing to compare
against. Resolving it via an extra client-side lookup per row (fetch the row's `Program`, read its
`majorProgramId`, compare) would be slow (N+1 per list), fragile, and exactly the kind of
"frontend fakes an authorization check it can't actually see" pattern this design's own governing
rule (`API_CONTRACTS.md` §1's "never trust a client-supplied scope filter as authorization... it is
a mirror of the server's enforcement, never a substitute for it") argues against — so it wasn't
built as a workaround.

**Needed:** echo `majorProgramId` (transitively resolved from each row's own `Program`, same as
`FeeType`/`Faculty` already do per `API_CONTRACTS.md` §8/§9) on:
- `GET /admissions/applications` (list) and `/:id` (detail) — resolved from `program_choice`'s
  program.
- `GET /users/students` (list) and `/:id` — resolved from the student's enrolled program.
- `GET /courses/offerings` (list) and `/:id` — resolved from the offering's course/program.
- `GET /fees/invoices` (list, and whatever detail/waive-precheck payload the waive/cancel dialog
  reads from) — resolved from the invoice's fee type or student's program.

Once that ships, wiring (2) is mechanical: add a `withinScope(majorProgramId: number | null)`
helper to `useMajorProgramScope()` (its own design doc, §7, already specified this and it was
dropped somewhere between design and build — the hook as built has `isUnscoped`/`scopedPrograms`/
`isMultiScoped` but no per-record helper), then gate each action button on
`isUnscoped || withinScope(record.majorProgramId)`.

**Also worth relaying independently of the above:** the OUT_OF_SCOPE error body itself
(`{"message": "OUT_OF_SCOPE: This record is not within your assigned scope."}`) is a flatter shape
than what `API_CONTRACTS.md` §2 originally specified (`{statusCode, error: "OUT_OF_SCOPE", message,
details: {requestedMajorProgramId, callerScope}}`) — see **B11** below. Not a blocker for (1), which
only needed the flat string, but means the frontend can't show which major program a record actually
belongs to in the toast, only a generic "outside your assigned major program."

### A29. `GET /admission/me/stages` marks an installment-eligible `PAYMENT` stage `COMPLETED` — and advances `currentStageKey` past it — the moment the *minimum* installment is paid, not once the balance reaches zero — HIGH (live, real student affected, found 2026-09-17)

**Live evidence, not a guess** — a real student (id 12, "Mary Solomon", Part-Time Programmes,
B.Sc. Maths and Statistics) who paid exactly the required minimum installment on Tuition Payment
(`minimumPayable: 90000` on a `180000` fee, `allowInstallments: true`, `minimumPercent: 50`).
`GET /admission/me/stages` response for this student, captured live via browser DevTools:

```json
{
  "currentStageKey": "COMPLETED",
  "stages": [
    {
      "key": "TUITION_PAYMENT",
      "status": "COMPLETED",
      "config": { "feeCategory": "TUITION", "allowInstallments": true, "minimumPercent": 50 },
      "state": {
        "amount": 180000,
        "amountPaid": 90000,
        "balance": 90000,
        "minimumPayable": 90000
      }
    },
    { "key": "COMPLETED", "type": "COMPLETE", "status": "NOT_STARTED" }
  ]
}
```

The `TUITION_PAYMENT` stage's own `state.balance` is correctly computed as `90000` (i.e. the
backend knows the fee isn't fully paid) — but `status` on that same stage object is `"COMPLETED"`,
and the top-level `currentStageKey` has already advanced all the way to `"COMPLETED"` (the terminal
`COMPLETE` stage), skipping past `TUITION_PAYMENT` entirely despite it being half-paid. `amountPaid`
exactly equals `minimumPayable` here, which is the strong signal: the completion check for an
installment-eligible `PAYMENT` stage appears to test `amountPaid >= minimumPayable` (the threshold
that unlocks *starting* the next thing) rather than `balance <= 0` (actually fully paid) when
deciding both this stage's own `status` and whether to advance `currentStageKey`.

**Real-world impact, not cosmetic:** the frontend has no client-side override for `source ===
"backend"` data (`useAdmissionStages.ts` trusts `backend.data.currentStageKey` and each stage's own
`status` completely, by design — see A28's note on why the frontend deliberately doesn't second-guess
server-resolved state) — so a student who pays only the minimum tuition installment is shown
"🎉 Admission Process Complete!" with a "Go to my courses" CTA, while still genuinely owing ₦90,000.
This likely also means real downstream effects tied to `admission_status`/course access treat this
student as fully admitted prematurely — worth checking whether LMS/course enrollment access is
gated on this same premature completion.

**Needed:** for any `PAYMENT` stage with `config.allowInstallments: true`, gate both that stage's own
`status` and whether `currentStageKey` advances past it on `state.balance <= 0` (fully paid),
never on `amountPaid >= minimumPayable` (which only means the *first* installment was made). This
is exactly the distinction the frontend's own now-unused fallback composer already gets right
(`src/app/(admission)/lib/admission-stages.ts`'s `paymentStatus()`: `"partial"` → `"IN_PROGRESS"`,
only `"paid"` → `"COMPLETED"`) — worth using as the reference behavior since it was designed against
the same `minimumPayable`/installment contract.

**Frontend:** nothing to fix — confirmed via code review that `useAdmissionStages.ts` has zero
client-side logic that could produce or correct this; it renders exactly what the backend sends.
`PaymentStageSection.tsx`'s partial-payment UI (badges, progress bar, "Pay Balance"/"Go to
Dashboard") is built and correct — it simply never gets a chance to render for this student because
`currentStageKey` never points at `TUITION_PAYMENT` once this bug fires.

### A30. Major-program RBAC build round 2026-09-17 — what shipped, what's still blocked, and 3 new gaps found tracing every endpoint

Direct instruction: build the frontend for A27's design now, splitting the work across parallel
agents, and skip nothing worthwhile — including the full per-role endpoint inventory a prior audit
round had skipped under time pressure. All work verified with `tsc`/`eslint`, nothing committed.

**New doc:** `sandbox/major-program-scoping/ENDPOINT_INVENTORY.md` — every nav item on all 7 scoped
roles' dashboards, traced to its literal API endpoint(s) and whether that endpoint is scoped today.
This is the missing per-endpoint companion to `README.md`'s dashboard-*content*-level "F. Per-role
dashboard data audit" — read it for the full picture; summarized below.

**Shipped this round (frontend-only, per CLAUDE.md §13):**
1. `useMajorProgramScope()` (`src/hooks/use-major-program-scope.ts`) gained the `withinScope(majorProgramId)`
   helper its own original design doc (`API_CONTRACTS.md` §7) specified but was never built.
2. Real major-program filter tabs (`<MajorProgramFilterTabs />`, matching Review Applications'
   existing pattern) now on Course Offerings (had none), Students (was using the wrong sibling
   component, `<MajorProgramTabs>` — the SUPER_ADMIN-institution-config variant, not the
   scope-aware one — swapped), and confirmed already-correct on Invoices. All three read from the
   4 A4-resolved endpoints, so this narrowing is real today, not cosmetic.
3. User creation (`CreateUserModal.tsx`) now sends the revised singular, conditionally-required
   `majorProgramId` per `API_CONTRACTS.md` §5 — hidden entirely for Student/Applicant/Super Admin,
   a real single-select for the other 7 roles, with a specific toast/field error if the backend
   ever returns the documented `MAJOR_PROGRAM_REQUIRED` 422. `ManageRolesModal.tsx` (the separate
   `POST /roles/assign` flow, §4) deliberately left on the array shape — that contract didn't
   change.
4. Dean's "create/manage any account, any role" access — the single item A27 flagged as
   highest-priority — is fixed: the User Management → Summary nav link is gone from Dean's sidebar
   and the page itself now refuses direct navigation for Dean. **Built as a role check, not a
   permission check, matching this codebase's *actual* RBAC architecture, not `CLAUDE.md` §5's**
   — see the correction below, this matters for anyone building on this pattern next.
5. A real, unrelated bug found and fixed while tracing the student side: the student Timetable
   page (`/student/timetable`) was still reading the current session from the old,
   institution-wide `/academic-calendar` module — the exact same class of bug the *admin* Class
   Schedules page had already been fixed for (switched to `/academic/sessions`, which does carry
   `majorProgramId`, via the already-built `resolveActiveSession()`). The student page was just
   never migrated to match. New shared hook `useMyActiveSession()` (`src/hooks/`) now resolves the
   logged-in student's own major program's active session/semester, reused wherever "current
   session" is needed for a student. Registration/Fees/Results were checked too — none of them
   had this bug (each already resolves its own state without a global-session assumption).

**Correction to `CLAUDE.md` §5 — the described RBAC architecture doesn't match what's actually
built.** §5 describes `src/lib/permissions.ts` (`allPermissions[]`, `pickPermissions()`) and
`src/lib/role-permissions.ts` (`rolePermissionMap`). Neither file exists — confirmed via a repo-wide
search, zero matches. The real, live architecture is `src/lib/permissions/usePermissions.ts` +
`PermissionGate.tsx`, and permissions come **entirely from the backend session** (`/auth/login`/
`/auth/me`) with no local fallback catalog (`src/store/appStore.ts`'s own comment says this
explicitly). Two static JSON files (`src/lib/utils/permissions.json`,
`.../Roles.Permissions.assignment.json`) look like the described catalog but are read nowhere at
runtime — documentation/reference only. Practical consequence hit this round: Dean and Admin's real
backend sessions currently return the *identical* permission set, so there was no permission to
gate the User Management fix on — it had to be a role check (matching the existing STAFF-branch
precedent on the same shared route), same as this codebase already does elsewhere when a live
permission distinction doesn't exist yet. `CLAUDE.md` §5 should be corrected to describe the real
`usePermissions`/`PermissionGate` system rather than the aspirational one, so the next session
doesn't go looking for files that were never built.

**3 new backend gaps found while tracing every endpoint (not built around, logged for the backend
team):**
1. **`GET /users/staff` has no `majorProgramId` support at all** — confirmed by direct code read,
   the only one of the three user-list endpoints (students/lecturers/staff) with zero scoping
   signal, frontend or backend. Needed for A27 to actually cover Staff.
2. **Tutor's two Grading screens (`/tutor/grading/submit`, `/tutor/grading/book`) pull their
   course-offering picker from the unfiltered `GET /courses/offerings`** — every offering
   system-wide, not the tutor's own assignments, unlike the properly `?lecturerId=`-scoped call
   the Course Assignments screen already uses for the same tutor. Independent of major-program
   scoping (a lecturer-ownership gap, not a program-scoping one) but found in the same trace —
   flagging rather than fixing, since it wasn't part of this round's ask.
3. **`GET /fees/reports/summary` and `GET /fees/reports/outstanding` 403 live for
   DIRECTOR/BURSARY/DEAN** — already tracked separately in
   `sandbox/fee-management/bursary_403_bug_report.md`, re-confirmed here from the Director/Bursary
   trace; noting the cross-reference so it isn't mistaken for a new major-program-scoping symptom
   once A27 ships and someone re-tests these screens.

**Still blocked on the backend, not guessed at:** full dashboard-level data narrowing for
Tutor/Admin/Director/HOD/Bursary/Staff (only Dean's one specific gap was fixable with today's live
permission data) needs the backend to extend scope enforcement well beyond the 4 A4 endpoints —
`ENDPOINT_INVENTORY.md`'s summary section ranks the endpoint clusters by how many roles/screens
depend on them, biggest first, as a starting point for sequencing that work.

## Part B — Built differently from the design (please change)

### B1. `custom_fields` key differs between submit and update — MEDIUM (re-verified 2026-09-15 — no live data loss today)

**Design:** `sandbox/multi-program-platform/API_CONTRACTS.md` §B — `custom_fields` on **both**
`POST /admissions/applications` and `PATCH /admissions/applications/{id}`.

**Built:** still inconsistent as of the latest bruno — `Applications - Update.bru` uses snake_case
`custom_fields`; `Applications - Submit.bru` uses camelCase `customFields` (its own docs call this
"a genuine pre-existing naming inconsistency"). Confirmed unchanged, not a stale note.

**Correction to this entry's original "Impact" claim:** this was written assuming the frontend sent
`custom_fields[key]` at submission, which would indeed have been silently dropped. Re-checked
2026-09-15 against `application-submit.service.ts` — the frontend actually already sends
**`customFields`** (camelCase) at submission, matching what Submit really reads, with an inline
comment recording exactly why. So **there is no live data loss today**: every dynamic answer
submitted at application time is received correctly. The `PATCH /admissions/applications/{id}`
side (applicant self-edit while `SUBMITTED`) doesn't send custom fields at all currently —
`UpdateApplicationPayload` (`src/types/school.d.ts`) has no such field, so editing a dynamic answer
after initial submission isn't built on the frontend yet, separate question from this naming
mismatch (flag as its own gap if that editing capability is wanted — not assumed here).

**Needed:** still worth fixing for its own sake — accept `custom_fields` on submit as designed (or
just document that `customFields` is the one true key and update the design doc instead), so the
two endpoints stop disagreeing. No longer urgent/blocking, since nothing live depends on it today.

### B2. Step scope can't be changed after creation — MEDIUM — ✅ RESOLVED 2026-09-15

**Design:** `multi-program-platform/API_CONTRACTS.md` §A — `programCategory`/`programId` are
settable on both `POST` and `PATCH /admissions/config/steps`.

**Built:** `Steps - Create.bru` says both are "immutable after creation like `group`/`key`".

**Needed:** allow `PATCH` to change them (still enforcing the `(group, key, programCategory,
programId)` uniqueness), so an admin can re-scope a step without deleting and recreating it.

### B3. Moodle reconcile & reset — MEDIUM

**Design:** `sandbox/moodle-sync-reconciliation/API_CONTRACTS.md` (rationale in `README.md`).

| # | Designed | Built (bruno) | Needed |
|---|---|---|---|
| a | 409 `PREVIEW_EXPIRED` when the preview's TTL has passed | Not documented; only a 15-minute expiry is mentioned | Return 409 with `error: "PREVIEW_EXPIRED"` |
| b | 409 `PREVIEW_STALE` when Moodle changed since preview | 409 with a message, no error code | Add `error: "PREVIEW_STALE"` |
| c | Apply applies everything the preview listed, reported in `applied.created` | **Courses apply silently skips `CREATE`** | Either create them as designed, or don't list `CREATE` in the courses preview — preview and apply must agree |
| d | Users preview can report `CREATE`/`NEEDS_MAPPING` | Users preview only reports `RENAMED`/`REMOVED_IN_MOODLE` | Confirm this limit is intended and document it |
| e | `repull: true` = **one queued job** that deletes and re-pulls; 202 | Runs the pull **synchronously inside the request** (`QUEUE_CONNECTION=sync`) | Run it after the response (like the drift scan's `afterResponse`) so a large re-pull can't time out the request |
| f | 409 `SYNC_IN_PROGRESS` if a pull/reset for that module is already running | Not documented | Add it |
| g | A `REMOVED_IN_MOODLE` row whose Moodle record reappears returns to `SYNCED` and clears `removed_in_moodle_at` | Not documented | Confirm it's implemented |

### B4. `moodle-sync.reset` permission — HIGH (blocks non-super-admins)

**Design:** `moodle-sync-reconciliation/API_CONTRACTS.md` §3 — new permission, added to the
catalog and assigned to `super_admin`.

**Built:** the reset routes check "Admin or `moodle-sync.reset`", but the permission was **not in
the live catalog** on 2026-09-14 (only `view/push/pull/manage` and `drift.resolve`).

**Needed:** seed `moodle-sync.reset` (module `moodle-sync`) and assign it to `super_admin`.

### B5. Deleting a referenced major program — LOW

**Design:** `major-program-scoping/API_CONTRACTS.md` §6 — 409 with
`error: "MAJOR_PROGRAM_HAS_PROGRAMS"`.

**Built:** 409 with a message only. **Needed:** add the error code.

### B6. `GET /users/stats` — no per-type totals — MEDIUM — ✅ RESOLVED 2026-09-15

**Design:** `sandbox/MISSING_BACKEND_APIS.md` "New: `GET /users/stats`" + §2.8 extension —
`totalUsers, totalStudents, totalTutors, totalStaff, activeUsers` plus the breakdowns.

**Built:** `totalUsers, activeUsers, inactiveUsers, verifiedUsers, newThisMonth, byRole{roleName:count}`
plus the breakdowns. There is **no `tutor`/`lecturer` role** in the live role list, so the tutor
total can't be derived from `byRole` — dashboards show 0 tutors.

**Needed:** add `totalStudents`, `totalTutors` (count of Lecturer records) and `totalStaff`, as
designed. Keeping the extra fields is fine. Also update `Users - Stats.bru`, which still
describes the old shape.

### B7. Director grade summary — reduced contract — MEDIUM — ✅ RESOLVED 2026-09-15 (full rebuild)

**Design:** `sandbox/result/missing_grade_apis.readme.md` §8 — filters
`facultyName, departmentName, programName, level, semesterName, academicYear, status, search, page, limit`;
response `summary`, `gradeDistribution`, `byFaculty`, paginated per-student `records`.

**Built:** `{overall, byFaculty, byProgram}` with only `semesterId`.

**Impact:** the frontend now composes the distribution and the student table from other
endpoints, and the Director page can't filter by faculty/department/level/status/search.

**Needed:** build §8 as designed, or confirm in writing that the reduced version is final.

### B8a. An inactive scoped step doesn't hide the inherited step — MEDIUM — ✅ RESOLVED 2026-09-15

**Design:** `multi-program-platform/API_CONTRACTS.md` §A — `effective` overlays scoped rows on the
institution default, matched by `key`.

**Built (original problem):** only `isActive` rows were overlaid, so a Certificate-scoped copy of a
step with `isActive: false` was simply skipped and the **default version still reached Certificate
applicants**. There was no way to remove a default step for one category or program.

**Fixed, confirmed live via `bruno/admission/Steps - Effective.bru`:** "the most specific row for a
given `key` now wins WHETHER OR NOT it's active... then drops the key from the final result if its
winning row is inactive" — exactly what was asked for. A scoped `isActive: false` copy now
correctly removes that step for that scope instead of falling back to the default.

**Frontend, updated 2026-09-15:** the admin's own "off here" warning
(`step-scope.ts`/`StepConfigPanel.tsx`) used to say "applicants still see the inherited version —
the backend doesn't hide inherited steps yet," which is no longer true and was actively misleading
once this shipped. Replaced with a neutral confirmation ("Off here — applicants in this scope won't
see this step") — no code change needed anywhere else, since the applicant-facing Live Preview and
the real admission process already read from the live `/effective` endpoint directly and were
already correct the moment the backend shipped this.

**Still open from the original "Needed":** required (`isRequired`) steps. The Edit modal's
"Required" toggle was never disabled (only the quick-toggle Switch and Delete button in the list
view are, to prevent an accidental one-click change) — so an admin *can* already open Edit on an
owned, required step and set `required: false` there, then switch it off from the list. Whether the
backend's `PATCH` actually accepts `isRequired: false` on a scoped copy of an institution-required
step (vs. rejecting it, or ignoring it) is unconfirmed — worth a live check before relying on it for
a case like "Certificate has no Application Payment at all."

### B8. Faculty/Department deactivation cascade — LOW — ✅ ANSWERED 2026-09-15 (no cascade, by design)

**Built:** `isActive` on Faculty/Department/Program `PATCH` — matches the ask
(`TRIPLE_AUDIT_2026-09-13.md` "Reactivation"). **Still needed:** document whether deactivating a
Faculty deactivates its Departments/Programs (and whether reactivating cascades back).

### B9. `PATCH /academic/sessions/:id` always fails with "The name has already been taken" — HIGH (blocks every session edit) — ✅ RESOLVED 2026-09-15

**Design:** `academic_README.md` — "All fields are optional (sometimes rule) — send only what
changes." A partial update should validate and apply only the fields actually sent.

**Live behavior (confirmed 2026-09-14):** `PATCH /academic/sessions/2` with body
`{"isActive": false}` — **`name` not present in the request at all** — still returns:

```json
{
  "message": "The name has already been taken.",
  "errors": { "name": ["The name has already been taken."] }
}
```

This means the endpoint isn't validating only the fields actually sent — it's re-validating the
full (merged) record's `name` for uniqueness on every update, and that uniqueness check isn't
excluding the row's own id (`Rule::unique('academic_sessions', 'name')->ignore($id)` is either
missing or not applied on this route). Since every session already has a name, and that name is
inherently "already taken" by itself, **this makes every update to an existing session fail**,
regardless of which fields the request actually contains — changing only `endDate`, only
`isActive`, or anything else all hit the same error.

**Impact:** blocks the frontend's session Edit and Deactivate actions entirely (both send minimal,
correct payloads per the docs above — verified, not a frontend bug). Deactivating an active session
currently does nothing but return this error.

**Needed:** add `->ignore($session->id)` (or equivalent) to the `name` uniqueness rule on the
update route, so a session's own unchanged name doesn't fail against itself. If uniqueness is
meant to be scoped per `majorProgramId` rather than global (matching
`sandbox/major-program-scoping/`), scope the `ignore()`/`where()` accordingly — right now it isn't
scoped at all, so two sessions with the same name under different major programs may also be
impossible even to create today (untested, but the same rule likely governs `POST` too).

### B10. `GET /admission/me/stages` doesn't resolve by major program — ✅ RESOLVED/NON-ISSUE 2026-09-16 — confirmed correct on all 3 real major programs

**Found while confirming A16's fix.** `bruno/admission/My Stages - List.bru`'s own docs describe the
resolution chain this endpoint uses to compute the applicant's effective PROCESS sequence: "from
their `AdmissionApplication` if one exists, else their program choice if any, else the
institution-wide default sequence." **Major program is not mentioned anywhere in that chain** — this
is the exact same "no fallback once `majorProgramId` is known" problem A23 already fixed for
`GET /admissions/config/steps/effective` (`BACKEND_DEVIATIONS_2026-09-14.md` A23,
`sandbox/dynamic-admission/SCHEMA_CHANGES.md` §2c), just not yet applied to this sibling endpoint.

**Why this matters concretely:** once A16's fix (above) lets an applicant's major-program choice
actually reach the backend, the very next thing that has to happen correctly is `GET /admission/
me/stages` resolving *that specific major program's own* PROCESS sequence — not falling through to
"the institution-wide default sequence," which per A23 is a **pure catalog**, never meant to be
served to any applicant directly. If this endpoint's resolution chain doesn't already have a
major-program tier ahead of "institution-wide default" (its own docs suggest it doesn't), an
applicant who picks a major program with its own fully-decoupled step list (e.g. Certificate: only
Access Fee + Tuition, no Application Fee — an existing, real product decision this session) would
still be served the generic catalog sequence instead, which is wrong on two counts: it doesn't match
the major program's actual configured steps, and per A23 the catalog isn't supposed to be servable
to an applicant at all.

**Resolved 2026-09-16 — live-tested end to end on all 3 real major programs, no gap found.** Ran
three real QA students through `POST /admission/major-program-choice` → Choice Program, one per
major program, and inspected `GET /admission/me/stages` + the accompanying `GET /admissions/config/
steps/effective` call after each step:

| Student | Major program | `majorProgramId` | Resolved sequence |
|---|---|---|---|
| `qa_parttime_ngozi` | Part-Time Programmes (id 2) | 2 | `CHOICE_PROGRAM → APPLICATION_PAYMENT → …` — Part-Time's own steps, not the catalog |
| `qa_cert_ibrahim` | Certificate Programmes (id 3) | 3 | `CHOICE_PROGRAM → ACCESS_FEE → …` — Certificate's own fully-decoupled sequence (the exact "Access Fee, no Application Fee" case this entry was originally worried about), correct |
| `qa_found_chiamaka` | Foundational Programmes (id 4) | 4 | `CHOICE_PROGRAM → APPLICATION_PAYMENT → …` — Foundational's own steps, and after picking a program, `?programId=5&majorProgramId=4` also resolved correctly |

Every one of these correctly reflects that major program's own configured PROCESS sequence, never
the institution-default catalog. The original concern (this endpoint's own bruno doc describing a
resolution chain that omits major program) was a documentation gap, not a real one — closing this
as a non-issue rather than leaving it open. Worth still asking the backend team to update `bruno/
admission/My Stages - List.bru`'s own docs to mention the major-program tier explicitly, so the
next person reading it doesn't raise the same false alarm.

**Needed:** either confirm (and update the bruno doc to state) that `GET /admission/me/stages`
already resolves via `major_program_id` ahead of "institution-wide default" when one is set on the
caller's `AdmissionStudent` record, or add that resolution tier so it matches A23's contract exactly.

### B11. `OUT_OF_SCOPE` 403 body is flatter than the agreed contract — LOW (found 2026-09-17, doesn't block the frontend fix, but narrows what it can show)

**Design:** `sandbox/major-program-scoping/API_CONTRACTS.md` §2 —
```json
{
  "statusCode": 403,
  "error": "OUT_OF_SCOPE",
  "message": "You do not have access to applications for major program 'Part-Time Programmes'.",
  "details": { "requestedMajorProgramId": 2, "callerScope": [4] }
}
```

**Built (per the write/action-endpoint proposal this file's own A28 is responding to):**
```json
{ "message": "OUT_OF_SCOPE: This record is not within your assigned scope." }
```
One flat string — no `error` code to branch on (the frontend now pattern-matches the `"OUT_OF_SCOPE"`
prefix on `message` instead, which works but is more brittle than a dedicated field), and no
`details.requestedMajorProgramId`/`callerScope`, so the frontend can't say *which* major program a
record belongs to or what the caller's actual scope is — only a generic "this record is outside your
assigned major program."

**Frontend:** adapted to the flat shape already (`src/lib/errors.ts`) — not blocked on this. Flagging
in case the backend team wants to align the body with the original contract for a richer error
message later; if the flat shape is the intended final form, no action needed beyond noting the
docs disagree.

---

## Part C — Built as designed (no action)

- Enrollment drift — all 9 routes, payloads, errors, permissions (`ENROLLMENT_DRIFT.md` §5–6)
- Reconcile/reset routes and payload shapes (apart from B3), mapping-delete routes with
  `MAPPING_STILL_ACTIVE`
- `/auth/me` and login `majorProgramScope`
- Major Programs CRUD (apart from B5), `Sessions` `majorProgramId`, scoped role assignment and
  user creation
- Dynamic form fields CRUD (`multi-program-platform/API_CONTRACTS.md` §B)
- `GET /admissions/config/steps/effective` with `fields`
- Moodle cohort sync (`/moodle-sync/cohorts`, push, sync-members)
- Faculty/Department/Program `isActive` on `PATCH`
- Offering `lecturerId` filter

**Accepted as built (frontend already adapted — just document them, see Part D):**
- `GET /fees/reports/summary` → `{invoiceCount, totalInvoiced, totalCollected}` (designed as
  `totalExpected`/`totalCollected`).
- `GET /fees/types/eligible-count` → `{data: {eligibleCount}}`.
- `GET /auth/roles/{id}/users` → `{data, meta}` with camelCase user fields.

---

## Part D — Bruno documentation needed

Please add or refresh these `.bru` files with a real example response:
- New files: `GET /fees/types/eligible-count`, `GET /auth/roles/{id}/users`.
- `Users - Stats.bru` — current shape.
- `Offering - List.bru`, `Invoices - List.bru`, `Students - Show.bru`, `Programs - List.bru` —
  example rows (production has no data to verify against).
- Bruno docs refer to `sandbox/moodle-sync-reconcile-reset/`; the folder is
  `sandbox/moodle-sync-reconciliation/`.
- `Fee Types - Generation Status.bru` — no example response at all right now, just prose
  ("eligible/processed/created/skipped counts" — note this doesn't even match the
  `processed`/`total`/`failures` names the frontend guessed at). Caused a real crash 2026-09-15:
  the frontend called `.toLocaleString()` on `processed`/`total` assuming they're always numbers,
  but a `QUEUED` job's real response apparently doesn't carry them yet (same shape as
  `ActivateFeeTypeResponseSchema` — `feeTypeId`/`jobId`/`status`(`/eligibleStudentCount`) only).
  Fixed defensively on the frontend (renders "Waiting to start…" until real counts show up,
  `?? 0` everywhere else so it can never crash again regardless of the exact shape) — but a real
  example for each status (`QUEUED`/`RUNNING`/`DONE`/`FAILED`) would let this be pinned down
  precisely instead of guessed at from a sibling schema.

---

## Part E — Policy-change requests (not bugs — built exactly as intended, asking you to reconsider)

### E1. Allow `majorProgramId`/`programId` scoping on APPLICATION and ACCEPTANCE fee types — NEW 2026-09-15

**This is not a gap or a bug.** Per `bruno/fee/Fee Types - Create.bru`/`Update.bru`, the backend
deliberately keeps APPLICATION and ACCEPTANCE fee types permanently institution-wide —
`majorProgramId` and `programId` must stay null for these two categories, and sending either 422s.
Every other category (TUITION, HOSTEL, CLEARANCE, OTHER) can be scoped freely per A12. This was
almost certainly a deliberate simplification (an applicant hasn't chosen a program yet when they
pay the application fee, so scoping by program didn't make sense at the time this was built).

**Why we're asking anyway:** the admission process is being rebuilt around a new **Major Program
Choice** stage that runs *before* Program Choice and before Application Payment in the sequence
(see A16 / `sandbox/dynamic-admission/`). Once an applicant has picked a major program (e.g.
Degree vs. Certificate vs. Part-Time) before paying, a different application fee per major program
becomes a completely normal requirement — e.g. a Certificate application fee lower than a Degree
one. The same applies to Acceptance once Program Choice has happened.

**Ask:** relax the null-scope constraint for APPLICATION and ACCEPTANCE specifically so they accept
`majorProgramId` (and, once a program is chosen, `programId`) the same way TUITION/HOSTEL/CLEARANCE
already do — most-specific-plus-institution-wide resolution, same as every other fee category.

**Frontend today (revised 2026-09-15):** `fee-type-scope-selector.tsx` briefly locked Major Program
and Program to "fixed" for these two categories, disabling the choice outright — reverted the same
day on explicit product direction: the frontend should never pre-emptively fix a scope choice at
the institutional level on the backend's behalf; the super admin decides, and a real backend
rejection (if it happens) surfaces as a normal save error rather than being guessed at in advance.
Both fields are real, live selects for every category again; an amber advisory shows only when
Major Program or Program is actually set on an Application/Acceptance fee, naming the current
backend constraint so the admin isn't surprised if saving 422s. The same reasoning was applied to
the `MAJOR_PROGRAM_CHOICE` stage type picker in admission-config (A16): it's no longer disabled in
the dropdown, just labeled "(may 422 — pending backend support)" — `stageTypesInUse`-based "already
in use" is the only thing that still actually blocks a selection anywhere in this app. If E1 is
accepted, no frontend change is needed at all — the fields already send the right payload; only the
advisory text becomes moot.
