# Audit Module — Implementation Workflow

This document explains the internal implementation flow for the Audit module. It is intended for developers building or maintaining this module.

---

## Module Dependencies

```
AuditModule
├── PrismaService          (database access)
└── (no outgoing dependencies — this is a leaf module)
```

> **Important:** The Audit module is a **pure provider**. It is injected into other modules via `AuditService`. It does NOT depend on any business module.

---

## Core Concept

All significant system actions are logged to a single `audit_logs` table. Other modules call `AuditService.log()` as an internal service — there are NO REST endpoints for creating logs.

```
┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│  AuthModule  │     │  PaymentModule│    │  ResultModule │
│  login()     │     │  verifyPay() │     │  approve()   │
└──────┬───────┘     └──────┬───────┘     └──────┬───────┘
       │                    │                    │
       └────────────────────┼────────────────────┘
                            │
                    ┌───────▼───────┐
                    │ AuditService  │
                    │   .log()      │
                    └───────┬───────┘
                            │
                    ┌───────▼───────┐
                    │  audit_logs   │
                    │   table       │
                    └───────────────┘
```

---

## 1. Logging Interface

```ts
@Injectable()
export class AuditService {
  constructor(private prisma: PrismaService) {}

  async log(data: {
    userId: number;
    action: string;
    entityType: string;
    entityId: number;
    oldValues?: object;
    newValues?: object;
    ipAddress?: string;
    userAgent?: string;
  }): Promise<AuditLog> {
    return this.prisma.auditLog.create({
      data: {
        userId: data.userId,
        action: data.action,
        entityType: data.entityType,
        entityId: data.entityId,
        oldValues: data.oldValues ? JSON.stringify(data.oldValues) : null,
        newValues: data.newValues ? JSON.stringify(data.newValues) : null,
        ipAddress: data.ipAddress,
        userAgent: data.userAgent,
      },
    });
  }
}
```

---

## 2. Usage Pattern (in other modules)

```ts
// In any service that needs audit logging
@Injectable()
export class GradeService {
  constructor(
    private prisma: PrismaService,
    private audit: AuditService,
  ) {}

  async updateGrade(id: number, dto: UpdateGradeDto, req: Request) {
    const oldGrade = await this.prisma.grade.findUnique({ where: { id } });

    const updated = await this.prisma.grade.update({
      where: { id },
      data: dto,
    });

    // Log the change
    await this.audit.log({
      userId: req.user.id,
      action: 'UPDATE',
      entityType: 'Grade',
      entityId: id,
      oldValues: { caScore: oldGrade.caScore, examScore: oldGrade.examScore },
      newValues: { caScore: dto.caScore, examScore: dto.examScore },
      ipAddress: req.ip,
      userAgent: req.headers['user-agent'],
    });

    return updated;
  }
}
```

---

## 3. Standard Action Codes

| Action | When to use | Example entityType |
| ------ | ----------- | ------------------ |
| `LOGIN` | User logs in | User |
| `LOGOUT` | User logs out | User |
| `CREATE` | New record created | Student, Invoice, Course |
| `UPDATE` | Record modified | Grade, Lecturer, Setting |
| `DELETE` | Record deleted/deactivated | Document, Announcement |
| `APPROVE` | Approval action | Grade, Clearance |
| `REJECT` | Rejection action | Grade, Clearance, Document |
| `ENROLL` | Student enrolls | StudentEnrollment |
| `PAYMENT` | Payment processed | Payment |
| `SYNC` | Moodle sync event | MoodleUser, MoodleEnrollment |

---

## 4. Query Patterns (Admin REST API)

### By Entity (most common)

```
GET /audit/logs/entity/Grade/42
→ "Show me everything that happened to Grade #42"
→ Returns: created by lecturer, updated twice, submitted, approved
```

### By User

```
GET /audit/logs/user/15
→ "Show me everything user #15 has done"
→ Returns: login, created grades, enrolled students, etc.
```

### By Time Range

```
GET /audit/logs?startDate=2025-01-01&endDate=2025-01-31&action=LOGIN
→ "Show all logins in January 2025"
```

---

## 5. Optional: Interceptor-Based Auto-Logging

Instead of manually calling `AuditService.log()` in every service method, you can create a NestJS interceptor:

```ts
@Injectable()
export class AuditInterceptor implements NestInterceptor {
  constructor(private audit: AuditService) {}

  intercept(context: ExecutionContext, next: CallHandler) {
    const request = context.switchToHttp().getRequest();
    const method = request.method;

    // Only log write operations
    if (['POST', 'PATCH', 'PUT', 'DELETE'].includes(method)) {
      return next.handle().pipe(
        tap((response) => {
          this.audit.log({
            userId: request.user?.id,
            action: this.mapMethodToAction(method),
            entityType: this.getEntityType(context),
            entityId: response?.id ?? request.params.id,
            ipAddress: request.ip,
            userAgent: request.headers['user-agent'],
          });
        }),
      );
    }
    return next.handle();
  }
}
```

> **Recommendation:** Use explicit `AuditService.log()` calls for critical actions (grades, payments) where you need `oldValues`/`newValues`. Use the interceptor for simpler CRUD operations.

---

## 6. Files to Create

```
src/modules/audit/
├── audit.module.ts            # exports AuditService
├── audit.controller.ts        # GET-only endpoints for admin
├── audit.service.ts           # log() method + query methods
├── dto/
│   └── query-audit.dto.ts     # filters: userId, action, entityType, dateRange
└── audit.service.spec.ts
```

---

## 7. Important Considerations

- **Immutability**: Audit logs are NEVER updated or deleted via API. They are append-only.
- **Performance**: Logging should be non-blocking. Consider using `setImmediate` or a lightweight queue for high-frequency operations.
- **JSON storage**: `oldValues` and `newValues` are stored as `JSON` (text). Keep them minimal — don't log entire entities, only changed fields.
- **Retention**: Consider a data retention policy (e.g., archive logs older than 2 years).
- **Indexing**: The table is indexed on `[entityType, entityId]` and `createdAt` for efficient lookups.
