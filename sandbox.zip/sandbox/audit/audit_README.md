# Audit Module

Provides audit logging for all significant actions in the system. Replaces the old separate AuditLog, SystemLog, LoginLog, and MoodleSyncLog tables with a single unified log.

## Models Owned

- **AuditLog** — unified audit trail for all system actions

---

## Endpoints

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/audit/logs` | List audit logs (filterable) | Admin |
| `GET` | `/audit/logs/:id` | Get a specific audit log entry | Admin |
| `GET` | `/audit/logs/user/:userId` | Get audit trail for a specific user | Admin |
| `GET` | `/audit/logs/entity/:entityType/:entityId` | Get audit trail for a specific entity | Admin |
| 'GET' | '/audit/logs/stats' | Get audit statistics for dashboard charts |	Admin

---

## Request & Response Types

### `GET /audit/logs`

**Query Parameters:**

```ts
{
  userId?: number;
  action?: string;            // e.g. "LOGIN", "CREATE", "UPDATE", "DELETE", "SYNC"
  entityType?: string;        // e.g. "Student", "Grade", "Payment"
  entityId?: number;
  startDate?: string;         // ISO 8601
  endDate?: string;           // ISO 8601
  page?: number;
  limit?: number;
}
```

**Response: `200 OK`**

```ts
{
  data: {
    id: number;
    userId: number;
    user: { firstName: string; lastName: string; email: string };
    action: string;
    entityType: string;
    entityId: number;
    oldValues: object | null;   // JSON parsed
    newValues: object | null;   // JSON parsed
    ipAddress: string | null;
    userAgent: string | null;
    createdAt: string;
  }[];
  meta: { total: number; page: number; limit: number };
}
```

---

### `GET /audit/logs/entity/:entityType/:entityId`

**Response: `200 OK`**

```ts
{
  data: {
    id: number;
    userId: number;
    user: { firstName: string; lastName: string };
    action: string;
    oldValues: object | null;
    newValues: object | null;
    createdAt: string;
  }[];
}
```

---

### `GET /audit/logs/stats`

**Response: `200 OK`**

```ts
{
  totalLogs: number;
  todayLogs: number;
  uniqueUsers: number;
  criticalActions: number;
  actionBreakdown: {
    action: "LOGIN" | "LOGOUT" | "CREATE" | "UPDATE" | "DELETE" | "APPROVE" | "REJECT" | "ENROLL" | "PAYMENT" | "SYNC";
    count: number;
    percentage: number;
  }[];
  entityBreakdown: {
    entityType: "Student" | "Grade" | "Invoice" | "Course" | "Tutor" | "Clearance" | "Payment" | "MoodleUser" | "MoodleEnrollment" | "Announcement" | "Document" | "User" | "Setting" | "StudentEnrollment";
    count: number;
  }[];
  dailyActivity: {
    date: string;    // ISO 8601 date (YYYY-MM-DD)
    count: number;
    logins: number;
    mutations: number;
  }[];
  hourlyActivity: {
    hour: number;    // 0-23
    count: number;
  }[];
}
```

---

## Creating Audit Logs (Internal Service API)

Audit logs are **not created through REST endpoints**. Instead, other modules call `AuditService.log()` internally.

**AuditService interface:**

```ts
class AuditService {
  async log(data: {
    userId: number;
    action: string;              // "LOGIN" | "LOGOUT" | "CREATE" | "UPDATE" | "DELETE" | "SYNC" | etc.
    entityType: string;          // e.g. "Student", "Grade", "Invoice"
    entityId: number;
    oldValues?: object;          // previous state (for updates/deletes)
    newValues?: object;          // new state (for creates/updates)
    ipAddress?: string;
    userAgent?: string;
  }): Promise<AuditLog>;
}
```

### Usage Example (in other modules)

```ts
// In grade.service.ts
await this.auditService.log({
  userId: currentUser.id,
  action: 'UPDATE',
  entityType: 'Grade',
  entityId: grade.id,
  oldValues: { caScore: 25, examScore: 40 },
  newValues: { caScore: 30, examScore: 45 },
  ipAddress: request.ip,
  userAgent: request.headers['user-agent'],
});
```

---

## Standard Actions

| Action | When to use |
| ------ | ----------- |
| `LOGIN` | User successfully logs in |
| `LOGOUT` | User logs out |
| `CREATE` | New entity created |
| `UPDATE` | Entity modified |
| `DELETE` | Entity deleted or deactivated |
| `SYNC` | Moodle sync events |
| `APPROVE` | Grade/clearance approval |
| `REJECT` | Grade/clearance rejection |
| `ENROLL` | Student enrolled in course |
| `PAYMENT` | Payment processed |

---

## Notes for Developers

- `oldValues` and `newValues` are stored as JSON text in the database. Parse them on read.
- The audit module should be imported by any module that needs logging.
- Indexed by `[entityType, entityId]` and `createdAt` for efficient lookups.
- Consider using a NestJS interceptor to auto-log write operations, or call `AuditService.log()` explicitly in service methods.
- `ipAddress` supports IPv6 (max 45 chars).
- Audit logs are **immutable** — no update or delete endpoints.
