# API Contracts — Multi-Program Platform

Full request/response shapes for every new and changed endpoint. Schema this rests on:
`SCHEMA_CHANGES.md`. Auth follows the existing convention for each module (bearer token, same
role gates as today unless noted).

---

## §A. Admission Step Registry scoping

### `GET /admissions/config/steps` (existing — gains optional filters)

Unchanged response shape. Two new optional query params, for the **admin management view**
(browsing/filtering raw rows across all scopes — not for runtime resolution, see the `effective`
endpoint below):

```
?group=PROCESS|FORM
?programId=55          // NEW — show only rows scoped to this exact program
?programCategory=CERTIFICATE   // NEW — show only rows scoped to this category
```

Response row gains the two new fields:

```ts
{
  id: number
  group: "PROCESS" | "FORM"
  key: string
  order: number
  label: string
  description: string
  icon: string
  isRequired: boolean
  isActive: boolean
  programCategory: string | null   // NEW
  programId: number | null         // NEW
}
```

### `POST /admissions/config/steps` / `PATCH /admissions/config/steps/:id` (existing — gains fields)

Body gains two optional fields:

```ts
{
  group, key, order, label, description, icon, isRequired, isActive,  // unchanged
  programCategory?: string | null,   // NEW — omit/null = institution-wide default
  programId?: number | null,         // NEW — omit/null = not program-specific
}
```

Validation: `programId`, if present, must reference a real Program; a row with both
`programCategory` and `programId` set is valid (the programId is simply the more specific match —
programCategory becomes irrelevant for that row since programId always wins in resolution, but
storing both is fine and can be useful for admin UI grouping/filtering).

### `GET /admissions/config/steps/effective` (**new**)

The runtime resolution endpoint — this is what the applicant-facing UI calls, and it does the
merge server-side so every consumer gets one already-correct answer instead of re-implementing
the resolution hierarchy.

```
?group=PROCESS|FORM   (required)
?programId=55         (optional — omit when the applicant hasn't chosen a program yet)
```

**Resolution logic:**
1. Start from every `isActive = true` row where `programCategory = null AND programId = null`
   (the institution-wide default set), keyed by `key`.
2. If `programId` is given: resolve the program's `programCategory`. Overlay every `isActive`
   row scoped to that `programCategory` on top (same `key` replaces the default; a new `key` not
   in the default set is added).
3. Then overlay every `isActive` row scoped to that exact `programId` the same way — most
   specific wins last.
4. Sort the merged set by `order`.

**Response** — same row shape as `GET /admissions/config/steps`, plus (for `group=FORM` only)
each step's resolved fields:

```ts
{
  data: {
    id: number
    group: "PROCESS" | "FORM"
    key: string
    order: number
    label: string
    description: string
    icon: string
    isRequired: boolean
    fields?: AdmissionFormField[]   // present only when group = FORM — see §B
  }[]
}
```

`isActive`/`programCategory`/`programId` are intentionally **not** in this response — the caller
gets a final answer, not raw configuration to re-filter.

---

## §B. Dynamic application form fields

### `GET /admissions/config/steps/:stepId/fields`

```ts
{
  data: {
    id: number
    key: string
    label: string
    type: "TEXT" | "TEXTAREA" | "EMAIL" | "PHONE" | "NUMBER" | "DATE"
        | "SELECT" | "MULTISELECT" | "FILE" | "REPEATING_GROUP"
    order: number
    isRequired: boolean
    helpText: string | null
    options: { value: string; label: string }[] | null   // SELECT / MULTISELECT only
    validation: {
      min?: number; max?: number; pattern?: string
      minDate?: string; maxDate?: string
    } | null
    repeatable: boolean
  }[]
}
```

### `POST /admissions/config/steps/:stepId/fields`

Body = one field object from the shape above, minus `id`. `key` must be unique within the step
(`slug`-safe — used verbatim as the `Application.customFields` key on submission).

### `PATCH /admissions/config/steps/:stepId/fields/:fieldId` / `DELETE .../fields/:fieldId`

Standard partial update / delete. Deleting a field does **not** retroactively touch
`customFields` on applications already submitted with that key present — historical submissions
keep whatever they were asked at the time.

### `POST /admissions/applications` / `PATCH /admissions/applications/:id` (existing — gains a field)

Body gains one optional field, alongside the existing `personal_info`/`academic_records`/
`program_choice`/`documents`:

```ts
{
  // ...existing fields unchanged...
  custom_fields?: Record<string, string | number | boolean | string[] | Record<string, unknown>[]>
}
```

Keys are `AdmissionFormField.key` values for whichever FORM-group steps resolved for this
application's program (via `effective` above). Validate server-side against each field's
`isRequired`/`validation` the same way `personal_info` etc. are validated today — the frontend
validates client-side first (Zod, generated from the resolved field defs) but the backend is the
source of truth as always.

---

## §C. Moodle cohort sync

### `GET /moodle-sync/cohorts`

```ts
{
  data: {
    id: number
    programId: number
    programName: string
    academicSessionId: number
    academicSessionName: string
    levelId: number | null
    levelName: string | null
    moodleCohortId: number | null
    idnumber: string
    name: string
    syncStatus: "PENDING" | "SYNCED" | "FAILED" | "STALE"
    syncError: string | null
    lastSyncAt: string | null
    memberCount: number    // live count from Moodle at read time, or last-known — implementer's call
  }[]
}
```

### `POST /moodle-sync/cohorts/push`

```ts
// Request
{ programId: number, academicSessionId: number, levelId?: number }

// Response — WRAPPED, `{ data: {...} }`.
//
// CORRECTION (2026-09-12): this contract previously claimed this response
// was unwrapped "matching pushCategory's convention." That claim was
// wrong. `CategorySyncController::push()` on the real backend wraps its
// response in `{ data: ... }` — it was never unwrapped either — and
// `CohortSyncController` was correctly built to match that actual
// behavior. Fixing the claim here at the source so nobody builds a
// consumer against the documented (wrong) shape instead of the real one.
{ data: { id, moodleCohortId, idnumber, name, syncStatus, ... } }
```

Idempotent — calling it again for the same `(programId, academicSessionId, levelId)` updates the
existing mapping (e.g. if the program/session name changed) rather than creating a duplicate,
same convention as `POST /moodle-sync/categories/push`.

**Implementation note for the backend:** create via Moodle's `core_cohort_create_cohorts` web
service function, `idnumber` set to the deterministic key above. See `MOODLE_COHORT_SYNC.md` for
the full web-service call sequence.

### `POST /moodle-sync/cohorts/:id/sync-members`

Manual reconciliation action — recomputes the correct membership (every student currently
`ENROLLED` in this program+session(+level)) and diffs it against Moodle's actual cohort
membership, adding/removing as needed. Exists as a fix-drift safety net; membership should
normally already be correct via the automatic event-driven sync below.

```ts
// Response — WRAPPED, same correction as push above.
{ data: { added: number; removed: number; unchanged: number } }
```

### Automatic membership sync (internal — no new endpoint, event-driven)

Hook into the enrollment lifecycle that already exists:

- `StudentEnrollment` created (status → `ENROLLED`) → look up (or lazily create) the
  `MoodleSyncCohort` for that student's `(programId, academicSessionId, levelId)` → if the
  student has a `MoodleSyncUser` (already Moodle-synced), call `core_cohort_add_cohort_members`.
- `StudentEnrollment` status → `DROPPED`/`WITHDRAWN`, or the student graduates →
  `core_cohort_delete_cohort_members`.
- If the student isn't Moodle-synced yet at enrollment time, no-op — cohort membership gets
  picked up the next time `sync-members` runs, or when the user-sync pull happens (whichever the
  backend's existing Moodle-sync scheduling already does for course enrolment; reuse it).

This deliberately reuses the exact trigger points the existing enrollment→Moodle sync already
watches — it is not a new subsystem, just one more thing that happens on the same events.

---

## Envelope convention

List/GET endpoints (§A `GET /admissions/config/steps[/effective]`, §B
`GET .../fields`, §C `GET /moodle-sync/cohorts`) follow the `{ data: ... }` convention already
used throughout `bruno/`. §C's single-record push/sync actions
(`POST /moodle-sync/cohorts/push`, `POST /moodle-sync/cohorts/:id/sync-members`) are **also
wrapped** — see the 2026-09-12 correction notes on those two responses above. There is no
unwrapped exception in this module: `CategorySyncController::push()` wraps in `{ data: ... }`
too, so `pushCategory`/`pullCategories` were never the unwrapped precedent an earlier version
of this doc claimed they were. Everything else in §A/§B (create/update/delete) follows
whatever envelope `/admissions/config/steps` already uses today for those verbs.
