# Multi-Program Platform — Architecture & Rollout

**Status:** approved design, 2026-09-11. Implementation starting this session (frontend); this
folder is the handoff package for the backend team.

---

## 1. The problem

This portal is deployed **single-tenant** — one running instance per institution (see
`CLAUDE.md` §1: "one deployment per university instance. No multi-tenancy."). That decision
stands. What doesn't hold up is the assumption baked into three specific subsystems that an
institution runs **one program shape**: today, every institution using this codebase gets one
hardcoded admission workflow, one hardcoded 9-step application form, and no way to auto-enrol a
program's intake into shared Moodle activities as a group.

The trigger case: a university running three genuinely distinct programs side by side —
**Degree**, **Foundational**, and **Part-Time** — each with its own curriculum, its own fee
schedule, its own admission workflow, and its own application form. Degree already has real
programs of its own; Foundational and Part-Time need to be added as first-class citizens, not
squeezed into Degree's shape.

## 2. The governing rule: single-program is the degenerate case

This is **not** a "multi-tenancy" feature and must not be built like one. It's the difference
between a template that happens to hardcode one program's assumptions, and a template that's
actually configuration-driven. The test for every piece of this design:

> A single-program institution must go through the exact same code paths as a five-program
> institution, just with zero scope-overrides ever created. If a feature needs an
> `if (institution has multiple programs)` branch anywhere, the design is wrong.

Concretely: every new scoping field introduced below is **nullable, and null means
"institution-wide default."** An institution that never creates a program-scoped override
behaves identically to today, with zero new code paths exercised.

## 3. What already supports this (verified against the live schema/types, not assumed)

Before proposing anything new, this audited what's already in place — most of the model already
generalizes past one program:

| Capability | Status | Where |
|---|---|---|
| Program-specific curriculum | ✅ Have | `ProgramCourse` — every Program owns its own course list |
| Program-specific grading | ✅ Have | `Program.gradingSchemeId`, `GradingScheme` (see `sandbox/schema-moodel-sync-refactor/`) |
| Program-specific fee amounts | ✅ Have | `FeeType.programId` / `.levelId`, fully optional-scoped already |
| Program-specific structure depth | ✅ Have | The generic `AcademicUnit` tree — a program can skip layers it doesn't need |
| Program-scoped admission *intake* | ✅ Have | `AdmissionCycle.program_id` (`""` = all programs) |
| Program-scoped admission *workflow steps* | ❌ Gap — **this doc, §A** | `AdmissionStepDefinition` today has no scope column at all |
| Program-specific application form fields | ❌ Gap — **this doc, §B** | The application form is 9 hardcoded steps with fixed Zod schemas, not data |
| Moodle-native cohort auto-enrolment | ❌ Gap — **this doc, §C** | No `MoodleSyncCohort` equivalent to the existing `MoodleSyncCategory`/`MoodleSyncCourse` pattern |
| New `ProgramCategory` values for Foundational/Part-Time | ❌ Gap — trivial | `FOUNDATIONAL`, `PART_TIME` not yet in the enum |

Three real gaps, one trivial enum addition. Everything else was already built defensively enough
(mostly during the earlier multi-structure refactor, see `sandbox/schema-moodel-sync-refactor/`)
to not need touching.

## 4. The three pieces

### A. Admission Step Registry — scope by program

Today one global list of steps drives every applicant's workflow (`PROCESS` group — Choice
Program, Application Payment, Admission Status, ...) and application form (`FORM` group —
Personal Info, Sponsor Info, ...). Add two nullable scope columns
(`programCategory`, `programId`) and a resolution hierarchy: program-specific row → category row
→ institution-wide default. Full contract: `SCHEMA_CHANGES.md` §1–§2, `API_CONTRACTS.md` §A.

### B. Dynamic application form fields

The application form's `FORM`-group steps gain a real `AdmissionFormField` child model — typed,
ordered, validated field definitions instead of fixed Zod schemas — so a Certificate program's
form can ask completely different questions from Degree's, composed by an admin, not a
developer. The frontend gains one generic field-renderer that reads this data instead of nine
hardcoded step components. Full contract: `SCHEMA_CHANGES.md` §3, `API_CONTRACTS.md` §B.

**Design call worth restating:** hybrid, not fully-generic. Universal fields (name, email, DOB,
documents, program choice) stay real typed columns on `Application` — they're the same across
every institution and every program, and keeping them queryable matters for reporting. Only the
fields that actually vary per program go through the dynamic `customFields` JSON bag. A fully
generic "every field is dynamic" design was considered and rejected — it would make cross-program
reporting (the thing a Director/Registrar actually needs) a JSON-scan instead of a query, for no
real gain since the "varying" fields are a small, bounded set per program.

### C. Moodle-native cohort sync

A cohort is not a new concept — it's `Program + AcademicSession (+ Level)`, which already exists.
A new `MoodleSyncCohort` mapping (same `idnumber`-keyed pattern as the existing
`MoodleSyncCategory`) pushes it to Moodle as a real cohort; membership is synced automatically off
the existing `StudentEnrollment` lifecycle (enrol → add to cohort, drop/withdraw → remove).
Courses shared across a program's intake (orientation, a shared semester-one course) then use
Moodle's own **"Cohort sync" enrolment method** — native auto-enrol/auto-unenrol, no custom Moodle
plugin. Full contract: `SCHEMA_CHANGES.md` §4, `API_CONTRACTS.md` §C, `MOODLE_COHORT_SYNC.md` for
the Moodle-side web service detail.

## 5. Rollout order

No dependency chain between the three — they can ship in any order, and each ships complete on
its own:

1. **A (Step Registry scoping)** — smallest, most contained; also unblocks real per-program
   admission workflows immediately even before B ships (an admin can already reorder/toggle among
   today's 9 fixed form steps per program, just can't yet change what a step *asks*).
2. **C (Cohort sync)** — self-contained, mirrors a proven pattern (`MoodleSyncCategory`)
   end-to-end, no dependency on A or B.
3. **B (Dynamic form fields)** — largest; depends on A's scope-resolution plumbing already
   existing (a `FORM`-group step needs the same `programCategory`/`programId` resolution logic A
   introduces) but not on C.

## 6. Files in this folder

- `SCHEMA_CHANGES.md` — every schema delta, Prisma-diff style, additive/breaking noted per change.
- `API_CONTRACTS.md` — full request/response contracts for every new/changed endpoint.
- `MOODLE_COHORT_SYNC.md` — the Moodle web-service integration detail for §C (cohort creation,
  membership sync, the "Cohort sync" enrolment method setup).
- `BACKEND_REQUIRED_ENDPOINTS.md` — the ship-to-backend-developer checklist: exactly what to
  build, cross-referenced to the frontend caller that's already wired and waiting on it.
- `FRONTEND_IMPLEMENTATION_PLAN.md` — internal build plan for the frontend side of this rollout
  (not needed by the backend team).

## 7. What this doesn't change

- Still single-tenant. No `tenant_id`, no subdomain routing, no per-institution branding — those
  are explicitly out of scope per the "reusable template, not SaaS" decision (§0 below).
- No change to Degree's existing behavior. Every schema change is additive with a null-default
  that preserves current rows/behavior exactly.
- No change to existing `AdmissionCycle`, `FeeType`, `GradingScheme`, or `AcademicUnit` contracts
  — this rollout uses them as-is, already scoped correctly.

## 0. "Deploy to any institution" — the scoping decision this rests on

Two readings were considered:

- **Reusable single-tenant template** (chosen): same codebase, redeployed fresh — own database,
  own Moodle, own hosting — per institution. Institution-specific structure becomes seed
  data/configuration instead of hardcoded, but each live deployment still serves exactly one
  institution.
- **True multi-tenant SaaS**: one running deployment serving many institutions simultaneously,
  data-isolated by tenant. Rejected — reverses the existing single-tenant architectural decision,
  and nothing in the actual requirement (one university, three programs) calls for it.

Every design decision in this folder assumes the first reading.
