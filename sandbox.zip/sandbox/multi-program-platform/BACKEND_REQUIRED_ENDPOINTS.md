# Backend Handoff — Multi-Program Platform

The actionable, backend-facing companion to `README.md`, `SCHEMA_CHANGES.md`,
`API_CONTRACTS.md`, and `MOODLE_COHORT_SYNC.md` in this folder — those cover the full design.
This document is the pure build list, cross-referenced to the frontend caller that's built and
waiting on each item.

None of the three subsystems depend on each other completing first (`README.md` §5) — ship in
whatever order suits you.

---

## 1. Admission Step Registry scoping — `/admissions/config/steps`

**Schema:** `SCHEMA_CHANGES.md` §2 (`AdmissionStepDefinition` +`programCategory`/+`programId`,
widened unique constraint). **Contract:** `API_CONTRACTS.md` §A.

**Endpoints needed:**
- `GET/POST/PATCH /admissions/config/steps[/:id]` — existing endpoints, gain the two new
  optional fields on read and write.
- `GET /admissions/config/steps/effective?group=&programId=` — **new**, does the
  program → category → institution-default resolution server-side (exact algorithm:
  `API_CONTRACTS.md` §A).

**Frontend caller:** `src/services/admissionStepsApi.ts` (`getEffective`, and the existing
`list`/`create`/`update` gain the scope params), consumed by
`src/app/(admission)/(routes)/process-admission/page.tsx` (PROCESS group — live). The FORM group
isn't consumed yet — see §2's status note. Managed from the admin Admission Config step editor:
`.../admission-config/components/{StepFormModal,StepConfigPanel}.tsx`.

---

## 2. Dynamic application form fields — `/admissions/config/steps/:stepId/fields`

**Schema:** `SCHEMA_CHANGES.md` §3 (`AdmissionFormField`, `FormFieldType`) and §4
(`Application.customFields`). **Contract:** `API_CONTRACTS.md` §B.

**Endpoints needed:**
- `GET /admissions/config/steps/:stepId/fields`
- `POST /admissions/config/steps/:stepId/fields`
- `PATCH /admissions/config/steps/:stepId/fields/:fieldId`
- `DELETE /admissions/config/steps/:stepId/fields/:fieldId`
- `POST/PATCH /admissions/applications[/:id]` — gains optional `custom_fields` in the body,
  validated server-side against the resolved field defs for that application's program (same
  place existing `personal_info` etc. validation already happens).

Depends on §1's `effective` endpoint existing so the frontend can resolve which fields to render
for a given program — ship §1 first if sequencing matters to you.

**Frontend caller:** `.../admission-application-form/services/admission-form-fields.service.ts`
(list/create/update/delete) and the admin composer panel,
`.../admission-config/components/StepFieldsModal.tsx` (opened via a "Manage fields" button on
each FORM-group step). The generic field renderer (`.../admission-application-form/components/
{DynamicFormField,DynamicFormStep}.tsx` + `lib/dynamic-field-schema.ts`) **is wired into the live
application wizard** as of 2026-09-11 — every custom field across a program's non-built-in
resolved FORM steps renders on one consolidated `FormStep.ADDITIONAL_INFO` page (design rationale
and exact mechanics: `FRONTEND_IMPLEMENTATION_PLAN.md` phase B3). It only appears for a
program/institution with at least one custom field — everyone else's flow is provably unchanged.
Not yet exercised against a real `effective` response since none exists server-side yet — see that
doc's "Residual risk" note for what to verify once §1/§2 ship.

---

## 3. Moodle cohort sync — `/moodle-sync/cohorts`

**Schema:** `SCHEMA_CHANGES.md` §5 (`MoodleSyncCohort`). **Contract:** `API_CONTRACTS.md` §C.
**Moodle-side detail:** `MOODLE_COHORT_SYNC.md` (web service functions, cohort creation payload,
the one manual per-course enrolment-method setup step).

**Endpoints needed:**
- `GET /moodle-sync/cohorts`
- `POST /moodle-sync/cohorts/push` — `{programId, academicSessionId, levelId?}`
- `POST /moodle-sync/cohorts/:id/sync-members` — manual reconciliation
- **Internal, no endpoint:** automatic membership add/remove hooked into the existing
  `StudentEnrollment` create/drop lifecycle (`API_CONTRACTS.md` §C, "Automatic membership sync").

**Frontend caller:** `src/modules/moodle-sync/services/moodle-sync.service.ts` (cohort methods),
`hooks/use-sync-cohorts.ts`, `/admin/moodle-sync/cohorts` (push form + list + sync-members
button) plus a "Cohorts" summary card on the `/admin/moodle-sync` overview page. All live.

---

## 4. `FOUNDATIONAL` / `PART_TIME` program categories

**Schema:** `SCHEMA_CHANGES.md` §1. Purely additive enum values — no endpoint change, existing
`POST/PATCH /academic/programs` already accepts `programCategory` and just needs the two new
values to validate.

---

## Status

As of this handoff (2026-09-11), all endpoints above are **not yet built** — every frontend
caller listed will 404 until you ship the corresponding piece, and is built to degrade gracefully
in the meantime (loading/empty states, no crashes, falls back to current behavior). This is the
same "frontend built ahead of backend" pattern used throughout this codebase — see
`sandbox/API_GAPS_2026-09.md` for other examples of the same convention if useful context.

**Frontend-side completion:** §1, §2, and §3 are all fully wired end-to-end on the frontend,
including admin UIs and the live applicant-facing wizard (§2). §4 (`FOUNDATIONAL`/`PART_TIME`) is
done on both sides already — just needs the enum values added to your `ProgramCategory`. Nothing
further is pending on the frontend for any of the four items; ship in whatever order suits you and
each lights up immediately, with the one caveat noted in `FRONTEND_IMPLEMENTATION_PLAN.md`'s
"Residual risk" section for §2 — recommend a manual smoke test once it's live.
