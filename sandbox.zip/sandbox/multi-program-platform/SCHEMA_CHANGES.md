# Schema Changes — Multi-Program Platform

Diff against the current schema. Everything not listed is unchanged. Model names for tables this
doc doesn't already have confirmed names for (the admission step registry backing table, the
Application table) are **inferred from the live API contract** (`/admissions/config/steps`,
`/admissions/applications`), not read from the actual Prisma schema — rename to match your real
model names, the columns/relations are what matter.

---

## 1. Modified enum — `ProgramCategory`

```diff
 enum ProgramCategory {
   DEGREE
   POSTGRADUATE
   CERTIFICATE
   DIPLOMA
   SECONDARY_SCHOOL
+  FOUNDATIONAL
+  PART_TIME
 }
```

Additive, no migration risk — every existing Program row keeps its current value.

---

## 2. Modified model — the Admission Step Registry (`AdmissionStepDefinition`)

Backs `GET/POST/PATCH/DELETE /admissions/config/steps`.

```diff
 model AdmissionStepDefinition {
   id          Int      @id @default(autoincrement())
   group       AdmissionStepGroup   // PROCESS | FORM
   key         String
   order       Int
   label       String
   description String
   icon        String
   isRequired  Boolean
   isActive    Boolean
   createdAt   DateTime @default(now())
   updatedAt   DateTime @updatedAt

+  // null = institution-wide default. Resolution order when building the
+  // steps for one applicant: programId match > programCategory match >
+  // both-null (institution default). See API_CONTRACTS.md §A.
+  programCategory ProgramCategory?
+  programId       Int?
+  program         Program?         @relation(fields: [programId], references: [id])

+  fields      AdmissionFormField[]  // only populated for group = FORM; see §3

-  @@unique([group, key])
+  @@unique([group, key, programCategory, programId])
 }
```

**Breaking at the DB constraint level, safe for data:** the old unique constraint
`[group, key]` forbade two rows sharing a key at all. The new one scopes that uniqueness — you
can now have a `key = "DOCUMENTS"` row with `programCategory = null` (the institution default)
**and** a separate `key = "DOCUMENTS"` row with `programCategory = CERTIFICATE` (the override) at
the same time. Every existing row keeps `programCategory = null, programId = null` and is
unaffected — it just becomes "the institution default," which is exactly what it already was.

**Migration:** add both columns nullable, backfill nothing (existing rows are correctly `null` by
default), then apply the new composite unique index. No data transformation needed.

---

## 3. New model — `AdmissionFormField`

One-to-many child of `AdmissionStepDefinition`, populated only for `group = FORM` steps. This is
what turns a fixed 9-step wizard into an admin-composable form.

```prisma
model AdmissionFormField {
  id           Int       @id @default(autoincrement())
  stepId       Int
  step         AdmissionStepDefinition @relation(fields: [stepId], references: [id], onDelete: Cascade)

  key          String     // stable identifier; becomes the key inside Application.customFields
  label        String
  type         FormFieldType
  order        Int
  isRequired   Boolean    @default(false)
  helpText     String?

  options      Json?      // [{ value: string; label: string }] — SELECT / MULTISELECT only
  validation   Json?      // { min?, max?, pattern?, minDate?, maxDate? } — all optional
  repeatable   Boolean    @default(false)  // true = applicant can add multiple entries (e.g. "prior qualifications")

  createdAt    DateTime   @default(now())
  updatedAt    DateTime   @updatedAt

  @@unique([stepId, key])
}

enum FormFieldType {
  TEXT
  TEXTAREA
  EMAIL
  PHONE
  NUMBER
  DATE
  SELECT
  MULTISELECT
  FILE
  REPEATING_GROUP
}
```

New model, no migration risk to existing data. `REPEATING_GROUP` is a field whose "value" is an
array of objects, each shaped by that field's own nested field list (`validation` can hold the
nested field defs as JSON, or — cleaner — give `AdmissionFormField` a nullable
`parentFieldId` self-relation for one level of nesting; pick whichever your ORM handles more
comfortably, the frontend contract in `API_CONTRACTS.md` §B works either way).

---

## 4. Modified model — the Application table

Backs `POST/PATCH/GET /admissions/applications`.

```diff
 model Application {
   id              Int      @id @default(autoincrement())
   applicantId     Int
   admissionCycleId Int
   status          ApplicationStatus
   personalInfo    Json
   academicRecords Json
   programChoice   Json
   documents       Json
+  customFields    Json?    // keyed by AdmissionFormField.key — only present for
+                            // program-scoped FORM steps this application's program opted into
   submittedAt     DateTime?
   reviewedAt      DateTime?
   reviewedBy      Int?
   denialReason    String?
   createdAt       DateTime @default(now())
   updatedAt       DateTime @updatedAt
 }
```

Additive, nullable — every existing application row is unaffected; `customFields` is only ever
populated going forward, for applications to a program with its own `AdmissionFormField` rows.

---

## 5. New model — `MoodleSyncCohort`

Same pattern as the already-real `MoodleSyncCategory` (see `sandbox/schema-moodel-sync-refactor/`):
an `idnumber`-keyed mapping row, pushed idempotently, no local membership table (Moodle is the
membership source of truth — the portal only triggers add/remove calls off events it already
tracks).

```prisma
model MoodleSyncCohort {
  id                Int       @id @default(autoincrement())

  programId         Int
  program           Program   @relation(fields: [programId], references: [id])
  academicSessionId Int
  academicSession   AcademicSession @relation(fields: [academicSessionId], references: [id])
  levelId           Int?
  level             Level?    @relation(fields: [levelId], references: [id])

  moodleCohortId    Int?
  idnumber          String    @unique   // "program:{programId}:session:{academicSessionId}[:level:{levelId}]"
  name              String               // e.g. "Certificate in Data Science — 2026/2027"

  syncStatus        MoodleSyncStatus     // reuse the existing enum (PENDING | SYNCED | FAILED | STALE)
  syncError         String?
  lastSyncAt        DateTime?

  createdAt         DateTime  @default(now())
  updatedAt         DateTime  @updatedAt

  @@unique([programId, academicSessionId, levelId])
}
```

New model, no migration risk. `levelId` is nullable because not every program needs
level-granularity cohorts — a Certificate program with no Level concept just omits it and gets one
cohort per session.

---

## 6. Summary

| Model | Change | Breaking? |
|---|---|---|
| `ProgramCategory` (enum) | +`FOUNDATIONAL`, +`PART_TIME` | No |
| `AdmissionStepDefinition` | +`programCategory`, +`programId`, +`fields` relation; unique constraint widened | No for existing data; yes at the constraint-shape level (see migration note above) |
| `AdmissionFormField` | New model | New |
| `FormFieldType` (enum) | New | New |
| `Application` | +`customFields` (nullable JSON) | No |
| `MoodleSyncCohort` | New model | New |

Nothing existing is removed or renamed. Every existing DEGREE program, every existing admission
step row, every existing application, keeps working unchanged.
