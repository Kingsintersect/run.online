# Frontend Implementation Plan — Multi-Program Platform

Internal build plan — not needed by the backend team (they need `SCHEMA_CHANGES.md` +
`API_CONTRACTS.md` + `MOODLE_COHORT_SYNC.md`). Tracks what's built, in progress, and pending, per
`README.md` §5's rollout order. Built defensively against `API_CONTRACTS.md` throughout — every
new endpoint call degrades gracefully (empty state / cached fallback / `retry:false`) until the
backend ships it, same pattern as every other endpoint in this codebase that's ahead of the
backend.

---

## Phase 0 — types/schema foundation ✅ done

- [x] `ProgramCategory` gains `FOUNDATIONAL`, `PART_TIME` (`src/types/school.d.ts`).
- [x] `AdmissionStepDefinition` type gains `programCategory`, `programId`, `fields`; new
      `EffectiveAdmissionStep` type for the resolved-endpoint shape
      (`src/types/admissionConfig.d.ts`).
- [x] New types: `AdmissionFormField`, `FormFieldType`, `FormFieldOption`, `FormFieldValidation`,
      `CreateAdmissionFormFieldPayload`/`UpdateAdmissionFormFieldPayload` (folded into
      `admissionConfig.d.ts`).
- [x] `MoodleSyncCohort` equivalent: `CohortSyncResponse`, `PushCohortDto`,
      `SyncCohortMembersResult` (`src/modules/moodle-sync/schemas/cohort.schema.ts` +
      `types/index.ts`).
- [x] `programSchema`/`ProgramFormDialog.tsx` gain a `programCategory` select — an admin can now
      actually create a Foundational/Part-Time/Certificate program (the type field already
      existed on `CreateProgramPayload`, only the form never collected it).

## Phase A — Admission Step Registry scoping ✅ done

- [x] `admissionStepsApi.ts`: `list` gains `{programId, programCategory}` filters; new
      `getEffective(group, programId?)` calling `GET /admissions/config/steps/effective`
      (`retry: false`-equivalent via plain query options, `staleTime` 5 min).
- [x] Admin Admission Config UI: `StepFormModal.tsx` gains Program Category / Specific Program
      selects (`NONE_SENTINEL` = institution default); `StepConfigPanel.tsx` shows a scope badge
      per row; `page.tsx`'s `handleFormSubmit` converts the sentinels to `null`/`number`.
- [x] `process-admission/page.tsx`: layers `getEffective("PROCESS", student.program_id)` over the
      raw `config()` list once a program is chosen — `retry: false`, falls straight back to
      today's behavior until the backend ships it.
- [ ] `useAdmissionForm.ts`'s FORM-group walk still uses the raw fixed steps — deferred to B3,
      since resolving FORM steps only matters once something can render their `fields`.

## Phase C — Moodle cohort sync ✅ done

- [x] `moodle-sync.service.ts`: `listCohorts()`, `pushCohort(dto)`, `syncCohortMembers(id)`.
      **CORRECTION (2026-09-12):** this line previously said `pushCohort`/`syncCohortMembers`
      return unwrapped responses "matching this module's existing `pushCategory` convention" —
      that premise was wrong. `CategorySyncController::push()` wraps its response in
      `{ data: ... }`, and `CohortSyncController` was correctly built to match that real
      behavior. See `API_CONTRACTS.md` §C for the corrected contract. This also means
      `pushCategory`/`pushCohort`/`syncCohortMembers` in `moodle-sync.service.ts` are typed as
      if unwrapped and should be checked against the real response shape — flagged separately,
      not fixed as part of this doc correction.
- [x] `moodleSyncKeys.cohorts()` + `use-sync-cohorts.ts` (`useSyncCohorts`, `usePushCohort`,
      `useSyncCohortMembers`) — mirrors `use-sync-categories.ts`.
- [x] Admin UI: `/admin/moodle-sync/cohorts` (push form + list + per-row "Sync members"), and a
      "Cohorts" summary card added to `/admin/moodle-sync`'s overview grid.

## Phase B — Dynamic application form fields ✅ done

- [x] **B1 — Field CRUD (admin):** `admission-form-fields.service.ts` (list/create/update/delete)
      + query options; `StepFieldsModal.tsx` — full add/edit/delete panel wired into the Admission
      Config UI via a new "Manage fields" (`ListTree`) icon on each FORM-group step row.
- [x] **B2 — Generic field renderer:** `DynamicFormField.tsx` (one component per `FormFieldType`)
      + `DynamicFormStep.tsx` (renders a whole resolved step's fields) + `buildFieldSchema`/
      `buildStepSchema` in `lib/dynamic-field-schema.ts` for runtime Zod generation. Deliberately
      built as **plain controlled components** (`value`/`onChange` props), not tied to
      `useFormContext<FormDefaultValues>()` — `FormFields.tsx`'s existing helpers type their
      `name` prop as `keyof FormDefaultValues`, a closed union that can't accept an
      admin-defined dynamic key.
- [x] **B3 — Wired into the live wizard**, via one deliberate design simplification: rather than
      giving each admin-defined custom *step* its own numbered wizard page (which would need
      `FormStep`/`activeSteps`/`STEP_FIELDS`/`STEP_SCHEMAS` to support a variable-length,
      admin-defined set of step identities — a much larger rework of a hook that's genuinely
      load-bearing for real applicants today), every custom field across every non-built-in
      resolved FORM step is flattened into **one new fixed step**,
      `FormStep.ADDITIONAL_INFO` (value `9`, appended *after* `REVIEW` in the enum specifically so
      `REVIEW`'s existing numeric value never shifted — an in-progress applicant's already-saved
      `stepStorageKey` value of `"8"` must keep meaning Review). It behaves exactly like the other
      8 steps everywhere (`STEP_FIELDS`, storage, navigation) except its "schema" is
      `buildStepSchema(customFormFields)` computed at runtime instead of a static import, and it
      only ever enters `activeSteps` when `getActiveFormSteps(..., hasCustomFields)` is true — a
      program/institution with no custom fields never sees it, satisfying the degenerate-case rule
      exactly. Files: `types/form-types.ts` (enum, `FORM_STEPS`, `STEP_FIELDS`,
      `getActiveFormSteps`, new `getCustomFormFields` helper, `customFields` on
      `FormDefaultValues`), `hooks/useAdmissionForm.ts` (resolves `effective("FORM", programId)`,
      validates/clears/reports errors for the new step), `components/steps/AdditionalInfoStep.tsx`
      (new), `page.tsx` (`StepRenderer` case + prop threading). Also fixed a real bug this surfaced:
      the saved-step restore bounds check (`step <= FormStep.REVIEW`) would have silently rejected
      a draft parked on the new step and bounced the user back to step 0 — widened to
      `FormStep.ADDITIONAL_INFO`, the new true max.
- [x] **B4 — Submission:** `application-submit.service.ts` appends `custom_fields` to the
      multipart payload (omitted entirely when empty — no change for any program without custom
      fields). Nested `File` values inside `customFields` persist through the IndexedDB draft
      save/restore cycle via the browser's structured-clone support (`storage.ts`'s `store.put()`)
      even though they aren't in that file's hardcoded top-level `fileFields` extraction list —
      confirmed by reading `storage.ts` directly rather than assumed.
- [x] **B5 — Review screen:** `ReviewStep.tsx` gained an "Additional Information" section,
      rendered only when the program has custom fields, showing each by its resolved
      label — generic, not hardcoded, so a program admin adding a new field needs no frontend
      change to see it reviewed correctly.

## Verification

Every phase run through `npx tsc --noEmit` + `npx eslint src`, both clean, before moving to the
next — including after B3–B5, the pass that touches the live wizard.

**Residual risk, stated plainly:** none of `API_CONTRACTS.md`'s endpoints exist on the live
backend yet (verified 2026-09-11), so B3–B5 could not be exercised end-to-end against a real
`effective` response — only against `tsc`/`eslint` and manual reasoning about the existing 8
steps' unchanged code paths. The design deliberately minimizes surface area touched (one new step,
gated behind a length check that's `0` today) specifically because of this — but it has not run in
a browser against live data. **Recommend a manual smoke test of the ordinary (no custom fields)
application flow once this deploys**, to confirm `activeSteps` genuinely excludes
`ADDITIONAL_INFO` and every existing step still behaves identically, before trusting it with real
applicants.

## Status (2026-09-11)

All phases (0, A, B, C) done on the frontend. Nothing left on this side pending backend delivery
of `BACKEND_REQUIRED_ENDPOINTS.md`. Next: ship the backend pieces, then do the live smoke test
above before considering B3–B5 fully proven.
