# Moodle Cohort Sync — Web Service Detail

Companion to `API_CONTRACTS.md` §C. This is the Moodle-side mechanics: which native Moodle
features this rides on, which web service functions the backend calls, and the one manual setup
step a Moodle admin does per shared course.

---

## Why cohorts, not a custom enrolment plugin

Moodle has had **cohorts** as a core concept since 2.0 — a named group of users, independent of
any course. Paired with the core **"Cohort sync" enrolment method** (`enrol_cohort`), adding a
user to a cohort automatically enrols them into every course that has that enrolment method
configured; removing them automatically unenrols them. This is exactly "auto-enrol a program's
whole intake into shared activities," built into Moodle already — no custom plugin, no cron
polling loop on our side beyond what already drives the rest of Moodle sync.

## What a cohort *is*, here

Not a new concept — `Program + AcademicSession (+ Level)`. "Certificate in Data Science —
2026/2027 Session" is a cohort; it doesn't need its own identity beyond that composite key. See
`SCHEMA_CHANGES.md` §5 for the `MoodleSyncCohort` mapping row and its `idnumber` convention
(`"program:{id}:session:{id}[:level:{id}]"` — the same `idnumber`-as-external-key pattern already
proven by `MoodleSyncCategory`, see MDL-28518).

## Web service functions used

All of these are core Moodle web services — no custom plugin required, just the same
webservice/token setup already in place for the rest of Moodle sync.

| Function | Used for |
|---|---|
| `core_cohort_create_cohorts` | Creating a new Moodle cohort for a `MoodleSyncCohort` row that has no `moodleCohortId` yet |
| `core_cohort_get_cohorts` | Reconciliation — reading a cohort's current state/members before a `sync-members` diff |
| `core_cohort_add_cohort_members` | Adding one or more users to a cohort (enrollment created, or `sync-members` reconciliation) |
| `core_cohort_delete_cohort_members` | Removing one or more users from a cohort (enrollment dropped/withdrawn) |

All four accept/return Moodle's own numeric IDs — the mapping row's `moodleCohortId` and each
student's already-tracked `MoodleSyncUser.moodleUserId` are what gets passed, no new ID
resolution needed beyond what Moodle Sync's user mapping already does today.

## Cohort creation payload

```json
{
  "cohorts": [
    {
      "name": "Certificate in Data Science — 2026/2027",
      "idnumber": "program:55:session:12",
      "description": "Auto-managed by the portal — do not edit membership manually.",
      "visible": 1
    }
  ]
}
```

Response includes Moodle's assigned cohort `id` — store as `MoodleSyncCohort.moodleCohortId`.

## Membership add/remove payload

```json
{
  "members": [
    { "cohorttype": { "type": "id", "value": 42 }, "usertype": { "type": "id", "value": 1001 } }
  ]
}
```
(`core_cohort_add_cohort_members` / `core_cohort_delete_cohort_members` share this shape — batch
multiple students in one call rather than one request per student, same batching discipline the
existing bulk user/enrollment sync already follows.)

## The one manual Moodle-side step

For each course that should auto-enrol a whole cohort (a shared orientation course, a shared
"Foundational — Semester 1" course, etc.), a Moodle admin — once, per course:

1. Course → Participants → Enrolment methods → Add method → **Cohort sync**.
2. Select the cohort (matches on the cohort's Moodle `name`/`idnumber` — the same one
   `MoodleSyncCohort` created).
3. Set the role to assign (usually **Student**).

From that point on, cohort membership changes (driven entirely by our automatic sync) flow
straight through to that course's enrolment — no further action needed per student, per
semester, or per intake.

**Optional future automation:** this manual step is itself scriptable via
`enrol_cohort_...` web service functions if the portal should provision the enrolment method too
(e.g. an admin picks "this course is shared across the whole Foundational intake" in our own UI
and we configure Moodle's side automatically). Not required for v1 — flagged here as the natural
next step if it turns out to matter operationally.

## What is *not* stored on our side

No local cohort-membership table. Moodle is the source of truth for who's actually in a cohort;
our side only ever *triggers* add/remove calls off events we already track
(`StudentEnrollment` status changes) and, for drift recovery, *reads* Moodle's membership via
`core_cohort_get_cohorts` to reconcile (`POST /moodle-sync/cohorts/:id/sync-members`,
`API_CONTRACTS.md` §C). This mirrors how the rest of Moodle Sync already treats Moodle as
authoritative for LMS-side state.
