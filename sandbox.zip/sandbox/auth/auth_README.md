# Auth Module

Handles authentication, authorization, roles, and permissions. Owns user credential management (login, registration, password reset, token refresh) and RBAC (role-based access control).

## Models Owned

- **RefreshToken** — JWT refresh tokens per user
- **PasswordReset** — password reset request tokens
- **Role** — named roles (e.g. `admin`, `student`, `lecturer`)
- **Permission** — granular resource + action permissions
- **UserRole** — user ↔ role assignments
- **RolePermission** — role ↔ permission assignments

---

## Endpoints

### Authentication

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `POST` | `/auth/register` | Register a new user account | Public |
| `POST` | `/auth/login` | Login with email/username + password | Public |
| `POST` | `/auth/refresh` | Refresh an expired access token | Public (requires refresh token) |
| `POST` | `/auth/logout` | Revoke the current refresh token | Authenticated |
| `POST` | `/auth/forgot-password` | Request a password reset email | Public |
| `POST` | `/auth/reset-password` | Reset password using a valid token | Public |
| `GET` | `/auth/me` | Get current authenticated user profile | Authenticated |

### Roles

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/auth/roles` | List all roles | Admin |
| `GET` | `/auth/roles/:id` | Get role details with permissions | Admin |
| `POST` | `/auth/roles` | Create a new role | Admin |
| `PATCH` | `/auth/roles/:id` | Update a role | Admin |
| `DELETE` | `/auth/roles/:id` | Delete a role | Admin |

### Permissions

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/auth/permissions` | List all permissions | Admin |
| `POST` | `/auth/permissions` | Create a permission | Admin |

### Role-Permission Assignments

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `POST` | `/auth/roles/:roleId/permissions` | Assign permissions to a role | Admin |
| `DELETE` | `/auth/roles/:roleId/permissions/:permissionId` | Remove permission from role | Admin |

### User-Role Assignments

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `POST` | `/auth/users/:userId/roles` | Assign roles to a user | Admin |
| `DELETE` | `/auth/users/:userId/roles/:roleId` | Remove role from a user | Admin |
| `GET` | `/auth/users/:userId/roles` | List roles assigned to a user | Admin |

---

## Request & Response Types

### `POST /auth/register`

**Request Body (`RegisterDto`):**

```ts
{
  email: string;          // unique, valid email
  username: string;       // unique, max 100 chars
  password: string;       // min 8 chars
}
```

> **Note:** Registration collects only credentials. Personal details (name, phone, etc.) are collected later through the admission application form or admin profile setup.

**Response: `201 Created`**

```ts
{
  accessToken: string;
  refreshToken: string;
  user: {
    id: number;
    email: string;
    username: string;
  };
}
```

---

### `POST /auth/login`

**Request Body (`LoginDto`):**

```ts
{
  emailOrUsername: string;
  password: string;
}
```

**Response: `200 OK`**

```ts
{
  accessToken: string;
  refreshToken: string;
  user: {
    id: number;
    email: string;
    username: string;
    firstName: string | null;
    lastName: string | null;
    roles: string[];       // e.g. ["admin", "lecturer"]
  };
}
```

---

### `POST /auth/refresh`

**Request Body (`RefreshTokenDto`):**

```ts
{
  refreshToken: string;
}
```

**Response: `200 OK`**

```ts
{
  accessToken: string;
  refreshToken: string;   // rotated
}
```

---

### `POST /auth/forgot-password`

**Request Body (`ForgotPasswordDto`):**

```ts
{
  email: string;
}
```

**Response: `200 OK`**

```ts
{
  message: "Password reset link sent if the email exists";
}
```

---

### `POST /auth/reset-password`

**Request Body (`ResetPasswordDto`):**

```ts
{
  token: string;
  newPassword: string;    // min 8 chars
}
```

**Response: `200 OK`**

```ts
{
  message: "Password reset successful";
}
```

---

### `GET /auth/me`

**Response: `200 OK`**

```ts
{
  id: number;
  email: string;
  username: string;
  firstName: string | null;
  middleName: string | null;
  lastName: string | null;
  phoneNumber: string | null;
  avatar: string | null;
  isActive: boolean;
  isVerified: boolean;
  lastLoginAt: string | null;
  roles: { id: number; name: string }[];
  permissions: string[];   // flattened, e.g. ["users.read", "courses.create"]
}
```

---

### `POST /auth/roles`

**Request Body (`CreateRoleDto`):**

```ts
{
  name: string;           // unique, max 50 chars
  description?: string;
}
```

**Response: `201 Created`** — returns the created role.

---

### `POST /auth/permissions`

**Request Body (`CreatePermissionDto`):**

```ts
{
  name: string;           // unique, max 100 chars (e.g. "users.read")
  description?: string;
  resource: string;       // max 100 chars (e.g. "users")
  action: string;         // max 50 chars (e.g. "read")
}
```

**Response: `201 Created`** — returns the created permission.

---

### `POST /auth/roles/:roleId/permissions`

**Request Body (`AssignPermissionsDto`):**

```ts
{
  permissionIds: number[];
}
```

**Response: `200 OK`** — returns the updated role with permissions.

---

## Notes for Developers

- Passwords must be hashed with bcrypt before storage (`passwordHash`).
- Access tokens should be short-lived (e.g. 15 min). Refresh tokens should be long-lived (e.g. 7 days) and stored in the `refresh_tokens` table.
- On refresh, rotate the refresh token (revoke old, issue new).
- The `PasswordReset` token should expire after a set time (e.g. 1 hour). Mark `usedAt` once consumed.
- Permission format: `resource.action` (e.g. `students.read`, `grades.approve`). Enforce via guards.
