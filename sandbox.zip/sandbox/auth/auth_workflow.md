# Auth Module — Implementation Workflow

This document explains the internal implementation flow for the Auth module. It is intended for developers building or maintaining this module.

---

## Module Dependencies

```
AuthModule
├── PrismaService          (database access)
├── JwtService              (token generation/verification)
├── ConfigService           (JWT secrets, expiry durations)
├── NotificationModule      (password reset emails)
└── AuditModule             (login/logout logging)
```

---

## 1. Registration Flow

**Endpoint:** `POST /auth/register`

```
Client sends { email, username, password }
         │
         ▼
┌─────────────────────────────┐
│  AuthController.register()  │
│  - Validate RegisterDto     │
└────────────┬────────────────┘
             │
             ▼
┌─────────────────────────────────────────────┐
│  AuthService.register()                     │
│  1. Check if email already exists → 409     │
│  2. Check if username already exists → 409  │
│  3. Hash password with bcrypt (10 rounds)   │
│  4. Create User record in DB                │
│     - firstName: null, lastName: null        │
│     - isActive: true, isVerified: false     │
│  5. Generate access token (JWT, 15min)      │
│  6. Generate refresh token (JWT, 7 days)    │
│  7. Store refresh token in DB               │
│  8. Return { accessToken, refreshToken,     │
│     user: { id, email, username } }         │
└─────────────────────────────────────────────┘
```

**Key implementation notes:**
- Registration is intentionally lightweight — only credentials. No personal info collected at this stage.
- Student applicants will provide their personal details later through the admission application form.
- Lecturer/Staff personal details are filled by admin when assigning roles (User Module).
- `isVerified` defaults to `false`. Email verification can be added later.

---

## 2. Login Flow

**Endpoint:** `POST /auth/login`

```
Client sends { emailOrUsername, password }
         │
         ▼
┌──────────────────────────────────────────────┐
│  AuthService.login()                         │
│  1. Find user by email OR username           │
│     - Not found → 401 "Invalid credentials"  │
│  2. Check isActive → false → 403 "Disabled"  │
│  3. Compare password with bcrypt hash        │
│     - Mismatch → 401 "Invalid credentials"   │
│  4. Load user roles (via UserRole → Role)    │
│  5. Update lastLoginAt timestamp             │
│  6. Generate access + refresh tokens         │
│  7. Store refresh token in DB                │
│  8. Log via AuditService (action: "LOGIN")   │
│  9. Return tokens + user object              │
│     - firstName/lastName may be null          │
└──────────────────────────────────────────────┘
```

**Security notes:**
- Always return the same error message for wrong email/username and wrong password (prevents enumeration).
- Rate-limit login attempts per IP/user (e.g., 5 attempts per 15 min).
- Consider locking the account after repeated failures.

---

## 3. Token Refresh Flow

**Endpoint:** `POST /auth/refresh`

```
Client sends { refreshToken }
         │
         ▼
┌──────────────────────────────────────────────────┐
│  AuthService.refreshToken()                      │
│  1. Verify JWT signature on refreshToken         │
│     - Invalid → 401                              │
│  2. Find token in DB by value                    │
│     - Not found → 401 (already revoked)          │
│  3. Check if expired (expiresAt < now)           │
│     - Expired → 401                              │
│  4. Revoke old refresh token (set revokedAt)     │
│  5. Generate new access token                    │
│  6. Generate new refresh token (rotation)        │
│  7. Store new refresh token in DB                │
│  8. Return { accessToken, refreshToken }         │
└──────────────────────────────────────────────────┘
```

**Key points:**
- **Token rotation**: Every refresh issues a new refresh token and revokes the old one.
- If a revoked token is used again, it may indicate token theft → consider revoking ALL tokens for that user.
- Refresh tokens are stored in the `refresh_tokens` table with `userId`, `token`, `expiresAt`, `revokedAt`.

---

## 4. Password Reset Flow

**Endpoint:** `POST /auth/forgot-password` → `POST /auth/reset-password`

```
Step 1: Request reset
─────────────────────
Client sends { email }
         │
         ▼
┌──────────────────────────────────────────────────┐
│  AuthService.forgotPassword()                    │
│  1. Find user by email                           │
│     - NOT found → still return 200 (no leak)     │
│  2. Generate secure random token (e.g. uuid v4)  │
│  3. Create PasswordReset record                  │
│     - token, userId, expiresAt (now + 1 hour)    │
│  4. Send email with reset link via Notification  │
│     - Link: {frontendUrl}/reset?token=xxx        │
│  5. Return { message: "..." }                    │
└──────────────────────────────────────────────────┘

Step 2: Consume reset token
────────────────────────────
Client sends { token, newPassword }
         │
         ▼
┌──────────────────────────────────────────────────┐
│  AuthService.resetPassword()                     │
│  1. Find PasswordReset by token                  │
│     - Not found → 400                            │
│  2. Check expiresAt > now                        │
│     - Expired → 400                              │
│  3. Check usedAt is null                         │
│     - Already used → 400                         │
│  4. Hash new password with bcrypt                │
│  5. Update user's passwordHash                   │
│  6. Set usedAt = now on the reset record         │
│  7. Revoke ALL refresh tokens for this user      │
│  8. Return success message                       │
└──────────────────────────────────────────────────┘
```

---

## 5. JWT Token Structure

### Access Token Payload

```ts
{
  sub: number;        // user ID
  email: string;
  username: string;
  roles: string[];    // ["admin", "student", ...]
  iat: number;        // issued at
  exp: number;        // expires (15 min)
}
```

### Refresh Token Payload

```ts
{
  sub: number;        // user ID
  tokenId: number;    // RefreshToken record ID (for revocation lookup)
  iat: number;
  exp: number;        // 7 days
}
```

---

## 6. RBAC (Role-Based Access Control)

### Permission Resolution

```
Request arrives with JWT
         │
         ▼
┌──────────────────────────────────────────────────┐
│  AuthGuard (JWT Strategy)                        │
│  1. Extract & verify access token                │
│  2. Attach user to request                       │
└────────────┬─────────────────────────────────────┘
             │
             ▼
┌──────────────────────────────────────────────────┐
│  RolesGuard / PermissionsGuard                   │
│  1. Read @Roles() or @Permissions() decorator    │
│  2. Load user's roles from JWT (or DB if needed) │
│  3. For permissions: resolve via                 │
│     UserRole → Role → RolePermission → Permission│
│  4. Check if user has the required role/perm     │
│     - Yes → allow                                │
│     - No → 403 Forbidden                         │
└──────────────────────────────────────────────────┘
```

### Managing Roles & Permissions (Admin)

```
Admin creates Roles:     POST /auth/roles        { name: "lecturer" }
Admin creates Perms:     POST /auth/permissions   { name: "grades.create", resource: "grades", action: "create" }
Admin links them:        POST /auth/roles/:id/permissions  { permissionIds: [1, 2, 3] }
Admin assigns to user:   POST /auth/users/:id/roles        { roleIds: [1] }
```

---

## 7. Guard Decorator Usage

```ts
// In any controller
@UseGuards(AuthGuard, RolesGuard)
@Roles('admin')
@Post()
createSomething() { ... }

@UseGuards(AuthGuard, PermissionsGuard)
@Permissions('grades.create')
@Post()
submitGrade() { ... }
```

---

## 8. Files to Create

```
src/modules/auth/
├── auth.module.ts              # Module definition, imports JwtModule
├── auth.controller.ts          # Routes: register, login, refresh, logout, forgot/reset, me, roles, perms
├── auth.service.ts             # Business logic for all auth operations
├── strategies/
│   └── jwt.strategy.ts         # Passport JWT strategy
├── guards/
│   ├── auth.guard.ts           # JWT verification guard
│   ├── roles.guard.ts          # Role-based guard
│   └── permissions.guard.ts    # Permission-based guard
├── decorators/
│   ├── roles.decorator.ts      # @Roles() decorator
│   ├── permissions.decorator.ts# @Permissions() decorator
│   └── current-user.decorator.ts # @CurrentUser() param decorator
├── dto/
│   ├── register.dto.ts
│   ├── login.dto.ts
│   ├── refresh-token.dto.ts
│   ├── forgot-password.dto.ts
│   ├── reset-password.dto.ts
│   ├── create-role.dto.ts
│   ├── create-permission.dto.ts
│   └── assign-permissions.dto.ts
└── auth.service.spec.ts
```

---

## 9. Cross-Module Integration Points

| Consumer Module | What it uses from Auth |
| --------------- | ---------------------- |
| **All modules** | `AuthGuard`, `RolesGuard`, `PermissionsGuard` decorators |
| **User Module** | Assigns roles when creating lecturer/staff |
| **Payment Module** | Assigns `student` role when creating Student record after tuition payment |
| **Admission Module** | Reads `userId` from JWT for application submission |
| **Audit Module** | Receives login/logout events via `AuditService.log()` |
