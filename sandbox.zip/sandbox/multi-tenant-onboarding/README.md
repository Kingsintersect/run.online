# Multi-Tenant Onboarding — Program Type Configuration Reference

**Status: research/reference document.** This is the input to an admin-facing **Onboarding
Module**: a screen (or wizard) that lets a super-admin configure a new institution instance —
or a new program within an existing instance — by picking a program type and having the portal
pre-populate the settings that type actually needs, instead of every deployment hand-rolling the
same decisions from scratch.

Goal, as given: one portal codebase, deployable per institution (separate database/config per
tenant), where each tenant's programs can be any mix of **Degree, Postgraduate, Business School,
Certificate, Sandwich**, and (per the standing benchmark-against-reality rule this project follows)
**Secondary School** — since a Nigerian group of schools running both a secondary school and a
degree-awarding affiliate is a completely normal real-world case, not an edge case.

This document does not decide the multi-tenancy architecture itself (single shared DB with a
`tenantId` column vs. one database per tenant vs. schema-per-tenant) — that's a separate
infrastructure decision. It answers a narrower, prerequisite question: **what actually differs
between these program types in a real Nigerian institution**, so the onboarding module has a
correct list of settings to expose, instead of guessing.

---

## 1. The program types, in plain terms

| Type | What it actually is in Nigeria |
|---|---|
| **Degree** | Standard NUC-accredited undergraduate: B.Sc/B.A/B.Eng/B.Ed etc., 4–6 years depending on faculty (Medicine/Engineering run longer), entered via UTME + Post-UTME. |
| **Postgraduate** | PGD/M.Sc/M.A/M.Ed/MBA/PhD run under a School (or Faculty) of Postgraduate Studies. Same institution, different admission path (first degree, not UTME), different grading floor, and a mandatory thesis/dissertation component. |
| **Business School** | Either (a) an NUC-accredited MBA/EMBA run through a university-affiliated business school (e.g. Lagos Business School under Pan-Atlantic University), or (b) non-degree executive/professional programs run in cohorts, often evenings/weekends, priced and structured completely differently from an academic semester. |
| **Certificate Programs** | Short, non-degree professional/skills programs — a Continuing Education Centre's diploma/certificate offerings, or an NBTE-recognized ND/HND track at a polytechnic. Rolling intakes, no UTME, often no credit-unit GPA at all. |
| **Sandwich Programs** | Vacation-only degree programs (classically B.Ed/B.Sc(Ed) for practicing teachers) — same NUC-accredited award as the regular degree, but delivered in intensive blocks during the long vacation (July–September) over 3–4 years, because students are working teachers who can't attend during term time. |
| **Secondary School** | JSS1–SS3 (6 years), WAEC/NECO/NABTEB-examined, 3-term session, no credit-unit GPA — a simple average + class position per term, with a Science/Arts/Commercial stream split starting at SS1. |

---

## 2. Configuration comparison matrix

| Setting | Degree | Postgraduate | Business School | Certificate | Sandwich | Secondary School |
|---|---|---|---|---|---|---|
| **Regulator / accreditor** | NUC | NUC (via the Postgraduate School) | NUC if degree-awarding (MBA); otherwise unregulated / professional body (CIBN, NIM, ICAN, etc.) | NBTE (ND/HND) or unaccredited (Continuing Education) | NUC (same accreditation as the regular degree it mirrors) | WAEC / NECO / NABTEB + State/Federal Ministry of Education |
| **Structure depth (`AcademicUnit` tree)** | Faculty → Department → Program → Level → Semester | School of PG Studies → Department → Program → Level (PG1/PG2 or Year) → Semester | Business School → Program → Cohort/Intake → Module (often no Faculty/Department layer at all) | Institute/Centre → Program → Batch → Module | Faculty of Education → Department → Program → Level → Semester (same shape as Degree) | Section (Junior/Senior) → Stream (Science/Arts/Commercial, SS only) → Level (JSS1–SS3) → Term |
| **Calendar model** | 2-semester session, ~9 months/session, 4–6 yrs total | 2-semester session; PGD ~1yr, Masters 1–2yrs, PhD 3–5yrs | Cohort/module-based, not tied to a standard academic calendar; executive programs run evenings/weekends across "modules" | Rolling intakes, short intensive runs (weeks–months), not session-based | Vacation-only intensive blocks (Jul–Sep), 3–4 yrs total elapsed | 3-term session (~Sept–July), 6 yrs total (JSS1–SS3) |
| **Grading model (`GradingSchemeType`)** | `CREDIT_WEIGHTED_GPA`, 5-point scale, CA 30–40% + Exam 60–70% | `CREDIT_WEIGHTED_GPA`, 5-point scale, but **higher minimum CGPA to graduate** (e.g. 3.00 vs 1.00 undergrad) | Often `PASS_FAIL` per module for executive/non-degree tracks; `CREDIT_WEIGHTED_GPA` if it's an accredited MBA | `PASS_FAIL` or Distinction/Merit/Pass — no GPA | `CREDIT_WEIGHTED_GPA`, identical to the regular degree (same award) | `SIMPLE_AVERAGE`, WAEC 9-point scale (A1–F9), computed per term + cumulative — **no credit-unit GPA** |
| **Course/subject unit model** | Credit units (2–4/course), min total (e.g. 120–180) to graduate | Credit units **plus** a heavily-weighted mandatory Thesis/Dissertation "course" | Modules — often contact-hours or pass/fail, not credit-unit based | Modules, completion-based, typically no credit-unit concept | Same credit-unit system as the regular degree | Subjects (WAEC-defined), no credit units; core (Math, English) + electives by stream |
| **Admission requirement** | UTME (JAMB) + O'Level (5 credits incl. Eng/Math) + Post-UTME screening | First degree (min CGPA threshold) in a relevant field, sometimes + work experience | First degree + work experience (2–5 yrs for MBA); GMAT/interview for top-tier schools | Varies — some need O'Level, many are open-entry (professional development) | Teaching qualification (NCE) or verified working-teacher status + O'Level; **no UTME** — entry via employer/state sponsorship | Common Entrance Exam (JSS1 entry) or JSS3/BECE result + stream choice (SS1 entry) |
| **Class arms / cohort grouping** | None — one Program cohort per Level/Semester | None | Named cohorts (e.g. "MBA 2026 Cohort A") | Named batches | Groups/sets, often by sponsoring state or entry year | Class arms (e.g. "SS2 Science A" vs "SS2 Science B") — a real modeling concern once you have more than one arm per Level+Stream |
| **Thesis / project / capstone** | Final-year undergraduate project, modest weight | Mandatory Thesis/Dissertation with a defense/viva, heavily weighted | Capstone/consulting project (MBA) or business plan; varies by program | Rare, sometimes a practical assignment, not heavily weighted | Same final-year project as the regular degree | SS3 project/practicals (sciences) — not a thesis, not separately weighted in the WAEC average |
| **Fee model** | Per-session tuition + acceptance fee + ancillary charges | Per-session, usually higher than undergrad; may include a thesis-supervision fee | Per-program (often installment-paid upfront) or per-module for executive tracks — materially higher fees than academic programs | Per-program flat fee, sometimes per-module | Per-session but concentrated into the vacation period; often subsidized by the sponsoring state government or employer | Per-term tuition + boarding (if applicable) + PTA levies |
| **Award / certification** | B.Sc/B.A/B.Eng etc., with a Class of Degree (First, Second Upper, …) | PGD / M.Sc / M.A / M.Ed / MBA / PhD — no "class of degree" | MBA/EMBA (degree, NUC-recognized) **or** a non-degree Certificate/Executive Certificate of Completion | Certificate/Diploma (non-degree), or NBTE-recognized ND/HND | Same B.Sc(Ed)/B.Ed award as the regular degree, full NUC accreditation | WAEC/NECO/NABTEB SSCE certificate + transcript |
| **Attendance policy** | Per-class attendance, minimum % required to sit the exam | Looser — thesis-progress tracking matters more than lecture attendance | Strict — minimum attendance often required for the certificate/award itself, given the cohort/executive format | Attendance-driven completion certificate | Strict — intensive vacation delivery means missed sessions are very costly to recover | Daily attendance register + conduct/discipline tracking, class-teacher remarks |
| **LMS / Moodle content shape** | One Moodle course per CourseOffering per semester | Course-per-offering + a thesis-supervision workspace | Module-per-cohort, blended/hybrid delivery is the norm, not the exception | Module-per-batch, often heavily self-paced content | Course-per-vacation-session (compressed delivery, same course shape as Degree) | Subject-per-term, content aligned to the WAEC/NECO syllabus |

---

## 3. What the onboarding module needs to let an admin configure

Reading the matrix as a settings checklist, per program type, an onboarding flow needs to capture
at minimum:

1. **`programCategory`** — which of the six types this program is (see gap note below).
2. **Structure template** — which `AcademicUnitType` shape to pre-build (Faculty-down vs
   Section/Stream-down vs flat Cohort-only), so the admin isn't hand-building the tree from
   scratch for a type this codebase already knows the shape of.
3. **`gradingSchemeId`** — pick an existing scheme or spin up a new one (name, `schemeType`, pass
   mark, CA/exam weights) right from the onboarding flow rather than as a separate later step.
4. **Calendar model** — session/semester (Degree/PG/Sandwich/Secondary) vs cohort/intake
   (Business School/Certificate) — this determines whether `AcademicSession`/`Semester` rows are
   even the right container, or whether a program needs a lighter "Cohort" `AcademicUnitType`
   instead (the generic tree already supports adding custom types for exactly this).
5. **Admission path** — UTME-gated vs direct-entry vs employer/state-sponsored vs open-enrollment;
   determines which `AdmissionApplication` fields are required/hidden per program.
6. **Fee model** — per-session vs per-program-flat vs per-module-installment; determines which
   `FeeType` scoping rules apply and how `Invoice` generation is triggered (session-start vs
   enrollment-start vs module-start).
7. **Class-arm support toggle** — whether this program's Levels split into arms (only really needed
   for Secondary School today, but worth making a generic toggle rather than hardcoding it).
8. **Thesis/capstone requirement toggle** — whether a `RESEARCH_PROJECT`-type course is mandatory
   and how heavily it's weighted in the final result.
9. **Attendance enforcement toggle** — whether attendance gates exam eligibility (Degree/Secondary)
   or is loosely tracked (PG) or gates certification itself (Business School/Sandwich).

---

## 4. Gap against the current schema

The multi-structure refactor already shipped this session (see
`sandbox/schema-moodel-sync-refactor/`) covers **Degree, Postgraduate, Certificate, Diploma, and
Secondary School** via the `ProgramCategory` enum. It does **not** yet have a category for
**Business School** or **Sandwich**:

- **Sandwich** structurally *is* a Degree (same award, same credit-unit GPA, same Faculty tree) —
  it only differs in calendar model (vacation-only delivery) and admission path (no UTME). This
  probably doesn't need its own `programCategory` value; it needs a **delivery-mode flag**
  (`STANDARD` vs `SANDWICH`) orthogonal to `programCategory`, since "Sandwich B.Ed" and "Regular
  B.Ed" are the same category with a different calendar/admission behavior, not different grading
  or structure.
- **Business School** genuinely differs in structure (flat, cohort-based, often no Faculty/
  Department layer) and grading (frequently pass/fail, not GPA) — this one likely *does* warrant
  its own `ProgramCategory` value, `BUSINESS_SCHOOL`, plus a `COHORT` structural `AcademicUnitType`
  as its natural anchor instead of Level/Semester.

Neither of these is built yet. Flagging here rather than in `MISSING_BACKEND_APIS.md` since this
is a schema/product decision to confirm before it becomes a backend contract to design.

---

## 5. Open questions before designing the onboarding module itself

- **Tenancy model**: separate database per institution, schema-per-tenant, or shared database with
  a `tenantId` column? This changes how "onboarding a new institution" behaves (provisioning a new
  DB vs inserting a tenant row) — worth deciding before the onboarding UI is designed, since it
  changes what the first screen of the wizard even does.
- **Scope of one onboarding flow**: does it configure a *new institution* (provisioning-level:
  branding, domain, first admin user, first program) or configure *a new program* inside an
  already-provisioned institution (the settings catalog in §3 above)? Likely both, as two distinct
  flows sharing the same settings catalog.
- **`CLAUDE.md` §1** currently states "Single-tenant — one deployment per university instance. No
  multi-tenancy." That will need updating once the multi-tenant direction is confirmed — not done
  here since it's a standing project-instructions change, not a byproduct of this reference doc.
