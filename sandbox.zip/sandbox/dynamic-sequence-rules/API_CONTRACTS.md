# API Contracts — Dynamic Sequence Rules

## 1. `GET /admissions/config/sequence-rules?majorProgramId=`

Admin-only. `majorProgramId` optional — omitted means "show the institution-default row." Returns
every known rule code (the fixed Phase-1 set) with its resolved state for the requested scope, so
the frontend can render one row per rule without hand-maintaining the list of codes.

```jsonc
// GET /admissions/config/sequence-rules?majorProgramId=7
[
  {
    "id": 14,                // this exact scope's own row id — present only when source is "own";
                              // null otherwise (nothing to delete/reset for "default"/"builtin")
    "ruleCode": "ACCEPTANCE_PAYMENT_AFTER_DECISION",
    "enabled": false,
    "source": "own"          // "own" | "default" | "builtin" — where this value came from,
                              // per SCHEMA_CHANGES.md §1's resolution order
  },
  {
    "id": null,
    "ruleCode": "MAJOR_PROGRAM_CHOICE_MUST_BE_FIRST",
    "enabled": true,
    "source": "builtin"      // no row for this scope or the institution default — hardcoded fallback
  }
  // ...remaining 4 rule codes, always all 6 present regardless of how many rows exist.
  // `label`/`description` are NOT sent — the frontend already owns that copy locally
  // (SEQUENCE_RULE_CATALOG, src/lib/admission-catalog.ts), same split as STAGE_TYPE_CATALOG today.
]
```

## 2. `PATCH /admissions/config/sequence-rules`

```jsonc
// Sets (or clears) one rule for one scope.
// PATCH /admissions/config/sequence-rules
{
  "majorProgramId": 7,              // null = writing the institution-default row
  "ruleCode": "ACCEPTANCE_PAYMENT_AFTER_DECISION",
  "enabled": false
}
// → 200, echoes the updated row. Upsert semantics — creates the row if it doesn't exist yet,
// updates it if it does (matches the existing `(majorProgramId, ruleCode)` unique constraint).
```

To remove an override and fall back to the next level in the resolution order (own → default →
builtin), a `DELETE /admissions/config/sequence-rules/{id}` — plain row delete, nothing scope-aware
needed beyond what already exists for deleting any other scoped row in this codebase.

## 3. The actual behavior change — `INVALID_STAGE_SEQUENCE` validation

**Today:** `POST`/`PATCH`/`DELETE /admissions/config/steps` and `PATCH
/admissions/config/steps/reorder` each validate the full resolved sequence for the request's scope
against all 8 hardcoded rules (`README.md` §3), rejecting with `422 { "message": "INVALID_STAGE_
SEQUENCE: <CODE>" }` on the first violation found — confirmed live, exact shape, 2026-09-15
(`ACCEPTANCE_PAYMENT_BEFORE_DECISION` hit on Certificate Programmes).

**Proposed:** before applying each of the 5 **Precedence** checks (not the 3 Integrity ones — see
`README.md` §4's Phase 1 scope), resolve `isRuleEnabled(ruleCode, majorProgramId)` (`SCHEMA_CHANGES.
md` §1) for the scope being validated, and skip that specific check when it resolves to `false`. The
3 Integrity checks (`MISSING_TYPE`, `MULTIPLE_{TYPE}`, `MISSING_COMPLETE`) run unconditionally,
exactly as today. The error code returned on a violation is unchanged — still e.g.
`ACCEPTANCE_PAYMENT_BEFORE_DECISION` — a disabled rule simply never gets the chance to fire, rather
than firing with a different code or message.

```jsonc
// BEFORE this change — Certificate Programmes, ACCEPTANCE_PAYMENT_AFTER_DECISION has no way to be
// turned off, so this 422 is unavoidable if Certificate has an Acceptance-fee payment step with no
// Decision stage ahead of it:
// PATCH /admissions/config/steps/58  { enabled: false }   (hiding Application Payment)
// → 422 { "message": "INVALID_STAGE_SEQUENCE: ACCEPTANCE_PAYMENT_BEFORE_DECISION" }

// AFTER — an admin first does:
// PATCH /admissions/config/sequence-rules
// { "majorProgramId": <certificate id>, "ruleCode": "ACCEPTANCE_PAYMENT_AFTER_DECISION", "enabled": false }
// PATCH /admissions/config/sequence-rules
// { "majorProgramId": <certificate id>, "ruleCode": "TUITION_PAYMENT_AFTER_DECISION", "enabled": false }
// — then the exact same PATCH /admissions/config/steps/58 call succeeds, because the validator
// skips both checks for Certificate's scope specifically. Every other major program is unaffected —
// they never referenced Certificate's `majorProgramId`.
```

**`GET /admissions/config/steps/effective`** — no change. This proposal only touches the write-side
validation, not step resolution (A23's rule stays exactly as it is).

## 4. Frontend call sites this would need (not built, listed for the backend team's awareness)

- A settings surface per major program (likely a new panel/tab inside `admission-config`) listing
  the 6 Precedence rules with a toggle each, backed by §1/§2 above.
- `validateStageSequence()` (`stage-sequence.ts`) would need to accept the resolved rule settings for
  the current scope (fetched via §1) and skip a check when its rule is disabled, so the client-side
  warning banner stays in sync with what the server will actually accept — mirroring the same
  "frontend mirrors backend's real rules" relationship it already has today.
- Not scoped or estimated yet — this file exists so the backend team can react to the contract shape
  now; the frontend build itself is a separate, later piece of work once this is agreed.
