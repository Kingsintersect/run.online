# Schema Changes — Dynamic Sequence Rules

## 1. New model — `AdmissionSequenceRuleSetting` (Phase 1)

```
AdmissionSequenceRuleSetting
  id                 PK
  majorProgramId     FK → MajorProgram, nullable   // null = institution-wide default row
  ruleCode           enum SequenceRuleCode          // one of the fixed 6 Precedence codes, see below
  enabled            boolean
  updatedByUserId    FK → User
  updatedAt          timestamp
```

```sql
CREATE TABLE admission_sequence_rule_settings (
  id SERIAL PRIMARY KEY,
  major_program_id INTEGER NULL REFERENCES major_programs(id),
  rule_code VARCHAR(64) NOT NULL,
  enabled BOOLEAN NOT NULL,
  updated_by_user_id INTEGER NOT NULL REFERENCES users(id),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (major_program_id, rule_code)
);
```

`rule_code` is a closed set for Phase 1 — validate against an enum, not a free string, so a typo
can't silently create a dead row:

```ts
type SequenceRuleCode =
  | "COMPLETE_MUST_BE_LAST"
  | "FORM_AFTER_PROGRAM_CHOICE"
  | "PROGRAM_CHOICE_AFTER_MAJOR_PROGRAM_CHOICE"
  | "MAJOR_PROGRAM_CHOICE_MUST_BE_FIRST"
  | "ACCEPTANCE_PAYMENT_AFTER_DECISION"
  | "TUITION_PAYMENT_AFTER_DECISION"
```

Note these are the "positive" phrasing of the existing `*_NOT_LAST`/`*_BEFORE_*`/`*_NOT_FIRST` error
codes already live today (`BACKEND_DEVIATIONS_2026-09-14.md` A16, and the `stage-sequence.ts` codes
quoted in this folder's `README.md` §3) — the error code returned on a violation stays exactly what
it already is (e.g. `ACCEPTANCE_PAYMENT_BEFORE_DECISION`); only the new settings table's `rule_code`
values use the "positive" form shown above, to read naturally as "is this rule ON."

**Not included here** — `MISSING_TYPE`, `MULTIPLE_{TYPE}`, `MISSING_COMPLETE` (the three Integrity
rules from the README's table) are proposed to stay permanently enforced, not represented in this
table at all. If that's wrong and they should be toggleable too, they'd just be three more enum
values — no structural difference, flagging the omission as deliberate so it's easy to override.

**Migration:** purely additive, zero existing rows required. `README.md` §5's resolution order
(major-program row → institution-default row → hardcoded `true`) means an empty table reproduces
today's exact behavior for every scope. No backfill, no data migration, no coordinated cutover needed
— unlike A23, which required sequencing around an existing-fallback-data problem, this ships inert
until an admin actually visits the new settings screen and flips something.

**Resolution helper** (pseudocode, whatever layer already resolves `/effective` for steps is the
natural home for this too):

```ts
function isRuleEnabled(ruleCode: SequenceRuleCode, majorProgramId: number | null): boolean {
  const ownRow = findSetting(majorProgramId, ruleCode)
  if (ownRow) return ownRow.enabled
  if (majorProgramId !== null) {
    const defaultRow = findSetting(null, ruleCode)
    if (defaultRow) return defaultRow.enabled
  }
  return true // no row anywhere — today's hardcoded behavior
}
```

## 2. Sketch only, not proposed for this round — Phase 2 `AdmissionSequenceConstraint`

If fixed named rules ever prove insufficient (see `README.md` §4's Phase 2), the shape would look
roughly like:

```
AdmissionSequenceConstraint
  id                 PK
  majorProgramId     FK → MajorProgram, nullable
  beforeType         StageType
  afterType          StageType
  beforeFeeCategory  AdmissionFeeCategory, nullable   // narrows to e.g. only ACCEPTANCE payments
  afterFeeCategory   AdmissionFeeCategory, nullable
```

This needs a cycle-detection pass over the resolved constraint graph per scope before any save is
accepted (reject `A→B→C→A`), which the fixed 8-rule Phase-1 checklist never has to worry about since
its rules are hand-verified not to conflict with each other. Given no concrete scenario has come up
yet that Phase 1 can't express, **this section exists only so the backend team can flag early if
Phase 1's shape would paint them into a corner** — not a request to build it now.
