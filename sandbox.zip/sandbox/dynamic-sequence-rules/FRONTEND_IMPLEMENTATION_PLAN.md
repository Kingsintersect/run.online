# Frontend Implementation Plan — Dynamic Sequence Rules

Internal build plan for the frontend side of `README.md`/`SCHEMA_CHANGES.md`/`API_CONTRACTS.md`.
**Not needed by the backend team** — same split as `major-program-scoping/` uses. Everything below
lives entirely inside the existing
`src/app/(dashboard)/admin/(routes)/configurations/admission-config/` screen; no new route, no new
module folder. This feature area already follows a lighter-weight shape than `CLAUDE.md` §3's full
`modules/[domain]/` structure (one `page.tsx`, a flat `components/` folder, and services/hooks
inlined in `src/services/admissionStepsApi.ts` rather than a dedicated module) — this plan matches
that existing precedent rather than introducing a new structure for one small addition.

---

## 0. The governing rule, restated for this feature

A rule that has never been overridden anywhere must behave **exactly as it does today** — same
error, same message, same code — for every scope. The settings panel is purely additive UI; an
institution that never opens it sees zero behavior change, ever. This mirrors the same "single/zero
major-program deployment renders unchanged" governing rule from `major-program-scoping/README.md`
§0, applied to rule settings instead of scoping.

## 1. Fallback — built, then removed once the backend shipped (`CLAUDE.md` §14)

**Superseded 2026-09-16 — the backend is live, this section is historical.** The original plan here
was a 404-triggered fallback to a hardcoded "every rule enabled" list with disabled toggles, matching
this codebase's established build-ahead-of-backend pattern. It was built exactly that way first. But
wiring it up against the real, now-live endpoint surfaced a real bug in that approach: the fallback
was detected by checking whether every returned rule had `source: "builtin"` — except that's also the
**genuine, correct** live response for any scope nothing has ever been configured for, not just a
sign the endpoint is missing. Once the backend shipped, that heuristic would have permanently disabled
every toggle for every untouched major program, silently, since a never-configured scope is the
common case, not the exception. Fixed by deleting the try/catch fallback from `admissionStepsApi.
sequenceRules()` outright — a real failure now surfaces as a normal `isError` query state, same as
every other live query on this page (`processQuery`, `formQuery`, the preview queries), and the panel
is fully interactive with no derived "is this live" guessing at all. Lesson for next time this
pattern gets reused: a build-ahead-of-backend fallback is safe exactly as long as its "not live"
signal can't also be produced by a legitimate live response — verify that before shipping the
fallback, not after the backend catches up.

## 2. New files

- `src/app/(dashboard)/admin/(routes)/configurations/admission-config/components/SequenceRulesPanel.tsx`
  — the panel itself (see §3).
- Additions to `src/services/admissionStepsApi.ts` (not a new service file — this stays with the
  step-related API calls it's already colocated with):
  - `admissionSequenceRulesKeys` — a small key factory: `all`, `list(majorProgramId)`.
  - `admissionSequenceRulesQueryOptions.list(majorProgramId)` — wraps `GET .../sequence-rules`, with
    the §1 fallback baked into the `queryFn` (catch the 404, return the hardcoded builtin list rather
    than letting the query error out — matches how other pre-launch endpoints in this file already
    degrade, if that pattern exists here; otherwise this is the first one and should set the
    convention cleanly for next time).
  - `admissionSequenceRulesMutationOptions.setRule()` (`PATCH`) and `.clearOverride()` (`DELETE`).
- A `SEQUENCE_RULE_CATALOG` constant (label + description per rule code, mirroring
  `STAGE_TYPE_CATALOG`'s shape in `src/lib/admission-catalog.ts`) — lives in `admission-catalog.ts`
  alongside it, not duplicated in the component, so the panel and any future consumer share one
  source of truth for rule copy.

## 3. `SequenceRulesPanel` — where it appears and what it shows

Reachable from **both** views the admission-config page already has (`page.tsx`'s `view` state,
built 2026-09-15 for the Catalog/Program-Configurations split):

- **Catalog view**: a "Sequence Rules (Institution Default)" button near the existing catalog CRUD
  controls, opening the panel with `majorProgramId: null` — this is where the institution-wide
  baseline (the fallback every major program inherits unless it overrides) gets set.
- **Program Configurations view**: a "Sequence Rules" button on each major-program tab (next to
  "Add from Catalog" in the panel header, or as its own small header action — exact placement is a
  visual-polish decision at build time, not a contract decision), opening the panel scoped to that
  major program's `majorProgramId`.

Panel content — one row per Precedence rule (the fixed 6, never the 3 locked Integrity rules, which
don't appear here at all since there's nothing to toggle):

```
┌─────────────────────────────────────────────────────────────────┐
│ Acceptance/Tuition payment must come after the admission decision│
│ An Acceptance or Tuition fee step can't be reached before the    │
│ applicant has an admission decision.                              │
│                                          [●━━] ON   · Your setting │
│                                                    [Reset to default]
├─────────────────────────────────────────────────────────────────┤
│ Major Program Choice must be the first stage                     │
│ ...                                       [━━●] OFF · Institution │
│                                                       default      │
└─────────────────────────────────────────────────────────────────┘
```

- **Toggle** — flips `enabled` for this exact scope. Flipping it calls `setRule({ majorProgramId,
  ruleCode, enabled })`, which upserts the scope's own row (matches `PATCH`'s upsert semantics per
  `API_CONTRACTS.md` §2). Immediately shows `source: "own"` after a successful toggle.
- **Source badge** — "Your setting" (`source: "own"`) / "Institution default" (`source: "default"`,
  only shown when viewing a major-program's panel and it has no override of its own) / "Built-in"
  (`source: "builtin"`, no row anywhere — today's hardcoded value). This is the one place in this
  panel where a major program's view differs from the institution-default view: the institution-
  default panel never shows "Institution default" as a source for itself, only "Your setting" (its
  own row) or "Built-in."
- **"Reset to default"** — only rendered when `source === "own"`. Calls `clearOverride()` (`DELETE`),
  which removes this scope's row and re-resolves to whatever's next in the chain (institution default
  if one exists, else builtin `true`). Not shown on the institution-default panel's own rows framed as
  resetting *them* — clearing an institution-default row falls back straight to `builtin`, which is a
  real and useful action too, so the button still applies there, just resolves one level further.

## 4. `validateStageSequence()` gets the resolved settings as a parameter

Current signature (`stage-sequence.ts`): `validateStageSequence(rows: ScopedStepRow[])`. New:

```ts
validateStageSequence(
  rows: ScopedStepRow[],
  ruleSettings?: Partial<Record<PrecedenceRuleCode, boolean>> // undefined = every rule enabled,
)                                                              // matching today's exact behavior
```

Each of the 5 Precedence checks gains a one-line guard in front of its existing `issues.push(...)`:
`if (ruleSettings?.[code] === false) return` (or equivalent early-continue in the loop it's in) — no
change to the check logic itself, only whether its result is reported. The 3 Integrity checks are
never guarded, per §0/README §4's locked decision. `page.tsx` passes
`ruleSettings` sourced from the same `useSequenceRules(scope's majorProgramId)` hook the panel uses,
so the pre-save warning banner and the actual server-side validation stay in agreement — same
relationship this file already has with the backend's real rules today, just parameterized instead of
all-hardcoded-true.

## 5. What does NOT change

- `AddFromCatalogDialog`, `adoptMutation`, `resolveScope`, the Catalog/Program-Configurations view
  split — all untouched. This is a fully additive panel bolted onto the existing page, not a
  restructuring of anything built for A22/A23.
- Every existing `INVALID_STAGE_SEQUENCE` 422 behavior for any scope that has never opened this panel
  — unchanged, per §0.

## 6. Build order — all steps complete as of 2026-09-16

1. ✅ `SEQUENCE_RULE_CATALOG` constant + the query/mutation additions to `admissionStepsApi.ts`.
2. ✅ `SequenceRulesPanel.tsx` — built with the §1 fallback first, then simplified once the backend
   shipped (see §1's "superseded" note).
3. ✅ Wired into both the Catalog view's institution-default button and each major-program tab in
   Program Configurations (adds the "Institution default" source badge case).
4. ✅ `validateStageSequence()` parameter addition + `page.tsx` wiring so the pre-save banner respects
   resolved settings.
5. ✅ Backend confirmed live 2026-09-16 — the §1 fallback was removed outright (not kept around for a
   transitional period) once wiring it up surfaced the `source: "builtin"` ambiguity bug documented
   in §1. `tsc --noEmit` and `eslint` both clean across every touched file.
