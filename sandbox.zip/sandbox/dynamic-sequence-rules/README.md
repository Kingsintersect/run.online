# Dynamic, Major-Program-Scoped Sequence Rules

**Status:** ✅ **shipped, confirmed live 2026-09-16** — `GET`/`PATCH`/`DELETE
/admissions/config/sequence-rules` all live per `bruno/admission/Sequence Rules - List/Set/Clear.bru`,
including a real live verification (Certificate Programmes' actual order-colliding steps: a PATCH
that 422'd before disabling `ACCEPTANCE_PAYMENT_AFTER_DECISION`/`TUITION_PAYMENT_AFTER_DECISION` for
it, succeeded after). Frontend built and wired end-to-end (`FRONTEND_IMPLEMENTATION_PLAN.md`) —
`SequenceRulesPanel.tsx` is fully interactive, no fallback/disabled state anymore. One real bug found
and fixed during this final wiring pass, worth recording: the original frontend fallback logic
inferred "backend not live yet" from every returned rule having `source: "builtin"` — but that's also
the legitimate live response for a scope with nothing configured at all, so once the backend actually
shipped, that heuristic would have permanently disabled every toggle for any untouched scope. Fixed
by removing the swallow-all-errors fallback from `admissionStepsApi.sequenceRules()` entirely (a real
failure now surfaces as a normal query error, same as every other live endpoint in this file) instead
of trying to infer liveness from response shape. Triggered by a real, live 422
(`INVALID_STAGE_SEQUENCE: ACCEPTANCE_PAYMENT_BEFORE_DECISION`) hit while configuring Certificate
Programmes' admission process. Builds on `major-program-scoping/` and `dynamic-admission/` — read
those first; this assumes `MajorProgram` and the fully-decoupled major-program step scoping (A22/A23
in `BACKEND_DEVIATIONS_2026-09-14.md`) already exist, which they do (confirmed live).

---

## 1. The ask

Direct instruction: "the operational sequence for each program should be dynamic and configurable
from the frontend to the backend, and should be major program scoped." Today, step **content** and
**order** are already fully dynamic and major-program-scoped (A22/A23) — an admin can freely decide
*which* steps a major program has and *what position* each sits in. What isn't dynamic is the set of
**rules that constrain valid orderings** — e.g. "an Acceptance/Tuition payment step must come after
the admission decision." Those are hardcoded, identical for every major program, on both sides of the
stack, and cannot be turned off even when a major program's actual process doesn't need them.

## 2. The trigger case, concretely

Certificate Programmes' admission process doesn't need — and per earlier product direction
("Certificate only takes Access Fee + Tuition Fee"), may deliberately not have — an "Admission
Status" (`DECISION`) stage at all. But the moment Certificate has *any* enabled `PAYMENT` step with
`feeCategory: ACCEPTANCE` or `TUITION`, both the frontend's own pre-save check (`stage-sequence.ts`)
and the backend's real validation reject it with `ACCEPTANCE_PAYMENT_BEFORE_DECISION` /
`TUITION_PAYMENT_BEFORE_DECISION` — because there's no way, today, to tell the system "Certificate
doesn't use the Decision-gate constraint." The admin's only options right now are (a) add a Decision
stage Certificate may not actually need, or (b) don't charge Acceptance/Tuition fees at all. Neither
is "configure the rule," which is what was actually asked for.

## 3. What's hardcoded today — the full rule set

Mirrored client-side in
[`step-scope.ts`'s sibling](../../src/app/(dashboard)/admin/(routes)/configurations/admission-config/components/stage-sequence.ts)
`validateStageSequence()`, and enforced server-side with matching error codes (confirmed live —
`MAJOR_PROGRAM_CHOICE_NOT_FIRST`, `ACCEPTANCE_PAYMENT_BEFORE_DECISION`, `COMPLETE_NOT_LAST` have all
been hit as real 422s this session). Every rule applies identically to every scope — default,
category, and every major program — with no per-scope override anywhere:

| Code | Rule | Kind |
|---|---|---|
| `MISSING_TYPE` | Every active step must resolve to a stage type | Integrity |
| `MULTIPLE_{TYPE}` | Types marked non-`multiple` (all except `PAYMENT`/`CONTENT`/`DOCUMENT_UPLOAD`) may appear at most once | Integrity |
| `MISSING_COMPLETE` | A non-empty sequence must include an enabled `COMPLETE` stage | Integrity |
| `COMPLETE_NOT_LAST` | `COMPLETE` must be the last active stage | Precedence |
| `FORM_BEFORE_PROGRAM_CHOICE` | `FORM` can't come before `PROGRAM_CHOICE` | Precedence |
| `PROGRAM_CHOICE_BEFORE_MAJOR_PROGRAM_CHOICE` | `PROGRAM_CHOICE` can't come before `MAJOR_PROGRAM_CHOICE` | Precedence |
| `MAJOR_PROGRAM_CHOICE_NOT_FIRST` | `MAJOR_PROGRAM_CHOICE` must be the very first stage | Precedence |
| `ACCEPTANCE_PAYMENT_BEFORE_DECISION` | An `ACCEPTANCE`-category `PAYMENT` must come after `DECISION` | Precedence |
| `TUITION_PAYMENT_BEFORE_DECISION` | A `TUITION`-category `PAYMENT` must come after `DECISION` | Precedence |

## 4. The design — two phases, propose shipping Phase 1 only for now

### Phase 1 (recommended): make each **Precedence** rule's applicability toggleable, per scope

Keep the fixed catalog of rule *codes* above (a known, closed set — no arbitrary rule authoring),
but let an admin turn each **Precedence** rule on or off for a given scope. Leave the three
**Integrity** rules (`MISSING_TYPE`, `MULTIPLE_{TYPE}`, `MISSING_COMPLETE`) permanently on,
everywhere — these aren't ordering preferences, they're structural guarantees (e.g. "more than one
Decision stage" or "a step with no type at all" isn't a valid configuration under any circumstance,
so it shouldn't be something a scope can opt out of). **Approved as-is, 2026-09-15** — Integrity
rules stay permanently locked, not represented in the settings table at all.

This directly fixes the trigger case: Certificate gets a row disabling
`ACCEPTANCE_PAYMENT_BEFORE_DECISION` and `TUITION_PAYMENT_BEFORE_DECISION`, ships its Acceptance/
Tuition payment steps with no Decision stage, and no other major program is affected.

### Phase 2 (optional, larger, not recommended to build yet): fully custom precedence pairs

If fixed named rules ever turn out to be insufficient — e.g. an admin wants to declare "X must come
before Y" for two arbitrary stage types with no existing rule for that pair — a further extension
would let admins define their own precedence constraints as data (`beforeType`/`afterType` pairs)
rather than picking from the fixed catalog. This is meaningfully bigger: it needs cycle detection
(reject a rule set where A→B→C→A), a rule-authoring UI, and a validator that runs an arbitrary
constraint graph instead of nine known checks (3 Integrity + 6 Precedence). **Not proposed for this
round** — Phase 1 covers the
actual trigger case and every scenario raised so far. Sketched in `SCHEMA_CHANGES.md` §2 only so the
backend team can see the shape and say now if Phase 1 is a dead end for where this is headed.

## 5. Scope inheritance — a deliberate reversal of A23's "no fallback" rule, flagged for confirmation

A22/A23 made step **content** fully decoupled per major program on purpose — "major programs are not
meant to be connected in any way." Rule **settings** are proposed to work the opposite way: a major
program that hasn't explicitly overridden a rule should **inherit the institution-wide default**
(itself overridable), not silently revert to "always on with no record of why." Reasoning: unlike
step content (which is genuinely different data per major program), most major programs want the
*same* baseline sequencing sanity checks — requiring every one of them to explicitly re-enable all
6 toggleable rules just to match today's behavior would be pure busywork with no benefit, and would make
"no explicit setting yet" indistinguishable from "deliberately disabled everything." Resolution order,
**approved as-is, 2026-09-15**: **major-program-specific row → institution-default row
(`majorProgramId: null`) → hardcoded `true`** (today's behavior, so a fresh install with zero rows
changes nothing). This is the opposite inheritance direction from A23's step-content model, deliberate
and confirmed, not an oversight.

## 6. What this doesn't change

- Step content/order scoping (A22/A23) — unaffected, still fully decoupled per major program.
- The fixed catalog of stage *types* (`STAGE_TYPE_CATALOG`) — unaffected; this proposal is about
  constraints between types, not the types themselves.
- Any major program that never touches this — keeps today's exact hardcoded behavior automatically,
  per §5's resolution order (no rows anywhere = current rules, unchanged).

## 7. Rollout order and risk

1. **Schema + resolution logic** (`SCHEMA_CHANGES.md` §1) — additive, zero-row-migration, no
   behavior change until an admin actually creates an override row. Lowest risk.
2. **`GET`/`PATCH /admissions/config/sequence-rules`** (`API_CONTRACTS.md` §1) — straightforward
   CRUD on the new table.
3. **Wiring the existing `INVALID_STAGE_SEQUENCE` validator to consult resolved settings** instead of
   the current hardcoded checks (`API_CONTRACTS.md` §2) — the one piece that needs care: every
   existing precedence check (already live, already tested) gets an added "is this rule even enabled
   for this scope" guard in front of it, nothing about the check logic itself changes.
4. **Frontend** — spec approved and written, `FRONTEND_IMPLEMENTATION_PLAN.md`. Build itself waits on
   steps 1-3 shipping (or, per that plan's own fallback section, ships now behind an honest
   "not live yet" fallback per `CLAUDE.md` §14, same as every other screen in this codebase built
   ahead of its backend).

## 8. Files in this folder

- `SCHEMA_CHANGES.md` — the new `AdmissionSequenceRuleSetting` table (Phase 1) and a sketch of the
  optional Phase 2 constraint table.
- `API_CONTRACTS.md` — the new settings endpoints, and the precise change to how
  `POST`/`PATCH`/`DELETE /admissions/config/steps` and `PATCH .../reorder` validation resolves which
  rules apply to a given request's scope.
- `FRONTEND_IMPLEMENTATION_PLAN.md` — internal build plan for the settings panel, its fallback while
  the backend endpoints don't exist yet, and how it wires into the existing Catalog/Program
  Configurations views (not needed by the backend team).
