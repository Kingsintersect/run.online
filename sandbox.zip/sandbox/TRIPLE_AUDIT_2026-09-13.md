# Triple Audit — Sandbox ↔ Bruno ↔ App, 2026-09-13

Backend reported "all outstanding work finished" and sent an updated bruno collection (422
`.bru` files, up from 396 — a new `bruno/director/` folder is the headline addition). This
audit cross-checks all three artifacts pairwise: sandbox proposals against the new bruno,
bruno against the actual frontend code, and sandbox proposals against the actual frontend
code. Each finding below was verified by opening real files, not inferred from names.

---

## 0. Bottom line

- **Sandbox ↔ App: 100%.** Every type/service/hook/UI item from `multi-program-platform/`,
  `program-structure-depth/`, and `major-program-scoping/` is genuinely implemented and wired
  in the frontend — confirmed by tracing each one to a real call site, not just a matching
  filename. This was already true before this round; nothing regressed.
- **Sandbox ↔ Bruno: mixed, and uneven across the three docs.**
  - `multi-program-platform/` — ~90% delivered. Only two real gaps left (below).
  - `program-structure-depth/` — ~0% delivered. This is the one to push hardest on.
  - `major-program-scoping/` — CRUD/grant mechanics are live, but the two pieces that make it
    *usable* (a way to read your own scope, and any actual enforcement) are both missing.
  - The **old punch-list** (`STILL_MISSING_AFTER_HANDOFF_2026-09.md`) saw real, substantial
    progress — roughly a dozen items closed, including the entire Director module appearing.
- **Bruno ↔ App: three real production-risk bugs**, all pre-existing response-shape
  mismatches now made *checkable* because bruno finally documents the real shapes. These are
  the most urgent items in this whole report — see §1.

---

## 1. Fix these first — real breakage, not gaps

### 1a. Director grade report is very likely broken
`src/modules/director/services/director.service.ts`'s `fetchGradeReport` sends filters
(`facultyName`, `departmentName`, `programName`, `level`, `semesterName`, `academicYear`,
`status`, `search`) and reads a response shape (`summary`, `gradeDistribution`, `records`,
`meta`) that **do not match** what `bruno/director/Grade Reports - Summary.bru` now documents
for `GET /results/reports/director-grade-summary` (only `semesterId` accepted; response is
`{data: {overall, byFaculty, byProgram}}`). If the backend matches its own bruno doc, this
screen renders broken or empty. **Rewrite against the real contract before shipping.**

### 1b. Fee collections summary — two independent mismatches on the same endpoint
`GET /fees/reports/summary` is now documented as returning a flat
`{data: {invoiceCount, totalInvoiced, totalCollected}}` — no array, no `totals` wrapper, no
`totalOutstanding`. Two frontend call sites disagree with this in two different ways:
- `fee-management.service.ts`'s `getCollectionsSummary` (feeds `collections-report.tsx` and
  `fee-management-overview.tsx`) expects `{data: [...rows], totals: {...}}` — every field these
  two admin widgets read will be `undefined`, rendering blank/NaN currency values.
- `director.service.ts`'s `fetchFeesSummaryData` reads a `totalExpected` field that doesn't
  exist (real field is `totalInvoiced`) — this one fails silently by falling back to a
  client-side sum, which *masks* the bug rather than crashing, so it's easy to miss in testing.

**Before fixing either, confirm with the backend team which shape is actually real** — two
frontend modules independently guessed differently, which suggests the contract may have
shifted more than once.

### 1c. The BURSARY/DIRECTOR 403 auth fix is documented but not confirmed working
`sandbox/fee-management/bursary_403_bug_report.md` (dated the same day as this bruno update)
records the team live-testing BURSARY/DIRECTOR tokens against `/fees/reports/summary`,
`/fees/reports/outstanding`, `/users/stats`, `/users/students`, `/users/lecturers`,
`/enrollments/trend`, and `/results/reports/director-grade-summary` — **every one still
403'd**, even after granting the exact permissions bruno now claims gate these routes. Yet
`bruno/fee/Reports - Summary.bru`, every `bruno/director/*.bru` file, etc. now say things like
"fixed 2026-09... requires `admin` role OR `financial-summary.view`." One inconsistency worth
flagging precisely: `bruno/user/Users - Stats.bru` still says "Admin only" while
`bruno/director/Dashboard - Stats.bru` (documenting the *same* live endpoint) claims the
permission-based fix — two bruno files contradict each other on one endpoint's auth rule.

**Recommendation:** don't trust any "confirmed fixed" comment tied to this permission change
(there are several across `director.service.ts`, `director.store.ts`, `use-fee-reports.ts`)
until BURSARY/DEAN/DIRECTOR tokens are re-tested live post-deploy. The docs describe an
intended fix, not a confirmed one.

---

## 2. Still genuinely missing on the backend — send this back

### `sandbox/multi-program-platform/` (~90% done, two gaps)
- **`programCategory`/`programId` scope fields on the base Admission Step Registry CRUD.**
  Only the new `GET /admissions/config/steps/effective` resolution endpoint exists — the
  underlying `Steps - Create/List/Update.bru` never gained the two scope fields or the widened
  `(group, key, programCategory, programId)` uniqueness. Practically: there's no way to
  *create* a scoped step row, so `effective`'s resolution hierarchy has nothing to resolve
  beyond institution-wide defaults. This blocks the admin step-scoping UI from doing anything
  real.
- **`custom_fields` on `POST/PATCH /admissions/applications`.** The field *definitions*
  (`AdmissionFormField` CRUD) are fully shipped, but applicants have no way to actually submit
  an answer — `Applications - Submit.bru`/`- Update.bru` have no `custom_fields` key at all.
  This blocks the entire dynamic-fields feature end-to-end despite the admin side being done.

### `sandbox/program-structure-depth/` (~0% done — proposed 2026-09-12, essentially untouched)
- No `Cohort` entity anywhere. Searched all of bruno for "cohort" — the only hit is the
  unrelated Moodle-sync cohort (Program+Session+Level mirror), a different concept entirely.
- `Course.level_id` still required (not nullable) in `Course - Create.bru`.
- `Student.current_level_id`/`current_cohort_id` — no response example in bruno at all, can't
  confirm either way, but nothing suggests nullability was added.
- `AdmissionOffer.levelId`/`.sessionId` still required unconditionally; no `.cohortId` field;
  no category-conditional validation or the `INVALID_PROGRAM_STRUCTURE_FIELDS`/
  `COHORT_NOT_OPEN` error shapes.
- `Program.entryLevelId` — not in `Programs - Create.bru`/`- Update.bru`.

This is the doc that saw the least backend attention. Worth flagging explicitly since it was
the newest of the three proposals — reasonable that it lags, but worth confirming it's on the
roadmap at all.

### `sandbox/major-program-scoping/` (grant mechanics live, usability pieces missing)
- **`GET /auth/me` doesn't return `majorProgramScope`.** The server-side grant mechanism
  (`majorProgramIds` on role assignment and user creation) is fully live — but a scoped user
  has no way to *learn* their own scope. This blocks `useMajorProgramScope()` from ever
  resolving anything but "unscoped" in practice, even for an account that has real scoped
  grants sitting in the database.
- **No enforcement or narrowing on any list endpoint.** `Applications - List.bru` (and every
  other list endpoint checked — students, fees, course offerings) has no `majorProgramId`
  param and no `OUT_OF_SCOPE` error shape. This is the actual authorization boundary the whole
  design exists for — without it, scoping is metadata with no effect.

### Reactivation for Faculty / Department / Program (added 2026-09-14)
`DELETE /academic/faculties/:id`, `/departments/:id` and `/programs/:id` are soft-deactivates
(`isActive: false`, 204 — see the header comment in `src/services/courseStructureApi.ts`), but
`Faculties - Update.bru`, `Departments - Update.bru` and `Programs - Update.bru` document **no
`isActive` field** (grepped all three, zero matches). There is no documented way to
**reactivate** any of them once deactivated, so the admin UI's power button can only switch them
off.

- **Ask:** accept `isActive` (boolean, `sometimes`) on `PATCH` for all three — the same way
  `Major Programs - Update.bru` already does ("plus `isActive` (boolean) to deactivate one
  without deleting it").
- **Clarify cascade:** does deactivating a Faculty also deactivate its Departments/Programs, and
  does reactivating cascade back? Please document either answer — the frontend will not assume a
  cascade.
- **Frontend:** the Major Programs power button is already a real on/off toggle via `PATCH`
  (fixed 2026-09-14). Faculty/Department/Program get the same treatment as soon as the backend
  documents `isActive` on their `PATCH`.

### Carried over from the old punch-list, still open
`GET /auth/roles/:roleId/users` · `GET /users/stats` breakdown extension (`byFaculty`/
`studentsByLevel`/`studentsByGender`/`tutorsByDesignation`, base shape) ·
`GET /fees/types/eligible-count` · `GET /fees/invoices` nested shape + faculty/department/level
filters · `Grade.hasOutstandingFees` · course-offering enrichment (`enrolledCount`, nested
`course.*` fields — the `lecturerId` filter piece is now done) · `ca-preview` endpoint (still
missing under both the old `/moodle-sync/assessments/` and new `/assessments/` paths) ·
Exam Timetable (zero backing anywhere) · six `/results` analytics endpoints still lack a
literal example response body (low severity).

**Note on assessments:** a chunk of this got fixed at a *different* path than requested — the
old `/moodle-sync/assessments/sync-status` and `/moodle-sync/assessments` (list filters) are
still exactly as broken as before, but a **new top-level `/assessments/*` module** now
delivers the get/my/visibility/delete endpoints plus the correct per-course sync-status shape
and full filter set. If the frontend is still calling the old `/moodle-sync/assessments/*`
paths anywhere, worth confirming which path is now canonical.

---

## 3. Frontend code accuracy — no functional risk, but comments now lie

Several places in the codebase have comments saying "not yet live" / "confirmed 404" /
"backend hasn't shipped this" that are now **false** — the backend delivered these:

| File | Stale claim | Reality |
|---|---|---|
| `src/services/courseStructureApi.ts` | `majorProgramsApi` — "no endpoint exists, 404s" | `bruno/academic/Major Programs - *.bru` — fully live CRUD |
| `src/services/academicStructureApi.ts` | "Not yet in bruno" | Fully documented, matches exactly |
| `src/services/rolesApi.ts` | `duplicate()` — "no `POST /auth/roles/:id/duplicate` endpoint, verified 404" | `bruno/auth/Roles - Duplicate.bru` — real, single-call endpoint now exists. **Action item, not just a comment fix**: replace the 3-request client-side composition (get → create → sync permissions) with one call. |
| `src/types/roles.d.ts`, `AssignRolesPayload`/`AdminCreateUserPayload` comments | "PROPOSED, not yet live" for `majorProgramIds` | Confirmed live and documented on both `Users - Assign Roles.bru` and `Users - Create (Admin).bru` |
| `src/modules/moodle-sync/schemas/cohort.schema.ts` | "Backend not yet shipped" | `Cohort Sync - {List,Push,Sync Members}.bru` are live and already correctly wired up in `moodle-sync.service.ts` — this one was actually already working, just mislabeled |
| `src/modules/director/services/director.service.ts` / `director.store.ts` / `use-fee-reports.ts` | Multiple "confirmed 403 live, 2026-09-12" comments | Bruno now documents these as fixed the same day — **do not update these comments until §1c is independently re-verified**, since the fix itself is unconfirmed |

**One more, smaller, pre-existing (not from this session) mismatch worth a backend check:**
`rolesApi.ts`'s `create()` sends `slug`/`is_default`/`permission_ids` in the body, but
`Roles - Create.bru` documents `CreateRoleRequest` as accepting only `name` + optional
`description`. Unclear whether the extra fields are silently ignored or rejected — worth
confirming, since `update()` already knows to strip `permission_ids` but `create()` doesn't
strip anything.

**Also worth confirming:** `userRolesApi.assign`'s return type doesn't declare the new
`grants`/`userId` fields bruno's response now includes (`{message, userId, grants: [...]}`,
replacing the old `{message, data: [...]}`) — harmless today since nothing reads past
`.message`, but the richer grant confirmation data is currently unused.

---

## 4. Corrected finding from this audit round

One claim from the automated pass was checked and found **incorrect**, so it's not carried
into §2/§3 above: `Program.majorProgramId` **is** sent by the frontend today —
`CreateProgramPayload` (school.d.ts) has the field, and `ProgramFormDialog.tsx` wires it
through a real form control into the create/update payload (verified directly by reading both
files). The automated audit only inspected the service-layer file in isolation and missed the
calling component.

---

## 5. What to do with this doc

Sections 2 and 3's table are the actionable "send to backend" content — precise enough to
paste into a message without editorializing. Section 1 is more urgent than either: those three
items are live production risk if shipped as-is, independent of whatever the backend still
owes.

---

## 6. Live verification against production — 2026-09-14

Probed `https://run.api.qverselearning.org/api/v1` as super_admin, read-only (write routes
checked with GET: 405 = route exists, 404 = missing). **34 of 40 checks live.**

### Still missing — send back
| Feature | Route(s) | Result |
|---|---|---|
| Exam Timetable — schedules | `GET/POST /timetable/exams`, `GET /timetable/exams/my`, `GET /timetable/exams/check-conflict`, `PATCH/DELETE /timetable/exams/{id}` | 404 — only `/timetable/venues` exists |
| Program Structure Depth — Cohorts | `GET/POST /academic/cohorts`, `PATCH/DELETE /academic/cohorts/{id}`, `POST /academic/cohorts/{id}/transition` | 404 |
| Moodle CA → `Grade.caScore` bridge | `GET /assessments/ca-preview` | 404 |

### Confirmed live
`/auth/me` `majorProgramScope` · Major Programs CRUD · `/moodle-sync/cohorts` · Moodle reconcile
preview/apply (categories/courses/users) · reset (assessments/calendar/grades) · enrollment drift
(list, summary, scan, check, re-enroll, unenrol, dismiss, reopen) · `REMOVED_IN_MOODLE` filter ·
`/users/stats` breakdown · `/fees/types/eligible-count` · `/auth/roles/{id}/users` · steps
`programCategory`/`programId` + `/steps/effective` with `fields` · `/admissions/applications`
`majorProgramId` param · director grade summary · fee reports summary.

### Shape differences found and fixed on the frontend
- `GET /fees/types/eligible-count` returns `{data: {eligibleCount}}` (frontend expected `{count}`).
- `GET /auth/roles/{id}/users` returns `{data, meta}` with camelCase user fields.
- `GET /admissions/config/steps/effective` rows use `isRequired`, not `required`.
- `GET /auth/me` `majorProgramScope` was returned but never carried into the session.

### Not verifiable yet (empty data on production)
Item shapes for programs (`entryLevelId`), venues, Moodle cohorts, drift items, invoices
(nested student faculty/department/level), course offerings (`enrolledCount`) and applications
returned empty arrays, so their row fields couldn't be checked. Please add example responses to
the corresponding `.bru` files and send the updated bruno collection — the local copy has no
requests for exams, reconcile/reset, drift or cohorts.

---

## 7. Updated bruno check — 2026-09-14 (442 `.bru` files)

### Now documented and matching the frontend
- Reconcile preview/apply (categories/courses/users) and reset (assessments/calendar/grades) —
  bodies, response shapes, error codes and permission split all match
  `moodle-sync.service.ts` / `reconcile.schema.ts`.
- Enrollment drift (list, summary, scan start/status, check, re-enroll, unenrol, dismiss, reopen)
  — matches `enrollment-drift.schema.ts`, including the `moodle-sync.drift.resolve` gate.
- Faculty/Department/Program `PATCH` now accept `isActive` — the frontend power buttons are
  now real on/off toggles through PATCH.
- `/auth/me` documents `majorProgramScope`.

### Still not in bruno (and 404 on production)
- **Exam Timetable schedules** — `/timetable/exams*` (list, my, check-conflict, CRUD).
- **Cohorts** — `/academic/cohorts*` including `/transition`.
- **`GET /assessments/ca-preview`**.

### New issue: `/timetable/venues` route collision
`bruno/timetable/Venues - List.bru` documents `GET /timetable/venues?semesterId=` as the
class-timetable autocomplete (distinct venue-name strings). The Exam Timetable proposal
(`sandbox/exam-timetable/API_CONTRACTS.md` §1) uses the same path for the `Venue` entity
(`{id, name, capacity, isExamHall, isActive}` with POST/PATCH/DELETE). Both cannot live on one
route. **Ask:** build exam venues at a distinct path (suggested `/timetable/exam-venues`) or turn
`/timetable/venues` into the entity list and move the autocomplete elsewhere — tell us which, and
the frontend will follow. Until then the exam venue list ignores non-object rows.

### Needs confirming
- `moodle-sync.reset` is documented as the gate for the three reset routes, but it is not in the
  frontend permission catalog and was not in the live catalog when checked on 2026-09-14 (only
  view/push/pull/manage and the newly created drift.resolve). Confirm whether it was seeded; if
  not, it needs creating and assigning to super_admin.
- Cascade on Faculty/Department deactivation is still undocumented.
- `Users - Stats.bru` docs still describe the old shape; production already returns the
  breakdown (`byFaculty`, `studentsByLevel`, `studentsByGender`, `tutorsByDesignation`).
- No example responses yet for eligible-count, `/auth/roles/{id}/users`, course offerings
  enrichment, or the invoice nested student fields.
