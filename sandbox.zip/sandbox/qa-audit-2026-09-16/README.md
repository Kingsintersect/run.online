# QA Audit — Role-by-Role, 2026-09-16

Live audit against the real deployed backend (`bruno/environments/Production.bru`'s
`baseUrl: https://run.api.qverselearning.org/api/v1`) and the local dev frontend
(`http://localhost:3031`, already running throughout this audit), driven by Playwright
(already installed in this repo: `playwright@1.62.1`) since no first-party browser tool is
available. Per direct instruction: create real test accounts, run real requests including a
real test-card payment, and document every backend error/schema-change/refactor need found —
zip and hand off whenever blocked, resume once the backend team confirms a fix.

Scripts live in the local scratchpad (not committed, not part of this repo) — this file and
its sibling findings docs are the durable record.

## Test accounts created

| Role | Major Program | Name | Username | Email | User ID |
|---|---|---|---|---|---|
| Applicant | Part-Time Programmes | Ngozi Balogun | `qa_parttime_ngozi` | qa.parttime.ngozi@run-test.qverselearning.org | 16 |
| Applicant | Certificate Programmes | Ibrahim Musa | `qa_cert_ibrahim` | qa.certificate.ibrahim@run-test.qverselearning.org | 17 |
| Applicant | Foundational Programmes | Chiamaka Eze | `qa_found_chiamaka` | qa.foundational.chiamaka@run-test.qverselearning.org | 18 |
| Tutor | — | Adaeze Nwosu | `qa_tutor_adaeze` | qa.tutor.adaeze@run-test.qverselearning.org | 24 |
| HOD | — | Emeka Chukwu | `qa_hod_emeka` | qa.hod.emeka@run-test.qverselearning.org | 25 |
| Dean | — | Folake Adeyemi | `qa_dean_folake` | qa.dean.folake@run-test.qverselearning.org | 26 |
| Director | — | Yusuf Bello | `qa_director_yusuf` | qa.director.yusuf@run-test.qverselearning.org | 27 |
| Bursary | — | Grace Okon | `qa_bursary_grace` | qa.bursary.grace@run-test.qverselearning.org | 28 |
| Staff | — | Kelechi Obi | `qa_staff_kelechi` | qa.staff.kelechi@run-test.qverselearning.org | 29 |
| Admin | — | Amaka Uche | `qa_admin_amaka` | qa.admin.amaka@run-test.qverselearning.org | 30 |
| Guest | — | Tobi Ajayi | `qa_guest_tobi` | qa.guest.tobi@run-test.qverselearning.org | 31 |

All 8 role accounts: password `Test@12345`, created via the real admin "Add User" flow
(`/admin/users/summary`, logged in as the real bootstrap super_admin —
`control@run.qverse.engine`, credentials from `bruno/auth/Login - Super Admin.bru`). All
returned `201` with the exact role requested, confirmed via `POST /auth/users`.

**Unrelated accounts noticed in the live user list, not created by this audit:**
`claude_debug_a26b`, `claude_debug_a26c`, `claude_debug_fcmb1/2/3` (and similar) — names that
reference this session's own A26 finding and what looks like a bank/gateway test ("fcmb").
Something else is actively touching this same live backend around the same issue — flagged for
you to check, not investigated further here since it isn't part of what was asked.

All three: password `Test@12345`, created via the real public `/auth/signup` flow (`POST
.../auth/register`, confirmed 201 for all three, real access/refresh tokens issued).

## Findings log

Newest first. Each entry: what was tested, what happened, whether it's a frontend or backend
issue, and current status.

---

### Round 1 — all 3 students through Major Program Choice → Choice Program → Payment stage

All three ran the identical real flow via Playwright against the live backend: sign up → sign in →
`/process-admission` → pick major program → save → pick program/entry mode/study mode → save →
land on the fee stage → click "Pay now".

**Confirmed working, all 3 major programs:**
- `POST /admission/major-program-choice` (A16) — succeeds, advances `currentStageKey` correctly for
  all three.
- `GET /admission/me/stages` resolution by major program (B10) — confirmed correct for all three,
  including Certificate's fully-decoupled Access-Fee-only sequence. **B10 closed as a non-issue** —
  full evidence table in `BACKEND_DEVIATIONS_2026-09-14.md`.
- Program choice (`POST /admission/program-choice`) — succeeds for all three, correctly narrows to
  each major program's own programs (confirmed `programOptions` only ever showed that major
  program's real programs, e.g. Certificate only offered its 2 certificate programs).

**Blocked — HIGH, universal, confirmed on 2 of 3 students (Part-Time, Certificate), same error
both times:**
```
POST /admission/me/stages/{key}/payments/initiate
→ 502 { "message": "Payment gateway error: Credo is not configured — set credo_public_key
        (and optionally credo_base_url) in Settings (group \"credo\")." }
```
This is an **operational/config gap, not a code bug** — logged as the corrected **A26** in
`BACKEND_DEVIATIONS_2026-09-14.md`. Blocks every payment-dependent test (the actual test-card
payment, enrollment-after-payment, LMS access after Access Fee, etc.) until fixed. `qa_parttime_
ngozi` is parked at `APPLICATION_PAYMENT` ready to complete a real payment with the provided test
card (`4012 8888 8888 1881`, exp `12/30`, CVV `123`, PIN `1234`) the moment this is configured.

**New minor finding, not yet root-caused — worth a follow-up look:** `qa_found_chiamaka`
(Foundational, program "ENGINEERING/PHYSICAL SCIENCE") landed on `APPLICATION_PAYMENT` with **Fee:
—, Paid: —, Balance: —** (all empty), unlike Part-Time's identical-looking Application Payment card
which correctly showed `Fee ₦10,000 / Paid ₦0 / Balance ₦10,000`. Two likely explanations, not yet
distinguished: (a) Foundational's `APPLICATION_PAYMENT` step has no `feeTypeId` assigned in admin
config (a data-entry gap, not a bug — check Admin → Admission Config → Foundational Programmes →
Application Payment step's fee link), or (b) a real resolution gap specific to Foundational.
Needs a quick look at that step's admin config before deciding which.

---

### Round 2 — the 8 remaining roles, real accounts, real logins, real dashboards

Same method: real admin-created account per role, real login via `/auth/signin`, whatever
`resolvePostSignInPath` (`src/config/nav.config.ts`) actually sent them to — not a guessed
route. All 8 logged in successfully (a few needed a retry — see "Script reliability" below,
not app bugs).

**Working cleanly, own dedicated dashboard, no network/console errors:** Director
(`/director/dashboard`), Bursary (`/admin/finance/fees`), Guest (`/guest/dashboard`).

**Real finding — Dean and Admin currently share an identical dashboard, nav, and framing.**
Both land on `/manager/dashboard` and see the exact same content: "PLATFORM CONTROL — Monitor
the entire portal like a control room," the same nav sections (Admission, Academic Sessions,
**User Management**, Finance, Grades Management, Reports), the same "Platform Users: 25" /
"Role Policies: 11 real roles configured" cards. Staff, which shares the same `/manager/
dashboard` route, correctly gets a narrower, role-appropriate "Staff Operations" view instead
— so the route itself is role-aware, this isn't a routing bug. What's actually being flagged:
**Dean currently has the same nav access as Admin, including User Management** (creating/
managing any account, any role). Not verified whether the underlying API calls are actually
permission-gated server-side beneath that shared UI — only that the UI offers it identically.
This needs your call: intentional (Deans are meant to have that much platform oversight here),
or a scoping gap worth narrowing. Not touching it without direction — this is exactly the kind
of thing that shouldn't be "fixed" on a guess.

**Existing, deliberate, not a new bug:** HOD shares Tutor's entire dashboard/nav
(`hodNav = tutorNav`, `nav.config.ts` line 332, with its own dated comment from a 2026-09-12
fix). Confirmed this is still true live — an HOD account sees the same "Teaching Workspace"
content a Tutor does. Worth knowing HOD has no dedicated dashboard yet, but this was already a
known, intentional stopgap before this audit, not something newly found.

**Worth a follow-up, not urgent:** both Tutor and HOD accounts hit errors tied to having no
matching domain-profile row:
```
404 GET /users/lecturers/me -> "No query results for model [App\Models\User\Lecturer]."
403 GET /timetable/my -> "Only students and lecturers have a personal timetable." (Tutor)
403 GET /timetable/my -> "You are not allowed to perform this action." (HOD — different message,
                                                                          same underlying cause)
```
Both dashboards degrade gracefully (zeros, no crash) despite these failing underneath. Likely
cause: the generic admin "Add User" flow creates the `User` + role only, not a matching
`Lecturer` profile row — a real Tutor/HOD onboarding probably needs a dedicated "Add
Lecturer"/staff-profile flow instead (if one exists) rather than the generic user-creation
modal used here. Not confirmed as a bug in either flow — just flagging the gap between "has the
tutor/hod role" and "has a real teaching profile," and that a more realistic test account would
need the latter.

**Minor, not investigated further:**
- Bursary's Fee Types list has visibly duplicate/messy entries (two "Acceptance Fee" rows at
  ₦30,000, "Access Fee" appearing under both `Acceptance` and `Other` categories) — leftover
  from this session's earlier admin-config testing, a data-hygiene thing, not a code bug.
- Bursary's summary cards (Total Invoiced/Collected/Outstanding/Overdue) all showed
  "Unavailable" with no failed network request behind it — worth a look, not blocking.
- Director's overview labeled itself "2024/2025 academic session" while every other screen this
  session shows "2026/2027" — likely just no enrollment data yet for the current session, not
  re-investigated.

### Round 3 — Application Form submission timing out at 30s

Real submission (Chiamaka, Foundational, with an uploaded document) hit `"Your application could
not be submitted: timeout of 30000ms exceeded"` on `POST /admissions/applications`. Checked
whether per-request timeout overrides exist in this codebase's `apiClient` before doing anything
global — they do (`RequestOptions.timeout`, already honored per-call, `src/lib/clients/
apiClient.ts` line 577). **Fixed** in `application-submit.service.ts`: this one call now passes
`timeout: 0` (axios's own "no timeout" convention), scoped to just this multipart submission —
every other request in the app keeps the global 30s default untouched. A real document upload
can legitimately take longer than 30s depending on connection speed and backend-side processing
(virus scan, storage write) without that being an actual failure. `tsc`/`eslint` both clean.

### Round 4 — a real completed payment fails to verify: "Unable to determine payment type"

Credo is clearly configured now (A26 resolved on the backend side) — a real payment actually
completed and redirected back with `status=success`:
```
localhost:3031/verify-payments?reference=PAY-2026-000016-TG4COV&status=success&feeType=Access+Fee
```
But the frontend's own verify screen failed: *"Unable to determine payment type from the
transaction amount. Please contact support."* **Root cause, confirmed by reading the code, not
guessed:** `verify-payments/page.tsx`'s `resolvePaymentType()` only recognized `feeType` values
containing the literal substrings "application"/"acceptance"/"tuition" — anything else fell
through to a hardcoded-amount guess, and failed outright if that didn't match either. "Access
Fee" (Certificate's custom, Dynamic-Admission-era PAYMENT step) matches none of the three, so it
always failed — this was never going to work for any admin-created custom fee, not just this one.

**Fixed.** Traced the actual verify call first: all three `verify*Payment()` methods
(`admissionService.ts`) already hit the exact same generic, reference-only endpoint —
`POST /fees/payments/verify/:reference` — regardless of fee type; the 3-way split only ever
existed for the on-screen title and query cache key, never the network call. So no backend
change was needed — added a fourth, generic path:
- `admissionService.verifyGenericPayment()` + `admissionQueryOptions.verifyGenericPayment()` —
  same underlying call, its own cache key.
- `useVerifyGenericPayment()` (`useAdmissionQueries.ts`) — same student-aggregate sync as the
  other three, **plus** invalidates `GET /admission/me/stages` (the other three never needed
  this; a dynamic PAYMENT stage's status lives there, not just on the student aggregate — without
  this, `/process-admission` would keep showing the stage as unpaid after a real success).
- `resolvePaymentType()` now returns a generic result (using the real `feeType` label the backend
  already sends) for anything outside the three legacy names, instead of falling through to a
  doomed amount guess and failing.

`tsc`/`eslint` both clean. Ibrahim's `PAY-2026-000016-TG4COV` (Certificate, Access Fee, ₦25,000)
should verify correctly if re-visited now — worth confirming live.

### Round 5 — blank "Admission Status" card after accepting an offer

Mary Solomon (Part-Time) accepted her offer; the page kept showing "Admission Status" as the
current stage with a status badge reading lowercase `accepted` and nothing else on the card —
the description text still claimed "being reviewed by the admissions officer." **Two real,
separate bugs, both fixed:**

1. **`AdmissionStatusSection.tsx` had no render branch for `admission_status === "accepted"` at
   all.** It handles `pending`/`offered`/`declined`/`expired`/`rejected` — accepted fell through
   all five, so the card rendered just the static header and badge with no content. Added the
   missing branch (matching the existing states' style: icon, message, a "Continue" button that
   just calls `onRefresh` rather than naming a specific next fee, since that depends on what this
   major program is actually configured with). Also made the header description dynamic instead
   of a single hardcoded "being reviewed" string shown for every status.
2. **The real root cause of the stuck stage indicator — systemic, not isolated.** Found that
   *every* mutation in `useAdmissionQueries.ts` that changes admission progress (program choice,
   every payment verify, accept, decline, every dev-simulate action — 15+ call sites) only
   resynced the legacy `admission/student` aggregate cache, never `GET /admission/me/stages` —
   the endpoint `currentStageKey` actually comes from once it's live. Same class of bug as Round
   4's generic-payment fix, just much more widespread. Fixed once, centrally, in the shared
   `syncAdmissionStudent()` helper every one of those 15+ call sites already goes through, instead
   of patching each site (and inevitably missing a 16th later). Removed the now-redundant one-off
   invalidation Round 4 had added directly in `useVerifyGenericPayment`, since it's covered by the
   central fix now.

`tsc`/`eslint` both clean. Accepting an offer should now immediately advance the stage indicator
to whatever comes next for that major program, with a real "Offer Accepted" screen in the
meantime rather than a blank one.

**Also noticed, not investigated further:** Part-Time's step indicator shows **Tuition Payment
before Acceptance Fee** — paying tuition before accepting/paying to accept the offer reads
backward. Not touched — could be this major program's actual intended configured order rather
than a bug (the enforced sequence rules only require both to come after the Decision stage, not
relative to each other) — flagging for you to confirm rather than reordering on a guess.

### Round 6 — fee-type scope labeling, discoverable editing, and one non-bug (parallel agents)

Three items raised together after reviewing the live Fee Types screen and its "Edit Step" fee-type
picker. Split across two background agents for speed; both verified clean (`tsc`/`eslint`) and
merged back into the main tree.

1. **Fixed — "Fee type" dropdown couldn't distinguish same-named fee types.**
   `StageConfigEditor.tsx`'s fee-type `SelectItem` labels now show the same scope info
   `fee-type-table.tsx`'s "Scope" column already displays (program name, else major program name,
   most specific first) — e.g. "Tuition Fee · Part-Time Programmes" instead of three indistinguishable
   "Tuition Fee" entries.
2. **Fixed — Fee Types list had no visible way to edit.** Editing already worked (click the fee
   type's *name*), but nothing in the Actions column said so. Added an explicit pencil "Edit" button
   next to Deactivate/Delete, same convention used elsewhere in this codebase. Name-click still works
   too.
3. **Investigated, no bug found — "Allow installments doesn't reflect."** Traced live, not
   guessed: toggled a real Tuition step's installment settings via a direct `PATCH`, confirmed the
   change immediately in both `GET .../steps/effective` and a real applicant's `GET /admission/me/stages`
   response (`config.allowInstallments: true`, `minimumPercent` correctly changed, `state.
   minimumPayable` correctly recomputed) — all within the same second, no cache staleness. The
   original report was likely from an earlier state of the same live data (other steps show
   `updatedAt` timestamps from earlier the same day) or a page that wasn't reloaded after saving.
   Current live behavior is correct — didn't invent a fix for a bug that wasn't there.

### Round 7 — admission-config Program Configurations tab bar showed two axes at once (parallel agent)

Program Configurations mixed legacy `programCategory` tabs (short names: "Part-time",
"Foundational / JUPEB", "Certificate") together with the real major-program tabs (full names:
"Certificate Programmes", "Foundational Programmes", "Part-Time Programmes") in one row — confirmed
via a real screenshot. **Deliberate, not a bug** per the project owner, who fixed the underlying step
*order* separately — but the tab-bar mixing itself was real and unrequested. Direct instruction:
"only the major program should appear in that screen." Fixed: the category tabs are gone from this
tab bar; every place that read the now-tabless `categories` array was traced and either updated
(the visibility condition, the empty-state condition, `handleEnterProgramsView`'s fallback — all
three would have produced a real glitch if left as-is) or deliberately left alone
(`step-scope.ts`'s category-scope resolution machinery itself, still fully intact for any
pre-existing category-scoped rows). `tsc`/`eslint` clean.

### Round 8 — major-program-scoped RBAC for staff roles (proposal, not built — see sandbox/major-program-scoping/)

Direct instruction: Tutor, Admin, Dean, Director, HOD, Bursary, and Staff accounts should each be
scoped to exactly one major program at creation, and every dashboard's data should be filtered to
that scope. This is backend RBAC/schema work — logged as a proposal extending the existing
`sandbox/major-program-scoping/` design, not built (per this repo's CLAUDE.md §13). Full writeup
in `README.md`'s "C/D — Revised 2026-09-16" and new "F. Per-role dashboard data audit" sections,
`SCHEMA_CHANGES.md` §3-4, and `API_CONTRACTS.md` §5 — summarized:

- `UserRole.majorProgramId` (already designed, `BACKEND_DEVIATIONS` A4) becomes **required, not
  optional**, for the seven roles above at creation — revised from the original design's
  optional/multi-scope framing to match "one scope, one role, one person" exactly as instructed.
- **Real, verified finding, not assumed:** created a fresh Dean account with a genuine
  `majorProgramId` grant *from the moment of creation* (bypassing the generic unscoped "Add User"
  flow) and logged into it for real. Its dashboard was **identical** to a completely unscoped
  Dean's — same full nav, same "PLATFORM CONTROL" framing, same User Management access. So even
  though `BACKEND_DEVIATIONS` A4 marks scope enforcement resolved for four list endpoints
  (Applications/Students/Invoices/Offerings), that enforcement doesn't reach dashboards or nav at
  all today — the frontend has no code anywhere that reads a caller's scope and conditionally
  narrows anything, and it's unconfirmed whether the dashboard summary-stat endpoints themselves
  even accept a scope filter yet.
- A live dashboard-by-dashboard audit (one real account per role, real login) of exactly what each
  role currently sees, unscoped, as the starting point for "every endpoint that needs filtering" —
  honest that it's dashboard-level, not yet a full per-endpoint inventory.
- Single highest-priority item flagged for the backend team if this has to ship incrementally:
  Dean currently has Admin-equivalent access, unscoped, including full User Management.

**Not built:** no frontend enforcement UI, no backend code — this is 100% a documented proposal,
ready to hand off.

**Script reliability note (mine, not the app's):** a few logins needed 2-3 retries — traced to
two real causes, both now fixed in the harness: (1) `page.waitForURL`'s default lifecycle wait
doesn't suit NextAuth's client-side `router.replace` redirect — switched to polling the URL
directly; (2) the Next.js **dev server** JIT-compiles each route on its first hit this process
("Compiling…" badge, tens of seconds) — not an app bug, just dev-mode cost, worth remembering
if this ever runs against a production build instead.

---
