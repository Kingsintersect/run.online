# Backend Hand-off — Dynamic Admission (typed stages, bound form fields)

> **Date:** 2026-09-14
> **Audience:** the backend developer.
> **Status:** **new capability request — not a deviation.** Nothing below was previously asked
> for or agreed. The step/field *registry* you already built
> (`sandbox/multi-program-platform/`, confirmed working) is the foundation this extends — it is
> not being replaced or redone.
> **Why now:** admins can already add a PROCESS step or a FORM field through the existing
> registry, but the applicant-facing pages can't render it — there's no typed "what kind of
> stage is this" and no way for a field to bind to real applicant data, be conditionally shown,
> or source a dropdown. The frontend is already built against this design (with a working
> fallback where no new endpoint exists yet), so every route below unlocks an already-finished
> screen rather than starting new frontend work.
> **Full contracts:** `README.md` (design + rationale), `SCHEMA_CHANGES.md` (models/enums/seed
> data), `API_CONTRACTS.md` (every payload). This file is the checklist + the one endpoint
> (`GET /admission/me/stages`) spelled out in full so it can be built without cross-referencing.

---

## 0. The two schema changes everything else depends on

1. **`AdmissionStepDefinition` gains `type` (enum, PROCESS rows only) and `config` (JSON, validated
   per type).** `SCHEMA_CHANGES.md` §2. Seed values for the 7 existing PROCESS rows: §6.
2. **`AdmissionFormField` gains `systemKey`, `lockedRequired`, `visibleWhen`, `optionsSource`,
   `dependsOn`, `parentFieldId`/`children`, `width`, `placeholder`, `defaultValue`, `isActive`.**
   `SCHEMA_CHANGES.md` §1. Seed data for the 8 existing FORM steps (mapping today's hardcoded
   fields onto this schema, including today's conditionals as `visibleWhen`): §6.

Everything below is additive — existing rows keep working unseeded; nothing needs a breaking
migration. Recommended build order: §0 schema → §1 catalogs → §2/§3 CRUD extensions → §4
(`GET /admission/me/stages` + actions), since §4 is what unlocks the applicant-facing screens.

---

## 1. New read-only catalogs

| Endpoint | Returns | Spec |
|---|---|---|
| `GET /admissions/config/system-fields` | The fixed catalog of bindable applicant fields (`dob`, `stateOfOrigin`, `passport`, …) with type, `lockedRequired`, and default step | `SCHEMA_CHANGES.md` §3, `API_CONTRACTS.md` §1.1 |
| `GET /admissions/config/stage-types` | The 7 stage types with their `config` field shapes, for the admin editor's type picker | `API_CONTRACTS.md` §1.2 |
| `GET /admissions/config/option-sources/{source}?dependsOn=` | Live dropdown data (COUNTRIES/STATES/LGAS/PROGRAMS/SESSIONS/ENTRY_MODES/EXAM_TYPES) for a field's `optionsSource` | `API_CONTRACTS.md` §1.3 |

The frontend already calls all three speculatively and falls back to a hardcoded copy of the
system-field catalog when `GET /admissions/config/system-fields` 404s, so shipping just that one
first is fine.

---

## 2. Stage (`PROCESS` step) CRUD — accept `type` and `config`

- `POST`/`PATCH /admissions/config/steps` accept `type` (create-only, immutable after — 422
  `STAGE_TYPE_IMMUTABLE` on attempted change) and `config` (validated per type — 422
  `INVALID_STAGE_CONFIG`). Exact shape per type: `API_CONTRACTS.md` §2.1–2.2.
- Validate stage **order/shape** server-side on create/update/reorder/delete: exactly one
  `FORM`/`DECISION`/`COMPLETE`, `COMPLETE` last, `FORM` after `PROGRAM_CHOICE` when both exist,
  `ACCEPTANCE`/`TUITION` payment stages after `DECISION`. 422 `INVALID_STAGE_SEQUENCE` with
  `details.reasons`. Full rule list: `API_CONTRACTS.md` §2.3.
- `GET /admissions/config/steps/effective?group=PROCESS&programId=` includes `type` and `config`
  on every row (§2.4).

## 3. Form field CRUD — accept the new properties

- `POST`/`PATCH .../fields` accept `systemKey` (create-only, immutable), `lockedRequired`,
  `visibleWhen`, `optionsSource`, `dependsOn`, `parentFieldId`, `width`, `placeholder`,
  `defaultValue`. Full payload + every error code (`SYSTEM_FIELD_LOCKED`,
  `DUPLICATE_SYSTEM_FIELD`, `MISSING_SYSTEM_FIELD`, `INVALID_FIELD_REFERENCE`,
  `INVALID_CONDITION`, `NESTING_TOO_DEEP`, `OPTIONS_REQUIRED`): `API_CONTRACTS.md` §3.1.
- Deleting a field/step/stage that already has submitted answers must soft-delete
  (`isActive=false`), never hard-delete — history has to stay intact for applications already
  submitted against it.
- `GET .../fields` and the `effective?group=FORM` route return the new properties plus
  `children` for `REPEATING_GROUP` fields (§3.2–3.3).
- **`POST /admissions/applications`** needs to accept the new `answers[STEP][field]` payload
  shape (multipart) alongside whatever it accepts today, evaluate `visibleWhen` server-side
  (dropping hidden fields' answers), route bound (`systemKey`) answers to their real `Application`
  columns and unbound ones to a JSON `answers` column, and store a `formSnapshot` of the resolved
  form at submission time so later config changes never change how an old application displays.
  Full behavior + 422 error shape: §3.4. This is the fix for **B1** in
  `BACKEND_DEVIATIONS_2026-09-14.md` (submit reads `customFields`, not `custom_fields`) — accepting
  `answers[...]` going forward doesn't require also fixing B1, but B1 should still be fixed for any
  client still on the old flat payload during the transition.
- **`GET /admissions/applications/{id}`** should add a `form` answer sheet built from the stored
  `formSnapshot` + the application's answers — every field with its label, value, a formatted
  `displayValue`, and whether it was visible. This is what lets the admin review page show
  applicant-specific answers without per-field frontend code. Exact shape: §3.6.

---

## 4. `GET /admission/me/stages` — full spec

This is the endpoint that replaces the frontend's current guesswork (deriving "what stage is the
applicant on" from a hardcoded map of `/admission/student` flags, and finding fees by slug). It
returns the applicant's **resolved, typed, statused** process stages in one call.

**Route:** `GET /admission/me/stages` — Bearer auth, the authenticated applicant, `{ data: … }` envelope.

**Response:**

```jsonc
{ "data": {
  "sessionId": 3,
  "programId": 55,           // null before PROGRAM_CHOICE is completed
  "currentStageKey": "ACCEPTANCE_FEE",
  "stages": [ /* one entry per resolved, active PROCESS row for this applicant, in order */ ]
} }
```

**Each stage entry** — common fields plus a `state` object shaped by `type`:

```jsonc
{
  "id": 5, "key": "ACCEPTANCE_FEE", "type": "PAYMENT",
  "label": "Acceptance Fee", "description": "…", "icon": "CreditCard", "order": 5,
  "status": "IN_PROGRESS",              // NOT_STARTED | IN_PROGRESS | COMPLETED | BLOCKED
  "completedAt": null,
  "blockedReason": null,                // only when status = BLOCKED (see below)
  "config": { "feeCategory": "ACCEPTANCE", "allowInstallments": false },   // that stage's own config, as configured by the admin
  "state": {                            // shape depends on `type` — see table below
    "feeTypeId": 7, "feeName": "Acceptance Fee", "currency": "NGN",
    "amount": 50000, "amountPaid": 0, "balance": 50000,
    "invoiceId": 991, "minimumPayable": 50000
  }
}
```

**`state` by type:**

| `type` | `state` fields |
|---|---|
| `PROGRAM_CHOICE` | `programId, programName, entryMode, studyMode, startTerm` |
| `PAYMENT` | `feeTypeId, feeName, currency, amount, amountPaid, balance, invoiceId, minimumPayable` |
| `FORM` | `{}` (status alone is enough — completed once the application is submitted) |
| `DECISION` | `applicationStatus, offerStatus, offerExpiryDate, admissionId` |
| `CONTENT` | `acknowledgedAt` (null until acknowledged) |
| `DOCUMENT_UPLOAD` | `documents: [{ key, documentId, fileName }]` — one entry per document the stage's `config.documents` asks for, `documentId`/`fileName` null until uploaded |
| `COMPLETE` | `{}` |

**Status rules:**
- `COMPLETED` / `IN_PROGRESS` / `NOT_STARTED` are derived per type: `PROGRAM_CHOICE` from whether a
  program choice exists, `PAYMENT` from the fee's paid/balance state, `FORM` from whether the
  application was submitted, `DECISION` from the offer status, `CONTENT` from whether it's been
  acknowledged, `DOCUMENT_UPLOAD` from whether every required document is present.
- `BLOCKED` applies to `DECISION` when the application was rejected or the offer was declined/
  expired, and carries `blockedReason`: `APPLICATION_REJECTED` | `OFFER_DECLINED` | `OFFER_EXPIRED`.
  A blocked stage ends the applicant's journey (no further stage is reachable).
- `currentStageKey` = the key of the first stage that is not `COMPLETED` (and not `BLOCKED` unless
  it's the terminal one), or the `COMPLETE` stage's key once every prior stage is done.
- `PROGRAM_CHOICE`, `PAYMENT`, `FORM`, `DECISION` status/state must be **derived on read** from the
  existing program-choice, invoice, application and offer records — no separate progress table, no
  risk of drift. Only `CONTENT` and `DOCUMENT_UPLOAD` need real stored state (`AdmissionStageProgress`,
  `SCHEMA_CHANGES.md` §5) since nothing else already tracks them.

**Actions** (each returns the updated stage in the same shape as above):

| Route | For type | Body | Effect |
|---|---|---|---|
| `POST /admission/me/stages/{key}/acknowledge` | `CONTENT` | — | sets `acknowledgedAt`, status → `COMPLETED` |
| `POST /admission/me/stages/{key}/documents` | `DOCUMENT_UPLOAD` | multipart `documents[{docKey}] = <file>` | stores/replaces that document; status → `COMPLETED` once every required document is present |
| `DELETE /admission/me/stages/{key}/documents/{docKey}` | `DOCUMENT_UPLOAD` | — | removes it |
| `POST /admission/me/stages/{key}/payments/initiate` | `PAYMENT` | `{ "amount"?: number }` (installments only, must be ≥ `minimumPayable`) | `{ "authorizationUrl": "…", "reference": "…" }` — same gateway flow as the existing fee-specific initiate routes |
| `POST /admission/program-choice` | `PROGRAM_CHOICE` | existing contract | unchanged — already exists (see `BACKEND_HANDOFF.md` A5 in the parent `sandbox/`) |
| `POST /admissions/{id}/accept` / `…/decline` | `DECISION` | existing contracts | unchanged |

Errors: 409 `STAGE_NOT_CURRENT` (acting on a stage before the current one is complete), 422
`WRONG_STAGE_TYPE`, 404 `STAGE_NOT_FOUND`, 422 `AMOUNT_BELOW_MINIMUM`.

**Keep the existing three fee-specific initiate routes** (`/fees/payments/{application|acceptance|
tuition}/initiate`) working as aliases during the transition — the frontend's fallback still calls
them directly when `GET /admission/me/stages` isn't available yet.

Full detail, plus a second full example (`CHOICE_PROGRAM`, `MEDICAL_GUIDANCE` CONTENT stage,
`ADMISSION_STATUS`, `EXTRA_DOCS`, `COMPLETED`): `API_CONTRACTS.md` §4.

---

## 5. Frontend status — nothing here blocks a release

Every screen this unlocks is **already built and shipping** with a working fallback:

- The applicant process page (`process-admission`) composes the same `stages`/`currentStageKey`
  shape from today's `GET /admission/student` flags + the step registry, and switches to the real
  endpoint transparently once it exists.
- `CONTENT` and `DOCUMENT_UPLOAD` stages render but are marked non-blocking in the fallback (they
  can't be completed without their endpoints), so applicants aren't stuck waiting on them.
- The admin review page's answer sheet falls back to labeling today's `custom_fields` via the
  program's current field definitions when `application.form` isn't present yet.

So there's no urgency pressure beyond normal prioritization — but every route built here turns an
already-finished frontend screen fully on.
