# Dynamic Admission — Typed Stages & Bound Form Fields

**Goal:** the admission process stages, the application form steps and every field inside them
are **data**, not code. An admin can add, remove, reorder, rename, hide or scope any stage, step or
field, and the applicant pages keep working with no frontend release.

**Status:** proposed 2026-09-14. Builds on (does not replace) `sandbox/multi-program-platform/`
(step scoping §A and the field registry §B are already built).

Files in this folder:
| File | What it holds |
|---|---|
| `README.md` | Why, the design, rules, migration, rollout |
| `SCHEMA_CHANGES.md` | Model changes, enums, seed data for today's built-in steps |
| `API_CONTRACTS.md` | Every request and response payload |

---

## 1. Why — what breaks today

Audited 2026-09-14 against the app, `sandbox/` and `bruno/`:

| Area | Today | Effect |
|---|---|---|
| Application form steps | 9 hand-built React components with fixed Zod schemas; backend `POST /admissions/applications` takes ~35 fixed multipart keys | A new form step has no page; a standard step's questions can't change |
| Fields added to a built-in step | Stored by the backend, **filtered out** by the frontend | Admin adds a field to "Personal Information" — applicants never see it |
| Custom form steps | All their fields are merged into one "Additional Information" page | Step boundaries/labels are lost |
| Conditional questions (sponsor, disability, second sitting) | Hardcoded `superRefine` rules | Not configurable |
| Dropdowns from live data (country/state/LGA, programs) | Hardcoded per component | Not configurable |
| Process stages | 7 hand-built sections; completion is a hardcoded map on `/admission/student` flags | A custom stage is **skipped and never shown**; fees are found by slug |
| Admin application review | Hardcoded `personal_info` layout | Dynamic answers are never displayed |
| Submit key | Frontend sends `custom_fields[...]`, backend reads `customFields[...]` | Dynamic answers are likely dropped |

`sandbox/multi-program-platform/README.md` §4B deliberately stopped at a "hybrid" (universal fields
hardcoded). This proposal finishes the job without losing what the hybrid protected: typed,
queryable columns for identity/program data that reports, matric numbers and student creation
depend on.

---

## 2. The design

### A. Form: every field is a definition — "bound fields"

- **Every** FORM step, including the standard ones, renders from its `AdmissionFormField` rows.
  The frontend has one generic step renderer and no per-step components.
- A field may carry a **`systemKey`** (e.g. `dob`, `stateOfOrigin`, `passport`). The backend maps a
  bound field's answer onto its real `Application` column. Unbound fields go to the application's
  `answers` JSON.
- System fields are **seeded**, not typed in by admins. Admins can relabel, reorder, move between
  steps, add help text, and change visibility; they **cannot delete** a system field or change its
  type, and **`lockedRequired`** ones can't be made optional (the backend needs them).
- **Conditional visibility** (`visibleWhen`) replaces every hardcoded conditional. A hidden field is
  never required, and its value is discarded on submit.
- **Option sources** (`optionsSource` + `dependsOn`) replace hardcoded dropdown data: countries →
  states → LGAs, programs, sessions.
- **Nested fields**: `REPEATING_GROUP` gets real child fields (`parentFieldId`, one level).
- **Files**: `FILE` fields declare `accept` (`IMAGE`/`DOCUMENT`/`ANY`), `maxSizeMb`, `multiple`.
- **Snapshot**: on submit, the backend stores the resolved form definition with the application,
  so later config changes never break how an old application is displayed.
- **Review** (applicant) and **application review** (admin) both render from the snapshot +
  answers — generic, no per-field code.

### B. Process: every stage has a type

A PROCESS step gets a **`type`** (fixed set, implemented once in code) and a **`config`**
(per-instance settings, data). Types stay code; stages are data.

| Type | What the applicant does | `config` | Completes when |
|---|---|---|---|
| `PROGRAM_CHOICE` | Picks program (+ entry mode / study mode / start term) | which extras to collect | choice saved |
| `PAYMENT` | Pays a fee | `feeCategory` (+ optional `feeTypeId`), installments rule | invoice paid (or installment threshold met) |
| `FORM` | Fills the application form (the FORM steps) | — | application submitted |
| `DECISION` | Waits for the admission decision, then accepts/declines the offer | show offer expiry | offer accepted |
| `CONTENT` | Reads instructions / a notice | title, body (Markdown), acknowledgement | acknowledged (or viewed, if no acknowledgement) |
| `DOCUMENT_UPLOAD` | Uploads extra documents (e.g. medical report) | list of required documents | all required documents uploaded |
| `COMPLETE` | Sees the finish screen | message, button label/link | always terminal |

- The **backend** owns progress: `GET /admission/me/stages` returns the resolved stages for the
  applicant's program with a `status` each and the `currentStageKey`. The frontend no longer
  derives the current stage itself.
- One generic action endpoint per interactive type (`acknowledge`, `documents`,
  `payments/initiate`) replaces the three fee-specific payment routes.
- **Order rules** are validated server-side (e.g. an `ACCEPTANCE` payment must come after
  `DECISION`; `FORM` after `PROGRAM_CHOICE` when both exist) — see `API_CONTRACTS.md` §2.3.

### C. Scoping — unchanged, and now complete

Stages, steps and fields keep the existing scope model (program → category → default). Fields
belong to a step row, so a customised step for Certificate programs has its own fields. **Depends on
`BACKEND_DEVIATIONS_2026-09-14.md` B8a**: an inactive scoped row must hide the inherited one,
otherwise a category can't remove a default stage/step.

---

## 3. Rules the backend must enforce

1. A resolved form may contain each `systemKey` **at most once** (422 `DUPLICATE_SYSTEM_FIELD`).
2. Every `lockedRequired` system field must be present and visible-by-default in the resolved form
   for every program (422 `MISSING_SYSTEM_FIELD` on the change that would remove/hide it).
3. `visibleWhen`/`dependsOn` may only reference fields that appear **earlier** in the resolved form
   (422 `INVALID_FIELD_REFERENCE`) — no cycles.
4. Field `key` is immutable (answers are stored under it); `type` and `systemKey` are immutable.
5. Stage `type` is immutable after creation; `config` is validated against the type (422
   `INVALID_STAGE_CONFIG`).
6. Exactly one `COMPLETE` stage, and it is last. At most one `FORM` and one `DECISION` stage per
   resolved process.
7. Deleting a stage/step/field that already has submitted answers or progress is a soft delete
   (`isActive=false`) — history stays intact.

---

## 4. What stays code (on purpose)

- The **7 stage types** and the **field types** — new *kinds* of behaviour (an interview-booking
  stage, a signature field) are a code change on both sides. Adding, removing, reordering, scoping
  or rewording any *instance* is not.
- The **system field catalog** — it mirrors real `Application` columns.
- Payment gateway integration, offer/decision workflow, student creation after tuition.

---

## 5. Migration (no applicant loses anything)

1. Add columns/tables (`SCHEMA_CHANGES.md`). All additive.
2. Seed: set `type` on the 7 existing PROCESS rows; create the system fields for the 8 existing FORM
   steps exactly as today's form asks them (`SCHEMA_CHANGES.md` §6), with today's conditionals as
   `visibleWhen`.
3. Keep accepting the **old flat submit payload** until the frontend switches; the new
   `answers[...]` payload is accepted from day one. Remove the old shape after one release.
4. Existing applications get a snapshot generated from the seeded definitions on first read.

---

## 6. Frontend plan (built ahead of the backend)

- **Admin — Admission Configuration:** stage type picker + per-type config editor; field editor
  gains system-field lock badges, `visibleWhen` builder, option source picker, child fields for
  repeating groups, file rules.
- **Applicant — form:** one `DynamicStep` renderer for every FORM step; runtime Zod built from the
  resolved fields; draft storage keyed by step/field key; generic Review.
- **Applicant — process:** stage renderer registry keyed by `type`, driven by
  `GET /admission/me/stages`.
- **Admin — application review:** generic answer sheet from the snapshot.
- Until the backend ships, the applicant pages keep today's hardcoded flow as a fallback, switched
  per endpoint availability — no broken screens in between.
