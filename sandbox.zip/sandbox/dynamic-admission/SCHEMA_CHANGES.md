# Schema Changes — Dynamic Admission

All changes are additive. Existing rows keep working until seeded (§6). Prisma-style notation;
translate to Laravel migrations as usual.

---

## 1. Modified model — `AdmissionFormField`

```diff
 model AdmissionFormField {
   id           Int       @id @default(autoincrement())
   stepId       Int
   key          String
   label        String
   type         FormFieldType
   order        Int
   isRequired   Boolean   @default(false)
   helpText     String?
   options      Json?
   validation   Json?
   repeatable   Boolean   @default(false)
+  isActive       Boolean   @default(true)     // soft delete once answers exist (README §3.7)
+  systemKey      String?                      // binds to an Application column — catalog §3
+  lockedRequired Boolean   @default(false)    // copied from the catalog; admin can't unset isRequired
+  placeholder    String?
+  width          FieldWidth @default(FULL)    // layout hint only
+  defaultValue   Json?
+  visibleWhen    Json?                        // Condition — §4
+  optionsSource  OptionsSource?               // null = use static `options`
+  dependsOn      String?                      // key of an earlier field feeding optionsSource (e.g. STATES ← country)
+  parentFieldId  Int?                         // child of a REPEATING_GROUP field (one level only)
+  parent         AdmissionFormField?  @relation("FieldChildren", fields: [parentFieldId], references: [id], onDelete: Cascade)
+  children       AdmissionFormField[] @relation("FieldChildren")

   @@unique([stepId, key])
 }

 enum FormFieldType {
   TEXT
   TEXTAREA
   EMAIL
   PHONE
   NUMBER
   DATE
   SELECT
   MULTISELECT
   FILE
   REPEATING_GROUP
+  BOOLEAN        // yes/no switch (has_sponsor, awaiting_result…)
+  RADIO          // single choice shown as radio buttons
+  YEAR           // four-digit year picker
 }

+enum FieldWidth { FULL HALF }

+enum OptionsSource {
+  COUNTRIES      // value = country name
+  STATES         // dependsOn → a COUNTRIES field
+  LGAS           // dependsOn → a STATES field
+  PROGRAMS       // value = program id (respects the applicant's scope)
+  SESSIONS       // value = session id
+  ENTRY_MODES    // UTME | DIRECT_ENTRY | TRANSFER
+  EXAM_TYPES     // WAEC | NECO | NABTEB | GCE
+}
```

`validation` gains file rules (all optional):

```ts
{
  min?: number; max?: number; pattern?: string; minDate?: string; maxDate?: string,  // existing
  minLength?: number; maxLength?: number,                                             // new
  accept?: "IMAGE" | "DOCUMENT" | "ANY",   // FILE only; DOCUMENT = PDF/DOC/DOCX + images
  maxSizeMb?: number,                       // FILE only, default 5
  multiple?: boolean,                       // FILE only
  maxItems?: number                         // REPEATING_GROUP / multiple FILE
}
```

---

## 2. Modified model — `AdmissionStepDefinition`

```diff
 model AdmissionStepDefinition {
   id              Int      @id @default(autoincrement())
   group           StepGroup           // PROCESS | FORM
   key             String
   order           Int
   label           String
   description     String
   icon            String
   isRequired      Boolean
   isActive        Boolean
   programCategory ProgramCategory?
   programId       Int?
+  type            StageType?          // PROCESS rows only; required for PROCESS, null for FORM
+  config          Json?               // per-type settings — API_CONTRACTS.md §2.2
 }

+enum StageType {
+  MAJOR_PROGRAM_CHOICE  // added 2026-09-14 — see the note below
+  PROGRAM_CHOICE
+  PAYMENT
+  FORM
+  DECISION
+  CONTENT
+  DOCUMENT_UPLOAD
+  COMPLETE
+}
```

FORM rows keep `type = null`. The `REVIEW` FORM row stays a reserved, always-last key.

**`MAJOR_PROGRAM_CHOICE` (added 2026-09-14):** for an institution running more than one major
program (Degree, Part-Time, Certificate, …), the applicant now picks their major program in its own
stage, before `PROGRAM_CHOICE` — so that stage's own picker can narrow to just that major program's
programs instead of listing every program in the institution together, and so the application form
and later stages resolve against the right one. No config of its own (`{}`, same as `FORM`). See
`API_CONTRACTS.md` §4.3 for the new endpoint this needs and the `GET /admission/student` field
addition — flagged as a new capability, not built yet, in `BACKEND_DEVIATIONS_2026-09-14.md` A16.

**`majorProgramId` (added 2026-09-15 — Major-Program Scoping, `BACKEND_DEVIATIONS_2026-09-14.md`
A22):** `MAJOR_PROGRAM_CHOICE` above lets an applicant declare which major program they're in, but
nothing let an admin actually configure *different* process/form steps per major program — every
step still only scoped by `programCategory`/`programId`, an orthogonal axis (a Certificate-category
program and a Part-Time major program aren't the same grouping). This closes that gap:

```diff
 model AdmissionStepDefinition {
   id              Int      @id @default(autoincrement())
   group           StepGroup
   key             String
   order           Int
   label           String
   description     String
   icon            String
   isRequired      Boolean
   isActive        Boolean
   programCategory ProgramCategory?
   programId       Int?
+  majorProgramId  Int?     // null = institution default — see the resolution table below
   type            StageType?
   config          Json?
 }
```

**Resolution table** (same governing rule as everywhere else major-program-scoping touches —
most specific wins, `null` at every level = institution-wide, unchanged from today):

| `programId` | `majorProgramId` | `programCategory` | Applies to |
|---|---|---|---|
| `null` | `null` | `null` | Every applicant, institution-wide (today's exact behavior) |
| `null` | `null` | set | Every applicant whose program is in that category (unchanged from today) |
| `null` | set | (either) | Every applicant who chose that major program at `MAJOR_PROGRAM_CHOICE`, regardless of category |
| set | (either) | (either) | Only that program's applicants — most specific, wins over everything else |

This is additive: a deployment that never adopts Major Program Choice keeps `majorProgramId` null
on every row and sees no behavior change at all. `GET /admissions/config/steps/effective` gains a
matching `majorProgramId` query param — see `API_CONTRACTS.md` §4.4.

`AdmissionFormField` needs no schema change for this — a FORM step's fields already belong to that
one step row, so scoping the step (via "customise for this major program," which already copies a
step's fields when it copies the step) is sufficient for "form fields differ per major program" too.

## 2c. Resolution rule change — full major-program decoupling (added 2026-09-15, supersedes §2's fallback for `majorProgramId`)

**Direct product instruction, quoted in full because it's the whole spec:** "the major programs are
completely different programs with no ties to each other. different user base, payments, sessions,
courses, admission steps, admission form, etc. they are not meant to be connected in any way...
order should not be tied to 'All major programs', it should be major program based, highly
decoupled... the system can reuse components to display similar data, but the data and resource is
different and should not be tied together."

**The problem with §2's original design:** it made `majorProgramId` a resolution tier that still
**falls back** to `programCategory` and then the institution default when a major program hasn't
customised a given `key` — the same inheritance model `programCategory`/`programId` already used.
In practice this means every major program's resolved sequence is a *merge* of its own rows plus
whatever it's still inheriting, and — because `order` is one shared number line across every scope
— an admin can trigger `INVALID_STAGE_SEQUENCE` by editing a step in Major Program A whose `order`
value happens to collide with an *inherited*, untouched step's `order` from the institution
default. Confirmed live 2026-09-15 (`ACCEPTANCE_PAYMENT_BEFORE_DECISION` on a `PATCH` that only
touched one step). This inheritance model is fundamentally the opposite of what's wanted: major
programs aren't meant to share anything by default.

**The fix — no schema change, a resolution *semantics* change on `GET /admissions/config/steps/
effective` (and nothing else — `majorProgramId` itself, its column, and its place in the `key`
uniqueness constraint are all unchanged, still exactly as A22 shipped):**

> **When `?majorProgramId=` is present on the request, resolve *only* among rows that belong to
> that major program — a `programId`-scoped row for a program under it (most specific), or a
> `majorProgramId`-scoped row matching it directly. Do not fall back to `programCategory`, and do
> not fall back to the institution default (`majorProgramId: null` / `programCategory: null` /
> `programId: null`) at all. If no row for a given `key` belongs to this major program, that step
> is simply absent from the result — no substitute is served.**
>
> **When `?majorProgramId=` is omitted, resolve exactly as before A22 shipped
> (`programId` > `programCategory` > institution default) — fully unchanged.** This is what keeps
> a deployment with zero or one major program (which never sends `majorProgramId` at all — see
> `major-program-scoping/README.md` §0's governing rule) rendering exactly as it always has.

This turns the institution-default rows (`majorProgramId`/`programCategory`/`programId` all null)
into a **pure catalog** — they're never served to any applicant under a major program once this
ships. They exist only as copy sources: an admin "adds" a catalog step to a major program by
creating a new, independent row scoped to it (mechanically identical to today's "customise" — copy
`label`/`description`/`icon`/`type`/`config`/fields into a new row with `majorProgramId` set) — no
new endpoint needed, `POST /admissions/config/steps` already does this.

**Why this also fixes the `order`-coupling bug as a side effect, not a separate fix:** once a major
program's resolved sequence contains *only* its own rows — no more inherited rows mixed in — its
`order` values are self-contained. Reordering, and `INVALID_STAGE_SEQUENCE` validation, both operate
on "the resolved sequence for this scope," which is now genuinely independent per major program.
`PATCH /admissions/config/steps/reorder` (already renumbers whatever ids it's given from 1) can be
used directly for a major-program scope now, the same way it already works for the institution
default — no backend change needed there either.

**Migration — decided, not automatic.** This is a breaking change for any environment already
relying on the old fallback (this one: Redeemer's University's real major programs currently see
every institution-default step by inheritance). Flipping the resolution rule with no data migration
makes every major program's admission process go instantly empty until an admin manually re-adds
every step. Both automatic options originally considered here — a one-time backend backfill, or a
single "adopt everything" bulk button — were explicitly rejected: "We don't want an automatic
all-or-nothing backend migration or a single bulk-adopt button. What we want is granular control per
major program." Built instead: a per-major-program, multi-select **"Add from Catalog"** action (see
`API_CONTRACTS.md` §2.6 and `BACKEND_DEVIATIONS_2026-09-14.md` A23's "Frontend: built" note) — no
backend-side migration to sequence, just the known admin-facing task of populating each major program
by hand before it reaches real applicants.

---

## 3. Reference data — system field catalog

Not a table the admin edits; a backend constant exposed by `GET /admissions/config/system-fields`.
`column` is the existing `Application` storage the answer maps to.

| systemKey | Type | lockedRequired | Maps to |
|---|---|---|---|
| `programId` | SELECT (PROGRAMS) | ✅ | program choice |
| `entryMode` | SELECT (ENTRY_MODES) | ✅ | program choice |
| `startTerm` | SELECT | ✅ | program choice |
| `studyMode` | RADIO | ✅ | program choice |
| `nationality` | SELECT (COUNTRIES) | ✅ | personal_info |
| `stateOfOrigin` | SELECT (STATES) | ✅ | personal_info |
| `lga` | SELECT (LGAS) | ✅ | personal_info |
| `religion` | SELECT | ✅ | personal_info |
| `dob` | DATE | ✅ | personal_info |
| `gender` | RADIO | ✅ | personal_info |
| `hometown` | TEXT | ✅ | personal_info |
| `hometownAddress` | TEXTAREA | ✅ | personal_info |
| `contactAddress` | TEXTAREA | ✅ | personal_info |
| `hasDisability` | BOOLEAN | — | personal_info |
| `disability` | TEXT | — | personal_info |
| `hasSponsor` | BOOLEAN | — | sponsor |
| `sponsorName`, `sponsorRelationship`, `sponsorEmail`, `sponsorContactAddress`, `sponsorPhoneNumber` | TEXT/SELECT/EMAIL/TEXTAREA/PHONE | — | sponsor |
| `nextOfKinName`, `nextOfKinRelationship`, `nextOfKinPhoneNumber`, `nextOfKinAddress` | TEXT/SELECT/PHONE/TEXTAREA | ✅ | next_of_kin |
| `nextOfKinEmail`, `nextOfKinAlternatePhoneNumber`, `nextOfKinOccupation`, `nextOfKinWorkplace`, `isNextOfKinPrimaryContact` | EMAIL/PHONE/TEXT/TEXT/BOOLEAN | — | next_of_kin |
| `passport` | FILE (IMAGE) | ✅ | documents |
| `firstSchoolLeaving`, `oLevel` | FILE (DOCUMENT) | — | documents |
| `otherDocuments` | FILE (DOCUMENT, multiple) | — | documents |
| `awaitingResult` | BOOLEAN | — | academic_records |
| `combinedResult` | RADIO | — | academic_records |
| `firstSittingType`, `firstSittingYear`, `firstSittingExamNumber`, `firstSittingResult` | SELECT(EXAM_TYPES)/YEAR/TEXT/FILE | — | academic_records |
| `secondSittingType`, `secondSittingYear`, `secondSittingExamNumber`, `secondSittingResult` | SELECT(EXAM_TYPES)/YEAR/TEXT/FILE | — | academic_records |

Identity (`firstName`, `middleName`, `lastName`, `email`, `phoneNumber`) is **not** a form field —
the backend keeps taking it from the authenticated user, as today.

---

## 4. `Condition` shape (`visibleWhen`)

```ts
type Condition =
  | { field: string; op: "equals" | "notEquals"; value: string | number | boolean }
  | { field: string; op: "in" | "notIn"; value: (string | number)[] }
  | { field: string; op: "isTrue" | "isFalse" | "isEmpty" | "isNotEmpty" }
  | { all: Condition[] }
  | { any: Condition[] }
```

`field` is another field's `key` in the same resolved form (earlier in order). The frontend and
backend evaluate it identically; the backend is authoritative.

---

## 5. New models

### `AdmissionStageProgress`

```prisma
model AdmissionStageProgress {
  id           Int      @id @default(autoincrement())
  userId       Int                      // the applicant
  sessionId    Int
  stepId       Int                      // the resolved PROCESS row
  stageKey     String
  status       StageStatus @default(NOT_STARTED)
  data         Json?                    // CONTENT: { acknowledgedAt }; DOCUMENT_UPLOAD: { documents: [{ key, documentId }] }
  completedAt  DateTime?
  createdAt    DateTime @default(now())
  updatedAt    DateTime @updatedAt

  @@unique([userId, sessionId, stageKey])
}

enum StageStatus { NOT_STARTED IN_PROGRESS COMPLETED BLOCKED }
```

Only `CONTENT` and `DOCUMENT_UPLOAD` need stored state. `PROGRAM_CHOICE`, `PAYMENT`, `FORM`,
`DECISION` status is **derived** on read from the existing program-choice, invoice, application and
offer records — no duplication.

### `Application` additions

```diff
 model Application {
   …existing columns unchanged…
   customFields    Json?
+  answers         Json?     // { [stepKey]: { [fieldKey]: value } } — unbound fields only
+  formSnapshot    Json?     // resolved FORM steps + fields at submission (API_CONTRACTS §3.4)
+  formVersion     Int       @default(1)
 }
```

`customFields` stays readable for old applications; new writes go to `answers`.

---

## 6. Seed data for today's built-in steps

### PROCESS rows → `type` / `config`

| key | type | config |
|---|---|---|
| `CHOICE_PROGRAM` | `PROGRAM_CHOICE` | `{ "collectEntryMode": true, "collectStudyMode": true, "collectStartTerm": true }` |
| `APPLICATION_PAYMENT` | `PAYMENT` | `{ "feeCategory": "APPLICATION", "allowInstallments": false }` |
| `APPLICATION_FORM` | `FORM` | `{}` |
| `ADMISSION_STATUS` | `DECISION` | `{ "showOfferExpiry": true }` |
| `ACCEPTANCE_FEE` | `PAYMENT` | `{ "feeCategory": "ACCEPTANCE", "allowInstallments": false }` |
| `TUITION_PAYMENT` | `PAYMENT` | `{ "feeCategory": "TUITION", "allowInstallments": true, "minimumPercent": 50 }` |
| `COMPLETED` | `COMPLETE` | `{ "message": "Your admission is complete.", "ctaLabel": "Go to my courses", "ctaHref": "/student/courses" }` |

### FORM rows → seeded fields (order within step; `visibleWhen` shown where today's form has a rule)

**PERSONAL_INFO:** `nationality`, `state_of_origin` (STATES dependsOn `nationality`), `lga` (LGAS
dependsOn `state_of_origin`), `religion` (options Christianity/Islam/Traditional/Other), `dob`,
`gender` (Male/Female), `hometown`, `hometown_address`, `contact_address`, `has_disability`,
`disability` — visibleWhen `{ field: "has_disability", op: "isTrue" }`, required.

**SPONSOR_INFO:** `has_sponsor`; `sponsor_name`, `sponsor_relationship`, `sponsor_email`,
`sponsor_contact_address` (minLength 10), `sponsor_phone_number` (minLength 10) — each visibleWhen
`{ field: "has_sponsor", op: "isTrue" }`, required.

**NEXT_OF_KIN:** `next_of_kin_name`, `next_of_kin_relationship` (Parent/Sibling/Spouse/Guardian/
Uncle/Aunt/Other), `next_of_kin_phone_number`, `next_of_kin_address`, `next_of_kin_email`
(optional), `is_next_of_kin_primary_contact`, `next_of_kin_alternate_phone_number`,
`next_of_kin_occupation`, `next_of_kin_workplace` (all optional).

**DOCUMENTS:** `passport` (IMAGE), `first_school_leaving`, `o_level` (DOCUMENT),
`other_documents` (DOCUMENT, multiple).

**QUALIFICATION_FIELDS:** `awaiting_result`; `combined_result` (single_result/combined_result) —
visibleWhen `{ field: "awaiting_result", op: "isFalse" }`, required.

**EXAM_SITTING:** `first_sitting_type`, `first_sitting_year`, `first_sitting_exam_number` — visibleWhen
`awaiting_result isFalse`, required; `second_sitting_*` — visibleWhen
`{ all: [{ field: "awaiting_result", op: "isFalse" }, { field: "combined_result", op: "equals", value: "combined_result" }] }`, required.

**QUALIFICATION_DOCUMENTS:** `first_sitting_result` (same visibility as first sitting, required),
`second_sitting_result` (same as second sitting, required).

**PROGRAM_SELECTION:** `program_id`, `entry_mode`, `start_term`, `study_mode` — only seeded/active
when the resolved process has **no** `PROGRAM_CHOICE` stage (otherwise those answers come from the
stage).

Each seeded field sets the matching `systemKey` and `lockedRequired` from §3.
