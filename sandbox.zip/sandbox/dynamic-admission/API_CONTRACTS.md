# API Contracts — Dynamic Admission

Bearer auth on every route. `{ data: … }` envelope as everywhere else. Admin routes = Admin role or
the matching `admission-config.*` permission. Applicant routes = the authenticated applicant.

---

## 1. Catalogs (admin, read-only)

### 1.1 `GET /admissions/config/system-fields`

```jsonc
{ "data": [
  { "systemKey": "dob", "label": "Date of birth", "type": "DATE", "lockedRequired": true,
    "optionsSource": null, "defaultStepKey": "PERSONAL_INFO" },
  { "systemKey": "stateOfOrigin", "label": "State of origin", "type": "SELECT", "lockedRequired": true,
    "optionsSource": "STATES", "dependsOnSystemKey": "nationality", "defaultStepKey": "PERSONAL_INFO" }
  // … full catalog in SCHEMA_CHANGES.md §3
] }
```

### 1.2 `GET /admissions/config/stage-types`

```jsonc
{ "data": [
  { "type": "PAYMENT", "label": "Payment", "multiple": true,
    "configFields": [
      { "key": "feeCategory", "type": "SELECT", "required": true,
        "options": ["APPLICATION", "ACCEPTANCE", "TUITION", "HOSTEL", "CLEARANCE", "OTHER"] },
      { "key": "feeTypeId", "type": "NUMBER", "required": false },
      { "key": "allowInstallments", "type": "BOOLEAN", "required": false },
      { "key": "minimumPercent", "type": "NUMBER", "required": false, "min": 1, "max": 100 }
    ] },
  { "type": "FORM", "label": "Application form", "multiple": false, "configFields": [] }
  // … one entry per StageType
] }
```

### 1.3 `GET /admissions/config/option-sources/{source}?dependsOn={value}`

Public to authenticated applicants (the form uses it). `source` ∈ `OptionsSource`.

```jsonc
// GET /admissions/config/option-sources/LGAS?dependsOn=Lagos
{ "data": [ { "value": "Ikeja", "label": "Ikeja" }, { "value": "Epe", "label": "Epe" } ] }
```

404 `UNKNOWN_OPTIONS_SOURCE`; 422 `DEPENDS_ON_REQUIRED` for STATES/LGAS without `dependsOn`.

---

## 2. Stages (PROCESS rows) — admin

### 2.1 `POST /admissions/config/steps` and `PATCH /admissions/config/steps/{id}` — new fields

```jsonc
{
  "group": "PROCESS",
  "key": "MEDICAL_GUIDANCE",
  "order": 4,
  "label": "Medical Guidance",
  "description": "Read before paying the acceptance fee.",
  "icon": "Stethoscope",
  "isRequired": false,
  "isActive": true,
  "programCategory": "DEGREE",
  "programId": null,
  "type": "CONTENT",                        // NEW — required for PROCESS; immutable after create
  "config": {                               // NEW — validated against the type (§2.2)
    "title": "Before you continue",
    "body": "## Medical examination\nBook your medical at the university clinic…",
    "requireAcknowledgement": true,
    "acknowledgementLabel": "I have read and understood this"
  }
}
```

`PATCH` accepts `config` (full replacement) but not `type` (422 `STAGE_TYPE_IMMUTABLE`).
Response: the step row including `type` and `config`.

### 2.2 `config` per type

```ts
PROGRAM_CHOICE:  { collectEntryMode: boolean; collectStudyMode: boolean; collectStartTerm: boolean }
PAYMENT:         { feeCategory: FeeCategory; feeTypeId?: number | null;
                   allowInstallments: boolean; minimumPercent?: number }   // minimumPercent only with installments
FORM:            {}
DECISION:        { showOfferExpiry: boolean }
CONTENT:         { title: string; body: string /* Markdown */; requireAcknowledgement: boolean;
                   acknowledgementLabel?: string }
DOCUMENT_UPLOAD: { documents: { key: string; label: string; accept: "IMAGE" | "DOCUMENT" | "ANY";
                                required: boolean; maxSizeMb?: number }[] }
COMPLETE:        { message: string; ctaLabel?: string; ctaHref?: string }
```

422 `INVALID_STAGE_CONFIG` with `details.errors: { [configKey]: string[] }`.

### 2.3 Order/shape validation (on create, update, reorder, delete — per resolved scope)

422 `INVALID_STAGE_SEQUENCE` with `details.reasons`:
- `COMPLETE_NOT_LAST` · `MULTIPLE_COMPLETE` · `MULTIPLE_FORM` · `MULTIPLE_DECISION`
- `FORM_BEFORE_PROGRAM_CHOICE` · `ACCEPTANCE_PAYMENT_BEFORE_DECISION`
- `TUITION_PAYMENT_BEFORE_DECISION`

### 2.4 `GET /admissions/config/steps/effective?group=PROCESS&programId=`

Each row now includes `type` and `config`. (Also apply `BACKEND_DEVIATIONS_2026-09-14.md` B8a: the
most specific row per key wins even when inactive, and an inactive winner removes the stage.)

### 2.5 `majorProgramId` on steps (new 2026-09-15 — `BACKEND_DEVIATIONS_2026-09-14.md` A22)

`POST`/`PATCH /admissions/config/steps` accept a third scope field alongside `programCategory`/
`programId`:

```jsonc
// POST /admissions/config/steps — a CONTENT stage scoped to one major program
{
  "group": "PROCESS",
  "key": "PART_TIME_ORIENTATION",
  "order": 3,
  "label": "Part-Time Orientation",
  "programCategory": null,
  "programId": null,
  "majorProgramId": 3,
  "type": "CONTENT",
  "config": { "title": "Welcome, Part-Time student", "body": "…", "requireAcknowledgement": true }
}
```

`GET /admissions/config/steps/effective?group=PROCESS&programId=&majorProgramId=` gains the
matching param, resolved per `SCHEMA_CHANGES.md` §2's table (`programId` still wins over
everything; `majorProgramId` wins over `programCategory` and the institution default). Omit both
before either choice has been made. `GET /admissions/config/steps` (the raw admin list) also
accepts `?majorProgramId=` as a browsing filter, same as the existing `programId`/`programCategory`
filters.

**Critical for `key` uniqueness specifically** (confirmed live 2026-09-15, `BACKEND_DEVIATIONS`
A22): the point of this whole feature is that the *same* `key` (e.g. `COMPLETE`, or a
"customise"-copied step's key) must be able to exist once per major program, exactly like it
already can once per `programCategory`/`programId` today. Whatever unique constraint currently
backs `key` uniqueness needs `majorProgramId` added to it alongside the existing columns — adding
the column alone, without extending that constraint, leaves every major-program-scoped create of an
already-used key rejected as a duplicate against the institution-default row, which defeats the
entire feature (this is exactly the 422 the frontend hits today, since the column doesn't exist at
all yet).

**One more sequencing rule, alongside §2.3's list:** `MAJOR_PROGRAM_CHOICE` itself must always have
`majorProgramId: null` (institution default) and must be the very first PROCESS stage in every
resolved sequence — `422 INVALID_STAGE_SEQUENCE` with a new reason `MAJOR_PROGRAM_CHOICE_NOT_FIRST`
if a create/update would place anything before it, and (new) `MAJOR_PROGRAM_CHOICE_SCOPED` if one
is ever created with a non-null `majorProgramId`/`programId`/`programCategory` — it's the stage that
decides which major program's steps apply, so scoping it to one specific major program is a
contradiction: it could never be reached from any other major program's sequence.

### 2.6 `?majorProgramId=` resolution rule change — full decoupling (new 2026-09-15, supersedes the fallback described in 2.5/§2's table)

Full rationale and the `order`-coupling bug it fixes: `SCHEMA_CHANGES.md` §2c. The contract change
itself, precisely:

```jsonc
// BEFORE (§2.5's original behavior) — falls back through category to the institution default
// GET /admissions/config/steps/effective?group=PROCESS&majorProgramId=3
// Major program 3 has no row for key "PERSONAL_INFORMATION" of its own
// → resolves to the institution-default row for that key (whatever `order` it has there)

// AFTER (this section) — no fallback once majorProgramId is on the request
// GET /admissions/config/steps/effective?group=PROCESS&majorProgramId=3
// Major program 3 has no row for key "PERSONAL_INFORMATION" of its own
// → that key is simply absent from the response. Nothing substitutes for it.
```

Resolution when `majorProgramId` is present: a `programId`-scoped row (for a program under this
major program) wins if present; else a `majorProgramId`-scoped row matching this major program
wins; else the key doesn't appear. `programCategory` and the institution default are **not**
consulted at all in this path — this is the one deliberate exception to "most specific wins,
broader is the fallback" everywhere else in this codebase, because the whole point here is that
there is no broader scope for a major program to fall back to.

**When `majorProgramId` is omitted from the request** (no major program chosen yet, or a
deployment that never has more than one — see `major-program-scoping/README.md` §0's governing
rule): resolves exactly as it always has — `programId` > `programCategory` > institution default.
Fully unchanged. This is what a deployment with 0–1 major programs keeps using forever, since the
frontend only ever sends `majorProgramId` once there's more than one to choose from.

**`GET /admissions/config/steps`** (the raw admin list, unresolved) needs no change — it already
returns every row regardless of scope; the admin UI does its own filtering per tab.

**Nothing about `POST`/`PATCH /admissions/config/steps` changes either** — "adding a catalog step
to a major program" is mechanically today's create-with-`majorProgramId` (already shipped, A22),
just reframed: a catalog (institution-default) row is a template to copy from, never something an
applicant is served directly once resolution stops falling back to it.

**Migration — decided.** Neither of the two automatic options originally proposed here (a full
backend backfill, or a single "adopt everything" bulk button) was wanted — explicit instruction:
"We don't want an automatic all-or-nothing backend migration or a single bulk-adopt button. What
we want is granular control per major program." Built instead: a per-major-program, multi-select
**"Add from Catalog"** action — the admin opens each major program's tab and explicitly checks off
exactly which catalog steps apply to it, nothing adopted automatically. See
`BACKEND_DEVIATIONS_2026-09-14.md` A23's "Frontend: built" note for the implementation. This is a
deliberate, admin-driven rollout, not a cutover-safe migration — **every existing major program has
zero steps until someone runs this for it.** Ship the resolution rule change whenever it's ready;
there's no backend-side migration to sequence around, only the known admin-facing task of
populating each major program by hand.

---

## 3. Form fields — admin and applicant

### 3.1 `POST /admissions/config/steps/{stepId}/fields` / `PATCH …/fields/{fieldId}` — new fields

```jsonc
{
  "key": "sponsor_phone_number",
  "label": "Sponsor's phone number",
  "type": "PHONE",
  "order": 5,
  "isRequired": true,
  "helpText": null,
  "placeholder": "+234…",
  "width": "HALF",
  "defaultValue": null,
  "options": null,
  "optionsSource": null,
  "dependsOn": null,
  "validation": { "minLength": 10 },
  "repeatable": false,
  "systemKey": "sponsorPhoneNumber",              // create only; immutable
  "visibleWhen": { "field": "has_sponsor", "op": "isTrue" },
  "parentFieldId": null
}
```

Errors (422 unless noted): `SYSTEM_FIELD_LOCKED` (delete / type change / unsetting `isRequired`
on a `lockedRequired` field — **409**), `DUPLICATE_SYSTEM_FIELD`, `MISSING_SYSTEM_FIELD`,
`INVALID_FIELD_REFERENCE` (visibleWhen/dependsOn → unknown or later field), `INVALID_CONDITION`,
`NESTING_TOO_DEEP` (child of a child), `OPTIONS_REQUIRED` (SELECT/MULTISELECT/RADIO without
`options` or `optionsSource`).

`DELETE` on a field with submitted answers → soft delete (`isActive=false`), 204.

### 3.2 `GET /admissions/config/steps/{stepId}/fields`

Rows include every property above plus `children: AdmissionFormField[]` for `REPEATING_GROUP`.

### 3.3 `GET /admissions/config/steps/effective?group=FORM&programId=&majorProgramId=`

Each step's `fields` are the full field objects (with `children`), active only, ordered.
`majorProgramId` param added 2026-09-15 alongside PROCESS's — see §2.5's resolution table, which
applies identically here: a FORM step (and therefore its whole field set) can be scoped to one
major program the same way a PROCESS stage can, so an applicant's application form differs by
major program without needing any change to how fields themselves work.

### 3.4 `POST /admissions/applications` — answers payload (multipart)

```
sessionId            = 3
answers[PERSONAL_INFO][nationality]     = Nigeria
answers[PERSONAL_INFO][state_of_origin] = Lagos
answers[PERSONAL_INFO][has_disability]  = 0
answers[SPONSOR_INFO][has_sponsor]      = 1
answers[SPONSOR_INFO][sponsor_name]     = Ada Obi
answers[DOCUMENTS][passport]            = <file>
answers[DOCUMENTS][other_documents][0]  = <file>
answers[EXTRA_QUESTIONS][prior_qualifications][0][institution] = UNILAG     // REPEATING_GROUP
agreeToTerms         = 1
```

Server behaviour:
1. Resolve the effective FORM steps for the applicant's program (from the `PROGRAM_CHOICE` stage,
   or `answers[PROGRAM_SELECTION][program_id]`).
2. Evaluate `visibleWhen`; drop answers for hidden fields.
3. Validate every visible field (`isRequired`, `validation`, option membership, file rules).
4. Bound fields (`systemKey`) → their `Application` columns; others → `answers` JSON; files →
   application documents tagged with `stepKey`/`fieldKey`.
5. Store `formSnapshot` (§3.6).

**422 shape** — keyed by `stepKey.fieldKey` so the frontend can put the error on the right field:

```jsonc
{ "message": "The given data was invalid.",
  "errors": { "SPONSOR_INFO.sponsor_email": ["Enter a valid email address."] } }
```

**Transition:** the old flat multipart keys remain accepted until the frontend switches (README §5).

### 3.5 `PATCH /admissions/applications/{id}`

Same `answers` shape (JSON body, no files — files keep using the Application Documents routes).
Only the sent steps are re-validated; the rest are kept.

### 3.6 `GET /admissions/applications/{id}` — adds the answer sheet

```jsonc
{ "data": {
  …existing personal_info / program_choice / documents / admission…,
  "form": {
    "version": 1,
    "steps": [
      { "key": "SPONSOR_INFO", "label": "Sponsor Information",
        "fields": [
          { "key": "has_sponsor", "label": "Do you have a sponsor?", "type": "BOOLEAN",
            "systemKey": "hasSponsor", "value": true, "displayValue": "Yes", "visible": true },
          { "key": "sponsor_name", "label": "Sponsor's name", "type": "TEXT",
            "systemKey": "sponsorName", "value": "Ada Obi", "displayValue": "Ada Obi", "visible": true }
        ] },
      { "key": "DOCUMENTS", "label": "Documents",
        "fields": [
          { "key": "passport", "label": "Passport photograph", "type": "FILE", "systemKey": "passport",
            "value": { "documentId": 812, "fileName": "passport.jpg", "url": "https://…" },
            "displayValue": "passport.jpg", "visible": true }
        ] }
    ]
  }
} }
```

Built from `formSnapshot`, so it always matches what the applicant was asked. `displayValue` is the
option label / formatted date / "Yes"–"No" — the admin review renders it verbatim.

---

## 4. Applicant stage progress

### 4.1 `GET /admission/me/stages`

```jsonc
{ "data": {
  "sessionId": 3,
  "programId": 55,
  "currentStageKey": "ACCEPTANCE_FEE",
  "stages": [
    { "id": 1, "key": "CHOICE_PROGRAM", "type": "PROGRAM_CHOICE", "label": "Choice Program",
      "description": "…", "icon": "Settings", "order": 1,
      "status": "COMPLETED", "completedAt": "2026-09-01T10:00:00Z",
      "config": { "collectEntryMode": true, "collectStudyMode": true, "collectStartTerm": true },
      "state": { "programId": 55, "programName": "B.Sc. Economics", "entryMode": "UTME",
                 "studyMode": "online", "startTerm": "2026/2027 First Semester" } },
    { "id": 5, "key": "ACCEPTANCE_FEE", "type": "PAYMENT", "label": "Acceptance Fee",
      "status": "IN_PROGRESS", "completedAt": null,
      "config": { "feeCategory": "ACCEPTANCE", "allowInstallments": false },
      "state": { "feeTypeId": 7, "feeName": "Acceptance Fee", "currency": "NGN", "amount": 50000,
                 "amountPaid": 0, "balance": 50000, "invoiceId": 991, "minimumPayable": 50000 } },
    { "id": 9, "key": "MEDICAL_GUIDANCE", "type": "CONTENT", "status": "NOT_STARTED",
      "config": { "title": "…", "body": "…", "requireAcknowledgement": true,
                  "acknowledgementLabel": "I have read and understood this" },
      "state": { "acknowledgedAt": null } },
    { "id": 3, "key": "ADMISSION_STATUS", "type": "DECISION", "status": "COMPLETED",
      "config": { "showOfferExpiry": true },
      "state": { "applicationStatus": "approved", "offerStatus": "accepted",
                 "offerExpiryDate": "2026-10-01", "admissionId": 41 } },
    { "id": 10, "key": "EXTRA_DOCS", "type": "DOCUMENT_UPLOAD", "status": "NOT_STARTED",
      "config": { "documents": [ { "key": "medical_report", "label": "Medical report",
                                   "accept": "DOCUMENT", "required": true } ] },
      "state": { "documents": [ { "key": "medical_report", "documentId": null, "fileName": null } ] } },
    { "id": 7, "key": "COMPLETED", "type": "COMPLETE", "status": "NOT_STARTED",
      "config": { "message": "Your admission is complete.", "ctaLabel": "Go to my courses",
                  "ctaHref": "/student/courses" },
      "state": {} }
  ]
} }
```

- `stages` = the resolved, active PROCESS rows for the applicant's program (default set before a
  program is chosen), in order.
- `status`: `COMPLETED` | `IN_PROGRESS` | `NOT_STARTED` | `BLOCKED`. `BLOCKED` carries
  `blockedReason` (`APPLICATION_REJECTED`, `OFFER_DECLINED`, `OFFER_EXPIRED`) and ends the journey.
- `currentStageKey` = first stage not `COMPLETED` (or the `COMPLETE` stage when all are done).
- `state` is type-specific and read-only — everything the stage screen needs, so the frontend never
  looks fees up by slug again.

### 4.2 Actions

| Route | Type | Body | Effect / response |
|---|---|---|---|
| `POST /admission/me/stages/{key}/acknowledge` | CONTENT | — | sets `acknowledgedAt`, status `COMPLETED`; returns the stage |
| `POST /admission/me/stages/{key}/documents` | DOCUMENT_UPLOAD | multipart `documents[{docKey}] = <file>` | stores/replaces; `COMPLETED` when all required present; returns the stage |
| `DELETE /admission/me/stages/{key}/documents/{docKey}` | DOCUMENT_UPLOAD | — | removes; returns the stage |
| `POST /admission/me/stages/{key}/payments/initiate` | PAYMENT | `{ "amount"?: number }` (installments only; ≥ `minimumPayable`) | `{ "authorizationUrl": "…", "reference": "…" }` |
| `POST /admission/major-program-choice` | MAJOR_PROGRAM_CHOICE | `{ "majorProgramId": number }` | sets the applicant's major program; status `COMPLETED`; returns the stage — see §4.3, new |
| `POST /admission/program-choice` | PROGRAM_CHOICE | existing contract | unchanged |
| `POST /admissions/{id}/accept` / `…/decline` | DECISION | existing contracts | unchanged |

Errors: 409 `STAGE_NOT_CURRENT` (acting on a stage before the current one is done), 422
`WRONG_STAGE_TYPE`, 404 `STAGE_NOT_FOUND`, 422 `AMOUNT_BELOW_MINIMUM`.

The existing `/fees/payments/{application|acceptance|tuition}/initiate` routes stay as aliases
during the transition.

### 4.3 `POST /admission/major-program-choice` (new, 2026-09-14) and `GET /admission/student`

Mirrors `POST /admission/program-choice`'s existing contract, one tier up. Backs the new
`MAJOR_PROGRAM_CHOICE` stage — flagged as **A16** in `BACKEND_DEVIATIONS_2026-09-14.md`; not built
yet, so the frontend falls back to a per-user local value in the meantime (never persisted
server-side until this ships).

```jsonc
// POST /admission/major-program-choice
{ "majorProgramId": 3 }

// 200 — no response body needed beyond the usual envelope; GET /admission/student
// (below) is what the frontend re-reads afterward.
```

422 `INVALID_MAJOR_PROGRAM` if the id doesn't exist or `isActive: false`. Once a `PROGRAM_CHOICE`
has already been made, changing the major program should either be blocked (409
`PROGRAM_ALREADY_CHOSEN`) or clear the existing program choice — pick whichever the admissions
office wants and document it; the frontend doesn't currently attempt to let an applicant change
their major program after picking a program.

`GET /admission/student` gains two fields, same nullable/optional shape as the existing
`program_id`/`program_name` pair:

```diff
 {
   …existing fields…,
+  "major_program_id": 3,
+  "major_program_name": "Part-Time Programmes"
 }
```

---

## 5. Frontend call sites (for the frontend plan)

- Admin config: `admissionStepsApi` (type/config), `admission-form-fields.service` (new field
  props), new catalog queries (§1).
- Applicant form: effective FORM steps (§3.3) → generic renderer; submit via §3.4.
- Applicant process: `GET /admission/me/stages` (§4.1) → renderer per `type`; actions §4.2.
- Admin application review: `form` answer sheet (§3.6).
