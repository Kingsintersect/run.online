# Demographics Module — Country / State / Local Government Registry

> **Audience:** Backend developer (qhub_backend_api, Laravel).
> **Status (2026-08-27):** New module. No backend contract exists yet — this is a from-scratch
> proposal, ready to implement. The frontend module (`src/modules/demographics/`) is built and
> wired against the contract below; every request 404s until the backend ships it.

---

## 1. Background

Every place in this portal that currently asks an applicant or admin to type a country, state, or
local government area (LGA) does so as a free-text input — most visibly the admission application
form's Personal Information step (`nationality`, `state_of_origin`, `lga`), but also student/staff
profile records (`nationality`, `state_of_origin`, `lga_of_origin` in `src/types/users.d.ts`). Free
text here is a real data-quality problem for a Nigerian university: "Lagos"/"lagos"/"Lagos State",
"Ikeja"/"Ikeja LGA"/"IKEJA" all mean the same thing but can't be grouped, filtered, or reported on
reliably. This module gives the institution a single, admin-managed source of truth for these three
levels, and the frontend now sources every country/state/LGA input from it as a cascading select
instead of a text field.

This is genuinely reference/configuration data — a `SUPER_ADMIN`/`ADMIN` concern, not something any
other role edits. Every authenticated user still needs **read** access, though, since any applicant
or staff member filling out a form with these selects needs to list the options.

---

## 2. Proposed Schema

Three new models, a straight three-level hierarchy:

```prisma
model Country {
  id        Int      @id @default(autoincrement())
  name      String   @unique @db.VarChar(100)
  code      String?  @unique @db.VarChar(2) // ISO 3166-1 alpha-2, e.g. "NG"
  isActive  Boolean  @default(true) @map("is_active")
  createdAt DateTime @default(now()) @map("created_at")
  updatedAt DateTime @updatedAt @map("updated_at")

  states State[]

  @@index([isActive])
  @@map("countries")
}

model State {
  id        Int      @id @default(autoincrement())
  countryId Int      @map("country_id")
  name      String   @db.VarChar(100)
  code      String?  @db.VarChar(10)
  isActive  Boolean  @default(true) @map("is_active")
  createdAt DateTime @default(now()) @map("created_at")
  updatedAt DateTime @updatedAt @map("updated_at")

  country          Country           @relation(fields: [countryId], references: [id])
  localGovernments LocalGovernment[]

  @@unique([countryId, name])
  @@index([countryId])
  @@index([isActive])
  @@map("states")
}

model LocalGovernment {
  id        Int      @id @default(autoincrement())
  stateId   Int      @map("state_id")
  name      String   @db.VarChar(100)
  isActive  Boolean  @default(true) @map("is_active")
  createdAt DateTime @default(now()) @map("created_at")
  updatedAt DateTime @updatedAt @map("updated_at")

  state State @relation(fields: [stateId], references: [id])

  @@unique([stateId, name])
  @@index([stateId])
  @@index([isActive])
  @@map("local_governments")
}
```

Also add the inverse relations already implied above (`Country.states`, `State.localGovernments`).
`isActive` lets an admin retire a stale/incorrectly-entered entry without breaking historical
records that already reference it by id (soft-disable, not delete — see §4's delete rule).

**Seeding:** this is a natural candidate for a one-time seed migration — all 36 Nigerian states +
FCT with their LGAs is public, stable data. Out of scope for the frontend to specify exactly, but
strongly recommended so the institution isn't starting from zero.

---

## 3. Endpoints

All three levels follow the identical CRUD shape. `GET` is open to any authenticated user (forms
need to read these); every mutating verb is `SUPER_ADMIN`/`ADMIN` only, gated behind the
`{resource: "demographics", action: "manage"}` permission (see §5).

| Method   | Endpoint                                   | Description                                              | Auth                    |
| -------- | ------------------------------------------- | --------------------------------------------------------- | ----------------------- |
| `GET`    | `/demographics/countries`                  | List countries. Query: `search`, `isActive`                | Authenticated            |
| `GET`    | `/demographics/countries/:id`               | Get one country                                            | Authenticated            |
| `POST`   | `/demographics/countries`                  | Create — `{ name, code?, isActive? }`                       | Admin/Super Admin        |
| `PATCH`  | `/demographics/countries/:id`               | Update any field                                            | Admin/Super Admin        |
| `DELETE` | `/demographics/countries/:id`               | Delete — `400` if the country has any `State` rows          | Admin/Super Admin        |
| `GET`    | `/demographics/states`                     | List states. Query: `countryId` (required for cascading selects), `search`, `isActive` | Authenticated |
| `GET`    | `/demographics/states/:id`                  | Get one state                                               | Authenticated            |
| `POST`   | `/demographics/states`                     | Create — `{ countryId, name, code?, isActive? }`             | Admin/Super Admin        |
| `PATCH`  | `/demographics/states/:id`                  | Update any field except `countryId`                         | Admin/Super Admin        |
| `DELETE` | `/demographics/states/:id`                  | Delete — `400` if the state has any `LocalGovernment` rows   | Admin/Super Admin        |
| `GET`    | `/demographics/local-governments`           | List LGAs. Query: `stateId` (required for cascading selects), `search`, `isActive` | Authenticated |
| `GET`    | `/demographics/local-governments/:id`       | Get one LGA                                                 | Authenticated            |
| `POST`   | `/demographics/local-governments`           | Create — `{ stateId, name, isActive? }`                      | Admin/Super Admin        |
| `PATCH`  | `/demographics/local-governments/:id`       | Update any field except `stateId`                            | Admin/Super Admin        |
| `DELETE` | `/demographics/local-governments/:id`       | Delete permanently — no children to guard against            | Admin/Super Admin        |

**Response envelope:** wrapped in `{ data: ... }` like every other endpoint in this backend, list
endpoints as `{ data: T[] }`, single-record endpoints as `{ data: T }`.

**Validation notes:**
- `POST /demographics/states` and `POST /demographics/local-governments` must validate the parent
  id actually exists (`countryId`/`stateId`) — return `422` with a clear message if not, the same
  pattern as `POST /admissions/config/steps` validating `order` is present.
- Uniqueness is scoped to the parent (`@@unique([countryId, name])` / `@@unique([stateId, name])`),
  not globally — "Lagos" the state and a hypothetical "Lagos" LGA in a different state are not the
  same row and shouldn't collide.
- Deleting a `Country`/`State` with children should `400` with a message like "Cannot delete — N
  states/LGAs still reference this record", matching the admission Step Registry's existing
  last-row-guard pattern (`admission_features_workflow.md`) rather than silently cascading.

---

## 4. Response Shapes

```ts
interface Country {
  id: number
  name: string
  code: string | null
  isActive: boolean
  createdAt: string
  updatedAt: string
}

interface State {
  id: number
  countryId: number
  name: string
  code: string | null
  isActive: boolean
  createdAt: string
  updatedAt: string
}

interface LocalGovernment {
  id: number
  stateId: number
  name: string
  isActive: boolean
  createdAt: string
  updatedAt: string
}
```

---

## 5. Roles & Permissions

This backend already has a fully dynamic, DB-backed RBAC system (`Permission {id, resource,
action, module, description}`, managed at `/admin/configurations/roles`) — there is no static
permission list to edit in code. Two new permission rows are all this module needs:

| Resource       | Action   | Module          | Description                                                        |
| -------------- | -------- | ---------------- | -------------------------------------------------------------------- |
| `demographics` | `view`   | `demographics`   | View the Country/State/LGA management screen                        |
| `demographics` | `manage` | `demographics`   | Create, edit, delete, and toggle countries/states/local governments |

`SUPER_ADMIN` bypasses permission checks entirely on the frontend (`usePermissions()`'s
`isSuperAdmin` short-circuit) and should have equivalent unconditional access enforced
server-side too, consistent with every other module. `ADMIN` needs both permission rows explicitly
assigned to its role via the existing Roles & Permissions admin screen — no code change required
for that assignment, it's data.

Reading the lists (`GET`) is intentionally **not** gated behind either permission — any
authenticated user (a student filling the admission form, a staff member editing their profile)
needs to read these options regardless of role.

---

## 6. Consumers (frontend, already built and wired)

- **`src/modules/demographics/`** — the full CRUD module: types, zod schemas, service layer
  (`demographics.service.ts`), React Query hooks, a small UI-only Zustand store (selected
  country/state for cascading filters), and the management screens.
- **`src/app/(dashboard)/admin/(routes)/configurations/demographics/page.tsx`** and
  **`src/app/(dashboard)/manager/(routes)/configurations/demographics/page.tsx`** — the
  `SUPER_ADMIN`/`ADMIN` management screens (thin route shells importing the module).
- **`src/app/(admission)/(routes)/admission-application-form/components/steps/PersonalInfoStep.tsx`**
  — `nationality`/`state_of_origin`/`lga` are now cascading `Country → State → Local Government`
  selects instead of free-text inputs, reusing `useCountries()`/`useStates(countryId)`/
  `useLocalGovernments(stateId)` from this module. The underlying form field names/schema are
  unchanged — only the input control changed, so `application-submit.service.ts`'s payload shape
  needs no changes.

Until the endpoints above ship, every select in the audited locations shows its existing
loading/error/empty states (the same pattern already used for the admission form's Program
Selection step) rather than fabricated data.
