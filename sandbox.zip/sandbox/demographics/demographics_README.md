# Demographics Module — API Reference

> Quick reference companion to `demographics_workflow.md` (full rationale, schema, and validation
> notes live there). This is the condensed endpoint/DTO reference for implementation.

## Endpoints

### Countries

| Method   | Endpoint                     | Auth              |
| -------- | ----------------------------- | ------------------ |
| `GET`    | `/demographics/countries`     | Authenticated       |
| `GET`    | `/demographics/countries/:id` | Authenticated       |
| `POST`   | `/demographics/countries`     | Admin/Super Admin   |
| `PATCH`  | `/demographics/countries/:id` | Admin/Super Admin   |
| `DELETE` | `/demographics/countries/:id` | Admin/Super Admin   |

**Query params (`GET /demographics/countries`):** `search?: string`, `isActive?: boolean`

**`CreateCountryDto`:**
```ts
{
  name: string       // required, unique
  code?: string       // ISO 3166-1 alpha-2, e.g. "NG"
  isActive?: boolean  // defaults true
}
```
`UpdateCountryDto` = `Partial<CreateCountryDto>`.

### States

| Method   | Endpoint                    | Auth              |
| -------- | ----------------------------- | ------------------ |
| `GET`    | `/demographics/states`        | Authenticated       |
| `GET`    | `/demographics/states/:id`    | Authenticated       |
| `POST`   | `/demographics/states`        | Admin/Super Admin   |
| `PATCH`  | `/demographics/states/:id`    | Admin/Super Admin   |
| `DELETE` | `/demographics/states/:id`    | Admin/Super Admin   |

**Query params (`GET /demographics/states`):** `countryId?: number`, `search?: string`, `isActive?: boolean`

**`CreateStateDto`:**
```ts
{
  countryId: number  // required, must reference an existing Country
  name: string        // required, unique within countryId
  code?: string
  isActive?: boolean
}
```
`UpdateStateDto` = `Partial<Omit<CreateStateDto, "countryId">>` — `countryId` is not editable
after creation (create a new row instead of reparenting).

### Local Governments

| Method   | Endpoint                                | Auth              |
| -------- | ------------------------------------------ | ------------------ |
| `GET`    | `/demographics/local-governments`          | Authenticated       |
| `GET`    | `/demographics/local-governments/:id`      | Authenticated       |
| `POST`   | `/demographics/local-governments`          | Admin/Super Admin   |
| `PATCH`  | `/demographics/local-governments/:id`      | Admin/Super Admin   |
| `DELETE` | `/demographics/local-governments/:id`      | Admin/Super Admin   |

**Query params (`GET /demographics/local-governments`):** `stateId?: number`, `search?: string`, `isActive?: boolean`

**`CreateLocalGovernmentDto`:**
```ts
{
  stateId: number   // required, must reference an existing State
  name: string       // required, unique within stateId
  isActive?: boolean
}
```
`UpdateLocalGovernmentDto` = `Partial<Omit<CreateLocalGovernmentDto, "stateId">>`.

## Response Shapes

```ts
interface Country {
  id: number
  name: string
  code: string | null
  isActive: boolean
  createdAt: string
  updatedAt: string
}

interface State {
  id: number
  countryId: number
  name: string
  code: string | null
  isActive: boolean
  createdAt: string
  updatedAt: string
}

interface LocalGovernment {
  id: number
  stateId: number
  name: string
  isActive: boolean
  createdAt: string
  updatedAt: string
}
```

All responses wrapped in `{ data: ... }` — lists as `{ data: T[] }`, single records as `{ data: T }`.

## Permissions

Two new rows in the existing dynamic Permission registry (`/admin/configurations/roles`) —
no code-level permission list to update:

- `{ resource: "demographics", action: "view", module: "demographics" }`
- `{ resource: "demographics", action: "manage", module: "demographics" }`

`GET` endpoints are open to any authenticated user regardless of these permissions — only the
mutating endpoints and the admin management screen are gated.

## Error Cases

- `POST /demographics/states` with a non-existent `countryId` → `422`
- `POST /demographics/local-governments` with a non-existent `stateId` → `422`
- `DELETE /demographics/countries/:id` when states reference it → `400`
- `DELETE /demographics/states/:id` when LGAs reference it → `400`
- Duplicate `name` within the same parent scope → `422` (unique constraint violation)
