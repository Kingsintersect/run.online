# Still Missing After Handoff — Verified Against `bruno/`, 2026-09

**Status:** verification audit, 2026-09-12. The backend team reported the docs listed in
`BACKEND_HANDOFF.md` (and the other shipped sandbox docs) as done. This doc is the result of
cross-checking every concrete ask in those docs against the actual `bruno/` collection (the
source-of-truth contract for what the live backend exposes) — file by file, not by trusting the
docs' own status headers. `sandbox/major-program-scoping/` is excluded (not shipped yet).

**Method:** every item below was checked by opening the real `.bru` file and reading its method,
url, body, and docs blocks — not inferred from filenames or folder structure.

---

## 0. Blocking contradiction — resolve this first

`multi-program-platform/README.md` §3 claims `Program.programCategory`, `.gradingSchemeId`, and
`.parentAcademicUnitId` "already exist" on the live schema. **They do not** —
`bruno/academic/Programs - Create.bru` and `Programs - Update.bru` show none of these fields in
their request bodies. This isn't just one missing field: `program-structure-depth/` and the
pending `major-program-scoping/` both assume `programCategory` is live and build their entire
category-conditional validation on top of it. Confirm with backend directly whether this was
silently dropped, exists but is undocumented in bruno, or was never built — this blocks trusting
any "done" claim that depends on it.

## 1. `multi-program-platform/` — effectively 0% delivered

- `GET /admissions/config/steps/effective` — missing
- `programCategory`/`programId` scope fields on `POST/PATCH /admissions/config/steps` — missing (old unscoped `(group,key)` uniqueness still documented)
- `GET/POST/PATCH/DELETE /admissions/config/steps/:stepId/fields` (AdmissionFormField) — all 4 missing
- `custom_fields` on `POST/PATCH /admissions/applications` — missing
- `GET/POST /moodle-sync/cohorts`, `POST /moodle-sync/cohorts/:id/sync-members` — missing (no "cohort" concept anywhere in bruno except an unrelated example string)

## 2. Auth / Roles / Permissions

- `GET /auth/roles/:roleId/users` — missing
- `POST /auth/roles/:id/duplicate` — missing
- `GET /auth/permissions/:id`, `DELETE /auth/permissions/:id` — missing (bruno explicitly documents "list + create only, no show/update/delete" — Update was added as a deviation, Get/Delete were not)
- `GET /users` — `roles` ships as flat name strings, not `{id, name, slug}[]` as requested; confirmed **no `slug` column exists at all** in this API — a shape decision, not an oversight, but still contradicts what was asked for

## 3. Director module — entirely absent

- No `bruno/director/` folder exists at all.
- `GET /enrollments/trend`, `GET /fees/reports/collections-trend`, `GET /results/reports/director-grade-summary` — none exist.
- `GET /users/stats` extension (`byFaculty`/`studentsByLevel`/`studentsByGender`/`tutorsByDesignation`) — not shipped; base shape is also different from what was asked (`byRole` instead of `totalStudents`/`totalTutors`/`totalStaff`).

## 4. Fees

- `GET /fees/types/eligible-count` — missing.
- `GET /fees/reports/summary` — still no documented response body or faculty/department filters.
- `GET /fees/invoices` (admin) — still no nested `feeType`/`session`/`student` objects or faculty/department/level filters.
- `Grade.hasOutstandingFees` — never added to `Grade - List/Get/By Student` responses (the fee-gated *publish* logic shipped — `withheld` count on `POST /results/grades/publish/:semesterId` is confirmed live — but the per-grade flag itself did not).

## 5. Course offerings — the enrichment doc shipped nothing

- `GET /courses/offerings` / `:id` — still the bare original shape: no `enrolledCount`, no nested `course.creditUnits`/`courseType`/`level`/`owningDepartment`/`programs`/`categoryPath`.
- `?lecturerId=` filter with `role`/`assignedAt` — not documented.

## 6. Moodle-sync assessments bridge

- `GET /moodle-sync/assessments/:id`, `.../my`, `PATCH .../:id/visibility`, `DELETE .../:id` — all missing.
- `GET /moodle-sync/assessments/ca-preview/:offeringId` — missing.
- `GET /moodle-sync/assessments/sync-status` — exists, but wrong shape (flat counts, no per-course array as asked).
- `GET /moodle-sync/assessments` — missing `isVisible`/`upcoming`/`page`/`limit` filters.
- `GET /assessments/ca-preview/:offeringId` (the non-moodle-sync path) — also missing.

## 7. Everything else still open

- `POST /users/staff` — still doesn't accept `roleId`.
- Exam Timetable — zero backing anywhere (no model, no endpoint, confirmed nothing was ever built).
- Six `/results` analytics endpoints (`Dashboard`, `Grade Distribution`, `Program Performance`, `CGPA Trends`, `Top Performers`, `Grouped Grades`) — still no literal example response body, only prose docs. Low severity — functionally present, just undocumented precisely.
- `program-structure-depth/` — confirmed nothing shipped (expected; this was only proposed 2026-09-12, not previously claimed done). Full list: `Cohort` CRUD, nullable `Course.level_id`/`Student.current_level_id`/`AdmissionOffer.levelId`/`.sessionId`, `Student.current_cohort_id`, `AdmissionOffer.cohortId`, `Program.entryLevelId`.

## 8. Not a bruno-checkable gap — flag separately, don't re-file as "missing endpoint"

- `fee-management/bursary_403_bug_report.md` — every route it names already exists as a real `.bru` contract; the bug is server-side hard-coded role allow-lists rejecting BURSARY/DEAN/DIRECTOR despite correct permissions. Needs a backend code review, not a new endpoint.
- `admission/student_admission_workflow.md` §5 — relaxed auth on `POST /fees/payments/verify/:reference` to permit the payment owner — not visible in a `.bru` auth annotation, needs a live check against actual authorization logic.

## 9. What's genuinely done (for balance — not everything failed)

Full credit where earned: `schema-moodel-sync-refactor/` (Academic Structure tree, Grading
Schemes, Category Sync rework) is essentially fully shipped and verified. Admission Cycle CRUD (9
endpoints), Admission Step Registry CRUD, Demographics (15 endpoints), the Pre-Application Program
Choice feature, tutor onboarding (bulk import, resend-invite, mustResetPassword, onboarding
progress), and the moodle-sync user/category/course/enrollment enrichment fixes are all confirmed
present and matching spec.
