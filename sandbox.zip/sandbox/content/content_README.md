# Content Module

Manages announcements and content publishing. Announcements cover news, events, academic calendar entries, and general communications.

## Models Owned

- **Announcement** — content items with category, priority, and publishing workflow

---

## Endpoints

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/content/announcements` | List published announcements (public) | Public / Authenticated |
| `GET` | `/content/announcements/all` | List all announcements including drafts | Super_Admin, Admin, Staff |
| `GET` | `/content/announcements/:id` | Get announcement details | Authenticated |
| `POST` | `/content/announcements` | Create an announcement | Super_Admin, Admin, Staff |
| `PATCH` | `/content/announcements/:id` | Update an announcement | Super_Admin, Admin, Staff (author) |
| `DELETE` | `/content/announcements/:id` | Delete an announcement | Super_Admin, Admin |
| `PATCH` | `/content/announcements/:id/publish` | Publish an announcement | Super_Admin, Admin, Staff (author) |
| `PATCH` | `/content/announcements/:id/unpublish` | Unpublish an announcement | Super_Admin, Admin |

---

## Request & Response Types

### `GET /content/announcements`

**Query Parameters:**

```ts
{
  category?: string;        // e.g. "news", "event", "academic", "general"
  priority?: string;        // "low", "normal", "high", "urgent"
  page?: number;
  limit?: number;
}
```

**Response: `200 OK`**

```ts
{
  data: {
    id: number;
    title: string;
    content: string;
    category: string;
    priority: string;
    publishedBy: number;
    publishedAt: string | null;
    expiresAt: string | null;
    createdAt: string;
  }[];
  meta: { total: number; page: number; limit: number };
}
```

---

### `POST /content/announcements`

**Request Body (`CreateAnnouncementDto`):**

```ts
{
  title: string;             // max 200 chars
  content: string;           // long text (HTML or markdown)
  category: string;          // max 30 chars: "news", "event", "academic", "general"
  priority?: string;         // default "normal": "low", "normal", "high", "urgent"
  expiresAt?: string;        // ISO 8601 date — auto-hide after this date
  isPublished?: boolean;     // default false (draft)
}
```

**Response: `201 Created`**

```ts
{
  id: number;
  title: string;
  content: string;
  category: string;
  priority: string;
  publishedBy: number;
  isPublished: boolean;
  publishedAt: string | null;
  expiresAt: string | null;
  createdAt: string;
}
```

---

### `PATCH /content/announcements/:id`

**Request Body (`UpdateAnnouncementDto`):**

```ts
{
  title?: string;
  content?: string;
  category?: string;
  priority?: string;
  expiresAt?: string | null;
}
```

**Response: `200 OK`** — returns the updated announcement.

---

### `PATCH /content/announcements/:id/publish`

**Response: `200 OK`**

```ts
{
  id: number;
  isPublished: true;
  publishedAt: string;
}
```

---

## Notes for Developers

- The public list endpoint should only return announcements where `isPublished = true` and `expiresAt` is null or in the future.
- `publishedBy` references the User ID of the creator. Set automatically from the JWT.
- `publishedAt` is set when `isPublished` transitions to `true`.
- Categories are free-text strings. Common values: `"news"`, `"event"`, `"academic"`, `"general"`.
- Use `"event"` category for academic calendar entries (e.g. "Registration Opens", "Exam Period").
- Content supports long text — consider HTML or Markdown based on frontend needs.
