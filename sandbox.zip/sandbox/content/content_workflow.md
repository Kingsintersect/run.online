# Content Module — Implementation Workflow

This document explains the internal implementation flow for the Content module. It is intended for developers building or maintaining this module.

---

## Module Dependencies

```
ContentModule
├── PrismaService          (database access)
├── AuditModule            (log content changes)
└── (no cross-module service imports)
```

> The Content module is self-contained. It manages announcements and content publishing with no dependencies on other business modules.

---

## Announcement Lifecycle

```
┌───────┐      ┌───────────┐
│ DRAFT │─────▶│ PUBLISHED │
└───────┘      └─────┬─────┘
     ▲               │
     │               ▼
     │         ┌─────────────┐
     └─────────│ UNPUBLISHED │
               └─────────────┘

Additionally:
Published + expiresAt < now → auto-hidden from public list
```

---

## 1. Create Announcement Flow

**Endpoint:** `POST /content/announcements`

```
Admin/Staff creates an announcement
         │
         ▼
┌──────────────────────────────────────────────────┐
│  ContentService.createAnnouncement(dto, userId)  │
│  1. Validate dto fields                          │
│  2. Create Announcement record:                  │
│     - title, content, category, priority         │
│     - publishedBy = userId (from JWT)            │
│     - isPublished = dto.isPublished ?? false     │
│     - If isPublished → publishedAt = now         │
│     - expiresAt (optional)                       │
│  3. Log via AuditService (action: "CREATE")      │
│  4. Return created announcement                  │
└──────────────────────────────────────────────────┘
```

---

## 2. Publishing Flow

**Endpoint:** `PATCH /content/announcements/:id/publish`

```
Admin publishes a draft announcement
         │
         ▼
┌──────────────────────────────────────────────────┐
│  ContentService.publish(id)                      │
│  1. Find announcement by ID                      │
│     - Not found → 404                            │
│  2. Update:                                      │
│     - isPublished = true                         │
│     - publishedAt = now                          │
│  3. Log via AuditService                         │
│  4. Return updated announcement                  │
└──────────────────────────────────────────────────┘
```

### Unpublish Flow

```
Admin unpublishes an announcement
         │
         ▼
┌──────────────────────────────────────────────────┐
│  ContentService.unpublish(id)                    │
│  1. Find announcement by ID                      │
│  2. Update:                                      │
│     - isPublished = false                        │
│  3. publishedAt remains (for audit trail)        │
│  4. Log via AuditService                         │
└──────────────────────────────────────────────────┘
```

---

## 3. Public Query Logic

**Endpoint:** `GET /content/announcements`

```
Anyone (public or authenticated) fetches announcements
         │
         ▼
┌──────────────────────────────────────────────────┐
│  ContentService.findPublished(filters)            │
│  Query:                                          │
│  WHERE isPublished = true                        │
│  AND (expiresAt IS NULL OR expiresAt > NOW())    │
│  AND (category = filter.category if provided)    │
│  AND (priority = filter.priority if provided)    │
│  ORDER BY priority DESC, publishedAt DESC        │
│  SKIP/TAKE for pagination                        │
└──────────────────────────────────────────────────┘
```

**Priority ordering:** `urgent > high > normal > low`

### Admin Query (all including drafts)

**Endpoint:** `GET /content/announcements/all`

```
Admin/Staff sees everything
         │
         ▼
┌──────────────────────────────────────────────────┐
│  ContentService.findAll(filters)                 │
│  No isPublished filter                           │
│  No expiresAt filter                             │
│  Returns drafts, published, expired              │
└──────────────────────────────────────────────────┘
```

---

## 4. Category Usage Guide

| Category | Purpose | Example |
| -------- | ------- | ------- |
| `news` | General university news | "New Library Hours" |
| `event` | Academic calendar events | "Registration Opens Sept 1" |
| `academic` | Academic notices | "Exam Timetable Released" |
| `general` | Miscellaneous | "Campus Maintenance Notice" |

Using `event` category for academic calendar entries avoids needing a separate AcademicCalendar model:

```ts
// "Registration Opens" event
{
  title: "Course Registration Opens",
  content: "Registration for First Semester 2025/2026 begins on...",
  category: "event",
  priority: "high",
  expiresAt: "2025-09-30T23:59:59Z"  // auto-hide after registration closes
}
```

---

## 5. Files to Create

```
src/modules/content/
├── content.module.ts
├── content.controller.ts         # All announcement routes
├── content.service.ts            # Business logic
├── dto/
│   ├── create-announcement.dto.ts
│   ├── update-announcement.dto.ts
│   └── query-announcement.dto.ts
└── content.service.spec.ts
```

---

## 6. Cross-Module Integration Points

| Direction | Module | Interaction |
| --------- | ------ | ----------- |
| **None** | — | Content module is self-contained |
| **Optional** | NotificationModule | Could send push notifications for urgent announcements |
