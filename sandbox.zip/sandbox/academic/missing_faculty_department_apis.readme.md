# Academic Module — Faculty / Department Leadership Gaps

> **Audience:** Backend developer (qhub_backend_api).
> **Status:** The frontend now has a real, schema-grounded Faculty → Department →
> Program/Lecturers drill-down (Faculties list → Faculty detail with its departments →
> Department detail with its programs and lecturers), replacing an old wizard UI that ran
> entirely on string-ID mock data. It uses the real `bruno/academic` endpoints
> (`/academic/faculties`, `/academic/departments`, `/academic/programs`, `/academic/levels`)
> as-is. This document covers two smaller gaps found while building it — neither blocks
> shipping, both are worth closing.

---

## 1. No way to pick a Department's HOD before the department has lecturers

`Department.hodUserId` references a `User`, and `Departments - Get By ID.bru` confirms the
department response includes its `lecturers` — so once a department exists and has
lecturers assigned, the frontend can offer a real dropdown (`Staff Name — Designation`,
value = `lecturer.userId`) for HOD. That's implemented.

The gap is **at creation time**: a brand-new department has no lecturers yet (they get
assigned afterward, presumably via the Lecturer/Staff module), so there's no way to show a
real picker in the "Create Department" form. The frontend currently just tells the admin
to assign an HOD after creating the department. This is a reasonable UX, not a bug — no
change requested here, just flagging it as the reason the create-form doesn't have an HOD
field while the edit-form does.

## 2. No way to pick a Faculty's Dean at all

`Faculty.deanUserId` also references a `User`, but unlike Department, a Faculty's detail
response only nests `departments` (per `Faculties - Get By ID.bru`: "Returns the faculty
plus its departments") — it does not nest anything analogous to "eligible deans." A Dean is
typically a senior lecturer/staff member, not necessarily scoped to one department, so
there's no existing endpoint the frontend can reuse the way it reuses a department's
`lecturers` list for HOD.

**Current frontend behavior:** the Faculty create/edit form asks for `deanUserId` as a
plain numeric input ("Dean — User ID (optional — see Users → Staff/Lecturers for the id)"),
and the Faculty detail view just displays `Dean: User #{id}` — no name resolution.

**Suggested fix (either would let the frontend show a real name and a real picker):**

- **Option A — cheapest:** have every `Faculty`/`Department` response that includes
  `deanUserId`/`hodUserId` also resolve and embed the basic user info those ids point to,
  e.g. `dean: { id, firstName, lastName, email } | null`. This alone fixes the *display*
  problem (no more raw `User #42`) even without a picker endpoint.
- **Option B — enables a real picker too:** add a lightweight listing endpoint, e.g.
  `GET /academic/faculties/:id/eligible-deans` (or a more general `GET /users?role=STAFF` /
  `role=TUTOR` type endpoint if one is planned elsewhere), returning candidates the frontend
  can render as a `<Select>` the same way Department's HOD picker works today.

Either is additive — no schema change needed since `deanUserId`/`hodUserId` already exist
on `Faculty`/`Department`.

---

## 3. Please confirm: do Update endpoints accept `deanUserId` / `hodUserId`?

`Faculties - Update.bru` and `Departments - Update.bru`'s example request bodies (as read)
don't show `deanUserId`/`hodUserId` in their sample payloads, only name/code/description/
contact fields. The frontend's edit forms send `deanUserId`/`hodUserId` on
`PATCH /academic/faculties/:id` and `PATCH /academic/departments/:id` on the assumption
that these are accepted since they're plain columns on the respective models — but this
hasn't been confirmed against a real response. If the update DTO currently excludes them,
please add them (optional, nullable) so the assignment UI in the frontend actually
persists.

---

## Notes

- No changes needed to `Level` — confirmed no update/delete endpoint by design (levels are
  referenced by students/courses/fee types), and the frontend's `LevelsPanel` correctly
  offers create-only with no edit/delete affordance.
- No changes needed to `Program` — its full CRUD (including deactivate) already matches
  what the frontend needs for the Department → Programs panel.
