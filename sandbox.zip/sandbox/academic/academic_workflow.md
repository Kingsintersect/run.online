# Academic Module — Implementation Workflow

This document explains the internal implementation flow for the Academic module. It is intended for developers building or maintaining this module.

---

## Module Dependencies

```
AcademicModule
├── PrismaService          (database access)
├── AuditModule            (log structural changes)
└── (no cross-module service imports)
```

> The Academic module is a **foundational/reference data module**. It does not depend on other business modules — other modules depend on it.

---

## Data Hierarchy

```
Faculty
  └── Department
        └── Program
              └── ProgramCourse (→ Course Module)

Level (standalone — 100, 200, 300, ...)

AcademicSession (e.g. "2025/2026")
  └── Semester (e.g. "First Semester")
```

> **Design note:** "current session/semester" is tracked via an `isActive`
> boolean on each row, not a separate pointer/singleton table. This keeps the
> pattern consistent with Faculty/Department/Program/Level, and the two risks
> that pattern normally carries — duplicate active rows, and stale reads on a
> hot path — are closed explicitly below (§1 DB constraint, §3 caching)
> rather than by introducing a second source of truth.

---

## 1. Setting Up a New Academic Year

This is the most common admin workflow. Here's the step-by-step process:

```
Step 1: Create Academic Session
─────────────────────────────────
POST /academic/sessions
{ name: "2025/2026", startDate: "2025-09-01", endDate: "2026-07-31" }
         │
         ▼
Step 2: Create Semesters for the Session
─────────────────────────────────────────
POST /academic/semesters
{ academicSessionId: 1, name: "First Semester",
  startDate: "2025-09-01", endDate: "2026-01-31",
  registrationStart: "2025-08-15", registrationEnd: "2025-09-30" }

POST /academic/semesters
{ academicSessionId: 1, name: "Second Semester",
  startDate: "2026-02-01", endDate: "2026-07-31",
  registrationStart: "2026-01-15", registrationEnd: "2026-02-28" }
         │
         ▼
Step 3: Activate the Session
─────────────────────────────
PATCH /academic/sessions/:id/activate
  → Deactivates ALL other sessions in a transaction
  → Sets isActive = true on selected session
  → Invalidates the active-session cache (see §3)
         │
         ▼
Step 4: Activate the First Semester
───────────────────────────────────
PATCH /academic/semesters/:id/activate
  → Deactivates ALL other semesters in a transaction
  → Sets isActive = true on selected semester
  → Invalidates the active-semester cache (see §3)
```

### Activation Logic (Critical)

```ts
// Only ONE session can be active at a time
async activateSession(id: number) {
  const result = await this.prisma.$transaction([
    this.prisma.academicSession.updateMany({
      data: { isActive: false },
    }),
    this.prisma.academicSession.update({
      where: { id },
      data: { isActive: true },
    }),
  ]);

  this.cache.del('academic:active-session');
  return result;
}
```

The same pattern applies to semesters (`activateSemester`, invalidating
`academic:active-semester`).

This is backed at the database level by a partial unique index (see API doc
§"Notes for Developers"), so even a write that bypasses this method entirely
cannot produce two active rows — it will fail the constraint instead of
silently corrupting state.

### ⚠️ Consistency Warning: Steps 3 and 4 are not atomic

Activating a session does **not** activate any of its semesters. Between Step
3 and Step 4, `getActiveSemester()` will still return a semester belonging to
the **previous** session — a state that is individually valid for each table
but logically inconsistent as a pair (Enrollment, Result, and Course all read
"active session" and "active semester" as if they describe one coherent
current period).

Two ways to close this gap — pick one before wiring dependent modules:

- **(a) Combine the calls.** Extend `PATCH /academic/sessions/:id/activate`
  to optionally accept a `semesterId` and activate both inside the same
  transaction, removing the manual two-step window entirely.
- **(b) Validate on read.** Have `getActiveSemester()` throw if the active
  semester's `academicSessionId` does not match the active session's `id`,
  so any inconsistent intermediate state fails loudly at the first consumer
  instead of silently serving mismatched data to Enrollment/Result/Course.

(b) is the cheaper fix and doesn't require an API shape change — recommended
if you're wiring this against a deadline; revisit (a) afterward if the
two-step admin flow proves error-prone in practice.

---

## 2. Setting Up Academic Structure (One-Time or Rarely)

```
Step 1: Create Faculties
─────────────────────────
POST /academic/faculties
{ name: "Faculty of Sciences", code: "SCI" }

Step 2: Create Departments under Faculty
─────────────────────────────────────────
POST /academic/departments
{ facultyId: 1, name: "Computer Science", code: "CSC" }

Step 3: Create Programs under Department
─────────────────────────────────────────
POST /academic/programs
{ departmentId: 1, name: "Computer Science", code: "CSC",
  degreeType: "B.Sc", durationYears: 4, minCreditUnits: 120 }

Step 4: Create Levels (if not already done)
────────────────────────────────────────────
POST /academic/levels
{ name: "100 Level", numericValue: 100 }
{ name: "200 Level", numericValue: 200 }
...
```

---

## 3. The "Active" Concept

Several modules depend on the currently active session and semester:

| Consumer | What it needs |
| -------- | ------------- |
| Enrollment | Active semester → registration window check |
| Course | Active semester → which offerings are current |
| Result | Active semester → current grading period |
| Hostel | Active session → current allocation period |
| Payment | Active session → current invoicing period |

**Implementation:** Expose `getActiveSession()` and `getActiveSemester()` as
public service methods that other modules can call.

```ts
async getActiveSession(): Promise<AcademicSession> {
  const cached = await this.cache.get<AcademicSession>('academic:active-session');
  if (cached) return cached;

  const session = await this.prisma.academicSession.findFirst({
    where: { isActive: true },
  });
  if (!session) throw new NotFoundException('No active academic session');

  await this.cache.set('academic:active-session', session, { ttl: 600 }); // 10 min
  return session;
}

async getActiveSemester(): Promise<Semester> {
  const cached = await this.cache.get<Semester>('academic:active-semester');
  if (cached) return cached;

  const semester = await this.prisma.semester.findFirst({
    where: { isActive: true },
  });
  if (!semester) throw new NotFoundException('No active semester');

  // Guards against the Step 3 / Step 4 inconsistency window described in §1(b)
  const activeSession = await this.getActiveSession();
  if (semester.academicSessionId !== activeSession.id) {
    throw new ConflictException(
      'Active semester does not belong to the active session — academic calendar is in an inconsistent state'
    );
  }

  await this.cache.set('academic:active-semester', semester, { ttl: 600 });
  return semester;
}
```

### Why caching matters here specifically

Per the table above, **every** authenticated request touching Enrollment,
Course, Result, Hostel, or Payment potentially calls one or both of these
methods. This data changes maybe twice a year, so without caching this is a
guaranteed DB round-trip on the hot path across five-plus modules, for
functionally static data. Cache with a short TTL (5–10 min is generous given
how rarely this changes) and **always invalidate explicitly on write** inside
`activateSession()`/`activateSemester()` — don't rely on TTL expiry alone to
reflect an activation, or admins will see the old active period for up to
the TTL window after switching it.

---

## 4. Relationship Rules

- **Faculty → Department**: `onDelete: Cascade` — deleting a faculty cascades to departments
- **Department → Program**: `onDelete: Cascade` — deleting a department cascades to programs
- **Dean / HOD**: `deanUserId` and `hodUserId` are User ID references but NOT Prisma relations. Validate manually that the user exists and has the appropriate role.
- **Level**: Standalone. `numericValue` is used for sorting (100 < 200 < 300). Level IDs are referenced by Student, Course, and CourseOffering.
- **AcademicSession → Semester**: `onDelete: Cascade` at the schema level, but in practice sessions/semesters are never deleted once referenced by offerings, enrollments, or results (see API doc — no `DELETE` endpoint exists for either). Treat the cascade as a safety net for pre-launch cleanup only, not a supported runtime operation.

---

## 5. Files to Create

```
src/modules/academic/
├── academic.module.ts
├── academic.controller.ts       # All academic routes
├── academic.service.ts          # Business logic
├── dto/
│   ├── create-faculty.dto.ts
│   ├── create-department.dto.ts
│   ├── create-program.dto.ts
│   ├── create-session.dto.ts
│   ├── create-semester.dto.ts
│   └── create-level.dto.ts
└── academic.service.spec.ts
```

---

## 6. Cross-Module Integration Points

| Consumer Module | What it uses from Academic |
| --------------- | -------------------------- |
| **Course** | `Program` (program-course mapping), `Level` (course level) |
| **Enrollment** | `Semester` (registration window), `AcademicSession` |
| **Result** | `Semester` (grading period) |
| **Hostel** | `AcademicSession` (allocation period) |
| **Payment** | `AcademicSession` (invoicing period) |
| **Admission** | `Program` (application program selection), `AcademicSession` |
| **User** | `Department` (lecturer/staff assignment) |
