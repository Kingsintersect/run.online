# Academic Module

Manages the university's academic structure: faculties, departments, programs, levels, academic sessions, and semesters. These are foundational entities used across courses, enrollment, admissions, and results.

## Models Owned

- **Faculty** — faculties/colleges
- **Department** — departments within faculties
- **Program** — degree programs within departments
- **Level** — academic levels (100, 200, 300, …)
- **AcademicSession** — academic sessions/years (e.g. 2025/2026)
- **Semester** — semesters within a session

---

## Endpoints

### Faculties

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/academic/faculties` | List all faculties | Authenticated |
| `GET` | `/academic/faculties/:id` | Get faculty by ID with departments | Authenticated |
| `POST` | `/academic/faculties` | Create a faculty | Admin |
| `PATCH` | `/academic/faculties/:id` | Update a faculty | Admin |
| `DELETE` | `/academic/faculties/:id` | Deactivate a faculty | Admin |

### Departments

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/academic/departments` | List all departments (filterable by faculty) | Authenticated |
| `GET` | `/academic/departments/:id` | Get department with programs & lecturers | Authenticated |
| `POST` | `/academic/departments` | Create a department | Admin |
| `PATCH` | `/academic/departments/:id` | Update a department | Admin |
| `DELETE` | `/academic/departments/:id` | Deactivate a department | Admin |

### Programs

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/academic/programs` | List all programs (filterable by department) | Authenticated |
| `GET` | `/academic/programs/:id` | Get program with courses & requirements | Authenticated |
| `POST` | `/academic/programs` | Create a program | Admin |
| `PATCH` | `/academic/programs/:id` | Update a program | Admin |
| `DELETE` | `/academic/programs/:id` | Deactivate a program | Admin |

### Levels

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/academic/levels` | List all levels | Authenticated |
| `POST` | `/academic/levels` | Create a level | Admin |

> No `GET /:id`, `PATCH`, or `DELETE` for Level — this is intentional. Levels
> (100, 200, 300, …) are treated as effectively immutable reference data once
> created and referenced by Student/Course/CourseOffering. If a correction is
> ever needed, do it via a direct migration, not a runtime endpoint.

### Academic Sessions

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/academic/sessions` | List all sessions | Authenticated |
| `GET` | `/academic/sessions/:id` | Get session with semesters | Authenticated |
| `GET` | `/academic/sessions/active` | Get the currently active session (cached — see Workflow doc §3) | Authenticated |
| `POST` | `/academic/sessions` | Create a new session | Admin |
| `PATCH` | `/academic/sessions/:id` | Update a session | Admin |
| `PATCH` | `/academic/sessions/:id/activate` | Set a session as active | Admin |

### Semesters

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/academic/semesters` | List semesters (filterable by session) | Authenticated |
| `GET` | `/academic/semesters/:id` | Get semester details | Authenticated |
| `GET` | `/academic/semesters/active` | Get the currently active semester (cached — see Workflow doc §3) | Authenticated |
| `POST` | `/academic/semesters` | Create a semester | Admin |
| `PATCH` | `/academic/semesters/:id` | Update a semester | Admin |
| `PATCH` | `/academic/semesters/:id/activate` | Set a semester as active | Admin |

> `AcademicSession`, `Semester`, and `Level` have no `DELETE` endpoint, by
> design. Once referenced by offerings, enrollments, grades, or admissions,
> historical data integrity requires they persist permanently. Retire a
> session/semester by leaving `isActive = false`, never by deleting the row.

---

## Request & Response Types

### `POST /academic/faculties`

**Request Body (`CreateFacultyDto`):**

```ts
{
  name: string;             // max 200 chars
  code: string;             // unique, max 10 chars (e.g. "SCI", "ENG")
  description?: string;
  deanUserId?: number;      // references User
  email?: string;
  phoneNumber?: string;
}
```

**Response: `201 Created`**

```ts
{
  id: number;
  name: string;
  code: string;
  description: string | null;
  deanUserId: number | null;
  email: string | null;
  phoneNumber: string | null;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}
```

---

### `POST /academic/departments`

**Request Body (`CreateDepartmentDto`):**

```ts
{
  facultyId: number;
  name: string;             // max 200 chars
  code: string;             // unique, max 10 chars (e.g. "CSC", "MTH")
  description?: string;
  hodUserId?: number;       // references User
  email?: string;
  phoneNumber?: string;
}
```

**Response: `201 Created`** — returns the created department.

---

### `POST /academic/programs`

**Request Body (`CreateProgramDto`):**

```ts
{
  departmentId: number;
  name: string;                   // max 200 chars
  code: string;                   // unique, max 20 chars (e.g. "CSC")
  degreeType: string;             // e.g. "B.Sc", "B.Eng", max 30 chars
  durationYears: number;
  description?: string;
  admissionRequirements?: string;
  minCreditUnits: number;
}
```

**Response: `201 Created`** — returns the created program.

---

### `POST /academic/sessions`

**Request Body (`CreateAcademicSessionDto`):**

```ts
{
  name: string;           // unique, e.g. "2025/2026", max 20 chars
  startDate: string;      // ISO 8601
  endDate: string;        // ISO 8601
  isActive?: boolean;     // default false
}
```

**Response: `201 Created`** — returns the created session.

---

### `POST /academic/semesters`

**Request Body (`CreateSemesterDto`):**

```ts
{
  academicSessionId: number;
  name: string;               // e.g. "First Semester", max 30 chars
  startDate: string;          // ISO 8601
  endDate: string;            // ISO 8601
  isActive?: boolean;
  registrationStart?: string; // ISO 8601
  registrationEnd?: string;   // ISO 8601
}
```

> `name` must be unique within a given `academicSessionId` (e.g. two "First
> Semester" rows cannot exist under the same session). Enforced by a
> `@@unique([academicSessionId, name])` constraint at the schema level.
> Returns `409 Conflict` on violation.

**Response: `201 Created`** — returns the created semester.

---

### `POST /academic/levels`

**Request Body (`CreateLevelDto`):**

```ts
{
  name: string;           // unique, e.g. "100 Level", max 20 chars
  numericValue: number;   // unique, e.g. 100, 200, 300
}
```

**Response: `201 Created`** — returns the created level.

---

## Notes for Developers

- Only **one session** and **one semester** should be `isActive = true` at a
  time. The activate endpoint deactivates all others in a transaction — see
  Workflow doc §1 for the exact pattern.
- This invariant is additionally enforced at the **database level** via a
  partial unique index, independent of application code:
  ```sql
  CREATE UNIQUE INDEX one_active_session ON academic_sessions (is_active) WHERE is_active = true;
  CREATE UNIQUE INDEX one_active_semester ON semesters (is_active) WHERE is_active = true;
  ```
  Any write that bypasses `activateSession()`/`activateSemester()` and
  violates this (e.g. a stray `update` in a seed script or admin fixup) fails
  loudly at the DB, instead of silently producing two "active" rows.
- `Faculty.deanUserId` and `Department.hodUserId` reference `User.id` but are
  not formal Prisma relations — validate manually.
- `Level.numericValue` is used for sorting and progression logic (e.g. 100 <
  200 < 300).
- Faculties → Departments → Programs is a strict hierarchy. Cascading deletes
  are set on department → faculty and program → department.
- `GET /academic/sessions/active` and `GET /academic/semesters/active` are
  cached (see Workflow doc §3). If you activate a new session/semester via a
  direct DB write instead of the activate endpoints, the cache will not
  invalidate and stale data will be served until TTL expiry.
