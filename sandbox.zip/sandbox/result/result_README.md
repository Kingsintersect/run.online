# Result Module

Manages student grades, grade scales, CGPA calculation, and result approval workflows.

## Models Owned

- **GradeScale** — grading system definition (A=5.0, B=4.0, etc.)
- **Grade** — individual student course grade with approval workflow
- **CgpaHistory** — semester-by-semester GPA/CGPA snapshots

---

## Endpoints

### Grade Scale

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/results/grade-scales` | List all grade scales | Authenticated |
| `POST` | `/results/grade-scales` | Create a grade scale entry | Admin |
| `PATCH` | `/results/grade-scales/:id` | Update a grade scale entry | Admin |
| `DELETE` | `/results/grade-scales/:id` | Delete a grade scale entry | Admin |

### Grades

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/results/grades` | List grades (filterable by student, course, semester, status) | Admin, Lecturer |
| `GET` | `/results/grades/:id` | Get grade details | Admin, Lecturer, Self |
| `GET` | `/results/grades/student/:studentId` | Get all grades for a student | Admin, Self |
| `GET` | `/results/grades/course/:courseId/semester/:semesterId` | Get all grades for a course in a semester | Lecturer, Admin |
| `POST` | `/results/grades` | Submit a single grade | Lecturer |
| `POST` | `/results/grades/bulk` | Submit grades in bulk for a course | Lecturer |
| `PATCH` | `/results/grades/:id` | Update a grade (only if DRAFT) | Lecturer |
| `PATCH` | `/results/grades/:id/submit` | Submit grade for approval | Lecturer |
| `PATCH` | `/results/grades/:id/approve` | Approve a submitted grade | HOD, Admin |
| `PATCH` | `/results/grades/:id/reject` | Reject back to draft | HOD, Admin |
| `POST` | `/results/grades/publish/:semesterId` | Publish all approved grades for a semester | Admin |

### CGPA History

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/results/cgpa/student/:studentId` | Get CGPA history for a student | Admin, Self |
| `POST` | `/results/cgpa/calculate/:studentId/:semesterId` | Calculate and store GPA/CGPA for a semester | Admin, System |

---

## Request & Response Types

### `POST /results/grade-scales`

**Request Body (`CreateGradeScaleDto`):**

```ts
{
  grade: string;         // unique, max 2 chars (e.g. "A", "AB", "B")
  minScore: number;      // decimal(5,2), e.g. 70.00
  maxScore: number;      // decimal(5,2), e.g. 100.00
  gradePoint: number;    // decimal(3,2), e.g. 5.00
  description?: string;  // e.g. "Excellent"
}
```

**Response: `201 Created`** — returns the created grade scale.

---

### `POST /results/grades`

**Request Body (`CreateGradeDto`):**

```ts
{
  studentId: number;
  courseId: number;
  semesterId: number;
  caScore?: number;       // decimal(5,2), continuous assessment
  examScore?: number;     // decimal(5,2), examination score
}
```

**Response: `201 Created`**

```ts
{
  id: number;
  studentId: number;
  courseId: number;
  semesterId: number;
  caScore: number | null;
  examScore: number | null;
  totalScore: number | null;   // computed: caScore + examScore
  gradeScaleId: number | null; // auto-assigned from total score
  gradePoint: number | null;
  status: "DRAFT";
  createdAt: string;
}
```

---

### `POST /results/grades/bulk`

**Request Body (`BulkGradeDto`):**

```ts
{
  courseId: number;
  semesterId: number;
  grades: {
    studentId: number;
    caScore?: number;
    examScore?: number;
  }[];
}
```

**Response: `201 Created`**

```ts
{
  submitted: number;
  errors: { studentId: number; message: string }[];
}
```

---

### `PATCH /results/grades/:id/approve`

**Request Body (`ApproveGradeDto`):**

```ts
{
  remarks?: string;
}
```

**Response: `200 OK`**

```ts
{
  id: number;
  status: "APPROVED";
  approvedBy: number;
  approvedAt: string;
}
```

---

### `GET /results/cgpa/student/:studentId`

**Response: `200 OK`**

```ts
{
  data: {
    id: number;
    semesterId: number;
    semester: { name: string; academicSession: { name: string } };
    gpa: number;             // decimal(3,2)
    cgpa: number;            // decimal(3,2)
    totalCreditUnits: number;
  }[];
  currentCGPA: number;       // latest CGPA from Student record
}
```

---

## Grade Workflow

```
DRAFT → SUBMITTED → APPROVED → PUBLISHED
                  ↘ REJECTED → DRAFT (back to lecturer)
```

1. **Lecturer** creates grades as `DRAFT`.
2. **Lecturer** submits for review → `SUBMITTED`.
3. **HOD/Admin** approves → `APPROVED`, or rejects → back to `DRAFT`.
4. **Admin** publishes approved grades → `PUBLISHED` (visible to students).

---

## Notes for Developers

- `totalScore` is computed as `caScore + examScore` in the service layer.
- `gradeScaleId` and `gradePoint` are auto-assigned by matching `totalScore` against `GradeScale` ranges.
- CGPA calculation: weighted average of grade points × credit units across all semesters.
- Grade unique constraint: `[studentId, courseId, semesterId]` — one grade per student per course per semester.
- Only `DRAFT` grades can be edited by lecturers. Once submitted, they enter the approval workflow.
- The `approvedBy` field references a User ID (HOD or admin who approved).
- **Moodle grade visibility**: In addition to the portal's own Grade model, students can view their Moodle LMS grades (assignments, quizzes, overall course grades) via the `MoodleSyncModule`. The Moodle grades are synced periodically and displayed alongside the portal's official grades. The portal grades (this module) remain the authoritative academic record.
