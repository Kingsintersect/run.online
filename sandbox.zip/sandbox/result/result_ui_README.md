# Results & Grading — Frontend UI Implementation Guide

Next.js 15 App Router · TypeScript Strict · TanStack React Query v5 · Zustand · Zod · ShadCN UI

> **Sidebar context:** The "Grading" section on the tutor dashboard exposes two routes — **Submit Results** and **Grade Book**. This guide covers the full implementation for all roles: tutor grading workflow, admin approval/publish pipeline, and student result view.

---

## Table of Contents

1. [Directory Structure](#1-directory-structure)
2. [Route Architecture](#2-route-architecture)
3. [Zod Schemas & Types](#3-zod-schemas--types)
4. [API Service Layer](#4-api-service-layer)
5. [React Query Hooks](#5-react-query-hooks)
6. [Zustand UI Store](#6-zustand-ui-store)
7. [Pages & Shell Components](#7-pages--shell-components)
8. [Client Component Breakdown](#8-client-component-breakdown)
9. [Auth & Role Gating](#9-auth--role-gating)
10. [Error Handling & Loading States](#10-error-handling--loading-states)
11. [Environment Variables & Dependencies](#11-environment-variables--dependencies)

---

## 1. Directory Structure

```
src/
├── modules/
│   └── result/
│       ├── components/
│       │   ├── GradeBookTable.tsx         # Tutor/Admin: tabular grade book per course
│       │   ├── GradeEntryRow.tsx          # Tutor: inline CA + Exam score inputs per student
│       │   ├── BulkGradeForm.tsx          # Tutor: bulk grade submission form for a course
│       │   ├── GradeStatusBadge.tsx       # Shared: DRAFT / SUBMITTED / APPROVED / PUBLISHED chip
│       │   ├── GradeApprovalPanel.tsx     # Admin/HOD: approve or reject submitted grades
│       │   ├── PublishGradesPanel.tsx     # Admin: review and publish all approved grades
│       │   ├── StudentResultCard.tsx      # Student: individual course result card
│       │   ├── StudentResultList.tsx      # Student: all published grades per semester
│       │   ├── CgpaHistoryChart.tsx       # Student: CGPA trend (Framer Motion or Recharts)
│       │   ├── CgpaHistoryTable.tsx       # Student: tabular GPA/CGPA per semester
│       │   ├── GradeScaleTable.tsx        # Admin: view/manage grade scale reference
│       │   └── SemesterCourseSelector.tsx # Shared: semester + course offering picker
│       ├── hooks/
│       │   ├── useGrades.ts               # Query/mutation hooks for Grade CRUD
│       │   ├── useCgpa.ts                 # Query hooks for CGPA history
│       │   └── useGradeScales.ts          # Query hooks for grade scale reference
│       ├── schemas/
│       │   ├── grade.schema.ts            # Zod: CreateGradeSchema, BulkGradeSchema, ApproveGradeSchema
│       │   └── grade-scale.schema.ts      # Zod: CreateGradeScaleSchema
│       ├── types/
│       │   └── result.types.ts            # z.infer<> types + API response interfaces
│       └── store/
│           └── useResultUIStore.ts        # Zustand: selected course/semester, dialog states
```

---

## 2. Route Architecture

### Route Map

| Path | Sidebar Label | Description | Roles |
| ---- | ------------- | ----------- | ----- |
| `/results` | My Results | Student: published grades for current/past semesters | `STUDENT` |
| `/results/cgpa` | — | Student: CGPA history chart + table | `STUDENT` |
| `(dashboard)/tutor/(routes)/grading` | Grade Book | Tutor: grade book per course — view and edit DRAFT grades | `TUTOR`, `ADMIN` |
| `(dashboard)/tutor/(routes)/grading/submit` | Submit Results | Tutor: bulk grade entry + submit for approval | `TUTOR`, `ADMIN` |
| `(dashboard)/admin/(routes)/results` | Results | Admin: all grades across all courses | `ADMIN` |
| `(dashboard)/admin/(routes)/results/approve` | Approve Results | Admin/HOD: review SUBMITTED grades and approve/reject | `ADMIN` |
| `(dashboard)/admin/(routes)/results/publish` | Publish Results | Admin: batch publish APPROVED grades per semester | `ADMIN` |
| `(dashboard)/admin/(routes)/results/grade-scales` | Grade Scales | Admin: manage grade scale configuration | `ADMIN` |

### App Router Directory

```
app/
├── (root)/                            # Public or lightly‑authenticated routes (e.g., landing, auth, etc.)
│   └── ...                            # No results or assessments here
│
└── (dashboard)/                       # Authenticated dashboard with sidebar/nav
    ├── student/
    │   └── results/
    │       ├── layout.tsx             # Semester tab switcher + page header
    │       ├── page.tsx               # Student: my published grades
    │       └── cgpa/
    │           └── page.tsx           # Student: CGPA history
    │
    ├── tutor/
    │   └── (routes)/
    │       └── grading/
    │           ├── layout.tsx         # Shared grading layout (course/semester selectors)
    │           ├── page.tsx           # Grade Book — view + inline edit DRAFT grades
    │           └── submit/
    │               └── page.tsx       # Submit Results — bulk entry + submit for approval
    │
    ├── manager/
    │   └── (routes)/
    │       └── results/
    │           ├── page.tsx           # All grades (filterable by course, semester, status)
    │           ├── approve/
    │           │   └── page.tsx       # Approve/reject SUBMITTED grades
    │           ├── publish/
    │           │   └── page.tsx       # Publish APPROVED grades per semester
    │           └── grade-scales/
    │               └── page.tsx       # Grade scale management
    │
    └── admin/
        └── (routes)/
            └── results/
                ├── page.tsx           # All grades (filterable by course, semester, status)
                ├── approve/
                │   └── page.tsx       # Approve/reject SUBMITTED grades
                ├── publish/
                │   └── page.tsx       # Publish APPROVED grades per semester
                └── grade-scales/
                    └── page.tsx       # Grade scale management
```

---

## 3. Zod Schemas & Types

**Location:** `src/modules/result/schemas/` and `src/modules/result/types/`

### `grade.schema.ts`

#### `CreateGradeSchema`

| Field | Zod Rule |
| ----- | -------- |
| `studentId` | `z.number().int().positive()` |
| `courseId` | `z.number().int().positive()` |
| `semesterId` | `z.number().int().positive()` |
| `caScore` | `z.number().min(0).max(100).optional()` |
| `examScore` | `z.number().min(0).max(100).optional()` |

#### `BulkGradeSchema`

| Field | Zod Rule |
| ----- | -------- |
| `courseId` | `z.number().int().positive()` |
| `semesterId` | `z.number().int().positive()` |
| `grades` | `z.array(z.object({ studentId: z.number().int().positive(), caScore: z.number().min(0).max(100).optional(), examScore: z.number().min(0).max(100).optional() })).min(1)` |

#### `UpdateGradeSchema`

| Field | Zod Rule |
| ----- | -------- |
| `caScore` | `z.number().min(0).max(100).optional()` |
| `examScore` | `z.number().min(0).max(100).optional()` |

#### `ApproveGradeSchema`

| Field | Zod Rule |
| ----- | -------- |
| `remarks` | `z.string().max(255).optional()` |

#### `GradeFilterSchema`

| Field | Zod Rule |
| ----- | -------- |
| `studentId` | `z.number().int().optional()` |
| `courseId` | `z.number().int().optional()` |
| `semesterId` | `z.number().int().optional()` |
| `status` | `z.enum(['DRAFT','SUBMITTED','APPROVED','PUBLISHED']).optional()` |
| `page` | `z.number().int().min(1).optional()` |
| `limit` | `z.number().int().min(1).max(100).optional()` |

### `grade-scale.schema.ts`

#### `CreateGradeScaleSchema`

| Field | Zod Rule |
| ----- | -------- |
| `grade` | `z.string().min(1).max(2)` |
| `minScore` | `z.number().min(0).max(100)` |
| `maxScore` | `z.number().min(0).max(100)` — `.refine()` that `maxScore > minScore` |
| `gradePoint` | `z.number().min(0).max(5)` |
| `description` | `z.string().max(50).optional()` |

### `result.types.ts`

Infer types from schemas:

```
type CreateGradeDto    = z.infer<typeof CreateGradeSchema>
type BulkGradeDto      = z.infer<typeof BulkGradeSchema>
type UpdateGradeDto    = z.infer<typeof UpdateGradeSchema>
type ApproveGradeDto   = z.infer<typeof ApproveGradeSchema>
type GradeFilter       = z.infer<typeof GradeFilterSchema>
type CreateGradeScaleDto = z.infer<typeof CreateGradeScaleSchema>
```

Define response interfaces for server shapes:

| Interface | Key Fields |
| --------- | ---------- |
| `Grade` | `id, studentId, courseId, semesterId, caScore, examScore, totalScore, gradeScaleId, gradePoint, status, approvedBy, approvedAt, remarks, createdAt, updatedAt` |
| `GradeWithDetails` | `Grade` + `student: { matricNumber, user: { firstName, lastName } }`, `course: { code, title, creditUnits }`, `semester: { name }`, `gradeScale?: { grade, gradePoint, description }` |
| `BulkGradeResult` | `submitted: number, errors: { studentId: number, message: string }[]` |
| `GradeScale` | `id, grade, minScore, maxScore, gradePoint, description` |
| `CgpaEntry` | `id, semesterId, semester: { name, academicSession: { name } }, gpa, cgpa, totalCreditUnits` |
| `CgpaResponse` | `data: CgpaEntry[], currentCGPA: number` |
| `StudentResult` | Published `GradeWithDetails` subset visible to students |
| `PaginatedResponse<T>` | `data: T[], meta: { total, page, limit, totalPages }` |

---

## 4. API Service Layer

> All methods call `apiClient` from `src/lib/clients/apiClient.ts`.  
> Token injection handled by the interceptor — never pass tokens explicitly.  
> No hardcoded URLs. Base URL from `process.env.NEXT_PUBLIC_API_URL`.

### `resultService`

| Method | HTTP | Path | Used by |
| ------ | ---- | ---- | ------- |
| `getAllGrades(params?)` | `GET` | `/results/grades` | Admin |
| `getGradeById(id)` | `GET` | `/results/grades/:id` | Admin, Tutor |
| `getStudentGrades(studentId)` | `GET` | `/results/grades/student/:studentId` | Admin, Student (self) |
| `getCourseGrades(courseId, semesterId)` | `GET` | `/results/grades/course/:courseId/semester/:semesterId` | Tutor, Admin |
| `createGrade(dto)` | `POST` | `/results/grades` | Tutor |
| `bulkCreateGrades(dto)` | `POST` | `/results/grades/bulk` | Tutor |
| `updateGrade(id, dto)` | `PATCH` | `/results/grades/:id` | Tutor |
| `submitGrade(id)` | `PATCH` | `/results/grades/:id/submit` | Tutor |
| `approveGrade(id, dto)` | `PATCH` | `/results/grades/:id/approve` | Admin |
| `rejectGrade(id, dto)` | `PATCH` | `/results/grades/:id/reject` | Admin |
| `publishGrades(semesterId)` | `POST` | `/results/grades/publish/:semesterId` | Admin |

### `cgpaService`

| Method | HTTP | Path | Used by |
| ------ | ---- | ---- | ------- |
| `getStudentCgpa(studentId)` | `GET` | `/results/cgpa/student/:studentId` | Admin, Student (self) |
| `calculateCgpa(studentId, semesterId)` | `POST` | `/results/cgpa/calculate/:studentId/:semesterId` | Admin |

### `gradeScaleService`

| Method | HTTP | Path | Used by |
| ------ | ---- | ---- | ------- |
| `getGradeScales()` | `GET` | `/results/grade-scales` | All authenticated |
| `createGradeScale(dto)` | `POST` | `/results/grade-scales` | Admin |
| `updateGradeScale(id, dto)` | `PATCH` | `/results/grade-scales/:id` | Admin |
| `deleteGradeScale(id)` | `DELETE` | `/results/grade-scales/:id` | Admin |

---

## 5. React Query Hooks

**Location:** `src/modules/result/hooks/`

### Query Key Factory

```
gradeKeys = {
  all:          ['grades']
  list:         (filters?) => ['grades', 'list', filters]
  detail:       (id) => ['grades', 'detail', id]
  byStudent:    (studentId) => ['grades', 'student', studentId]
  byCourse:     (courseId, semesterId) => ['grades', 'course', courseId, semesterId]
}

cgpaKeys = {
  all:          ['cgpa']
  byStudent:    (studentId) => ['cgpa', 'student', studentId]
}

gradeScaleKeys = {
  all:          ['grade-scales']
}
```

### `useGrades.ts` — Hooks

| Hook | Query Type | Description |
| ---- | ---------- | ----------- |
| `useAllGrades(filters?)` | `useQuery` | Admin: paginated grade list with filters |
| `useGradeById(id)` | `useQuery` | Single grade detail |
| `useStudentGrades(studentId)` | `useQuery` | All grades for a student (admin or self) |
| `useCourseGrades(courseId, semesterId)` | `useQuery` | Tutor/Admin: all grades for a course in a semester — the **Grade Book** data source |
| `useCreateGrade()` | `useMutation` | Create single grade; invalidates `byCourse` key on success |
| `useBulkCreateGrades()` | `useMutation` | Submit bulk grades; invalidates `byCourse` key on success |
| `useUpdateGrade()` | `useMutation` | Update DRAFT grade; invalidates detail + byCourse |
| `useSubmitGrade()` | `useMutation` | Submit grade for approval; invalidates grade keys |
| `useApproveGrade()` | `useMutation` | Admin approve; invalidates grade keys |
| `useRejectGrade()` | `useMutation` | Admin reject; invalidates grade keys |
| `usePublishGrades()` | `useMutation` | Admin publish; invalidates all grade keys |

### `useCgpa.ts` — Hooks

| Hook | Query Type | Description |
| ---- | ---------- | ----------- |
| `useStudentCgpa(studentId)` | `useQuery` | CGPA history + current CGPA |
| `useCalculateCgpa()` | `useMutation` | Trigger CGPA recalculation (admin); invalidates `cgpaKeys.byStudent` |

### `useGradeScales.ts` — Hooks

| Hook | Query Type | Description |
| ---- | ---------- | ----------- |
| `useGradeScales()` | `useQuery` | All grade scales (staleTime: 30 min — rarely changes) |
| `useCreateGradeScale()` | `useMutation` | Admin: create scale; invalidates `gradeScaleKeys.all` |
| `useUpdateGradeScale()` | `useMutation` | Admin: update scale; invalidates `gradeScaleKeys.all` |
| `useDeleteGradeScale()` | `useMutation` | Admin: delete scale; invalidates `gradeScaleKeys.all` |

### Query Config Notes

- `useCourseGrades` is the most critical query — cache it with `staleTime: 2 * 60 * 1000` (2 min). It drives both the Grade Book and Submit Results pages.
- `useStudentGrades` for the student self-view should only fetch `status: PUBLISHED` grades (pass as filter param).
- `usePublishGrades` mutation success should also invalidate `useStudentGrades` queries site-wide (use `queryClient.invalidateQueries({ queryKey: gradeKeys.all })`).
- Disable `useCourseGrades(courseId, semesterId)` with `enabled: !!courseId && !!semesterId` to prevent premature fetching before the user selects a course.

---

## 6. Zustand UI Store

**Location:** `src/modules/result/store/useResultUIStore.ts`

> Zustand stores only UI state — no server data.

### `useResultUIStore`

| State Field | Type | Default | Purpose |
| ----------- | ---- | ------- | ------- |
| `selectedSemesterId` | `number \| null` | `null` | Active semester in the course/semester selector |
| `selectedOfferingId` | `number \| null` | `null` | Active course offering in the grade book / submit form |
| `selectedCourseId` | `number \| null` | `null` | Derived: course ID of the selected offering |
| `gradeBookView` | `'table' \| 'cards'` | `'table'` | Toggle between table and card view in Grade Book |
| `submitStep` | `'entry' \| 'review' \| 'confirm'` | `'entry'` | Multi-step flow state for Submit Results page |
| `pendingGrades` | `Record<number, { caScore?: number, examScore?: number }>` | `{}` | Unsaved inline edits keyed by studentId (cleared after bulk submit) |
| `isApproveDialogOpen` | `boolean` | `false` | Admin: approval remarks dialog |
| `approvingGradeId` | `number \| null` | `null` | Which grade is being acted on in the approval dialog |
| `approvalAction` | `'approve' \| 'reject' \| null` | `null` | Whether dialog is in approve or reject mode |

### Actions

| Action | Description |
| ------ | ----------- |
| `setSelectedSemesterId(id)` | Update active semester |
| `setSelectedOffering(offeringId, courseId)` | Select a course offering for the grade book |
| `setGradeBookView(view)` | Toggle table/cards |
| `setSubmitStep(step)` | Advance or retreat in the submit flow |
| `setPendingGrade(studentId, scores)` | Stage an inline edit to a student's scores |
| `clearPendingGrades()` | Clear all staged edits (after submit or discard) |
| `openApprovalDialog(gradeId, action)` | Open approval/rejection dialog for a grade |
| `closeApprovalDialog()` | Close and reset approval state |

---

## 7. Pages & Shell Components

All pages are thin **Server Components** — they render client component shells. No direct data fetching in page files.

### `app/(root)/results/layout.tsx`

- Wraps student results section
- Renders navigation tabs: "My Results" | "CGPA History"
- Reads active semester for context via `useAcademicCalendar` (from timetable module hooks — reusable)

### `app/(root)/results/page.tsx`

- Title: "My Results"
- Renders `StudentResultList` client component
- Default view: active semester's published grades

### `app/(root)/results/cgpa/page.tsx`

- Title: "Academic Performance"
- Renders `CgpaHistoryChart` and `CgpaHistoryTable` client components side by side

### `app/(dashboard)/tutor/(routes)/grading/layout.tsx`

- Renders `SemesterCourseSelector` at the top (shared between both grading sub-routes)
- Selector drives `useResultUIStore.selectedSemesterId` and `selectedOfferingId`

### `app/(dashboard)/tutor/(routes)/grading/page.tsx`

- Sidebar label: **"Grade Book"**
- Renders `GradeBookTable` client component
- Displays all enrolled students for the selected course + their current grade entries (DRAFT through PUBLISHED)
- Inline editing enabled for DRAFT grades

### `app/(dashboard)/tutor/(routes)/grading/submit/page.tsx`

- Sidebar label: **"Submit Results"**
- Renders `BulkGradeForm` client component
- Multi-step flow: entry → review → confirm
- After confirm: triggers `useBulkCreateGrades` or individual `useSubmitGrade` mutations

### `app/(dashboard)/admin/(routes)/results/page.tsx`

- Title: "Grade Management"
- Renders `GradeBookTable` (admin variant: all courses, all statuses)
- Includes filter controls (semester, course, status)

### `app/(dashboard)/admin/(routes)/results/approve/page.tsx`

- Title: "Approve Results"
- Renders `GradeApprovalPanel` — list of SUBMITTED grades awaiting review

### `app/(dashboard)/admin/(routes)/results/publish/page.tsx`

- Title: "Publish Results"
- Renders `PublishGradesPanel` — summary of APPROVED grades ready to be published per semester

### `app/(dashboard)/admin/(routes)/results/grade-scales/page.tsx`

- Title: "Grade Scale Configuration"
- Renders `GradeScaleTable` — view and manage grade scale entries

---

## 8. Client Component Breakdown

> All components are `"use client"`. Data comes from React Query hooks; UI state from Zustand.

### `SemesterCourseSelector`

- Shared component used on both tutor grading pages (via layout)
- Calls `useAcademicCalendar()` (reused from timetable module) for semester list
- Calls a `useTutorOfferings(semesterId)` hook (fetches tutor's assigned offerings for that semester via `/timetable/schedules/tutor/me` or a result-specific endpoint)
- Updates `useResultUIStore.selectedSemesterId` and `selectedOfferingId` on change
- ShadCN: `Select`, `Label`
- Disables the course selector until a semester is chosen

### `GradeBookTable`

- Calls `useCourseGrades(courseId, semesterId)` — enabled only when both are selected
- Renders a ShadCN `Table` with one row per enrolled student
- Columns: Matric No, Student Name, CA Score, Exam Score, Total Score, Grade, Grade Point, Status
- **Tutor variant**: CA and Exam score cells are editable inline when status is `DRAFT`
  - Edits are staged into `useResultUIStore.pendingGrades` (not sent to server yet)
  - A "Save Changes" button at the top triggers `useUpdateGrade` for each pending change
- **Admin variant**: Read-only; status badge per row; filter by status
- Status column renders `GradeStatusBadge`
- ShadCN: `Table`, `TableHeader`, `TableBody`, `TableRow`, `TableCell`, `Input` (inline), `Button`, `Badge`, `Skeleton`

### `GradeEntryRow`

- Sub-component of `GradeBookTable` for editable rows
- Renders `Input` fields for `caScore` and `examScore`
- On change: dispatches `setPendingGrade(studentId, scores)` to Zustand
- Computes optimistic `totalScore` display: `(caScore ?? 0) + (examScore ?? 0)`
- Highlights rows with unsaved changes using `cn()` conditional classes

### `BulkGradeForm`

- Multi-step submit flow driven by `useResultUIStore.submitStep`

  **Step 1 — Entry:**
  - Renders the same editable table as `GradeBookTable` (tutor variant)
  - "Next: Review" button advances to step 2

  **Step 2 — Review:**
  - Read-only summary of all entered scores
  - Shows computed total + auto-assigned grade for each row
  - "Back" and "Submit for Approval" buttons

  **Step 3 — Confirm:**
  - Calls `useBulkCreateGrades()` or individual `useSubmitGrade()` per grade
  - Shows success count and error list from `BulkGradeResult`
  - "Done" clears `pendingGrades` and resets `submitStep` to `'entry'`

- ShadCN: `Button`, `Table`, `Badge`, `Alert` (for errors), `Progress` (step indicator)
- Framer Motion: slide transition between steps

### `GradeStatusBadge`

- Presentational; accepts `status: GradeStatus`
- Color map: `DRAFT` = gray, `SUBMITTED` = blue, `APPROVED` = green, `PUBLISHED` = emerald
- ShadCN: `Badge` with `variant` prop and `cn()` for color overrides

### `GradeApprovalPanel`

- Calls `useAllGrades({ status: 'SUBMITTED' })`
- Lists all SUBMITTED grades grouped by course offering
- Each group has an "Approve All" and "Reject All" batch action
- Individual rows have Approve and Reject icon buttons
- Approve/Reject opens `GradeApprovalDialog` (a shared modal)
- ShadCN: `Table`, `Button`, `Badge`, `Collapsible` (group expand/collapse)

### `GradeApprovalDialog`

- Controlled by `useResultUIStore.isApproveDialogOpen`
- Renders a `remarks` textarea for the admin
- Submits via `useApproveGrade()` or `useRejectGrade()` depending on `useResultUIStore.approvalAction`
- ShadCN: `Dialog`, `DialogContent`, `DialogHeader`, `Textarea`, `Button`, `Label`

### `PublishGradesPanel`

- Calls `useAllGrades({ status: 'APPROVED', semesterId })` — grouped by semester
- Shows count of approved grades per semester, total students affected
- "Publish Semester Results" button triggers `usePublishGrades(semesterId)`
- Confirmation step before publish (inline confirm — not a dialog)
- ShadCN: `Card`, `CardHeader`, `CardContent`, `CardFooter`, `Button`, `Badge`, `Alert`

### `StudentResultList`

- Calls `useStudentGrades(currentStudentId)` — only PUBLISHED grades
- Groups results by semester using a date-sort helper
- Semester toggle tabs (driven by `useResultUIStore.selectedSemesterId`)
- Each result renders as a `StudentResultCard`
- Shows semester GPA summary row at the bottom of each semester group
- ShadCN: `Tabs`, `TabsList`, `TabsTrigger`, `TabsContent`, `Skeleton`

### `StudentResultCard`

- Presentational — one published grade per enrolled course
- Displays: course code, course title, credit units, CA, Exam, Total, Grade letter, Grade point
- Background color tint based on grade tier (A = emerald, B = blue, C = yellow, F = red)
- ShadCN: `Card`, `CardContent`, `Badge`

### `CgpaHistoryChart`

- Calls `useStudentCgpa(currentStudentId)`
- Renders a line chart of CGPA over semesters
- Use Recharts (if installed) or a simple SVG path drawn with Framer Motion `motion.path`
- X-axis: semester names; Y-axis: 0.00 – 5.00 CGPA scale
- Tooltip shows: semester name, GPA, CGPA, total credit units
- Skeleton while loading

### `CgpaHistoryTable`

- Same data source as `CgpaHistoryChart`
- Tabular fallback for accessibility
- Columns: Session, Semester, GPA, CGPA, Total Credit Units
- Highlights the best and most recent semester rows
- ShadCN: `Table`

### `GradeScaleTable`

- Calls `useGradeScales()`
- Admin: inline add row at bottom + edit and delete per row
- ShadCN: `Table`, `Input`, `Button`, `Badge`
- Mutations via `useCreateGradeScale`, `useUpdateGradeScale`, `useDeleteGradeScale`

---

## 9. Auth & Role Gating

Role gating is handled entirely in `middleware.ts`.

### `middleware.ts` — Route Matcher

```
Route pattern                                                  Required roles
──────────────────────────────────────────────────────         ──────────────────────────
/results/*                                                     ["STUDENT"]
/(dashboard)/tutor/(routes)/grading/*                          ["TUTOR", "ADMIN"]
/(dashboard)/admin/(routes)/results/*                          ["ADMIN"]
/(dashboard)/admin/(routes)/results/approve                    ["ADMIN"]
/(dashboard)/admin/(routes)/results/publish                    ["ADMIN"]
/(dashboard)/admin/(routes)/results/grade-scales               ["ADMIN"]
```

### Pattern

The middleware reads the JWT from the `access_token` cookie, decodes roles with `jwt-decode`, and redirects to `/403` if the required role is not present.

### Component-level Guard

For in-page UI differences between roles (e.g., showing "Submit for Approval" only to TUTOR, not ADMIN when viewing the grade book), use a `useCurrentUser()` hook that reads roles from the decoded JWT. This is cosmetic only — server-side authorization is the authoritative gate.

### Grade Ownership Guard

The tutor's `GradeBookTable` and `BulkGradeForm` must only show courses the logged-in tutor teaches. The `SemesterCourseSelector` enforces this by only fetching offerings assigned to the current tutor. The backend also enforces this via `CourseOfferingTutor` check — a 403 is returned if the tutor tries to grade a course they're not assigned to.

---

## 10. Error Handling & Loading States

### Route-level `error.tsx`

Place `error.tsx` at:
- `app/(root)/results/error.tsx`
- `app/(dashboard)/tutor/(routes)/grading/error.tsx`
- `app/(dashboard)/admin/(routes)/results/error.tsx`

Each should be `"use client"` and render a `reset()` button (ShadCN `Button`) with an error message.

### Route-level `loading.tsx`

Place `loading.tsx` at:
- `app/(root)/results/loading.tsx` — skeleton: 6 grade cards stacked
- `app/(dashboard)/tutor/(routes)/grading/loading.tsx` — skeleton: table with 10 rows
- `app/(dashboard)/admin/(routes)/results/loading.tsx` — skeleton: table with 15 rows

ShadCN `Skeleton` for all loading states.

### Mutation Feedback

| Mutation | Success Feedback | Error Feedback |
| -------- | ---------------- | -------------- |
| `useBulkCreateGrades` | Toast: "X grades saved" + show error list inline | Toast: "Failed to save grades" + inline error detail |
| `useSubmitGrade` | Toast: "Submitted for approval" | Toast: "Submission failed" |
| `useApproveGrade` | Toast: "Grade approved" | Toast: "Approval failed" |
| `useRejectGrade` | Toast: "Grade sent back to tutor" | Toast: "Rejection failed" |
| `usePublishGrades` | Toast: "Results published for [semester]" + Banner on student portal | Toast: "Publish failed — check for unapproved grades" |

### Bulk Submit Error Display

`BulkGradeResult` returns `{ submitted: number, errors: [] }`. If `errors.length > 0`, render an inline `Alert` in the confirm step listing each failed student and their error message. Do not prevent the user from seeing the success count — partial success is valid.

---

## 11. Environment Variables & Dependencies

### Environment Variables

```bash
# .env.local
NEXT_PUBLIC_API_URL=http://localhost:3000   # NestJS backend base URL
```

### Installation

```bash
npm install @tanstack/react-query zustand zod react-hook-form @hookform/resolvers framer-motion jwt-decode
```

### Dependency Table

| Package | Purpose |
| ------- | ------- |
| `@tanstack/react-query` | All grade/CGPA data fetching, mutations, and cache management |
| `zustand` | Grading UI state (selected course, pending edits, submit step, dialog state) |
| `zod` | Form validation schemas; type inference for all grade DTOs |
| `react-hook-form` | Grade scale form and approval remarks form |
| `@hookform/resolvers` | Connects Zod schemas to React Hook Form via `zodResolver` |
| `framer-motion` | Multi-step submit flow transitions, result card animations |
| `jwt-decode` | Decode JWT roles in middleware for route protection |
