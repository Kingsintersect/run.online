# Result Module — Missing Analytics & Fee-Gated Publishing Endpoints

> **Audience:** Backend developer (qhub_backend_api / NestJS Result module).
> **Status update (2026-08-22):** Sections 1–6 below now have real `.bru` contracts in
> `bruno/result/` and the frontend is wired to all of them for real — see
> `MISSING_BACKEND_APIS.md` §2.7 for the current per-endpoint status (one shape mismatch on
> §1 Dashboard was fixed frontend-side; `hasOutstandingFees` from §7 is still not shipped).
> Section 8 (added 2026-08-22) is a new, separate, still-fully-pending endpoint for the
> Director dashboard's Grade Reports screen — everything below this note describes the
> original ask; §8 is new.
>
> **Original status (as first written):** The frontend Results & Grading module
> (`src/modules/student-grades/`) has a fully built analytics dashboard, grouped-results
> view, top-performers leaderboard, and a fee-gated publishing UI (results are held back
> from publication for students with outstanding fees). None of this had a real endpoint in
> `bruno/result` or `result_README.md` at the time. The frontend was **not** given
> fabricated/locally-computed numbers to fill this gap — per product decision, these screens
> must be backed by real backend logic, not client-side math or invented flags. This
> document specifies exactly what to build so the frontend can be wired to real data once
> these endpoints exist.

Every endpoint below should follow the same conventions already established elsewhere in
`bruno/result`: bearer auth, `{data: ...}` JSON envelope for GET responses, and standard
error handling. Add each as a new `.bru` request in `bruno/result/` once implemented so it
becomes part of the collection's contract, the same way every other Result endpoint is
documented there.

---

## 1. Dashboard Summary

**`GET /results/dashboard`** — Admin. Optional query filters: `semesterId`, `academicSessionId`.

```ts
{
  data: {
    totalGrades: number;
    publishedCount: number;
    approvedCount: number;
    pendingApprovals: number;   // SUBMITTED count
    draftCount: number;
    averageCGPA: number;        // mean of Student.cgpa across active students
    highestCGPA: number;
    passRate: number;           // % of grades with gradePoint > 0
  };
}
```

Backing query: aggregate `Grade` (grouped by `status`) + `Student.cgpa` across the whole
student body (or the filtered semester/session), not just whatever page the frontend
happens to have loaded.

---

## 2. Grade Distribution

**`GET /results/grades/distribution`** — Admin. Optional query filters: `semesterId`,
`academicSessionId`, `programId`.

```ts
{
  data: {
    grade: string;        // "A", "AB", "B", ...
    gradePoint: number;
    count: number;
    percentage: number;   // count / total grades in the filtered set, 0-100
  }[];
}
```

Backing query: `GROUP BY gradeScaleId` over `Grade`, joined to `GradeScale` for the
letter/point, with the filters applied server-side.

---

## 3. Program Performance

**`GET /results/programs/performance`** — Admin. Optional query filter: `semesterId`.

```ts
{
  data: {
    programId: number;
    programName: string;
    programCode: string;
    studentCount: number;   // distinct students with a graded record in scope
    avgGPA: number;         // weighted: Σ(gradePoint × creditUnits) / Σ(creditUnits)
    passRate: number;       // % of grades with gradePoint > 0
  }[];
}
```

Backing query: join `Grade` → `Course`/`CourseOffering` → `Program` (via the student's
enrolled program), grouped by program.

---

## 4. CGPA Trends

**`GET /results/cgpa/trends`** — Admin. No required filters (whole-institution trend
across semesters), optional `programId` to scope to one program.

```ts
{
  data: {
    semesterId: number;
    semesterLabel: string;      // e.g. "2024/2025 First Semester"
    avgGPA: number;             // mean semester GPA across students in scope
    avgCGPA: number;            // mean cumulative CGPA across students in scope, as of that semester
  }[];
}
```

Backing query: aggregate `CgpaHistory` grouped by `semesterId` (join `Semester` +
`AcademicSession` for the label), averaged across students in scope.

---

## 5. Top Performers

**`GET /results/students/top-performers`** — Admin. Optional query filters: `programId`,
`limit` (default 10).

```ts
{
  data: {
    rank: number;
    studentId: number;
    studentName: string;
    studentMatric: string;
    programName: string;
    programCode: string;
    cgpa: number;
  }[];
}
```

Backing query: `Student` ordered by `cgpa` descending, optionally filtered by program,
limited to `limit`. Rank is 1-indexed position in that ordering.

---

## 6. Grouped Results

**`GET /results/grades/grouped`** — Admin. Required query param `groupBy`:
`academic_year | semester | program`. Optional filters: `semesterId`, `programId`,
`status` (same filter set as `GET /results/grades`).

```ts
{
  data: {
    key: string;             // stable group identifier (semesterId, programId, or academicSessionId as a string)
    label: string;           // display label (semester name, program name, or session label)
    subLabel: string | null; // secondary label (e.g. academic year for a semester group, program code for a program group)
    gradeCount: number;
    studentCount: number;    // distinct students in the group
    avgGPA: number;          // weighted average as in §3
    passRate: number;
  }[];
}
```

This is the same shape the frontend's `getGroupedGrades()` already expects — it currently
computes this by filtering an in-memory mock dataset. The real version needs a `GROUP BY`
over `Grade` matching whichever dimension `groupBy` selects, not a client-side reduction
over a single filtered page of `/results/grades`.

---

## 7. Fee-Gated Publishing

The publish flow needs to know, per grade, whether the student has an outstanding fee
balance — and the publish action itself needs to skip those students rather than
publishing their results regardless. Today `Grade` has no such field and
`POST /results/grades/publish/:semesterId` has no such exclusion; this is a real gap, not
a cosmetic one, since the frontend currently shows every grade as fee-cleared.

### 7a. `Grade.hasOutstandingFees` on every Grade response

Add `hasOutstandingFees: boolean` to the `Grade` object wherever it's returned (List, Get,
By-Student, By-Course, and the flat Create/Update responses). Compute it by checking
whether the student has any `Invoice` in the relevant `FeeManagement`/Payment module with
a status other than `PAID` for a fee type relevant to that semester/session (e.g. tuition)
— see `sandbox/payment/payment_README.md` and `bruno/fee/*` for the Invoice model this
should join against.

```ts
// GET /results/grades, /results/grades/:id, /results/grades/student/:studentId,
// /results/grades/course/:courseId/semester/:semesterId
{
  // ...existing Grade fields
  hasOutstandingFees: boolean;
}
```

### 7b. `POST /results/grades/publish/:semesterId` excludes fee-withheld students

When publishing, skip any APPROVED grade whose student currently has
`hasOutstandingFees: true` for that semester — their grade stays APPROVED (not PUBLISHED)
until the balance clears, at which point a subsequent publish call should pick them up.
Report how many were withheld alongside the existing published count:

```ts
{
  data: {
    semesterId: number;
    published: number;
    withheld: number;   // APPROVED grades skipped due to outstanding fees
  };
}
```

This is additive to the endpoint's existing documented response
(`{data: {semesterId, published}}` in `bruno/hostel/Grade - Publish.bru`'s docs block) —
just add the `withheld` field, no breaking change to `published`.

---

## 8. Director Grade Reports — PENDING BACKEND IMPLEMENTATION

**`GET /results/reports/director-grade-summary`** — Admin, Director. Backs the Director
dashboard's Grade Reports screen (`/director/grades`), which needs a cross-institution view
(KPIs + grade distribution + per-faculty breakdown + a searchable, paginated per-student
table with each student's course-level scores) that none of sections 1–6 provide on their
own — those are scoped to a single program/semester/institution-wide trend, not a
faculty-grouped, per-student drill-down.

This was previously proposed as a bespoke `/director/grade-report` endpoint in
`src/app/(dashboard)/director/INTEGRATION.md` (an old scaffold doc predating the real
backend) with a `{status, message, data}` envelope and name-based faculty/level/semester
params — that shape doesn't match this API's actual conventions anywhere else. The contract
below supersedes it for this one screen, reusing this collection's `{data: ..., meta: ...}`
envelope and the same field naming as sections 1–6.

**Query params** (all optional; omit to mean "no filter" — a bare call returns
institution-wide numbers):

```
?facultyName=&departmentName=&programName=&level=&semesterName=&academicYear=&status=&search=&page=&limit=
```

- `level` — numeric (e.g. `300`), matches `Level.numericValue`.
- `status` — one of `distinction | pass | probation | fail` (see classification below).
- `search` — matches student name or matric number, case-insensitive partial.
- `page`/`limit` — paginate the `records` array only; `summary`/`gradeDistribution`/
  `byFaculty` are always computed over the *entire* filtered set, not just the current page.

**Note on `facultyName`/`departmentName`/`programName` vs. IDs:** these are sent as display
strings, not FK ids, because the current Director filter bar (`DirectorFilterBar.tsx`,
shared with the Financial and Statistical Reports tabs, out of scope for this pass) only
collects free-text/display values, not real Faculty/Department/Program pickers. Please
resolve by name (`WHERE faculty.name = :facultyName`) rather than requiring an id. **Please
confirm this is workable** — if an id-based filter is required instead, the filter bar needs
a follow-up rebuild with real dropdowns sourced from the Academic module, which is a
separate, larger piece of work than this endpoint itself.

**Response:**

```ts
{
  data: {
    summary: {
      averageGPA: number;       // weighted: Σ(gradePoint × creditUnits) / Σ(creditUnits), over the filtered set
      passRate: number;         // % of filtered records with status != "fail"
      distinctionRate: number;  // % of filtered records with status == "distinction"
      totalRecords: number;     // count of filtered records (not just the current page)
    };
    gradeDistribution: {        // same shape as §2, computed over the filtered set
      grade: string;
      gradePoint: number;
      count: number;
      percentage: number;
    }[];
    byFaculty: {
      faculty: string;          // Faculty.name
      studentCount: number;     // distinct students in this faculty within the filtered set
      averageGPA: number;
    }[];
    records: {                  // one row per Grade record (a student's result in one course, one semester)
      studentId: number;
      matricNumber: string;
      studentName: string;
      faculty: string;
      department: string;
      program: string;
      level: number;           // Level.numericValue
      academicYear: string;    // AcademicSession.name
      semester: string;        // Semester.name
      totalUnits: number;      // sum of creditUnits across this student's courses in this semester
      earnedUnits: number;     // sum of creditUnits for courses with gradePoint > 0
      semesterGPA: number;     // from the matching CgpaHistory entry (§ CGPA - By Student), not recomputed ad hoc
      cgpa: number;            // same source
      status: "distinction" | "pass" | "probation" | "fail"; // classified from semesterGPA per the thresholds below
      courses: {
        courseId: number;
        courseCode: string;
        courseTitle: string;
        creditUnits: number;
        score: number | null;   // Grade.totalScore
        grade: string | null;   // GradeScale.grade
        gradePoints: number | null;
        tutorName: string | null; // assigned lecturer's name, if any
      }[];
    }[];
  };
  meta: { total: number; page: number; limit: number };
}
```

**Status classification thresholds** (matches this frontend's existing convention, unchanged
from the mock it replaces — reuse exactly, don't invent new cutoffs):
`semesterGPA >= 4.5` → `distinction`; `>= 2.4` → `pass`; `>= 1.5` → `probation`; else `fail`.

---

## Notes

- Sections 1–6 (analytics) are read-only, Admin-scoped, and independent of each other —
  they can ship incrementally; the frontend calls each separately and will simply show an
  error/empty state for whichever ones aren't live yet.
- None of the analytics endpoints should require the frontend to fetch the *entire* grades
  table and aggregate client-side — that doesn't scale past a small seed dataset and is
  exactly the approach this document exists to avoid.
- Section 7's `hasOutstandingFees` field is currently mapped straight through from the raw
  API response with no client-side computation — until the backend adds it, every grade
  will just read as fee-cleared (`false`/`undefined`), which is an honest "not wired yet"
  state rather than a fabricated one.
