# Result Module — Implementation Workflow

This document explains the internal implementation flow for the Result module. It is intended for developers building or maintaining this module.

---

## Module Dependencies

```
ResultModule
├── PrismaService          (database access)
├── EnrollmentModule       (verify student is enrolled before grade entry)
├── AcademicModule         (semester lookup)
├── NotificationModule     (notify students when results are published)
├── AuditModule            (log grade submissions, approvals, publications)
└── CourseModule            (course credit units for CGPA calculation)
```

---

## Grade Workflow State Machine

```
┌───────┐      ┌───────────┐      ┌──────────┐      ┌───────────┐
│ DRAFT │─────▶│ SUBMITTED │─────▶│ APPROVED │─────▶│ PUBLISHED │
└───────┘      └─────┬─────┘      └──────────┘      └───────────┘
                     │
                     ▼
               ┌──────────┐
               │ REJECTED │──────▶ back to DRAFT
               └──────────┘
```

| Transition | Who | Action |
| ---------- | --- | ------ |
| → DRAFT | Lecturer | Creates/edits grade |
| DRAFT → SUBMITTED | Lecturer | Submits for review |
| SUBMITTED → APPROVED | HOD/Admin | Approves grade |
| SUBMITTED → REJECTED | HOD/Admin | Rejects back to lecturer |
| APPROVED → PUBLISHED | Admin | Publishes to students |

---

## 1. Grade Entry Flow

**Endpoint:** `POST /results/grades` or `POST /results/grades/bulk`

```
Lecturer enters grades for a course
         │
         ▼
┌──────────────────────────────────────────────────┐
│  ResultService.createGrade(dto) / bulkCreate     │
│                                                  │
│  Validation:                                     │
│  ┌────────────────────────────────────────────┐  │
│  │ 1. Verify lecturer teaches this course     │  │
│  │    (via CourseOfferingLecturer)             │  │
│  │    - Not assigned → 403                    │  │
│  │                                            │  │
│  │ 2. Verify student is enrolled in this      │  │
│  │    course offering this semester            │  │
│  │    - Not enrolled → 400                    │  │
│  │                                            │  │
│  │ 3. Check for existing grade:               │  │
│  │    @@unique([studentId, courseId, semesterId])│ │
│  │    - Exists → 409                          │  │
│  │                                            │  │
│  │ 4. Validate scores:                        │  │
│  │    - caScore: 0-40 (configurable)          │  │
│  │    - examScore: 0-60 (configurable)        │  │
│  └────────────────────────────────────────────┘  │
│                                                  │
│  Processing:                                     │
│  ┌────────────────────────────────────────────┐  │
│  │ 1. totalScore = caScore + examScore        │  │
│  │ 2. Auto-assign gradeScaleId:               │  │
│  │    - Query GradeScale where                │  │
│  │      minScore ≤ totalScore ≤ maxScore      │  │
│  │ 3. Set gradePoint from GradeScale          │  │
│  │ 4. Create Grade record (status: DRAFT)     │  │
│  └────────────────────────────────────────────┘  │
│                                                  │
│  Log via AuditService                            │
└──────────────────────────────────────────────────┘
```

### Auto Grade Assignment

```ts
async assignGradeScale(totalScore: number) {
  const scale = await this.prisma.gradeScale.findFirst({
    where: {
      minScore: { lte: totalScore },
      maxScore: { gte: totalScore },
    },
  });
  // Returns: { id, grade: "A", gradePoint: 5.00 }
  return scale;
}

// Example GradeScale table:
// A  → 70-100 → 5.00
// AB → 60-69  → 4.00
// B  → 50-59  → 3.50
// BC → 45-49  → 3.00
// C  → 40-44  → 2.50
// CD → 35-39  → 2.00
// D  → 30-34  → 1.50
// F  → 0-29   → 0.00
```

---

## 2. Grade Approval Flow

```
Lecturer submits grade → HOD/Admin reviews
         │
         ▼
┌──────────────────────────────────────────────────┐
│  ResultService.submitGrade(gradeId, lecturerId)  │
│  1. Find grade by ID                             │
│  2. Verify status == DRAFT → else 400            │
│  3. Verify lecturer owns this grade              │
│     (via offering assignment)                    │
│  4. Update status = SUBMITTED                    │
│  5. Notify HOD: "Grades submitted for review"    │
└──────────────────────────────────────────────────┘
         │
         ▼
┌──────────────────────────────────────────────────┐
│  ResultService.approveGrade(gradeId, adminId)    │
│  1. Find grade, verify status == SUBMITTED       │
│  2. Update:                                      │
│     - status = APPROVED                          │
│     - approvedBy = adminId                       │
│     - approvedAt = now                           │
│  3. Log via AuditService (action: "APPROVE")     │
└──────────────────────────────────────────────────┘
         │
    OR   ▼
┌──────────────────────────────────────────────────┐
│  ResultService.rejectGrade(gradeId, adminId, dto)│
│  1. Find grade, verify status == SUBMITTED       │
│  2. Update:                                      │
│     - status = DRAFT (back to lecturer)          │
│     - remarks from dto                           │
│  3. Notify lecturer: "Grade rejected, please fix"│
│  4. Log via AuditService (action: "REJECT")      │
└──────────────────────────────────────────────────┘
```

---

## 3. Publishing Flow

**Endpoint:** `POST /results/grades/publish/:semesterId`

```
Admin publishes all approved grades for a semester
         │
         ▼
┌──────────────────────────────────────────────────┐
│  ResultService.publishGrades(semesterId)          │
│  1. Find all APPROVED grades for this semester   │
│  2. Bulk update status = PUBLISHED               │
│  3. For each affected student:                   │
│     - Send notification: "Your results are ready"│
│  4. Log via AuditService                         │
│  5. Return count of published grades             │
└──────────────────────────────────────────────────┘
```

---

## 4. CGPA Calculation

**Endpoint:** `POST /results/cgpa/calculate/:studentId/:semesterId`

```
System calculates GPA/CGPA after results are published
         │
         ▼
┌────────────────────────────────────────────────────────┐
│  ResultService.calculateCGPA(studentId, semesterId)    │
│                                                        │
│  Step 1: Calculate Semester GPA                        │
│  ┌──────────────────────────────────────────────────┐  │
│  │ Get all PUBLISHED grades for student + semester  │  │
│  │ For each grade:                                  │  │
│  │   weightedPoint = gradePoint × course.creditUnits│  │
│  │                                                  │  │
│  │ GPA = Σ(weightedPoints) / Σ(creditUnits)         │  │
│  │                                                  │  │
│  │ Example:                                         │  │
│  │   CSC301 (3 units) → A (5.0) → 15.0             │  │
│  │   MTH301 (3 units) → B (3.5) → 10.5             │  │
│  │   PHY301 (2 units) → AB (4.0) → 8.0             │  │
│  │   Total: 33.5 / 8 = 4.19 GPA                    │  │
│  └──────────────────────────────────────────────────┘  │
│                                                        │
│  Step 2: Calculate Cumulative CGPA                     │
│  ┌──────────────────────────────────────────────────┐  │
│  │ Get all PUBLISHED grades across ALL semesters    │  │
│  │ Same weighted average calculation but cumulative │  │
│  │                                                  │  │
│  │ CGPA = Σ(all weightedPoints) / Σ(all creditUnits)│ │
│  └──────────────────────────────────────────────────┘  │
│                                                        │
│  Step 3: Store CgpaHistory record                      │
│  - semesterId, gpa, cgpa, totalCreditUnits             │
│                                                        │
│  Step 4: Update Student.cgpa (latest snapshot)         │
└────────────────────────────────────────────────────────┘
```

---

## 5. Files to Create

```
src/modules/result/
├── result.module.ts
├── result.controller.ts          # Grade + CGPA routes
├── result.service.ts             # Business logic + CGPA calc
├── dto/
│   ├── create-grade-scale.dto.ts
│   ├── create-grade.dto.ts
│   ├── bulk-grade.dto.ts
│   ├── approve-grade.dto.ts
│   └── query-grade.dto.ts
└── result.service.spec.ts
```

---

## 6. Cross-Module Integration Points

| Direction | Module | Interaction |
| --------- | ------ | ----------- |
| **Consumes** | EnrollmentModule | Verify student enrollment for grade entry |
| **Consumes** | CourseModule | Course credit units for CGPA calculation |
| **Consumes** | AcademicModule | Semester lookup |
| **Consumes** | NotificationModule | Notify students on publish |
| **Consumed by** | EnrollmentModule | Prerequisite check (has student passed course X?) |
| **Consumed by** | ClearanceModule | Academic standing check |
