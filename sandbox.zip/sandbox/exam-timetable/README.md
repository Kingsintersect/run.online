# Exam Timetable — Architecture & Rollout

**Status:** proposed design, 2026-09-13. Closes the gap flagged in
`sandbox/MISSING_BACKEND_APIS.md` §2.12 — a real Nigerian university need (a separate exam
schedule, distinct from the weekly class timetable — different rooms/seating, invigilators,
exam periods) that had **zero backing anywhere**: no model, no bruno collection, not even a
workflow doc, explicitly flagged as "pending a decision on scope." This doc is that decision.

---

## 1. Why this is a separate entity, not an extension of `ClassSchedule`

`ClassSchedule` (see `timetable_README.md`) models a **recurring weekly slot** —
`day_of_week`/`start_time`/`end_time`/`venue` (free-text) repeating every week of a semester.
An exam is a **one-off dated event** — a specific calendar date, not a weekly recurrence — that
additionally needs:

- **Capacity-aware venue booking.** A class slot's free-text `venue: string` has no notion of
  how many students it holds; an exam needs to know a hall seats 200 before scheduling a
  300-student course into it, and needs to detect a genuine double-booking (same venue,
  overlapping date+time) across *different* exams, not just across class slots.
- **Invigilators**, not lecturers. The person supervising an exam is frequently not the course's
  own lecturer.
- **Exam type** — a regular sitting, a makeup, or a resit, each potentially needing different
  reporting/analytics treatment.

Retrofitting `ClassSchedule`'s free-text venue into a capacity-aware model is out of scope here
— that would touch the entire class-timetable feature for no benefit to it. Exams get their own
`Venue` entity instead; `ClassSchedule.venue` stays exactly as it is today.

## 2. The two new entities

### `Venue`

A physical space that can host an exam (and, later, a class — but nothing here requires
migrating `ClassSchedule` to use it). Capacity-aware so scheduling can validate a course's
expected candidate count against the room before double-booking.

### `ExamSchedule`

One exam sitting: which course offering, which date/time, which venue, which invigilators,
what type of sitting. Scoped to a `CourseOffering` (course + semester + session already
resolved through that relation, matching how `ClassSchedule` itself is scoped) rather than
duplicating `courseId`/`semesterId` separately.

## 3. What this doesn't do

- No seating-chart/candidate-list UI — this is scheduling (when/where/who invigilates), not
  candidate allocation within a hall. A future pass can add that once scheduling itself exists.
- No automatic conflict *prevention* — the proposed `check-conflict` endpoint (§ in
  `API_CONTRACTS.md`) lets the admin UI *warn* before double-booking a venue or an invigilator,
  but the create/update endpoints don't hard-reject on conflict server-side in this first pass
  (a genuine institution sometimes deliberately double-books, e.g. splitting a large cohort
  across two simultaneous sittings in the same hall for different courses — an outright DB
  constraint would block that legitimate case).
- Doesn't touch `ClassSchedule`, `TimetableSlot`, or the existing Venue Availability Checker for
  class schedules — those are unrelated, unaffected code paths.

## 4. Rollout

1. `Venue` CRUD — foundational, needed before any `ExamSchedule` can reference one.
2. `ExamSchedule` CRUD + conflict-check endpoint.
3. Frontend: a new "Exams" tab alongside the existing admin Timetable page's Grid/List toggle,
   following the same `ScheduleFormDialog` pattern already established for class schedules.

## 5. Files in this folder

- `SCHEMA_CHANGES.md` — the two new models, Prisma-diff style.
- `API_CONTRACTS.md` — full request/response contracts for both entities' CRUD plus the
  conflict-check endpoint.
