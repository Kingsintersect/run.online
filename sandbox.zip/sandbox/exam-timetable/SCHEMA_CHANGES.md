# Schema Changes — Exam Timetable

New models only — nothing existing is modified. Names inferred from this codebase's existing
conventions (`ClassSchedule`, `CourseOffering`); rename to match your real Prisma schema, the
fields/relations are what matter.

---

## 1. New model — `Venue`

```prisma
model Venue {
  id          Int      @id @default(autoincrement())
  name        String              // "New Hall", "Faculty of Science LT1"
  capacity    Int
  location    String?             // building/block, free text
  isExamHall  Boolean  @default(true)
  isActive    Boolean  @default(true)

  examSchedules ExamSchedule[]

  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt

  @@unique([name])
}
```

No migration risk — new model, no existing data affected.

## 2. New model — `ExamSchedule`

```prisma
enum ExamType {
  REGULAR
  MAKEUP
  RESIT
}

enum ExamScheduleStatus {
  SCHEDULED
  ONGOING
  COMPLETED
  CANCELLED
}

model ExamSchedule {
  id                Int      @id @default(autoincrement())

  courseOfferingId  Int
  courseOffering    CourseOffering @relation(fields: [courseOfferingId], references: [id])

  venueId           Int
  venue             Venue    @relation(fields: [venueId], references: [id])

  examDate          DateTime  // date only, no time component
  startTime         String    // "HH:MM", same convention as ClassSchedule
  endTime           String

  examType          ExamType  @default(REGULAR)
  status            ExamScheduleStatus @default(SCHEDULED)

  invigilatorIds    Int[]     // Lecturer/Staff user ids — no dedicated join
                              // table needed, mirrors how OfferingLecturerAssignment
                              // keeps things simple for a small, unordered set

  notes             String?

  createdAt         DateTime @default(now())
  updatedAt         DateTime @updatedAt

  @@index([venueId, examDate])
  @@index([courseOfferingId])
}
```

New model, no migration risk. `invigilatorIds` as a plain integer array (Postgres native array
type) avoids a join table for what's typically 1-3 people per exam — consistent with keeping
this schema lean per README.md §3's explicit non-goals (no seating-chart complexity in this
pass).

## 3. Summary

| Model | Change | Breaking? |
|---|---|---|
| `Venue` | new model | New |
| `ExamSchedule` (+`ExamType`, +`ExamScheduleStatus`) | new model | New |

Nothing existing is touched — `ClassSchedule`, `TimetableSlot`, and every other model stay
exactly as they are.
