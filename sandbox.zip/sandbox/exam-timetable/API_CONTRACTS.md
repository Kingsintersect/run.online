# API Contracts — Exam Timetable

Full request/response contracts for `SCHEMA_CHANGES.md`. Same conventions as the rest of this
codebase's proposed contracts (bearer auth, `{data: ...}` envelope, standard pagination on list).

---

## 1. `Venue` CRUD

### `POST /timetable/venues`

```jsonc
// Request
{ "name": "New Hall", "capacity": 300, "location": "Main Campus, Block C", "isExamHall": true }

// Response 201
{
  "id": 1, "name": "New Hall", "capacity": 300, "location": "Main Campus, Block C",
  "isExamHall": true, "isActive": true,
  "createdAt": "2026-09-13T09:00:00Z", "updatedAt": "2026-09-13T09:00:00Z"
}
```

### `GET /timetable/venues?isExamHall=true&isActive=true`

```jsonc
{ "data": [ /* Venue rows as above */ ] }
```

### `PATCH /timetable/venues/{id}` / `DELETE /timetable/venues/{id}`

Standard CRUD; `DELETE` blocked (409 `VENUE_HAS_EXAM_SCHEDULES`) while any `ExamSchedule`
references it — same immutable-once-referenced convention `Level` already follows.

---

## 2. `ExamSchedule` CRUD

### `POST /timetable/exams`

```jsonc
// Request
{
  "courseOfferingId": 42,
  "venueId": 1,
  "examDate": "2026-12-08",
  "startTime": "09:00",
  "endTime": "11:00",
  "examType": "REGULAR",
  "invigilatorIds": [7, 12],
  "notes": "Bring calculators, no phones"
}

// Response 201
{
  "id": 5,
  "courseOfferingId": 42,
  "courseCode": "CSC301",
  "courseTitle": "Data Structures",
  "venue": { "id": 1, "name": "New Hall", "capacity": 300 },
  "examDate": "2026-12-08",
  "startTime": "09:00",
  "endTime": "11:00",
  "examType": "REGULAR",
  "status": "SCHEDULED",
  "invigilatorIds": [7, 12],
  "notes": "Bring calculators, no phones",
  "createdAt": "2026-09-13T09:00:00Z",
  "updatedAt": "2026-09-13T09:00:00Z"
}
```

**Validation:** `courseOfferingId` must reference a real `CourseOffering`; `venueId` a real,
active `Venue`. No hard conflict rejection in this first pass — see §3 for the advisory check
the admin UI calls before submitting.

### `GET /timetable/exams?semesterId=&venueId=&courseOfferingId=&from=&to=`

```jsonc
{
  "data": [ /* ExamSchedule shape above */ ],
  "meta": { "total": 1, "page": 1, "limit": 20 }
}
```

`semesterId` filters via the linked `courseOffering.semesterId` — same resolution pattern
`ClassSchedule`'s own semester-scoped queries already use.

### `GET /timetable/exams/my` (Lecturer)

```jsonc
// Every exam this lecturer invigilates OR whose course they teach, upcoming first.
{ "data": [ /* ExamSchedule shape above */ ] }
```

### `PATCH /timetable/exams/{id}` / `DELETE /timetable/exams/{id}`

Standard CRUD. `PATCH` also accepts `{"status": "CANCELLED"}` as a status-only update — no
separate transition endpoint needed for a 4-state enum this simple (unlike `Cohort`'s richer
lifecycle in `program-structure-depth/`).

---

## 3. `GET /timetable/exams/check-conflict`

Advisory only — see README.md §3. Called by the admin form before submit to warn, not block.

```jsonc
// Request: GET /timetable/exams/check-conflict?venueId=1&examDate=2026-12-08&startTime=09:00&endTime=11:00&invigilatorIds=7,12

// Response 200
{
  "venueConflict": {
    "hasConflict": true,
    "conflictingExams": [
      { "id": 3, "courseCode": "MTH201", "startTime": "10:00", "endTime": "12:00" }
    ]
  },
  "invigilatorConflicts": [
    { "userId": 7, "conflictingExams": [ { "id": 3, "courseCode": "MTH201" } ] }
  ]
}
```

---

## 4. Frontend call sites once this ships

(For the frontend implementation plan, not the backend team.)

- New `src/modules/timetable/services/exam-timetable.service.ts` — mirrors
  `timetable.service.ts`'s existing shape/conventions.
- New `src/modules/timetable/types/exam-timetable.types.ts`, `schemas/exam-schedule.schema.ts`.
- New hooks in `src/modules/timetable/hooks/useExamTimetable.ts`.
- New UI: `VenueManager.tsx`, `ExamScheduleFormDialog.tsx`, an "Exams" tab in
  `src/app/(dashboard)/admin/(routes)/timetable/page.tsx` alongside the existing Grid/List
  toggle for class schedules.
- Student/Tutor "My Exams" surfaces, mirroring the existing "My Timetable" pattern.
