# Tutor Onboarding — API Reference

Companion to `user_README.md`. That doc covers the User module in general (Users, Students,
Lecturers, Staff — one at a time). This doc covers **provisioning lecturers/tutors in bulk**, the
reformed flow that replaces "admin manually creates one lecturer at a time" with "registrar hands
over a list, the whole department gets access at once."

Audience: frontend developers building the Tutor Onboarding screens, and the backend team
implementing the endpoints marked **NEW** / **EXTEND** below.

> Everywhere this doc says "tutor" it means the `Lecturer` model / `lecturer` role — `bruno/`,
> the Prisma schema, and `user_README.md` all use "Lecturer"; `"lecturer"` is the accepted role
> name, with `"tutor"` only appearing as an input alias on CSV rows (see §1) and in some
> frontend route/module names (`tutor-courses`, `/tutor` dashboard). This doc uses "Lecturer" for
> anything schema/endpoint-shaped and "tutor" only in prose.

---

## 0. Endpoint audit — what already exists vs. what's new

| # | Endpoint | Status | Used for |
| - | -------- | ------ | -------- |
| 1 | `POST /users/bulk-import` | ✅ Exists — **extend** (§1) | CSV import → User + Lecturer + role + department, one call |
| 2 | `GET /users/lecturers` | ✅ Exists — **extend** (§4) | List/search tutors, filter by onboarding status |
| 3 | `GET /users/lecturers/:id` | ✅ Exists as-is | Admin view of one tutor |
| 4 | `GET /users/lecturers/me` | ⚠️ Requested, not shipped (see `MISSING_BACKEND_APIS.md` §1.1b) | Tutor's own profile/id after login |
| 5 | `POST /users/lecturers` | ✅ Exists as-is | Edge case: promote an *existing* user (e.g. a staff member) to lecturer one at a time |
| 6 | `PATCH /users/lecturers/:id` | ✅ Exists as-is | Admin fallback — reassign department/designation without recreating the account |
| 7 | `POST /courses/offerings/:offeringId/lecturers` | ✅ Exists as-is | Assign a tutor to a course offering |
| 8 | `DELETE /courses/offerings/:offeringId/lecturers/:lecturerId` | ✅ Exists as-is | Remove a course assignment |
| 9 | `GET /courses/offerings?lecturerId=` (enriched) | ⚠️ Partly shipped — enrichment spec'd in `sandbox/course/missing_course_offering_enrichment.readme.md` | "My assigned courses" checklist step; course-assignment dialog |
| 10 | `GET /academic/departments` | ✅ Exists as-is | Department picker; CSV `departmentId` validation reference |
| 11 | `POST /notifications`, `POST /notifications/bulk` | ✅ Exists as-is | Fallback: manually (re)send an onboarding notification |
| 12 | `POST /notifications/templates` | ✅ Exists as-is | Define the "Tutor Welcome" email template once |
| 13 | `POST /moodle-sync/users/push`, `POST /moodle-sync/users/push-bulk` | ✅ Exists as-is | Step 7 — sync new tutors into Moodle as teachers |
| 14 | `POST /auth/forgot-password` / `POST /auth/reset-password` | ✅ Exists as-is | Self-service reset if a tutor forgets their (already-changed) password later |
| 15 | `POST /users/lecturers/:id/resend-invite` | 🆕 **New** (§2) | Admin fallback — regenerate + resend credentials for one straggler |
| 16 | `mustResetPassword` on User / login / `/auth/me` + `POST /auth/change-password` | 🆕 **New** (§3) | Force a password change on first login |
| 17 | `onboardingProgress` on Lecturer + `PATCH /users/lecturers/me/onboarding` | 🆕 **New** (§4) | In-app first-login checklist, persisted per tutor |

Full contracts for the ✅ existing rows are already correct in `bruno/user/`, `bruno/course/`,
`bruno/moodle-sync/`, `bruno/notification/`, and `bruno/auth/` — reuse them as documented there and
in `user_README.md`. Only the 🆕 rows are specified below; they are additive and don't change any
existing response shape.

---

## 1. `POST /users/bulk-import` (extend)

**Already implemented.** Admin/HOD uploads a CSV of new users; the backend creates the `User` +
role, and for `tutor`/`staff` rows the profile record too, in one pass. This is the endpoint that
replaces one-by-one lecturer signup — no new endpoint is needed for the import itself, only two
additive request fields and a response tweak so it can also handle onboarding email dispatch.

**Request: `multipart/form-data`**

```ts
{
  file: File;                    // .csv or .txt, max 10MB
  sendWelcomeEmail?: boolean;    // NEW — default false (today's behavior, unchanged)
  loginUrl?: string;             // NEW — interpolated into the welcome email; falls back to a configured portal URL
  templateId?: number;           // NEW — NotificationTemplate id; falls back to a built-in "tutor_welcome_email" template
}
```

> Multipart form fields are transmitted as strings, and the backend's boolean validation
> rejects the literals `"true"` / `"false"` — send `sendWelcomeEmail` as `"1"` / `"0"`. The
> frontend `apiClient` handles this automatically when a request uses `contentType:
> "multipart"` (booleans in the body become `"1"` / `"0"`, `File`s pass through, empty fields
> are dropped).

**CSV columns** (case/spacing-insensitive header matching):

| Column | Required | Notes |
| ------ | -------- | ----- |
| `email` | Yes | Row's User identity — also the match key for existing users |
| `role` | Yes | `tutor` (alias for `lecturer`), `staff`, `student`, or a "plain" role (`guest`, `bursary`, `hod`) |
| `firstName` | Yes | |
| `middleName` | No | |
| `lastName` | Yes | |
| `phoneNumber` | No | |
| `username` | No | Generated from email local-part if omitted |
| `password` | No | If omitted, backend generates one — see §3 for what happens to it |
| `staffNumber` | Tutor/staff rows | Unique across Lecturer + Staff |
| `departmentId` | Tutor rows | Must reference a real `Department` — `GET /academic/departments` first |
| `designation` | Tutor/staff rows | e.g. "Lecturer II", "Senior Lecturer" |
| `jobTitle` | Staff rows | |
| `admissionId` | Student rows only | Student rows require an already-existing user + accepted admission — never fabricated from a row |

**Sample rows:**

```csv
email,role,firstName,middleName,lastName,phoneNumber,staffNumber,departmentId,designation
grace.hopper@qhub.local,tutor,Grace,,Hopper,08067890123,LEC-0042,3,Senior Lecturer
ada.lovelace@qhub.local,tutor,Ada,,Lovelace,08023456780,LEC-0043,3,Lecturer I
```

**Response: `200 OK`**

```ts
{
  data: {
    total: number;
    succeeded: number;
    failed: number;
    results: {
      row: number;
      email: string;
      role: string;
      success: boolean;
      action: "created" | "updated" | "skipped" | "failed";
      userId: number | null;
      error?: string;
      generatedPassword?: string;   // present ONLY if sendWelcomeEmail is false/omitted AND no password was supplied for the row
      emailSent?: boolean;          // NEW — present when sendWelcomeEmail=true; true/false per row
      emailError?: string;          // NEW — present when emailSent=false
    }[];
  };
}
```

**Behavior change when `sendWelcomeEmail: true`:** for every row that creates or updates a
User with a system-generated password, the backend sends that password directly in the welcome
email (see §3 for the recommended template) and **omits `generatedPassword` from the HTTP
response entirely** — the temp password is never rendered in the admin's browser or written to
any frontend state/log. This is the default the frontend should use; `sendWelcomeEmail: false` is
kept only for scripted/offline imports where an admin genuinely wants the passwords back
(e.g. to print physical onboarding slips).

---

## 2. `POST /users/lecturers/:id/resend-invite` — NEW

Admin/HOD fallback for a tutor who never received or lost their onboarding email (bounced,
spam-filtered, wrong inbox). Regenerates credentials and resends — no manual password handling by
the admin at any point.

**Auth:** Admin, HOD

**Request Body:**

```ts
{
  loginUrl?: string;    // same override as bulk-import
  templateId?: number;  // same override as bulk-import
}
```

**Behavior:**
1. Generate a new random password for the Lecturer's linked `User`.
2. Set `mustResetPassword = true` (§3) and revoke all of that user's existing refresh tokens
   (mirrors `POST /auth/reset-password`'s existing revoke behavior) — any device currently logged
   in with the old password is signed out.
3. Send the onboarding email via the Notification module with the new password.

**Response: `201 Created`**

```ts
{
  data: {
    userId: number;
    email: string;
    emailSent: boolean;
    sentAt: string;   // ISO timestamp
  };
}
```

No password field — same rule as §1's `sendWelcomeEmail: true` path.

---

## 3. Forced password reset on first login — NEW

**Schema:** add `mustResetPassword: boolean` (default `false`) to `User`.

**Set to `true` by:**
- `POST /users/bulk-import`, for any row where the backend generated the password
- `POST /users/lecturers/:id/resend-invite`
- (Future-proofing, not required now) any other admin flow that creates a User with a
  system-generated rather than admin-typed password

**Surfaced on:**
- Every `POST /auth/login/*` response — add `mustResetPassword: boolean` alongside the existing
  `user` object
- `GET /auth/me` — add `mustResetPassword: boolean` to the response documented in
  `auth_README.md`

**New endpoint — `POST /auth/change-password`** (Authenticated, self)

Distinct from the existing `POST /auth/reset-password`, which is the *unauthenticated*,
token-based flow reached via "Forgot Password." This one is for an already-logged-in user (using
their temporary password) who wants to set a new one directly.

**Request Body:**

```ts
{
  currentPassword: string;
  newPassword: string;   // same strength rules as registration
}
```

**Response: `200 OK`**

```ts
{
  message: "Password changed successfully";
}
```

**Behavior:** verifies `currentPassword`, sets the new password hash, clears
`mustResetPassword`, and revokes all *other* refresh tokens (keeps the current session valid, per
the pattern already used elsewhere in Auth — reasonable default, confirm with backend).

**Frontend contract:** on login, if `mustResetPassword: true` comes back, redirect straight to a
"Set Your Password" screen before anything else in the dashboard renders — same idea as
`useRoleGuard`, but gating on this flag instead of role.

---

## 4. First-login checklist, persisted — NEW

**Schema:** add `onboardingProgress` (JSON) to `Lecturer`:

```ts
{
  profileConfirmed: boolean;
  coursesConfirmed: boolean;
  firstAnnouncementPosted: boolean;
}
```

Defaults to all-`false` on creation (bulk-import or `POST /users/lecturers`).

**Read path:** once `GET /users/lecturers/me` ships (already requested, §0 row 4), its response
gains `onboardingProgress` — no separate read endpoint needed. Until then, `GET
/users/lecturers/:id` (self-accessible per `user_README.md`) also carries it.

**Write — `PATCH /users/lecturers/me/onboarding`** (Self only)

```ts
// Request
{
  step: "profileConfirmed" | "coursesConfirmed" | "firstAnnouncementPosted";
}

// Response: 200 OK
{
  data: {
    profileConfirmed: boolean;
    coursesConfirmed: boolean;
    firstAnnouncementPosted: boolean;
  };
}
```

Idempotent — marking an already-`true` step just returns the current state. Only ever sets a
step `true`; there's no "un-complete" action.

**Admin visibility — extend `GET /users/lecturers`:**
- Each row in `data[]` gains `onboardingProgress` (or a single derived `onboardingComplete:
  boolean`, whichever is cheaper server-side — either works for the frontend)
- New optional query param `onboardingComplete?: boolean` to filter the list down to stragglers
  worth following up with (candidates for §2's resend-invite)

---

## 5. Auth summary

| Endpoint | Roles |
| -------- | ----- |
| `POST /users/bulk-import` | super_admin, admin, hod |
| `POST /users/lecturers/:id/resend-invite` | admin, hod |
| `POST /auth/change-password` | any authenticated user (self) |
| `PATCH /users/lecturers/me/onboarding` | lecturer (self) |
| `GET /users/lecturers` (with `onboardingComplete` filter) | admin, staff |

Per this project's RBAC rule (`CLAUDE.md` §5): none of the above should be gated by
`if (role === 'ADMIN')` in the frontend — gate on permissions (`users.manage`,
`departments.manage`, etc.) via `usePermissions`/`<PermissionGate>`, same as every other module.
SUPER_ADMIN implicitly has all of these per the standing "SUPER_ADMIN has full access" rule.

---

## 6. Frontend types (for `modules/user-management/types/` or a new `modules/tutor-onboarding/types/`)

```ts
interface BulkImportRow {
  row: number;
  email: string;
  role: string;
  success: boolean;
  action: "created" | "updated" | "skipped" | "failed";
  userId: number | null;
  error?: string;
  generatedPassword?: string;
  emailSent?: boolean;
  emailError?: string;
}

interface BulkImportResult {
  total: number;
  succeeded: number;
  failed: number;
  results: BulkImportRow[];
}

interface OnboardingProgress {
  profileConfirmed: boolean;
  coursesConfirmed: boolean;
  firstAnnouncementPosted: boolean;
}

type OnboardingStep = keyof OnboardingProgress;

interface ResendInviteResult {
  userId: number;
  email: string;
  emailSent: boolean;
  sentAt: string;
}
```

See `tutor_onboarding_workflow.md` for how these fit into the end-to-end flow and which files own
them.
