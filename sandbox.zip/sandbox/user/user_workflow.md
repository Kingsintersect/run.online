# User Module — Implementation Workflow

This document explains the internal implementation flow for the User module. It is intended for developers building or maintaining this module.

---

## Core Concept

The `User` table is an **auth-only** table. It stores credentials (`email`, `username`, `passwordHash`) and basic profile fields that may be populated later. The three profile types (Student, Lecturer, Staff) each have their own table linked via `userId`.

**Who creates what:**

| Record Type | Created By | When |
| ----------- | ---------- | ---- |
| **User** | Auth Module | At registration (email + username + password only) |
| **Student** | Payment Module | Automatically, when tuition payment is verified |
| **Lecturer** | User Module | Admin selects an existing user + fills lecturer form |
| **Staff** | User Module | Admin selects an existing user + fills staff form |

---

## 1. List/Get Users (Admin)

**Endpoint:** `GET /users`, `GET /users/:id`

```
Admin requests user list
         │
         ▼
┌──────────────────────────────────────────────────┐
│  UserService.findAll(filters)                    │
│  1. Build Prisma query with:                     │
│     - search (email, username, firstName,        │
│       lastName — nullable, use conditional where) │
│     - isActive filter                            │
│     - pagination (skip, take)                    │
│  2. Include: roles (via UserRole → Role)         │
│  3. Return paginated list with meta              │
└──────────────────────────────────────────────────┘
```

**Note:** `firstName` and `lastName` can be `null` for users who just registered but haven't gone through admission or been assigned a role yet. The frontend should handle displaying these as "—" or "No name".

---

## 2. Create Lecturer (Admin)

**Endpoint:** `POST /users/lecturers`

```
Admin searches Users → selects one → fills lecturer form
         │
         ▼
┌──────────────────────────────────────────────────┐
│  UserController.createLecturer(dto)              │
│  - Validate CreateLecturerDto                    │
│  - dto.userId must be an existing User           │
└────────────┬─────────────────────────────────────┘
             │
             ▼
┌──────────────────────────────────────────────────┐
│  UserService.createLecturer(dto)                 │
│                                                  │
│  Transaction:                                    │
│  ┌────────────────────────────────────────────┐  │
│  │ 1. Verify User exists by dto.userId        │  │
│  │    - Not found → 404                       │  │
│  │    - Already has Lecturer record → 409     │  │
│  │                                            │  │
│  │ 2. Update User record:                     │  │
│  │    - firstName = dto.firstName             │  │
│  │    - lastName = dto.lastName               │  │
│  │    - middleName = dto.middleName           │  │
│  │    - phoneNumber = dto.phoneNumber         │  │
│  │                                            │  │
│  │ 3. Create Lecturer record:                 │  │
│  │    - userId = dto.userId                   │  │
│  │    - staffNumber = dto.staffNumber         │  │
│  │    - departmentId = dto.departmentId       │  │
│  │    - designation, specialization, etc.     │  │
│  │    - Bio-data fields                       │  │
│  │                                            │  │
│  │ 4. Assign "lecturer" role:                 │  │
│  │    - Find Role where name = "lecturer"     │  │
│  │    - Create UserRole { userId, roleId }    │  │
│  └────────────────────────────────────────────┘  │
│                                                  │
│  5. Log via AuditService (action: "CREATE",      │
│     entityType: "Lecturer")                      │
│  6. Return lecturer with user data               │
└──────────────────────────────────────────────────┘
```

---

## 3. Create Staff (Admin)

**Endpoint:** `POST /users/staff`

Same pattern as "Create Lecturer" above, but:
- Creates a `Staff` record instead of `Lecturer`
- Assigns a staff role (e.g., `"staff"`, `"registrar"`, etc.)
- Staff-specific fields: `staffNumber`, `jobTitle`, `designation`, `departmentId` (optional)

---

## 4. Student Record Creation (NOT in User Module)

Students are **never** created directly via the User module. The flow is:

```
Registration (Auth)
       │
       ▼
Pay Application Fee (Payment)
       │
       ▼
Submit Application (Admission)   ← links to userId
       │
       ▼
Admin Review → ADMITTED
       │
       ▼
Accept Offer → Pay Acceptance Fee → Pay Tuition
       │
       ▼
┌──────────────────────────────────────────────────┐
│  PaymentService.onTuitionPaymentVerified()       │
│  (THIS creates the Student record)               │
│  1. Look up user's Admission + Application       │
│  2. Pull bio-data from AdmissionApplication      │
│  3. Create Student record linked to userId       │
│  4. Generate matricNumber                        │
│  5. Assign "student" role                        │
│  6. Backfill studentId on all user invoices      │
└──────────────────────────────────────────────────┘
```

The User module only provides **read** and **update** endpoints for students.

---

## 5. Update Student Profile

**Endpoint:** `PATCH /users/students/:id`

```
Student or Admin updates profile
         │
         ▼
┌──────────────────────────────────────────────────┐
│  UserService.updateStudent(id, dto)              │
│  1. Find Student by ID                           │
│     - Not found → 404                            │
│  2. If Self: verify JWT userId === student.userId │
│  3. Update only provided fields:                 │
│     - Student fields: currentLevelId, modeOfStudy│
│       status, contactAddress, etc.               │
│     - User fields (via relation): phoneNumber    │
│  4. Log via AuditService                         │
│  5. Return updated student                       │
└──────────────────────────────────────────────────┘
```

---

## 6. Files to Create

```
src/modules/user/
├── user.module.ts              # Module definition
├── user.controller.ts          # Routes for all user types
├── user.service.ts             # Business logic
├── dto/
│   ├── create-lecturer.dto.ts  # userId + personal + lecturer fields
│   ├── create-staff.dto.ts     # userId + personal + staff fields
│   ├── update-student.dto.ts   # optional student fields
│   ├── update-lecturer.dto.ts
│   ├── update-staff.dto.ts
│   └── query-users.dto.ts      # search, isActive, pagination
└── user.service.spec.ts
```

---

## 7. Cross-Module Integration Points

| Direction | Module | Interaction |
| --------- | ------ | ----------- |
| **Consumes** | AuthModule | Role assignment (UserRole creation) |
| **Consumes** | PrismaService | Direct DB access for User, Student, Lecturer, Staff |
| **Consumed by** | Enrollment | Student lookup for enrollment |
| **Consumed by** | Result | Student lookup for grade entry |
| **Consumed by** | Hostel | Student lookup for room allocation |
| **Consumed by** | Document | Student lookup for document upload |
| **Consumed by** | Clearance | Student lookup for clearance requests |
| **Consumed by** | Moodle | Student lookup for Moodle sync |

---

## 8. Important Considerations

- **Null names:** After registration, `firstName` and `lastName` are `null`. Any endpoint that returns user data must handle this gracefully.
- **Duplicate protection:** Before creating Lecturer/Staff, check that the user doesn't already have a record of that type.
- **Staff number uniqueness:** `staffNumber` is unique across both Lecturer and Staff tables — validate across both.
- **Gender matching:** For hostel allocation, the student's gender from their Admission Application is used. Ensure it's accessible.
