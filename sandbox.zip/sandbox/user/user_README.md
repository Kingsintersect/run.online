# User Module

Manages user profiles for the three user types: **Students**, **Lecturers**, and **Staff**. The `User` model holds shared account data (email, username) while the type-specific models hold role-specific fields and bio-data.

## Models Owned

- **User** — core account / auth data (shared across all user types)
- **Student** — student profile + bio-data (created automatically after admission payment verification)
- **Lecturer** — lecturer profile + bio-data (created by admin from an existing user)
- **Staff** — staff profile + bio-data (created by admin from an existing user)

---

## Endpoints

### Users (Admin)

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/users` | List all users (paginated, filterable) | Admin |
| `GET` | `/users/:id` | Get user by ID with profile | Admin |
| `PATCH` | `/users/:id` | Update user account fields | Admin |
| `DELETE` | `/users/:id` | Soft-delete or deactivate a user | Admin |

### Students

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/users/students` | List all students (paginated, filterable) | Admin, Staff |
| `GET` | `/users/students/:id` | Get student profile with user data | Admin, Staff, Self |
| `PATCH` | `/users/students/:id` | Update student profile | Admin, Self |
| `GET` | `/users/students/matric/:matricNumber` | Find student by matric number | Admin, Staff |

> **Note:** Student records are NOT created directly. They are created automatically when an admitted applicant's tuition payment is verified. 

### Lecturers

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/users/lecturers` | List all lecturers (paginated, filterable) | Admin, Staff |
| `GET` | `/users/lecturers/:id` | Get lecturer profile with user data | Admin, Staff, Self |
| `POST` | `/users/lecturers` | Assign lecturer role to an existing user | Admin |
| `PATCH` | `/users/lecturers/:id` | Update lecturer profile | Admin, Self |

### Staff

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/users/staff` | List all staff (paginated, filterable) | Admin |
| `GET` | `/users/staff/:id` | Get staff profile with user data | Admin, Self |
| `POST` | `/users/staff` | Assign staff role to an existing user | Admin |
| `PATCH` | `/users/staff/:id` | Update staff profile | Admin, Self |

---

## Request & Response Types

### `GET /users`

**Query Parameters:**

```ts
{
  search?: string;        // search by name, email, or username
  isActive?: boolean;
  page?: number;
  limit?: number;
}
```

**Response: `200 OK`**

```ts
{
  data: {
    id: number;
    email: string;
    username: string;
    firstName: string | null;
    middleName: string | null;
    lastName: string | null;
    phoneNumber: string | null;
    avatar: string | null;
    isActive: boolean;
    isVerified: boolean;
    lastLoginAt: string | null;
    createdAt: string;
  }[];
  meta: { total: number; page: number; limit: number };
}
```

---

### `POST /users/lecturers`

Admin selects an existing user from the Users list and fills a form with lecturer-specific details. The backend creates the `Lecturer` record linked to that user and assigns the `lecturer` role.

**Request Body (`CreateLecturerDto`):**

```ts
{
  userId: number;                 // existing user ID (admin selects from user list)
  // Personal details (updates User record)
  firstName: string;              // max 100 chars
  middleName?: string;
  lastName: string;               // max 100 chars
  phoneNumber?: string;
  // Lecturer fields
  staffNumber: string;            // unique, max 30 chars
  departmentId: number;
  designation: string;            // max 100 chars
  specialization?: string;
  officeLocation?: string;
  officePhone?: string;
  // Bio-data
  dateOfBirth?: string;
  gender?: "MALE" | "FEMALE";
  nationality?: string;
  stateOfOrigin?: string;
  qualifications?: string;
  researchAreas?: string;
  publications?: string;
  bio?: string;
}
```

> **Flow:** Admin searches Users → selects a user → fills the lecturer form → backend creates Lecturer record, updates User with name/phone, and assigns the `lecturer` role.

**Response: `201 Created`** — returns the created lecturer with user data.

---

### `POST /users/staff`

Admin selects an existing user from the Users list and fills a form with staff-specific details. The backend creates the `Staff` record linked to that user and assigns the appropriate staff role.

**Request Body (`CreateStaffDto`):**

```ts
{
  userId: number;                 // existing user ID (admin selects from user list)
  // Personal details (updates User record)
  firstName: string;              // max 100 chars
  middleName?: string;
  lastName: string;               // max 100 chars
  phoneNumber?: string;
  // Staff fields
  staffNumber: string;            // unique, max 30 chars
  departmentId?: number;
  designation: string;            // max 100 chars
  jobTitle: string;               // max 100 chars
  officeLocation?: string;
  officePhone?: string;
  // Bio-data
  dateOfBirth?: string;
  gender?: "MALE" | "FEMALE";
  nationality?: string;
  stateOfOrigin?: string;
}
```

> **Flow:** Admin searches Users → selects a user → fills the staff form → backend creates Staff record, updates User with name/phone, and assigns the appropriate role.

**Response: `201 Created`** — returns the created staff with user data.

---

## Notes for Developers

- **Student records** are NOT created via the User module. Students are only created when an admitted applicant's tuition payment is verified (see Admission + Payment modules).
- **Lecturer/Staff creation** always references an existing `User` record. The admin searches and selects a user, fills the role-specific form, and the backend:
  1. Updates the User record with `firstName`, `lastName`, `phoneNumber` (if provided)
  2. Creates the Lecturer/Staff record linked to `userId`
  3. Assigns the appropriate role via the `UserRole` table
- The `User` model holds authentication data (email, passwordHash). Profile models reference `userId`.
- Use `StudentStatus` enum to manage student lifecycle (ACTIVE → GRADUATED, etc.).
