# Tutor Onboarding — Workflow

Companion to `tutor_onboarding_README.md` (the API contract) and `user_workflow.md` (the User
module's internal implementation flow). This doc explains the **end-to-end process** — what
happens, in what order, who triggers each step, and which files it touches on the frontend.

---

## Why this exists

The current flow (`user_workflow.md` §2, `TutorList.tsx`) requires an admin to already know an
existing `User.id` and manually type it into a form — the registrar's list has to be turned into
individual self-registrations first, one at a time, before a lecturer can be assigned. That's the
thing being replaced. The reformed flow is:

> **bulk import → auto-generated credentials → role + department assigned at creation → one
> onboarding email → in-app first-login checklist → admin fallback for edits → optional Moodle
> sync in the same pipeline.**

Every numbered step below maps 1:1 to that list.

---

## 1. Bulk import, not one-by-one signup

```
Registrar/HOD hands admin a list (name, staff ID, department, email, phone)
         │
         ▼
Admin opens Tutor Onboarding screen → downloads/fills the CSV template
         │
         ▼
Admin uploads the CSV, ticks "Send welcome email"
         │
         ▼
POST /users/bulk-import  (multipart: file, sendWelcomeEmail: true)
         │
         ▼
┌────────────────────────────────────────────────────────┐
│ Backend, per row:                                       │
│  1. Match/create User by email                          │
│  2. role="tutor" → create Lecturer (needs departmentId)  │
│  3. Assign "lecturer" role via UserRole                  │
│  4. No password in row → generate one                    │
│  5. sendWelcomeEmail=true → dispatch onboarding email,    │
│     omit password from the HTTP response entirely        │
└────────────────────────────────────────────────────────┘
         │
         ▼
Admin sees a per-row result table: created / updated / failed,
with a reason for every failure (bad departmentId, duplicate
staffNumber, etc.) — nothing silently dropped
```

Existing users are never asked to "register" themselves into a role — the account, profile,
department, and role all land in one transaction per row.

---

## 2. Auto-generate credentials, don't make them set a password first

Handled entirely by `POST /users/bulk-import` + the `mustResetPassword` flag
(`tutor_onboarding_README.md` §3) — no separate provisioning step. The password is generated
server-side and never surfaced to the admin when `sendWelcomeEmail: true` (the frontend default).
On the tutor's first successful login, the login response carries `mustResetPassword: true`; the
frontend must intercept that **before** rendering the dashboard shell:

```
Login (any variant) → mustResetPassword: true in response
         │
         ▼
Redirect to /set-password (new route, outside the (dashboard) group)
         │
         ▼
POST /auth/change-password { currentPassword, newPassword }
         │
         ▼
mustResetPassword cleared → redirect to roleDashboardPath[role]
```

This is the same shape as `useRoleGuard`'s redirect-on-mismatch pattern, but the check happens
once, right after login, ahead of any role routing.

---

## 3. Assign role + department at creation, not after

Already true of `POST /users/bulk-import` for tutor rows — `role: tutor` and `departmentId` are
required CSV columns, so there is no "no permissions" limbo window between account creation and
role assignment; both happen in the same backend transaction. Nothing further needed here beyond
what §1 already covers — this point exists in the workflow purely to confirm the requirement is
satisfied by design, not to add a step.

---

## 4. Send one clear onboarding email

**Template** (create once via `POST /notifications/templates`, reuse forever):

```json
{
  "name": "tutor_welcome_email",
  "subject": "Welcome to QHub, {{firstName}}",
  "body": "Hi {{firstName}},\n\nYour QHub lecturer account is ready.\n\nLogin: {{loginUrl}}\nTemporary password: {{tempPassword}}\n\nFirst steps:\n1. Log in and set your own password.\n2. Check your assigned courses.\n3. Post your first announcement to a class.\n\nQuestions? Contact the registrar's office.",
  "channel": "EMAIL"
}
```

`{{tempPassword}}` and `{{loginUrl}}` are per-row/per-call variables the backend resolves at send
time from the bulk-import row / resend-invite call — same interpolation mechanism already
documented in `Templates - Create.bru`, just fed row-specific values instead of only user fields.
Capture the returned `templateId` once and reuse it as the default for both `sendWelcomeEmail`
(§1) and `resend-invite` (§6) — no need to pass it explicitly every time.

No separate manual step required beyond ticking "Send welcome email" in §1 — this section exists
to pin down the template content the backend team should ship, not a new UI action.

---

## 5. Give them a short first-login checklist inside the portal

```
Tutor logs in (post password-reset, §2)
         │
         ▼
Dashboard shell checks GET /users/lecturers/me → onboardingProgress
         │
         ▼
Any step false → render dismissible 3-step banner/widget:
   ☐ Confirm profile        ☐ Confirm assigned courses        ☐ Post first announcement
         │
         ▼
Tutor completes a step (views profile / views course list / posts to content module)
         │
         ▼
PATCH /users/lecturers/me/onboarding { step: "..." }
         │
         ▼
All three true → banner stops rendering (checked on every load, not dismissed client-side only —
persisted server-side so it doesn't reappear on another device/browser)
```

**Frontend home:** `modules/tutor-courses/components/OnboardingChecklist.tsx` (or a new
`modules/tutor-onboarding/components/` if the checklist grows beyond a single widget — see §8).
Rendered once, near the top of `app/(dashboard)/tutor/layout.tsx`.

---

## 6. Have an admin fallback for edits

Two distinct fallback needs, two distinct existing/new endpoints — don't conflate them:

| Need | Endpoint | Notes |
| ---- | -------- | ----- |
| Tutor's department/designation changed | `PATCH /users/lecturers/:id` | Already exists — update in place, no delete/recreate |
| Tutor's course load changed | `POST` / `DELETE /courses/offerings/:offeringId/lecturers[/:lecturerId]` | Already exists — `TutorCoursesPanel` in `TutorList.tsx` already implements this pattern for one lecturer at a time |
| Tutor should lose/regain portal access | `PATCH /users/:id { isActive }` | Already exists — `TutorList.tsx`'s row-level Deactivate/Reactivate action (`useSetUserActive`), with a `ConfirmDialog`. This is the reversible alternative to `DELETE /users/:id`'s hard soft-delete: the Lecturer record, course assignments, and history are untouched, only login access flips. Same action was added to `StaffList.tsx`/`StudentList.tsx` for consistency. |
| Tutor never got/lost their onboarding email | `POST /users/lecturers/:id/resend-invite` | **New**, §2 of the README — regenerates + resends, no password ever touches the admin's screen |

The `onboardingComplete=false` filter on `GET /users/lecturers` (README §4) is what surfaces
which tutors are candidates for the resend-invite fallback — surface it as a filter chip on the
Tutors list, e.g. "Pending first login".

---

## 7. Optional but valuable: bulk Moodle account sync

```
Bulk import finishes (§1) → admin reviews the result table
         │
         ▼
Admin selects the successfully-created rows (or "select all succeeded")
         │
         ▼
POST /moodle-sync/users/push-bulk { userIds: [...] }
         │
         ▼
Each pushed user gets a Moodle account; teacher-role mapping happens
on the Moodle-sync side per its own category/course mapping (see
moodle_sync sandbox docs — out of scope here beyond triggering the push)
```

Kept as a **separate, explicit action** after reviewing the import results rather than an
automatic side effect of `POST /users/bulk-import` — a failed/partial Moodle push shouldn't be
able to roll back or block portal account creation, and the admin should see the portal-side
result before deciding to push. If a future need arises to fully automate this, it belongs in
`moodle_sync`'s own workflow doc, not here.

---

## 8. Frontend structure — where this lives

Current state (`user-management` module) already deviates from `CLAUDE.md`'s module structure in
a way worth fixing during this refactor, not perpetuating:

- `TutorList.tsx` calls hooks from `../hooks/useUsersData.ts`, which import query options from
  **`@/services/usersApi`** (global) instead of a module-scoped `services/user.service.ts` +
  `hooks/query-keys.ts`.
- `CreateUserModal.tsx` calls `adminCreateUser` from **`@/lib/auth/backendAuth`** (global) instead
  of a module service.

Per `CLAUDE.md` §3–4, this belongs in `modules/[domain]/`, not `/lib` or a bare `/services` at
the src root (2+ module reuse is the only bar for global — user-management, auth, and the tutor
dashboard don't all need the same client). **This doc doesn't fix that** (out of scope — docs +
audit only, per the current task), but flags it per §11 (Communication) so whoever implements the
endpoints above doesn't build new code on top of the same structural conflict. Recommended target
for the new pieces specifically:

```
src/modules/user-management/           # existing — bulk import + resend-invite belong here,
├── services/                          # they operate on the same Lecturer/User records as
│   └── tutor-onboarding.service.ts    # TutorList.tsx already manages
├── schemas/
│   └── bulk-import.schema.ts          # zod schema for the CSV-upload form (file + sendWelcomeEmail + loginUrl)
├── hooks/
│   ├── query-keys.ts                  # NEW — usersKeys factory currently lives in @/services/usersApi;
│   │                                  #   move it here so this module owns its own keys
│   ├── use-bulk-import.ts             # POST /users/bulk-import
│   └── use-resend-invite.ts           # POST /users/lecturers/:id/resend-invite
└── components/
    ├── BulkImportModal.tsx            # CSV upload + sendWelcomeEmail toggle + per-row result table
    └── ResendInviteButton.tsx         # row action in TutorList.tsx

src/modules/tutor-courses/              # existing — self-service checklist belongs here,
├── hooks/                             # it's tutor-facing, not admin-facing
│   └── use-onboarding-progress.ts     # GET .../me (once shipped) + PATCH .../me/onboarding
└── components/
    └── OnboardingChecklist.tsx
```

Every form in `BulkImportModal.tsx` still needs `zod` + `zodResolver` per `CLAUDE.md` §4 —
validate `sendWelcomeEmail: boolean`, `loginUrl: string().url().optional()`, and the file itself
(type/size) client-side before the multipart request goes out, even though the backend
re-validates too.

---

## 9. Error handling notes

- **Partial success is the normal case, not an error.** A 200 from `bulk-import` with `failed >
  0` is not a toast-worthy failure — render the per-row table so the admin can fix just the bad
  rows (typically a wrong `departmentId`) and re-upload only those.
- **`resend-invite` failure** (e.g. the email provider is down) should surface `emailError`
  inline on that tutor's row, not as a silent no-op — the admin needs to know whether to try
  again or fall back to telling the tutor to use "Forgot Password" once they know their email
  went through in principle (registration succeeded, just not the email).
- **`mustResetPassword` redirect must not be skippable** — a tutor who closes the "Set Your
  Password" tab and re-logs-in should land back on it, not the dashboard. Check the flag on every
  login response and on session rehydration (`app.store.ts`), not just once at login time.

---

## 10. Summary — endpoints this workflow depends on

See `tutor_onboarding_README.md` §0 for the full table. In implementation order:

1. `POST /users/bulk-import` (extend) — the core of §1–§3
2. `POST /notifications/templates` — one-time setup for §4
3. `mustResetPassword` + `POST /auth/change-password` — §2
4. `onboardingProgress` + `PATCH /users/lecturers/me/onboarding` (+ `GET /users/lecturers/me`,
   already tracked separately) — §5
5. `POST /users/lecturers/:id/resend-invite` — §6
6. `POST /moodle-sync/users/push-bulk` (already exists, no change) — §7
