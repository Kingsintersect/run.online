# Hostel Module

Manages hostels, blocks, rooms, and student room allocations.

## Models Owned

- **Hostel** — hostel buildings (male/female)
- **HostelBlock** — blocks/wings within a hostel
- **HostelRoom** — individual rooms within blocks
- **HostelAllocation** — student-to-room assignments per session

---

## Endpoints

### Hostels

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/hostels` | List all hostels | Authenticated |
| `GET` | `/hostels/:id` | Get hostel with blocks | Authenticated |
| `POST` | `/hostels` | Create a hostel | Admin |
| `PATCH` | `/hostels/:id` | Update a hostel | Admin |
| `DELETE` | `/hostels/:id` | Deactivate a hostel | Admin |

### Blocks

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/hostels/:hostelId/blocks` | List blocks in a hostel | Authenticated |
| `GET` | `/hostels/blocks/:id` | Get block with rooms | Authenticated |
| `POST` | `/hostels/:hostelId/blocks` | Create a block | Admin |
| `PATCH` | `/hostels/blocks/:id` | Update a block | Admin |
| `DELETE` | `/hostels/blocks/:id` | Deactivate a block | Admin |

### Rooms

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/hostels/blocks/:blockId/rooms` | List rooms in a block | Authenticated |
| `GET` | `/hostels/rooms/:id` | Get room details with current occupants | Authenticated |
| `POST` | `/hostels/blocks/:blockId/rooms` | Create a room | Admin |
| `POST` | `/hostels/blocks/:blockId/rooms/bulk` | Bulk create rooms | Admin |
| `PATCH` | `/hostels/rooms/:id` | Update a room | Admin |

### Allocations

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/hostels/allocations` | List allocations (filterable by session, hostel, student) | Admin, Staff |
| `GET` | `/hostels/allocations/student/:studentId` | Get student's allocation history | Admin, Self |
| `POST` | `/hostels/allocations` | Allocate a student to a room | Admin |
| `PATCH` | `/hostels/allocations/:id/vacate` | Vacate a student from a room | Admin |
| `GET` | `/hostels/rooms/available` | List available rooms (with vacancy) | Authenticated |

---

## Request & Response Types

### `POST /hostels`

**Request Body (`CreateHostelDto`):**

```ts
{
  name: string;            // unique, max 100 chars
  hostelType: string;      // "male" or "female", max 10 chars
  address?: string;
}
```

**Response: `201 Created`** — returns the created hostel.

---

### `POST /hostels/:hostelId/blocks`

**Request Body (`CreateBlockDto`):**

```ts
{
  name: string;            // max 50 chars (e.g. "Block A")
  floors: number;
}
```

**Response: `201 Created`** — returns the created block.

---

### `POST /hostels/blocks/:blockId/rooms`

**Request Body (`CreateRoomDto`):**

```ts
{
  roomNumber: string;      // max 10 chars (e.g. "A101")
  floor: number;
  capacity: number;        // how many students the room holds
  roomType: string;        // e.g. "single", "double", "shared", max 20 chars
}
```

**Response: `201 Created`** — returns the created room.

---

### `POST /hostels/blocks/:blockId/rooms/bulk`

**Request Body (`BulkCreateRoomsDto`):**

```ts
{
  rooms: {
    roomNumber: string;
    floor: number;
    capacity: number;
    roomType: string;
  }[];
}
```

**Response: `201 Created`**

```ts
{
  created: number;
  errors: { roomNumber: string; message: string }[];
}
```

---

### `POST /hostels/allocations`

**Request Body (`CreateAllocationDto`):**

```ts
{
  studentId: number;
  roomId: number;
  sessionId: number;       // academic session ID
}
```

**Response: `201 Created`**

```ts
{
  id: number;
  studentId: number;
  roomId: number;
  sessionId: number;
  status: "active";
  allocatedAt: string;
  room: {
    roomNumber: string;
    block: { name: string; hostel: { name: string } };
  };
}
```

---

### `PATCH /hostels/allocations/:id/vacate`

**Response: `200 OK`**

```ts
{
  id: number;
  status: "vacated";
  vacatedAt: string;
}
```

---

### `GET /hostels/rooms/available`

**Query Parameters:**

```ts
{
  hostelId?: number;
  hostelType?: string;     // "male" or "female"
  roomType?: string;
  sessionId: number;       // required — check against current allocations
}
```

**Response: `200 OK`**

```ts
{
  data: {
    id: number;
    roomNumber: string;
    floor: number;
    capacity: number;
    roomType: string;
    currentOccupancy: number;    // computed from active allocations
    vacancies: number;           // capacity - currentOccupancy
    block: { name: string; hostel: { name: string; hostelType: string } };
  }[];
}
```

---

## Notes for Developers

- Block names are unique per hostel (`@@unique([hostelId, name])`).
- Room numbers are unique per block (`@@unique([blockId, roomNumber])`).
- Before allocating, check: room capacity vs. active allocations count, and hostel type vs. student gender.
- Hostel fees are handled by the Payment module (create an Invoice with the hostel FeeType).
- `isAvailable` on the room is a manual override. The vacancy check should also count active allocations against capacity.
- `sessionId` on allocation is not a Prisma relation — validate against AcademicSession manually.
