# Hostel Module — Implementation Workflow

This document explains the internal implementation flow for the Hostel module. It is intended for developers building or maintaining this module.

---

## Module Dependencies

```
HostelModule
├── PrismaService          (database access)
├── PaymentModule          (hostel fee invoice verification)
├── AcademicModule         (active session for allocations)
├── UserModule             (student gender check for hostel type matching)
├── AuditModule            (log allocation events)
└── NotificationModule     (allocation confirmation)
```

---

## Data Hierarchy

```
Hostel (e.g. "Male Hostel A")
  ├── hostelType: "male" | "female"
  │
  └── HostelBlock (e.g. "Block A")
        ├── floors: number
        │
        └── HostelRoom (e.g. "A101")
              ├── capacity: number
              ├── roomType: "single" | "double" | "shared"
              │
              └── HostelAllocation (per student, per session)
                    ├── studentId
                    ├── sessionId
                    └── status: "active" | "vacated"
```

---

## 1. Setup Flow (Admin, One-Time)

```
Step 1: Create hostel buildings
────────────────────────────────
POST /hostels
{ name: "Male Hostel A", hostelType: "male", address: "..." }

Step 2: Create blocks within hostels
──────────────────────────────────────
POST /hostels/:hostelId/blocks
{ name: "Block A", floors: 3 }

Step 3: Create rooms within blocks
───────────────────────────────────
POST /hostels/blocks/:blockId/rooms/bulk
{
  rooms: [
    { roomNumber: "A101", floor: 1, capacity: 4, roomType: "shared" },
    { roomNumber: "A102", floor: 1, capacity: 4, roomType: "shared" },
    { roomNumber: "A201", floor: 2, capacity: 2, roomType: "double" },
    ...
  ]
}
```

---

## 2. Student Allocation Flow

**Endpoint:** `POST /hostels/allocations`

```
Admin allocates a student to a room
         │
         ▼
┌──────────────────────────────────────────────────┐
│  HostelService.allocateStudent(dto)              │
│                                                  │
│  Validation:                                     │
│  ┌────────────────────────────────────────────┐  │
│  │ 1. Verify student exists and is ACTIVE     │  │
│  │                                            │  │
│  │ 2. Verify room exists                      │  │
│  │                                            │  │
│  │ 3. Gender match:                           │  │
│  │    - Get student gender from profile       │  │
│  │    - Get room → block → hostel.hostelType  │  │
│  │    - MALE ↔ "male", FEMALE ↔ "female"     │  │
│  │    - Mismatch → 400 "Gender mismatch"      │  │
│  │                                            │  │
│  │ 4. Capacity check:                         │  │
│  │    - Count active allocations for this room│  │
│  │      in this session                       │  │
│  │    - >= room.capacity → 400 "Room full"    │  │
│  │                                            │  │
│  │ 5. Duplicate check:                        │  │
│  │    - Student already allocated this session│  │
│  │    - → 409 "Already allocated"             │  │
│  │                                            │  │
│  │ 6. Payment check (optional):               │  │
│  │    - Verify hostel fee invoice is PAID     │  │
│  │    - Not paid → 400 "Hostel fee not paid"  │  │
│  └────────────────────────────────────────────┘  │
│                                                  │
│  Create:                                         │
│  - HostelAllocation record                       │
│    { studentId, roomId, sessionId,               │
│      status: "active", allocatedAt: now }        │
│                                                  │
│  Post-allocation:                                │
│  - Notify student: "Room assigned to you"        │
│  - Log via AuditService                          │
└──────────────────────────────────────────────────┘
```

---

## 3. Available Rooms Query

**Endpoint:** `GET /hostels/rooms/available`

```
┌──────────────────────────────────────────────────┐
│  HostelService.getAvailableRooms(filters)        │
│                                                  │
│  Query Logic:                                    │
│  1. Find all rooms matching filters:             │
│     - hostelId, hostelType, roomType             │
│  2. For each room:                               │
│     - Count active allocations for sessionId     │
│     - currentOccupancy = count                   │
│     - vacancies = room.capacity - count          │
│  3. Filter: only rooms where vacancies > 0       │
│     AND isAvailable = true                       │
│  4. Return with block and hostel info            │
└──────────────────────────────────────────────────┘

-- Efficient SQL approach:
SELECT r.*, b.name as blockName, h.name as hostelName,
  r.capacity - COUNT(ha.id) as vacancies
FROM hostel_rooms r
JOIN hostel_blocks b ON r.block_id = b.id
JOIN hostels h ON b.hostel_id = h.id
LEFT JOIN hostel_allocations ha
  ON ha.room_id = r.id
  AND ha.session_id = :sessionId
  AND ha.status = 'active'
WHERE r.is_available = true
GROUP BY r.id
HAVING vacancies > 0
```

---

## 4. Vacate Flow

**Endpoint:** `PATCH /hostels/allocations/:id/vacate`

```
Admin vacates a student from their room
         │
         ▼
┌──────────────────────────────────────────────────┐
│  HostelService.vacateStudent(allocationId)       │
│  1. Find allocation by ID                        │
│  2. Verify status == "active"                    │
│     - Already vacated → 400                      │
│  3. Update:                                      │
│     - status = "vacated"                         │
│     - vacatedAt = now                            │
│  4. Room's effective vacancy count increases by 1│
│  5. Log via AuditService                         │
└──────────────────────────────────────────────────┘
```

---

## 5. Files to Create

```
src/modules/hostel/
├── hostel.module.ts
├── hostel.controller.ts         # All hostel routes
├── hostel.service.ts            # Business logic
├── dto/
│   ├── create-hostel.dto.ts
│   ├── create-block.dto.ts
│   ├── create-room.dto.ts
│   ├── bulk-create-rooms.dto.ts
│   ├── create-allocation.dto.ts
│   └── query-rooms.dto.ts
└── hostel.service.spec.ts
```

---

## 6. Cross-Module Integration Points

| Direction | Module | Interaction |
| --------- | ------ | ----------- |
| **Consumes** | PaymentModule | Verify hostel fee payment |
| **Consumes** | AcademicModule | Active session for allocation |
| **Consumes** | UserModule | Student gender for hostel matching |
| **Consumed by** | ClearanceModule | Hostel clearance check |
