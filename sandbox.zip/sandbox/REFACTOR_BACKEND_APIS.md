# Admission Module — Pre-Application Program Choice ("Choice Program" step)

> **Audience:** Backend developer (qhub_backend_api).
> **Status (2026-08-27):** An admin added a new, real admission PROCESS step called "Choice
> Program" via the existing Admission Step Registry (`GET/POST/PATCH/DELETE
> /admissions/config/steps` — see `sandbox/admission/admission_features_workflow.md`), intended
> to sit **before** the Application Fee step. The frontend has a fully-built, wired-up UI for it
> (`ChoiceProgramSection.tsx`, `admissionStore.ts`'s order-driven `deriveStep`,
> `AdmissionStepIndicator.tsx`), but the endpoint it needs to persist a choice against
> (`POST /admission/program-choice`) and the corresponding fields on `GET /admission/student`
> **do not exist yet**. Until they ship, the frontend degrades gracefully — the step renders and
> is fully usable, it just can't save a real choice, and `submitProgramChoice()` 404s. This doc is
> the ready-to-implement spec for both. No existing table needs to change; this is additive.

---

## Background — why this step exists

A real Nigerian university admission portal typically lets an applicant pick their program
(and entry mode / study mode) **before** they pay anything, since the choice can affect which fee
applies and shouldn't be buried deep inside a multi-step application form the applicant only
reaches after paying. Today, program/entry-mode/study-mode selection
(`programId`/`entryMode`/`studyMode`/`startTerm`) only ever happens as part of the final
`POST /admissions/applications` submission (`Applications - Submit.bru`), which is itself only
reachable *after* the Application Fee step. There's no way for an applicant to record this choice
earlier, before an `AdmissionApplication` record exists — which is the entire point of the new
"Choice Program" step.

**Frontend consequence already shipped:** since the choice now happens earlier, asking the same
question again inside the application form would be redundant, so the form's own "Program
Selection" step has been removed from the live wizard entirely
(`getActiveFormSteps` in `admission-application-form/types/form-types.ts` unconditionally excludes
it) and from the admin's "Application Form Steps" config panel. `useAdmissionForm.ts` pre-fills
`programId`/`entryMode`/`studyMode`/`startTerm` from the earlier choice instead of collecting them
again, then still sends them as part of the final submit payload exactly as before — **no change
needed to `POST /admissions/applications` itself.**

> **Note for whoever manages the Admission Step Registry data:** the "Choice Program" step is
> currently a regular, admin-togglable/optional PROCESS step. If it's ever disabled for a given
> deployment, applicants would have no way to choose a program anywhere in the flow, since the
> form-side alternative has been removed. Until/unless the frontend adds a fallback for that case,
> please treat "Choice Program" as effectively mandatory (`required: true`) once it's turned on for
> a deployment — same as `APPLICATION_FORM`/`ADMISSION_STATUS`/`COMPLETED` are today.

---

## Proposed Schema

One new model, uniquely scoped per applicant (and per session, since a returning applicant across
multiple sessions should be able to choose again):

```prisma
model AdmissionProgramChoice {
  id          Int       @id @default(autoincrement())
  userId      Int       @map("user_id")
  sessionId   Int       @map("session_id")
  programId   Int       @map("program_id")
  entryMode   EntryMode @map("entry_mode")
  studyMode   StudyMode @default(ONLINE) @map("study_mode")
  createdAt   DateTime  @default(now()) @map("created_at")
  updatedAt   DateTime  @updatedAt @map("updated_at")

  // Relations
  user    User            @relation(fields: [userId], references: [id])
  session AcademicSession @relation(fields: [sessionId], references: [id])
  program Program         @relation(fields: [programId], references: [id])

  @@unique([userId, sessionId])
  @@index([programId])
  @@map("admission_program_choices")
}

enum EntryMode {
  UTME
  DIRECT_ENTRY
  TRANSFER
}

enum StudyMode {
  ONLINE
  OFFLINE
}
```

If `EntryMode`/`StudyMode` (or equivalent) enums already exist elsewhere in the schema for
`AdmissionApplication`, reuse those instead of adding duplicates — the frontend just needs the
same three values (`UTME | DIRECT_ENTRY | TRANSFER`) and two values (`online | offline`,
lowercase on the wire) it already sends to `POST /admissions/applications` today.

`@@unique([userId, sessionId])` makes this an upsert: an applicant can change their mind and
resubmit before paying, and the same row is simply updated rather than duplicated.

Also add the inverse relations:
- `User.admissionProgramChoices AdmissionProgramChoice[]`
- `AcademicSession.admissionProgramChoices AdmissionProgramChoice[]`
- `Program.admissionProgramChoices AdmissionProgramChoice[]`

---

## Endpoints

| Method | Endpoint | Description | Auth |
| --- | --- | --- | --- |
| `POST` | `/admission/program-choice` | Create or update (upsert on `userId`+active session) the caller's pre-application program choice | Authenticated |
| `GET` | `/admission/student` | **Extend** the existing Student Admission Progress aggregate with the fields below | Authenticated |

### `POST /admission/program-choice`

Request body:

```json
{
  "programId": 12,
  "entryMode": "UTME",
  "studyMode": "online",
  "startTerm": "2026/2027"
}
```

- `entryMode`: one of `UTME | DIRECT_ENTRY | TRANSFER` — same enum `Applications - Submit.bru`
  already accepts.
- `studyMode`: `online | offline`.
- `startTerm`: the active academic session's display name. Sent for parity with the final
  application submission; safe to ignore and derive server-side from the active
  `AcademicSession` instead if preferred — it isn't persisted as its own column above since it's
  fully derivable from `sessionId`.

Resolve `sessionId` server-side from whichever `AcademicSession` is currently active, the same way
other admission endpoints already do — the frontend does not send it.

Response (wrapped in the same `{ data: ... }` envelope as every other endpoint in this backend —
see `admissionService.ts`'s note on `GET /admission/student`'s wrapping):

```json
{
  "data": {
    "has_selected_program": true,
    "program_id": 12,
    "program_name": "B.Sc. Computer Science",
    "entry_mode": "UTME",
    "study_mode": "online",
    "start_term": "2026/2027"
  }
}
```

Returning the full, refreshed `AdmissionStudent` aggregate (i.e. every field `GET
/admission/student` returns, not just these five) is fine and simplest — the frontend
(`admissionService.ts`'s `submitProgramChoice`) treats the response as a complete `AdmissionStudent`
and re-syncs its local cache from it directly, no merge needed on the frontend side.

### `GET /admission/student` — field additions

Extend the existing composed aggregate (`admission/Admission - Student Aggregate.bru`) with:

```json
{
  "has_selected_program": false,
  "program_id": null,
  "program_name": null,
  "entry_mode": null,
  "study_mode": null,
  "start_term": null
}
```

`has_selected_program` is `true` once an `AdmissionProgramChoice` row exists for
`(userId, activeSessionId)`; the other four fields mirror that row (`program_name` is the
program's display name, joined in). All five default to `false`/`null` when no choice has been
made yet — this lets a returning applicant's choice survive a page reload/new session, the same
way every other stage's completion is already reflected in this aggregate
(`application_payment_status`, `has_applied`, etc.).

---

## Interaction with the existing flow — nothing else changes

- `POST /admissions/applications` (`Applications - Submit.bru`) keeps accepting
  `programId`/`entryMode`/`startTerm`/`studyMode` exactly as it does today — the frontend still
  sends them, just sourced from the earlier choice instead of a form field. **No backend change
  needed here.** If it's convenient, the backend may cross-check the submitted values against the
  applicant's `AdmissionProgramChoice` row and reject a mismatch, but this isn't required — the
  frontend never lets them diverge in practice since the fields are pre-filled and read-only by
  the time the applicant reaches Review & Submit.
- No change to `POST /fees/payments/application/initiate` or any other payment endpoint — the
  program choice is informational at this stage, not fee-gating (unless a future requirement
  wants the application fee amount to vary by program, which is out of scope here).

---

## Frontend, already built and wired

- `src/app/(admission)/services/admissionService.ts` — `submitProgramChoice()` (calls the new
  endpoint) and `fetchStudentAdmission()` (defensively defaults the five new fields until they
  ship).
- `src/app/(admission)/hooks/useAdmissionQueries.ts` — `useSubmitProgramChoice()`.
- `src/app/(admission)/components/ChoiceProgramSection.tsx` — the actual program/entry-mode/
  study-mode picker UI, rendered as the `CHOICE_PROGRAM` process step.
- `src/app/(admission)/store/admissionStore.ts` — `deriveStep()`'s `STEP_COMPLETION` map treats
  `CHOICE_PROGRAM` as satisfied once `has_selected_program` is `true`.
- `src/app/(admission)/(routes)/admission-application-form/hooks/useAdmissionForm.ts` — pre-fills
  the form's `programId`/`entryMode`/`studyMode`/`startTerm` from the student aggregate once this
  ships (currently a no-op since those fields default to `null`/`false`).

Once both pieces above ship exactly as specced, no further frontend changes are needed — the
degrade-gracefully behavior (404 on submit, "not yet chosen" defaults on read) simply stops
triggering.
