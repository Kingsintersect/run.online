# Outstanding API Gaps — 2026-09-10 re-audit

> **Audience:** Backend developer (qhub_backend_api) + product.
> **Purpose:** The successor tracking doc to `sandbox/MISSING_BACKEND_APIS.md`. That file's
> header claims "RESOLVED — every item shipped", but its own body (§2.8, §2.9, §2.11–§2.14) still
> describes work that was never delivered. This doc is the current, accurate list of what's
> genuinely open, found in the full frontend↔`bruno/` re-audit
> (`sandbox/API_INTEGRATION_AUDIT.md`, 2026-09-10).
> **Method:** every item below was confirmed by tracing the frontend call site to the absence of a
> matching `.bru`. The response contracts each item needs are already specified in
> `MISSING_BACKEND_APIS.md` — this doc points at those specs rather than re-typing them.
> **Frontend status:** every gap below has a built, wired frontend that degrades gracefully
> (empty state / `retry: false` / `Promise.allSettled` fallback) — nothing is blocking, but the
> feature is inert until the backend catches up.

---

## 1. Director analytics — no `bruno/director/` collection exists

`src/modules/director/services/director.service.ts` composes the Director portal from real
User / Academic / Fee endpoints wherever one exists, and calls a designed contract for the
aggregates that have no backing anywhere. Those designed endpoints are **not shipped** — no `.bru`,
no route:

| Endpoint | Backs | Spec |
|---|---|---|
| `GET /enrollments/trend?months=` | Overview → enrollment time-series chart | `MISSING_BACKEND_APIS.md` §2.8 "Genuinely new aggregates" |
| `GET /fees/reports/collections-trend?months=` | Financial → monthly revenue chart | `MISSING_BACKEND_APIS.md` §2.8 "Genuinely new aggregates" |
| `GET /results/reports/director-grade-summary` | Grade Reports tab | `sandbox/result/missing_grade_apis.readme.md` §8 |
| `GET /users/stats` **extended** with `byFaculty` / `studentsByLevel` / `studentsByGender` / `tutorsByDesignation` | Overview faculty-distribution chart + Statistical tab breakdowns | `MISSING_BACKEND_APIS.md` §2.8 "Proposed extensions" |
| `GET /users/students` / `GET /users/lecturers` — add `facultyName` / `departmentName` string filters, and a numeric `level` filter for students | Statistical + Financial + Grade tab filter bar | `MISSING_BACKEND_APIS.md` §2.8 |
| `GET /fees/reports/summary` — documented response shape + `facultyName` / `departmentName` filters | Financial tab totals | `MISSING_BACKEND_APIS.md` §2.8 (`bruno/fee/Reports - Summary.bru` has no example body) |
| `GET /fees/invoices` (admin list) — documented nested shape (`feeType` / `session` / `student.{...}`) + `facultyName` / `departmentName` / `level` filters | Financial tab payments table | `MISSING_BACKEND_APIS.md` §2.8 |

**Current effect:** the three trend/summary tiles are blank in production; the composed tiles
(faculty count, program count, graduation ratio, fee-type revenue breakdown) are real and work.

`src/app/(dashboard)/director/INTEGRATION.md` is a stale drop-in bundle doc (`@modules/directordirector/`,
`src/middleware.ts`, "UNIZIK") — **do not use it as the contract.** The `MISSING_BACKEND_APIS.md`
§2.8 spec is current.

---

## 2. Assessments — RESOLVED on the frontend (2026-09-10 live verification)

**Live check against the running backend settled this:** `/assessments/*` is the **complete,
working contract** — 11 of 12 endpoints respond (list, `/my`, `/upcoming`, `/:id`, `/course/:id`,
`/course/:id/upcoming` all `200`; `/:id/visibility`, `DELETE /:id`, `/sync/*` return `403` for a
student = they exist, role-gated). `/moodle-sync/assessments/*` is the **incomplete** one — it
`404`s on `/my`, `/:id`, `/:id/visibility`, `DELETE /:id`, `/sync/*`.

The frontend had consolidated onto the wrong path (`/moodle-sync/assessments/*`), which is why the
student "All assessments" tab and the assessment detail page were 404-broken and the admin
sync-status table was shape-broken.

**Done:** `src/modules/moodle-sync/services/moodle-sync.service.ts` assessment methods repointed to
`/assessments/*`, with a normalizer (`mapAssessmentListItem` / `mapAssessmentDetail`) because list
rows carry a flat `course:{code,title,semesterName}` while `/:id` carries the deep
`course.courseOffering.{course,semester,academicSession}`. Components consume one normalized
`AssessmentResponse`. No backend action needed here.

### Still open: `ca-preview` (the ONLY genuinely-missing assessment endpoint)

`GET /assessments/ca-preview/:offeringId?semesterId=&caMax=` — **404 on every path tried**
(`/assessments/ca-preview` and `/moodle-sync/assessments/ca-preview`). Backs the "Pull CA from
Moodle" button in `BulkGradeForm.tsx`. Read-only preview; the previewed scores save through the
already-real `POST /results/grades/bulk`, so no new write endpoint is needed. Full spec:
`MISSING_BACKEND_APIS.md` §2.14. Frontend keeps the button wired — it surfaces the error until the
endpoint lands; manual CA entry works meanwhile.

### Optional backend cleanup: retire `/moodle-sync/assessments/*` or fill it in

Now that the frontend is on `/assessments/*`, the partial `/moodle-sync/assessments/*` surface
(`list`, `course/:id`, `upcoming`, `pull/:id`, `pull-all`, `sync-status`) has **no caller**. Either
deprecate it, or bring it to parity with `/assessments/*` — the backend team's call. `bruno/`
documents both today.

---

## 3. `GET /fees/types/eligible-count`

`src/modules/fee-management/services/fee-management.service.ts:103` — the "how many students would
this fee type apply to" live preview in `fee-type-scope-selector.tsx`. Already calls it
speculatively with `retry: false`; degrades to no-preview on 404. **Low priority** — spec in
`MISSING_BACKEND_APIS.md` §2.9. Build only if the preview is wanted.

---

## 4. Student transcript / result-sheet download — **backend gap** (FE built, awaiting endpoint)

`GET /students/me/results/:semesterId/download` (`bruno/student/Download Result.bru`) is documented
as streaming a semester transcript / result-sheet PDF — but **verified 404 against the live backend
2026-09-10**, so it is *not* actually shipped (the `.bru` doc got ahead of the implementation).

**Frontend: DONE.** `gradesService.downloadSemesterResult(semesterId)` + `useDownloadSemesterResult()`
+ a per-semester Download button in `StudentResultsPage.tsx`. A 404 shows
"No downloadable result for this semester yet." — so it lights up the moment the endpoint lands.

**Backend still needed:** implement the endpoint per `bruno/student/Download Result.bru`
(`StudentResultService::downloadSemesterResult()`), 404 when no `PUBLISHED` result exists.

---

## 5. Pre-application "Choice Program" — already tracked, no action here

`POST /admission/program-choice` + the `has_selected_program` / `program_*` fields on
`GET /admission/student` are fully specified in **`sandbox/REFACTOR_BACKEND_APIS.md`**. Frontend is
built and wired (`admissionService.submitProgramChoice`, `ChoiceProgramSection.tsx`); 404s until
shipped. Not restated here — that doc is the reference.

---

## 6. `GET /auth/roles/:roleId/users` — backend gap (FE composed a fallback)

RoleDetailView's "Users" tab needs a "which users hold this role" reverse lookup.
`GET /auth/roles/:roleId/users` **404s** (2026-09-10) and `GET /users` carries no role data to
filter on. FE now catches the 404 and renders an empty state instead of an error.
**Backend needed:** either `GET /auth/roles/:roleId/users` (shape = `UserWithRoles[]`, see
`src/types/roles.d.ts`) or a `?roleId=` filter on `GET /users`.

---

## Integration progress (2026-09-10 pass)

| Item | Status |
|---|---|
| Assessments repointed to `/assessments/*` + normalizer | ✅ done (§2) |
| Header bell + student dashboard + settings → real `/notifications` | ✅ done — mock `notificationStore` deleted |
| `POST /auth/change-password` wired into student Settings → Security | ✅ done |
| Transcript download button (`/students/me/results/:id/download`) | ✅ FE done — endpoint 404s (§4) |
| `POST /auth/roles/:id/duplicate` (was fabricated) → composed from Create + permission-sync | ✅ done |
| `GET /auth/roles/:roleId/users` (fabricated) → degrades to empty | ✅ done (§6) |
| `GET /audit/export` + `POST /audit/log` (fabricated) → removed (export is client-side) | ✅ done |
| `GET /academic/faculties/eligible-deans` → Faculty form Dean `<select>` | ✅ done |
| `GET /timetable/schedules/{lecturer,semester}/:id` → admin timetable filter bar | ✅ done |
| `PATCH /users/lecturers/me/onboarding` → tutor first-login checklist on `/tutor` | ✅ done |
| `POST /users/lecturers/:id/resend-invite` → "Resend invite" button in admin TutorList | ✅ done |
| `POST`/`PATCH`/`DELETE /results/grade-scales` → Grade Bands table on Grading Schemes page | ✅ done |
| `GET /results/grades/course/:c/semester/:s` → `useGradesByCourseAndSemester` hook (service + hook wired) | ✅ done |
| `GET /admissions/applications/:id/documents/:docId/download` → authed download button in the review UI's DocumentList | ✅ done |
| `GET /admissions/applications/track/:number` → public `/admissions/track` page | ✅ done |
| `POST /admissions/applications/bulk-review` → bulk-select checkbox column + floating action bar + deny-reason modal on the Review Applications table | ✅ done |
| `POST /admissions/bulk` (bulk-create offers) → "Create offers (N)" batch action on the Review Applications table + shared-fields dialog (`bulk-create-offers-dialog.tsx`), auto-generates admission numbers per session | ✅ done |
| `GET /audit/logs/:id` → detail modal fetches the full JSON-decoded record, falls back to the list row | ✅ done |
| `GET /moodle-sync/users/unmatched` → standing unmatched list feeds the "Unmatched" button (last pull still takes precedence) | ✅ done |
| `GET /students/me/courses` → `moodleSynced` flag layered onto the student My Courses cards; "Not on Moodle yet" disabled state | ✅ done |
| `GET /users/students/matric/:matricNumber` → "Find by matric no…" lookup box in the admin Students page header | ✅ done |
| `DELETE /auth/roles/:roleId/permissions/:permissionId` → `rolePermissionsApi.reconcile` (the role-edit sync now detaches removed permissions, which `POST …/permissions` alone cannot — it's `syncWithoutDetaching`) | ✅ done |
| `GET /calendar/events/course/:offeringId` → "Course" filter on the student Calendar page (switches the event source to that offering) | ✅ done |
| `GET /academic-calendar/events` → "Academic Calendar" list section on the student Calendar page | ✅ done |
| `GET /academic-calendar/sessions/:id` → "View semesters" modal on each session card in Academic Sessions (admin) | ✅ done |
| `GET /results/grades/course/:c/semester/:s` → the tutor Grade Book is now a course-scoped view (`TutorCourseGradeBook`) | ✅ done |
| `GET /results/grades/:id` → the grade detail modal refreshes the row against server state (falls back to the list row) | ✅ done |
| `GET /notifications/:id` → click a notification → reading-pane modal with the full body + delivery metadata (`NotificationDetailModal`) | ✅ done |
| `GET /fees/payments/:id` → "Details" button on each payment-history row → payment detail modal | ✅ done |
| A1 (grades analytics envelope) → all six `/results` analytics reads routed through `unwrap()` — flat or `{data}`, safe empty fallback | ✅ done |
| Student Settings → Save Profile now `PATCH /users/students/:id` (phone + contact address); identity fields read-only | ✅ done |
| Student My Courses → "Register for courses" button (hero + empty state) → `/student/enrollment` | ✅ done |

### 2026-09-10 pass 2 — completion sweep

Everything the frontend can integrate against `bruno/` is now wired. What's left is **backend-side only** — see `sandbox/BACKEND_HANDOFF.md` for the ship-ready list. Summary:

- **Genuine gaps (endpoint missing / 404):** Director aggregates (`/enrollments/trend`, `/fees/reports/collections-trend`, `/results/reports/director-grade-summary`, extended `/users/stats`), `/students/me/results/:semesterId/download`, `/auth/roles/:roleId/users`, `/assessments/ca-preview/:offeringId`, `POST /admission/program-choice`.
- **Contract decisions:** `/courses/schedules/*` vs `/timetable/schedules/*` (pick one); deprecate or fill `/moodle-sync/assessments/*`; add example bodies to the six `/results` analytics `.bru` files and confirm `/results/dashboard` envelope.
- **Verify with real data:** `/results/grades/:id` and `/fees/payments/:id` both 404'd on id `1` (seed likely has no such row) — confirm the routes resolve for a real id; the FE degrades to the list row meanwhile.

Live re-verification 2026-09-10: `/academic-calendar/events`, `/academic-calendar/sessions/:id`, `/calendar/events/course/:id` → **200**; `/notifications/:id`, `/results/grades/course/:c/semester/:s`, `/results/grades/distribution`, `/results/grades/grouped` → **403** for a student = exist, role-gated; `/results/grades/:id`, `/fees/payments/:id` → **404** on id 1 (see above).
