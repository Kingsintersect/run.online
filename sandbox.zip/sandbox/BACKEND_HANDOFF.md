# Backend Hand-off — outstanding work for `qhub_backend_api`

> **Date:** 2026-09-10 (pass 2)
> **Audience:** the backend developer.
> **Context:** the frontend integration against `bruno/` is **complete** — every documented
> endpoint that exists is wired. Every item below is backend-side. Each frontend feature that
> depends on one of these is already built and degrades gracefully (empty state / `retry:false` /
> falls back to cached list data), so nothing here is blocking a release — but the feature stays
> inert until the endpoint lands.
> **Detailed contracts** already exist in the per-module docs referenced under each item; this
> file is the single checklist to work from.

---

## A. Genuine gaps — endpoint missing or 404 against the live API

### A1. Director analytics aggregates — no `bruno/director/` collection

`src/modules/director/services/director.service.ts` composes the Director portal from real
User / Academic / Fee endpoints where one exists, and calls these designed contracts where none
does. All verified **404**.

| Endpoint | Backs | Spec |
|---|---|---|
| `GET /enrollments/trend?months=` | Overview → enrollment time-series chart | `MISSING_BACKEND_APIS.md` §2.8 |
| `GET /fees/reports/collections-trend?months=` | Financial → monthly revenue chart | `MISSING_BACKEND_APIS.md` §2.8 |
| `GET /results/reports/director-grade-summary` | Grade Reports tab | `sandbox/result/missing_grade_apis.readme.md` §8 |
| `GET /users/stats` — add `byFaculty`, `studentsByLevel`, `studentsByGender`, `tutorsByDesignation` | Overview faculty-distribution + Statistical tab | `MISSING_BACKEND_APIS.md` §2.8 |
| `GET /users/students` / `GET /users/lecturers` — add `facultyName` / `departmentName` string filters + numeric `level` filter for students | Statistical / Financial / Grade tab filter bar | `MISSING_BACKEND_APIS.md` §2.8 |
| `GET /fees/reports/summary` — documented response body + `facultyName` / `departmentName` filters | Financial tab totals | `MISSING_BACKEND_APIS.md` §2.8 |
| `GET /fees/invoices` (admin list) — documented nested shape (`feeType` / `session` / `student.{…}`) + `facultyName` / `departmentName` / `level` filters | Financial tab payments table | `MISSING_BACKEND_APIS.md` §2.8 |

Ignore `src/app/(dashboard)/director/INTEGRATION.md` — it's a stale drop-in bundle doc. The
`MISSING_BACKEND_APIS.md` §2.8 spec is current.

### A2. Student transcript / result-sheet PDF

- **`GET /students/me/results/:semesterId/download`** — documented in `bruno/student/Download Result.bru`
  as streaming a semester transcript (credit-weighted programs) or result sheet (simple-average),
  `Content-Type: application/pdf`. **Verified 404** — the `.bru` got ahead of the implementation.
- 404 when no `PUBLISHED` result exists for that semester.
- Frontend: **done** — per-semester Download button in `StudentResultsPage`; a 404 shows
  "No downloadable result for this semester yet."
- Spec: `sandbox/API_GAPS_2026-09.md` §4, `bruno/student/Download Result.bru`.

### A3. `GET /auth/roles/:roleId/users` — reverse "who holds this role" lookup

- **404**, and `GET /users` carries no role data to filter on.
- Either ship `GET /auth/roles/:roleId/users` (response shape = `UserWithRoles[]`, see
  `src/types/roles.d.ts`) **or** add a `?roleId=` filter to `GET /users`.
- Frontend: catches the 404 and renders an empty state on RoleDetailView's "Users" tab.
- Spec: `sandbox/API_GAPS_2026-09.md` §6.

### A4. `GET /assessments/ca-preview/:offeringId?semesterId=&caMax=`

- **404 on every path tried** (`/assessments/ca-preview` and `/moodle-sync/assessments/ca-preview`).
- Read-only: computes each student's CA score from their Moodle assignment/quiz grades for the
  offering. The previewed scores save through the already-real `POST /results/grades/bulk`, so
  **no new write endpoint is needed**.
- Backs the "Pull CA from Moodle" button in `BulkGradeForm.tsx`. Manual CA entry works meanwhile.
- Spec: `MISSING_BACKEND_APIS.md` §2.14.

### A5. Pre-application program choice

- **`POST /admission/program-choice`** plus `has_selected_program` / `program_*` fields on
  `GET /admission/student`.
- Fully specified in **`sandbox/REFACTOR_BACKEND_APIS.md`**.
- Frontend: built and wired (`admissionService.submitProgramChoice`, `ChoiceProgramSection.tsx`);
  404s until shipped.

### A6. `GET /fees/types/eligible-count` — low priority

- Live "how many students would this fee type apply to" preview in `fee-type-scope-selector.tsx`.
- Already called speculatively with `retry:false`; degrades to no-preview on 404.
- Build only if the preview is wanted. Spec: `MISSING_BACKEND_APIS.md` §2.9.

---

## B. Contract decisions — mostly not new code

### B1. Class-schedule path duplication

`bruno/` documents **both** `/courses/offerings/:id/schedules` (Course module) and
`/timetable/schedules/*` (Timetable module) for the same `ClassSchedule` table. The frontend
standardised on `/timetable/schedules/*` (richer: conflict detection, role guards). Pick one as
canonical and deprecate the other, or reconcile them. Spec: `MISSING_BACKEND_APIS.md` §2.11.

### B2. `/moodle-sync/assessments/*` vs `/assessments/*`

Live verification settled that **`/assessments/*` is the complete, working contract** (11/12
endpoints respond) and `/moodle-sync/assessments/*` is the incomplete stub (404s on `/my`,
`/:id`, `/:id/visibility`, `DELETE /:id`, `/sync/*`). The frontend is now entirely on
`/assessments/*`. The partial `/moodle-sync/assessments/*` surface has **no caller** — deprecate
it, or bring it to parity. Backend's call. Spec: `sandbox/API_GAPS_2026-09.md` §2.

### B3. `/results` analytics — add example response bodies to the `.bru` files

Six endpoints have `.bru` files with **no example body**, and this module's envelope is
inconsistent (`bruno/result` mixes `{data:…}` and flat). The frontend now tolerates both via an
`unwrap()` helper, but the contract should be pinned:

- `GET /results/dashboard` — the `.bru` docs say the body is flat `GradeSummaryStats`; the code
  used to assume `{data:…}`. Confirm which, add an example body.
- `GET /results/grades/distribution`, `GET /results/programs/performance`,
  `GET /results/cgpa/trends`, `GET /results/students/top-performers`,
  `GET /results/grades/grouped` — add example bodies.

Spec: `sandbox/result/missing_grade_apis.readme.md`, `MISSING_BACKEND_APIS.md` §2.7.

---

## C. Verify with real data (routes probably fine, seed lacks rows)

Both `.bru`-documented; sibling routes 403 for a student (= exist, role-gated); these two 404'd
on id `1`, most likely because the seed DB has no such row rather than a missing route. Confirm
they resolve for a real id / with an admin token. The frontend degrades to the already-loaded
list row in both cases.

- `GET /results/grades/:id` (`bruno/result/Grade - Get.bru`)
- `GET /fees/payments/:id` (`bruno/fee/Payments - Get.bru`)

---

## D. Frontend-side — no backend action, listed for completeness

All done and shipping:

- Assessments repointed to `/assessments/*` with a list/detail shape normalizer.
- `DELETE /auth/roles/:roleId/permissions/:permissionId` wired — role edit now **reconciles**
  (adds + detaches). Before this, unchecking a permission on a role silently did nothing because
  `POST /auth/roles/:id/permissions` is `syncWithoutDetaching`.
- Bulk application review + bulk offer creation on the Review Applications table.
- Course-scoped tutor grade book, notification reading pane, payment detail modal, academic
  calendar sections, course calendar filter, session-semesters modal, find-student-by-matric,
  standing unmatched-Moodle-users list, student "Register for courses" button.
- Full list with file references: `sandbox/API_GAPS_2026-09.md` progress table.
