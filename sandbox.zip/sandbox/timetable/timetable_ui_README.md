# Timetable & Calendar — Frontend UI Implementation Guide

Next.js 15 App Router · TypeScript Strict · TanStack React Query v5 · Zustand · Zod · ShadCN UI

---

## Table of Contents

1. [Directory Structure](#1-directory-structure)
2. [Route Architecture](#2-route-architecture)
3. [Zod Schemas & Types](#3-zod-schemas--types)
4. [API Service Layer](#4-api-service-layer)
5. [React Query Hooks](#5-react-query-hooks)
6. [Zustand UI Store](#6-zustand-ui-store)
7. [Pages & Shell Components](#7-pages--shell-components)
8. [Client Component Breakdown](#8-client-component-breakdown)
9. [Auth & Role Gating](#9-auth--role-gating)
10. [Error Handling & Loading States](#10-error-handling--loading-states)
11. [Environment Variables & Dependencies](#11-environment-variables--dependencies)

---

## 1. Directory Structure

```
src/
├── modules/
│   └── timetable/
│       ├── components/
│       │   ├── TimetableGrid.tsx          # Weekly grid view (day columns × time rows)
│       │   ├── TimetableList.tsx          # Flat list view of schedule slots
│       │   ├── ScheduleSlotCard.tsx       # Single slot card (course, time, venue, lecturer)
│       │   ├── CalendarEventCard.tsx      # Single Moodle calendar event card
│       │   ├── CalendarEventList.tsx      # List/feed of upcoming calendar events
│       │   ├── AcademicCalendarBanner.tsx # Session/semester info header banner
│       │   ├── VenueAvailabilityChecker.tsx  # Admin tool for venue conflict checking
│       │   ├── ScheduleFormDialog.tsx     # Admin: create/edit schedule modal
│       │   └── EventVisibilityToggle.tsx  # Admin: toggle isVisible on a calendar event
│       ├── hooks/
│       │   ├── useTimetable.ts            # Query hooks for schedules
│       │   ├── useCalendarEvents.ts       # Query hooks for Moodle calendar events
│       │   └── useAcademicCalendar.ts     # Query hook for session/semester metadata
│       ├── schemas/
│       │   ├── schedule.schema.ts         # Zod: CreateScheduleSchema, UpdateScheduleSchema
│       │   └── calendar-event.schema.ts   # Zod: CalendarEventFilterSchema
│       ├── types/
│       │   └── timetable.types.ts         # z.infer<> types + shared response interfaces
│       └── store/
│           └── useTimetableUIStore.ts     # Zustand: view mode, selected day, filter state
```

---

## 2. Route Architecture

### Route Map

| Path | Description | Roles |
| ---- | ----------- | ----- |
| `/timetable` | Current user's weekly timetable | `STUDENT`, `TUTOR` |
| `/timetable/calendar` | Calendar view: Moodle events + announcements | `STUDENT`, `TUTOR` |
| `/timetable/upcoming` | Next 14 days of events for the user | `STUDENT`, `TUTOR` |
| `(dashboard)/tutor/(routes)/timetable` | Tutor: their schedule per semester | `TUTOR`, `ADMIN` |
| `(dashboard)/admin/(routes)/timetable` | Admin: manage all class schedules | `ADMIN` |
| `(dashboard)/admin/(routes)/timetable/venue-check` | Admin: venue availability tool | `ADMIN` |
| `(dashboard)/admin/(routes)/calendar` | Admin: all calendar events + visibility management | `ADMIN` |

### App Router Directory

```
app/
├── (root)/
│   └── timetable/
│       ├── layout.tsx                    # Shared layout for timetable section
│       │                                 # (academic calendar banner + semester tab switcher)
│       ├── page.tsx                      # Weekly timetable — current user
│       ├── calendar/
│       │   └── page.tsx                  # Calendar event feed (Moodle + announcements)
│       └── upcoming/
│           └── page.tsx                  # Upcoming events for the current user
│
└── (dashboard)/
    ├── tutor/
    │   └── (routes)/
    │       └── timetable/
    │           └── page.tsx              # Tutor: their semester schedule
    │
    └── admin/
        └── (routes)/
            ├── timetable/
            │   ├── page.tsx              # Admin: all schedules (list/manage)
            │   └── venue-check/
            │       └── page.tsx          # Admin: venue availability checker
            └── calendar/
                ├── page.tsx              # Admin: all Moodle calendar events
                └── sync-status/
                    └── page.tsx          # Admin: Moodle calendar sync status
```

---

## 3. Zod Schemas & Types

### Location

All schemas and types for this module live under:
`src/modules/timetable/schemas/` and `src/modules/timetable/types/`

### `schedule.schema.ts`

#### `CreateScheduleSchema`

| Field | Zod Rule |
| ----- | -------- |
| `offeringId` | `z.number().int().positive()` |
| `lecturerId` | `z.number().int().positive()` |
| `dayOfWeek` | `z.enum(['MONDAY','TUESDAY','WEDNESDAY','THURSDAY','FRIDAY','SATURDAY','SUNDAY'])` |
| `startTime` | `z.string().regex(/^\d{2}:\d{2}$/)` |
| `endTime` | `z.string().regex(/^\d{2}:\d{2}$/)` — with `.refine()` that `endTime > startTime` |
| `venue` | `z.string().min(1).max(100)` |
| `classType` | `z.enum(['LECTURE','LAB','TUTORIAL','SEMINAR'])` |

#### `UpdateScheduleSchema`

`CreateScheduleSchema.partial()` — all fields optional.

#### `ScheduleFilterSchema`

| Field | Zod Rule |
| ----- | -------- |
| `semesterId` | `z.number().int().optional()` |
| `offeringId` | `z.number().int().optional()` |
| `lecturerId` | `z.number().int().optional()` |
| `dayOfWeek` | `z.enum([...]).optional()` |
| `venue` | `z.string().optional()` |
| `classType` | `z.enum([...]).optional()` |
| `page` | `z.number().int().min(1).optional()` |
| `limit` | `z.number().int().min(1).max(100).optional()` |

### `calendar-event.schema.ts`

#### `CalendarEventFilterSchema`

| Field | Zod Rule |
| ----- | -------- |
| `eventType` | `z.enum(['course','site','user','zoom']).optional()` |
| `courseOfferingId` | `z.number().int().optional()` |
| `from` | `z.string().datetime().optional()` |
| `to` | `z.string().datetime().optional()` |
| `isVisible` | `z.boolean().optional()` |
| `days` | `z.number().int().min(1).max(90).optional()` |
| `page` | `z.number().int().min(1).optional()` |
| `limit` | `z.number().int().min(1).max(100).optional()` |

### `timetable.types.ts`

Infer all types from Zod schemas:

```ts
// Pattern — infer from schemas
type CreateScheduleDto = z.infer<typeof CreateScheduleSchema>
type UpdateScheduleDto = z.infer<typeof UpdateScheduleSchema>
type ScheduleFilter    = z.infer<typeof ScheduleFilterSchema>
type CalendarEventFilter = z.infer<typeof CalendarEventFilterSchema>
```

Define response interfaces (not Zod — these describe server shapes):

| Interface | Key Fields |
| --------- | ---------- |
| `TimetableSlot` | `id, dayOfWeek, startTime, endTime, venue, classType, courseCode, courseTitle, creditUnits, lecturerName, offeringId` |
| `TimetableGrouped` | `MONDAY: TimetableSlot[], TUESDAY: TimetableSlot[], ...` |
| `CalendarEvent` | `id, eventType, name, description, startDate, endDate, meetingUrl, isVisible, courseCode?, courseTitle?` |
| `AcademicCalendarMeta` | `session: { id, name, startDate, endDate }, semesters: Semester[], currentSemester: Semester \| null` |
| `Semester` | `id, name, startDate, endDate, isActive, registrationStart, registrationEnd` |
| `VenueAvailability` | `venue, dayOfWeek, busySlots: BusySlot[], freeWindows: TimeWindow[]` |
| `BusySlot` | `startTime, endTime, courseCode, lecturerName` |
| `TimeWindow` | `startTime, endTime` |
| `PaginatedResponse<T>` | `data: T[], meta: { total, page, limit, totalPages }` |

---

## 4. API Service Layer

**Location:** `src/modules/timetable/` services are kept modular.

> All methods call `apiClient` from `src/lib/clients/apiClient.ts`.  
> No hardcoded URLs. Base URL from `process.env.NEXT_PUBLIC_API_URL`.  
> Token injection is handled by the `apiClient` interceptor — never pass tokens explicitly.

### `timetableService`

| Method | HTTP | Path | Used by |
| ------ | ---- | ---- | ------- |
| `getMyTimetable(params?)` | `GET` | `/timetable/my` | Student, Tutor |
| `getStudentTimetable(studentId, params?)` | `GET` | `/timetable/student/:id` | Admin |
| `getLecturerTimetable(lecturerId, params?)` | `GET` | `/timetable/lecturer/:id` | Admin |
| `getSchedulesByOffering(offeringId)` | `GET` | `/timetable/schedules/offering/:id` | Admin, Tutor |
| `getSchedulesBySemester(semesterId, params?)` | `GET` | `/timetable/schedules/semester/:id` | Admin |
| `getAllSchedules(params?)` | `GET` | `/timetable/schedules` | Admin |
| `getScheduleById(id)` | `GET` | `/timetable/schedules/:id` | Admin |
| `createSchedule(dto)` | `POST` | `/timetable/schedules` | Admin |
| `updateSchedule(id, dto)` | `PUT` | `/timetable/schedules/:id` | Admin |
| `deleteSchedule(id)` | `DELETE` | `/timetable/schedules/:id` | Admin |
| `getVenueAvailability(params)` | `GET` | `/timetable/venue-availability` | Admin |
| `getVenues()` | `GET` | `/timetable/venues` | Admin |

### `calendarService`

| Method | HTTP | Path | Used by |
| ------ | ---- | ---- | ------- |
| `getMyEvents(params?)` | `GET` | `/calendar/events/my` | Student, Tutor |
| `getMyUpcomingEvents()` | `GET` | `/calendar/events/my/upcoming` | Student, Tutor |
| `getUpcomingEvents(days?)` | `GET` | `/calendar/events/upcoming` | All authenticated |
| `getEventsByCourse(courseOfferingId, params?)` | `GET` | `/calendar/events/course/:id` | Student, Tutor, Admin |
| `getAllEvents(params?)` | `GET` | `/calendar/events` | Admin |
| `getEventById(id)` | `GET` | `/calendar/events/:id` | All authenticated |
| `toggleEventVisibility(id)` | `PATCH` | `/calendar/events/:id/visibility` | Admin |

### `academicCalendarService`

| Method | HTTP | Path | Used by |
| ------ | ---- | ---- | ------- |
| `getCurrent()` | `GET` | `/academic-calendar` | All authenticated |
| `getActiveSemester()` | `GET` | `/academic-calendar/semesters/active` | All authenticated |
| `getActiveSession()` | `GET` | `/academic-calendar/sessions/active` | All authenticated |
| `getSessions(params?)` | `GET` | `/academic-calendar/sessions` | All authenticated |
| `getSessionById(id)` | `GET` | `/academic-calendar/sessions/:id` | All authenticated |
| `getCalendarAnnouncements()` | `GET` | `/academic-calendar/events` | All authenticated |

---

## 5. React Query Hooks

**Location:** `src/modules/timetable/hooks/`

### Query Key Factory

Define a centralized query key factory in `src/modules/timetable/hooks/useTimetable.ts`:

```
timetableKeys = {
  all:              ['timetable']
  myTimetable:      (semesterId?) => ['timetable', 'my', { semesterId }]
  student:          (studentId, semesterId?) => ['timetable', 'student', studentId, { semesterId }]
  lecturer:         (lecturerId, semesterId?) => ['timetable', 'lecturer', lecturerId, { semesterId }]
  schedules:        (filters?) => ['timetable', 'schedules', filters]
  scheduleById:     (id) => ['timetable', 'schedules', id]
  byOffering:       (offeringId) => ['timetable', 'offering', offeringId]
  bySemester:       (semesterId) => ['timetable', 'semester', semesterId]
  venues:           () => ['timetable', 'venues']
  venueAvail:       (params) => ['timetable', 'venue-availability', params]
}

calendarKeys = {
  all:              ['calendar']
  myEvents:         (params?) => ['calendar', 'my', params]
  myUpcoming:       () => ['calendar', 'my', 'upcoming']
  upcoming:         (days?) => ['calendar', 'upcoming', days]
  byCourse:         (offeringId, params?) => ['calendar', 'course', offeringId, params]
  all:              (filters?) => ['calendar', 'events', filters]
  byId:             (id) => ['calendar', 'events', id]
}

academicCalendarKeys = {
  current:     () => ['academic-calendar', 'current']
  sessions:    (params?) => ['academic-calendar', 'sessions', params]
  session:     (id) => ['academic-calendar', 'sessions', id]
  active:      () => ['academic-calendar', 'active']
  semester:    () => ['academic-calendar', 'semester', 'active']
  announcements: () => ['academic-calendar', 'announcements']
}
```

### `useTimetable.ts` — Hooks

| Hook | Type | Description |
| ---- | ---- | ----------- |
| `useMyTimetable(params?)` | `useQuery` | Current user's timetable for active/specified semester |
| `useStudentTimetable(studentId, params?)` | `useQuery` | Admin: specific student's timetable |
| `useLecturerTimetable(lecturerId, params?)` | `useQuery` | Admin: specific lecturer's timetable |
| `useSchedulesByOffering(offeringId)` | `useQuery` | All slots for a course offering |
| `useSchedulesBySemester(semesterId, params?)` | `useQuery` | All slots across a semester |
| `useAllSchedules(filters?)` | `useQuery` | Admin paginated schedule list |
| `useScheduleById(id)` | `useQuery` | Single schedule detail |
| `useVenues()` | `useQuery` | All distinct venue names |
| `useVenueAvailability(params, enabled?)` | `useQuery` | Venue busy/free window check |
| `useCreateSchedule()` | `useMutation` | Create schedule; invalidates `timetableKeys.all` on success |
| `useUpdateSchedule()` | `useMutation` | Update schedule; invalidates schedule keys on success |
| `useDeleteSchedule()` | `useMutation` | Delete schedule; invalidates schedule keys on success |

### `useCalendarEvents.ts` — Hooks

| Hook | Type | Description |
| ---- | ---- | ----------- |
| `useMyCalendarEvents(params?)` | `useQuery` | Current user's course + site events |
| `useMyUpcomingEvents()` | `useQuery` | Shortcut: next 14 days |
| `useUpcomingEvents(days?)` | `useQuery` | Global upcoming events (any role) |
| `useEventsByCourse(offeringId, params?)` | `useQuery` | Events for a specific course |
| `useAllCalendarEvents(filters?)` | `useQuery` | Admin: paginated all events |
| `useCalendarEventById(id)` | `useQuery` | Single event detail |
| `useToggleEventVisibility()` | `useMutation` | Admin: toggle visibility; invalidates event keys |

### `useAcademicCalendar.ts` — Hooks

| Hook | Type | Description |
| ---- | ---- | ----------- |
| `useAcademicCalendar()` | `useQuery` | Active session + all semesters (staleTime: 10 min) |
| `useActiveSemester()` | `useQuery` | Active semester (derived from `useAcademicCalendar`) |
| `useActiveSession()` | `useQuery` | Active academic session |
| `useSessions(params?)` | `useQuery` | Paginated list of sessions |
| `useSessionById(id)` | `useQuery` | Session with semesters |
| `useCalendarAnnouncements()` | `useQuery` | Portal-side event announcements |

### Query Config Notes

- `useMyTimetable` and `useAcademicCalendar` should have `staleTime: 5 * 60 * 1000` (5 min) since timetable data rarely changes mid-session.
- `useMyCalendarEvents` and `useMyUpcomingEvents` should have `refetchInterval: 5 * 60 * 1000` for soft polling (new events added via Moodle sync).
- Disable queries with `enabled: false` when required params (like `studentId`) are not yet resolved.

---

## 6. Zustand UI Store

**Location:** `src/modules/timetable/store/useTimetableUIStore.ts`

> Zustand stores only UI state — no server data.

### `useTimetableUIStore`

| State Field | Type | Default | Purpose |
| ----------- | ---- | ------- | ------- |
| `viewMode` | `'grid' \| 'list'` | `'grid'` | Toggle between weekly grid and flat list view |
| `selectedSemesterId` | `number \| null` | `null` | Which semester is selected in the tab switcher |
| `selectedDay` | `DayOfWeek \| null` | `null` | Highlight a specific day column in grid view |
| `scheduleFilters` | `ScheduleFilter` | `{}` | Admin filter state (persisted across re-renders) |
| `calendarFilters` | `CalendarEventFilter` | `{}` | Calendar event filter state |
| `venueCheckerDayOfWeek` | `DayOfWeek \| null` | `null` | Admin venue checker: selected day |
| `venueCheckerVenue` | `string` | `''` | Admin venue checker: selected venue |
| `isScheduleDialogOpen` | `boolean` | `false` | Admin: create/edit schedule dialog open state |
| `editingScheduleId` | `number \| null` | `null` | Admin: which schedule is being edited (null = create) |

### Actions

| Action | Description |
| ------ | ----------- |
| `setViewMode(mode)` | Toggle grid/list |
| `setSelectedSemesterId(id)` | Switch timetable semester |
| `setSelectedDay(day)` | Highlight a day in grid |
| `setScheduleFilters(filters)` | Update admin filter state |
| `setCalendarFilters(filters)` | Update calendar filter state |
| `openScheduleDialog(id?)` | Open dialog (pass id to edit, omit to create) |
| `closeScheduleDialog()` | Close dialog and clear editingScheduleId |
| `resetVenueChecker()` | Clear venue checker state |

---

## 7. Pages & Shell Components

All pages are thin **Server Components** — they provide layout/metadata and render client component shells. They do **not** fetch data directly; data fetching is handled by React Query hooks inside the client components.

### `app/(root)/timetable/layout.tsx`

- Wraps all `/timetable/**` routes in a shared layout
- Renders `AcademicCalendarBanner` (client component)
- Renders a semester tab switcher (driven by `useAcademicCalendar`)

### `app/(root)/timetable/page.tsx`

- Title: "My Timetable"
- Renders `TimetableGrid` or `TimetableList` client component (toggled by `useTimetableUIStore.viewMode`)
- Passes `semesterId` from Zustand store or active semester

### `app/(root)/timetable/calendar/page.tsx`

- Title: "Calendar"
- Renders `CalendarEventList` client component
- Shows Moodle events + portal announcements merged, sorted by date

### `app/(root)/timetable/upcoming/page.tsx`

- Title: "Upcoming Events"
- Renders `CalendarEventList` with `upcoming` mode (next 14 days)

### `app/(dashboard)/tutor/(routes)/timetable/page.tsx`

- Title: "My Schedule"
- Renders `TimetableGrid` and `TimetableList` (tutor variant)
- Includes `CalendarEventList` for course events in a side panel or tab

### `app/(dashboard)/admin/(routes)/timetable/page.tsx`

- Title: "Class Schedules"
- Renders `TimetableList` (admin variant with edit/delete actions)
- Includes filter controls and "Create Schedule" button (opens `ScheduleFormDialog`)

### `app/(dashboard)/admin/(routes)/timetable/venue-check/page.tsx`

- Title: "Venue Availability"
- Renders `VenueAvailabilityChecker` client component

### `app/(dashboard)/admin/(routes)/calendar/page.tsx`

- Title: "Calendar Events"
- Renders `CalendarEventList` (admin variant with visibility toggles)

---

## 8. Client Component Breakdown

> All components below are `"use client"`. They consume React Query hooks and Zustand store — no props threading for token or server data.

### `AcademicCalendarBanner`

- Calls `useAcademicCalendar()`
- Displays: active session name, current semester name, registration dates
- Shows countdown badge (days until registration close or semester end)
- ShadCN: `Badge`, `Separator`
- Skeleton while loading

### `TimetableGrid`

- Calls `useMyTimetable({ semesterId, groupByDay: true })`
- Renders a 7-column grid (or 5-column Mon–Fri depending on data)
- Each column = a day; rows represent time slots sorted by `startTime`
- Highlights the current day column
- Empty state when no classes on a given day
- ShadCN: `Card`, `Badge`
- Framer Motion: subtle enter animation per slot card

### `TimetableList`

- Calls `useMyTimetable()` or `useAllSchedules()` depending on context (role/page)
- Flat sortable list of `ScheduleSlotCard` components
- Supports filter controls via `useTimetableUIStore.scheduleFilters`
- Admin variant includes Edit and Delete action buttons per row
- ShadCN: `Table` (thead, tbody, tr, th, td), `Button`, `Badge`, `Skeleton`

### `ScheduleSlotCard`

- Presentational component for a single timetable slot
- Displays: day chip, time range, venue, class type badge, course code + title, lecturer name
- Admin variant: shows Edit and Delete icon buttons
- ShadCN: `Card`, `CardContent`, `Badge`, `Button`
- Color-coded class type: `LECTURE` = blue, `LAB` = green, `TUTORIAL` = yellow, `SEMINAR` = purple

### `ScheduleFormDialog`

- Controlled by `useTimetableUIStore.isScheduleDialogOpen` and `editingScheduleId`
- Uses `react-hook-form` with `zodResolver(CreateScheduleSchema)` (or `UpdateScheduleSchema`)
- Pre-fills form when editing (calls `useScheduleById(editingScheduleId)` when `editingScheduleId != null`)
- Submits via `useCreateSchedule()` or `useUpdateSchedule()` mutation
- Inline venue conflict warning: on blur of time fields, calls `useVenueAvailability` with `enabled` flag to surface clashes before submission
- ShadCN: `Dialog`, `DialogContent`, `DialogHeader`, `Form`, `FormField`, `FormItem`, `FormLabel`, `FormControl`, `FormMessage`, `Select`, `Input`, `Button`

### `CalendarEventCard`

- Presentational component for a single Moodle calendar event
- Displays: event type badge, name, date, course code (if course event), Zoom link button (if `meetingUrl` present)
- Admin variant: includes `EventVisibilityToggle`
- ShadCN: `Card`, `Badge`, `Button`

### `CalendarEventList`

- Calls `useMyCalendarEvents()` or `useAllCalendarEvents()` depending on context
- Groups events by date (today, this week, later) using a date grouping helper
- Refetches every 5 minutes (`refetchInterval`)
- Empty state: "No upcoming events"
- ShadCN: `Skeleton`, `Separator`
- Framer Motion: staggered list entrance

### `EventVisibilityToggle`

- Admin-only
- Calls `useToggleEventVisibility()` mutation
- ShadCN: `Switch`, `Label`
- Shows optimistic UI update while mutation is in-flight

### `VenueAvailabilityChecker`

- Calls `useVenues()` for venue autocomplete
- Calls `useVenueAvailability(params, enabled)` — query enabled only when venue + day + semester are all set
- Renders a timeline visualization of busy and free slots for the selected day
- ShadCN: `Select`, `Card`, `Badge`, `Skeleton`

---

## 9. Auth & Role Gating

Role gating is handled entirely in `middleware.ts` — no `requireRole()` utility in server components.

### `middleware.ts` — Route Matcher

```
Route pattern                                          Required roles
──────────────────────────────────────────────────     ──────────────────────────
/timetable/*                                           ["STUDENT", "TUTOR", "ADMIN", "STAFF"]
/timetable/calendar                                    ["STUDENT", "TUTOR", "ADMIN"]
/(dashboard)/tutor/(routes)/timetable                  ["TUTOR", "ADMIN"]
/(dashboard)/admin/(routes)/timetable/*                ["ADMIN"]
/(dashboard)/admin/(routes)/calendar/*                 ["ADMIN"]
```

### Pattern

The middleware:
1. Reads the JWT from the `access_token` cookie
2. Decodes roles with `jwt-decode` (no verification — stateless read only)
3. Checks if the user's roles include at least one required role for the route
4. Redirects to `/403` if access is denied; to `/login` if no token

### Component-level Guard

For in-page UI differences (e.g., showing Edit buttons only to ADMIN), decode roles client-side using a `useCurrentUser()` hook that reads from the JWT cookie or a global auth store. Conditional rendering based on role should be purely cosmetic — server-side authorization is the authoritative gate.

---

## 10. Error Handling & Loading States

### Route-level `error.tsx`

Place `error.tsx` files at:
- `app/(root)/timetable/error.tsx`
- `app/(dashboard)/admin/(routes)/timetable/error.tsx`
- `app/(dashboard)/admin/(routes)/calendar/error.tsx`

Each should:
- Be `"use client"`
- Display the error message with a "Try again" action (calls `reset()`)
- ShadCN: `Button`

### Route-level `loading.tsx`

Place `loading.tsx` files at:
- `app/(root)/timetable/loading.tsx`
- `app/(dashboard)/admin/(routes)/timetable/loading.tsx`

Each should render skeleton placeholders matching the shape of the page content:
- Timetable grid: 5 column skeleton blocks
- Timetable list: 6 row skeleton cards
- ShadCN: `Skeleton`

### React Query Error Handling

- All hooks should pass `throwOnError: false` (default)
- Handle `error` state inside each component — show inline `Alert` with message
- For mutations: use `onError` callback to call `toast({ variant: "destructive" })` via ShadCN `useToast`
- For mutations: use `onSuccess` callback to `toast({ title: "Success" })` and invalidate relevant queries

### Conflict Errors

When `useCreateSchedule` or `useUpdateSchedule` returns a `409 Conflict`:
- Display an inline error within `ScheduleFormDialog` indicating which slot conflicts
- Do not dismiss the dialog — allow the user to adjust the time/venue

---

## 11. Environment Variables & Dependencies

### Environment Variables

```bash
# .env.local
NEXT_PUBLIC_API_URL=http://localhost:3000   # NestJS backend base URL
```

### Installation

```bash
npm install @tanstack/react-query zustand zod react-hook-form @hookform/resolvers framer-motion jwt-decode
```

### Dependency Table

| Package | Purpose |
| ------- | ------- |
| `@tanstack/react-query` | All server data fetching and caching |
| `zustand` | Timetable UI state (view mode, filters, dialog state) |
| `zod` | Form validation schemas; type inference |
| `react-hook-form` | Schedule create/edit form state |
| `@hookform/resolvers` | Connects Zod schemas to React Hook Form via `zodResolver` |
| `framer-motion` | Slot card entrance animations, list transitions |
| `jwt-decode` | Decode JWT roles in middleware for route protection |
