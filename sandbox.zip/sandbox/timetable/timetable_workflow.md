# Timetable & Calendar Module — Implementation Workflow

This document explains the internal NestJS implementation flow for the Timetable and Calendar module. Intended for developers building or maintaining this module.

---

## Module Dependencies

```
TimetableModule
├── PrismaService              (database access)
├── AcademicModule             (read AcademicSession, Semester — exposed via AcademicService)
├── CourseModule               (read CourseOffering — exposed via CourseService)
├── EnrollmentModule           (read StudentEnrollment — exposed via EnrollmentService)
├── MoodleSyncModule           (read MoodleSyncCalendarEvent, MoodleSyncCourse)
├── ContentModule              (read Announcement where category = "event")
└── AuthModule / JwtGuard      (role-based access control)
```

---

## File Structure

```
src/modules/timetable/
├── timetable.module.ts
├── timetable.controller.ts         # /timetable/* routes
├── timetable.service.ts
├── calendar.controller.ts          # /calendar/* routes
├── calendar.service.ts
├── academic-calendar.controller.ts # /academic-calendar/* routes
├── academic-calendar.service.ts
├── dto/
│   ├── create-schedule.dto.ts
│   ├── update-schedule.dto.ts
│   ├── schedule-filter.dto.ts
│   ├── venue-availability.dto.ts
│   └── calendar-event-filter.dto.ts
└── types/
    ├── timetable.types.ts           # internal return shapes
    └── calendar.types.ts
```

---

## 1. Create Class Schedule Flow

**Trigger:** Admin POSTs to `POST /timetable/schedules`

```
Admin sends: { offeringId, lecturerId, dayOfWeek, startTime, endTime, venue, classType }
                   │
                   ▼
┌─────────────────────────────────────────────────┐
│  TimetableService.createSchedule(dto)           │
│                                                 │
│  Step 1: Validate CourseOffering exists         │
│          and status is OPEN or PLANNED          │
│          → CourseService.findOfferingById()     │
│                                                 │
│  Step 2: Validate Lecturer is assigned          │
│          to that CourseOffering                 │
│          → Check CourseOfferingLecturer table   │
│                                                 │
│  Step 3: Validate startTime < endTime           │
│          (string HH:MM comparison)              │
│                                                 │
│  Step 4: Check venue conflict                   │
│          → Query ClassSchedule WHERE            │
│            venue = dto.venue                    │
│            AND dayOfWeek = dto.dayOfWeek        │
│            AND offering.semesterId = derived    │
│            AND time ranges overlap              │
│          → If conflict: throw 409               │
│                                                 │
│  Step 5: Check lecturer conflict                │
│          → Query ClassSchedule WHERE            │
│            lecturerId = dto.lecturerId          │
│            AND dayOfWeek = dto.dayOfWeek        │
│            AND time ranges overlap              │
│          → If conflict: throw 409               │
│                                                 │
│  Step 6: prisma.classSchedule.create(...)       │
│                                                 │
│  Step 7: Return created record enriched with    │
│          course code, lecturer name             │
└─────────────────────────────────────────────────┘
```

### Time Overlap Logic

Two time ranges [A_start, A_end] and [B_start, B_end] overlap when:
```
A_start < B_end AND A_end > B_start
```
Since `startTime` and `endTime` are stored as `HH:MM` strings, comparison is done lexicographically (safe for 24h format) or by parsing to minutes since midnight.

---

## 2. Get Student Timetable Flow

**Trigger:** Student calls `GET /timetable/my` (or admin calls `GET /timetable/student/:studentId`)

```
JWT → extract userId → resolve Student record
                   │
                   ▼
┌─────────────────────────────────────────────────┐
│  TimetableService.getStudentTimetable(          │
│      studentId, semesterId?)                    │
│                                                 │
│  Step 1: Resolve semesterId                     │
│          → if provided: use it                  │
│          → if not: fetch active Semester        │
│            from AcademicService                 │
│                                                 │
│  Step 2: Fetch student's ENROLLED offerings     │
│          → StudentEnrollment WHERE              │
│              studentId = studentId              │
│              AND semesterId = semesterId         │
│              AND status = ENROLLED              │
│          → collect offeringIds[]                │
│                                                 │
│  Step 3: Fetch ClassSchedules for those         │
│          offeringIds                            │
│          → ClassSchedule WHERE                  │
│              offeringId IN offeringIds[]        │
│          → include: offering.course,            │
│              lecturer.user (firstName, lastName)│
│                                                 │
│  Step 4: Map to timetable slot shape:           │
│          { scheduleId, dayOfWeek, startTime,    │
│            endTime, venue, classType,           │
│            courseCode, courseTitle, creditUnits,│
│            lecturerName }                       │
│                                                 │
│  Step 5: If groupByDay=true: reduce into        │
│          { MONDAY: [...], TUESDAY: [...], ... } │
│                                                 │
│  Return shaped result                           │
└─────────────────────────────────────────────────┘
```

---

## 3. Get Lecturer Timetable Flow

**Trigger:** Tutor calls `GET /timetable/my` (or admin calls `GET /timetable/lecturer/:lecturerId`)

```
JWT → extract userId → resolve Lecturer record
                   │
                   ▼
┌─────────────────────────────────────────────────┐
│  TimetableService.getLecturerTimetable(         │
│      lecturerId, semesterId?)                   │
│                                                 │
│  Step 1: Resolve semesterId (same as above)     │
│                                                 │
│  Step 2: Fetch offerings the lecturer is        │
│          assigned to in that semester           │
│          → CourseOfferingLecturer WHERE         │
│              lecturerId = lecturerId            │
│              AND offering.semesterId            │
│                  = semesterId                   │
│          → collect offeringIds[]                │
│                                                 │
│  Step 3: Fetch ClassSchedules WHERE             │
│          offeringId IN offeringIds[]            │
│          OR lecturerId = lecturerId             │
│          (lecturer may teach a slot for an      │
│           offering co-taught with others)       │
│                                                 │
│  Step 4: Map and optionally group by day        │
│                                                 │
│  Return shaped result                           │
└─────────────────────────────────────────────────┘
```

---

## 4. Venue Availability Check Flow

**Trigger:** Admin calls `GET /timetable/venue-availability?venue=...&dayOfWeek=...&semesterId=...`

```
┌─────────────────────────────────────────────────┐
│  TimetableService.getVenueAvailability(         │
│      venue, dayOfWeek, semesterId,              │
│      excludeScheduleId?)                        │
│                                                 │
│  Step 1: Query ClassSchedule WHERE              │
│          venue = venue (case-insensitive)        │
│          AND dayOfWeek = dayOfWeek              │
│          AND offering.semesterId = semesterId   │
│          AND id != excludeScheduleId (opt.)     │
│          ORDER BY startTime ASC                 │
│                                                 │
│  Step 2: Build "busy slots" list:               │
│          [{ startTime, endTime,                 │
│             courseCode, lecturerName }]         │
│                                                 │
│  Step 3: Build "free windows" list by           │
│          calculating gaps between busy slots    │
│          (e.g., 08:00–10:00, 12:00–16:00)      │
│                                                 │
│  Return { venue, dayOfWeek, busySlots,          │
│           freeWindows }                         │
└─────────────────────────────────────────────────┘
```

---

## 5. Academic Calendar Flow

**Trigger:** Any authenticated user calls `GET /academic-calendar`

```
┌─────────────────────────────────────────────────┐
│  AcademicCalendarService.getCurrent()           │
│                                                 │
│  Step 1: Fetch active AcademicSession           │
│          → AcademicSession WHERE isActive = true│
│          → If none: fetch most recent session   │
│            by startDate DESC                    │
│                                                 │
│  Step 2: Fetch all Semesters for that session   │
│          → Semester WHERE                       │
│              academicSessionId = session.id     │
│          ORDER BY startDate ASC                 │
│                                                 │
│  Step 3: Resolve currentSemester                │
│          → semesters.find(s => s.isActive)      │
│          → null if none active                  │
│                                                 │
│  Step 4: Return { session, semesters,           │
│                   currentSemester }             │
└─────────────────────────────────────────────────┘
```

---

## 6. My Calendar Events Flow

**Trigger:** Student or Tutor calls `GET /calendar/events/my`

```
JWT → resolve userId + role
             │
             ▼
┌─────────────────────────────────────────────────┐
│  CalendarService.getMyEvents(userId, role, dto) │
│                                                 │
│  Step 1: Resolve date window                    │
│          → if from/to provided: use them        │
│          → else: now to now + 14 days           │
│                                                 │
│  Step 2: Fetch site-wide events                 │
│          → MoodleSyncCalendarEvent WHERE        │
│              moodleSyncCourseId IS NULL         │
│              AND isVisible = true               │
│              AND startDate >= from              │
│              AND startDate <= to                │
│                                                 │
│  Step 3: Resolve user's moodleSyncCourse IDs    │
│          ─ if STUDENT:                          │
│              StudentEnrollment WHERE            │
│              studentId = resolved               │
│              AND status = ENROLLED              │
│              → offeringIds[]                    │
│              → MoodleSyncCourse WHERE           │
│                courseOfferingId IN offeringIds  │
│              → moodleSyncCourseIds[]            │
│          ─ if TUTOR / LECTURER:                 │
│              CourseOfferingLecturer WHERE       │
│              lecturerId = resolved              │
│              → offeringIds[]                    │
│              → MoodleSyncCourse WHERE           │
│                courseOfferingId IN offeringIds  │
│              → moodleSyncCourseIds[]            │
│                                                 │
│  Step 4: Fetch course events                    │
│          → MoodleSyncCalendarEvent WHERE        │
│              moodleSyncCourseId IN ids[]        │
│              AND isVisible = true               │
│              AND startDate >= from              │
│              AND startDate <= to                │
│                                                 │
│  Step 5: Merge site-wide + course events        │
│          Deduplicate by moodleEventId           │
│          Sort by startDate ASC                  │
│                                                 │
│  Step 6: Enrich each event with                 │
│          courseCode and courseTitle             │
│          (join via moodleSyncCourse             │
│           → courseOffering → course)            │
│                                                 │
│  Return enriched sorted events[]               │
└─────────────────────────────────────────────────┘
```

---

## 7. Toggle Event Visibility Flow

**Trigger:** Admin calls `PATCH /calendar/events/:id/visibility`

```
┌─────────────────────────────────────────────────┐
│  CalendarService.toggleVisibility(id)           │
│                                                 │
│  Step 1: Fetch MoodleSyncCalendarEvent by id    │
│          → throw 404 if not found               │
│                                                 │
│  Step 2: Toggle: isVisible = !current.isVisible │
│                                                 │
│  Step 3: prisma.moodleSyncCalendarEvent.update  │
│          ({ where: { id }, data: { isVisible }})│
│                                                 │
│  Return updated event                           │
└─────────────────────────────────────────────────┘
```

---

## DTOs

### CreateScheduleDto

| Field | Validation |
| ----- | ---------- |
| `offeringId` | `@IsInt()`, `@IsPositive()` |
| `lecturerId` | `@IsInt()`, `@IsPositive()` |
| `dayOfWeek` | `@IsEnum(['MONDAY','TUESDAY','WEDNESDAY','THURSDAY','FRIDAY','SATURDAY','SUNDAY'])` |
| `startTime` | `@Matches(/^\d{2}:\d{2}$/)` — must be `HH:MM` |
| `endTime` | `@Matches(/^\d{2}:\d{2}$/)` — must be `HH:MM`, validated > startTime at service layer |
| `venue` | `@IsString()`, `@MaxLength(100)` |
| `classType` | `@IsEnum(['LECTURE','LAB','TUTORIAL','SEMINAR'])` |

### UpdateScheduleDto

All fields from `CreateScheduleDto` wrapped in `@IsOptional()` (PartialType pattern).

### ScheduleFilterDto

| Field | Validation |
| ----- | ---------- |
| `semesterId` | `@IsOptional()`, `@IsInt()` |
| `offeringId` | `@IsOptional()`, `@IsInt()` |
| `lecturerId` | `@IsOptional()`, `@IsInt()` |
| `dayOfWeek` | `@IsOptional()`, `@IsEnum(...)` |
| `venue` | `@IsOptional()`, `@IsString()` |
| `classType` | `@IsOptional()`, `@IsEnum(...)` |
| `page` | `@IsOptional()`, `@IsInt()`, `@Min(1)` |
| `limit` | `@IsOptional()`, `@IsInt()`, `@Min(1)`, `@Max(100)` |

### VenueAvailabilityDto

| Field | Validation |
| ----- | ---------- |
| `venue` | `@IsString()`, `@IsNotEmpty()` |
| `dayOfWeek` | `@IsEnum(...)` |
| `semesterId` | `@IsInt()`, `@IsPositive()` |
| `excludeScheduleId` | `@IsOptional()`, `@IsInt()` |

### CalendarEventFilterDto

| Field | Validation |
| ----- | ---------- |
| `eventType` | `@IsOptional()`, `@IsEnum(['course','site','user','zoom'])` |
| `courseOfferingId` | `@IsOptional()`, `@IsInt()` |
| `from` | `@IsOptional()`, `@IsISO8601()` |
| `to` | `@IsOptional()`, `@IsISO8601()` |
| `isVisible` | `@IsOptional()`, `@IsBoolean()` |
| `days` | `@IsOptional()`, `@IsInt()`, `@Min(1)`, `@Max(90)` (for upcoming shortcuts) |
| `page` | `@IsOptional()`, `@IsInt()`, `@Min(1)` |
| `limit` | `@IsOptional()`, `@IsInt()`, `@Min(1)`, `@Max(100)` |

---

## Role Guards Summary

| Endpoint Group | Roles Allowed |
| -------------- | ------------- |
| `GET /timetable/my` | `STUDENT`, `TUTOR` |
| `GET /timetable/schedules` (list/filter) | `ADMIN`, `STAFF` |
| `GET /timetable/schedules/:id` | `ADMIN`, `STAFF`, `TUTOR` |
| `GET /timetable/schedules/offering/:id` | `ADMIN`, `STAFF`, `TUTOR` |
| `GET /timetable/schedules/semester/:id` | `ADMIN`, `STAFF` |
| `GET /timetable/student/:id` | `ADMIN`, `STAFF` |
| `GET /timetable/lecturer/:id` | `ADMIN`, `STAFF` |
| `POST/PUT/DELETE /timetable/schedules` | `ADMIN` only |
| `GET /timetable/venue-availability` | `ADMIN` |
| `GET /timetable/venues` | `ADMIN`, `STAFF` |
| `GET /academic-calendar/**` | Any authenticated |
| `GET /calendar/events/my` | `STUDENT`, `TUTOR` |
| `GET /calendar/events/upcoming` | Any authenticated |
| `GET /calendar/events/course/:id` | `STUDENT`, `TUTOR`, `ADMIN` |
| `GET /calendar/events` (admin list) | `ADMIN`, `STAFF` |
| `PATCH /calendar/events/:id/visibility` | `ADMIN` |

---

## Error Handling

| Scenario | Exception |
| -------- | --------- |
| `startTime >= endTime` | `BadRequestException` |
| Venue conflict detected | `ConflictException` — include details of conflicting schedule |
| Lecturer double-booking | `ConflictException` — include conflicting course name |
| `CourseOffering` not found | `NotFoundException` |
| `CourseOffering.status` is `CLOSED` or `CANCELLED` | `BadRequestException` |
| Lecturer not assigned to offering | `BadRequestException` |
| Calendar event not found | `NotFoundException` |
| No active semester (timetable/my) | Return empty result with `{ activeSemester: null }` flag — do not throw |

---

## Caching Strategy

| Query | Recommended Cache | TTL |
| ----- | ---------------- | --- |
| `GET /academic-calendar` | Redis cache keyed by active session | 10 min |
| `GET /timetable/my` | Per-user Redis cache | 5 min, invalidated on schedule create/update/delete |
| `GET /calendar/events/upcoming` | Public cache | 5 min |
| `GET /timetable/venues` | Redis cache | 10 min, invalidated on schedule write |

---

## Module Registration

```
TimetableModule imports:
  - PrismaModule
  - forwardRef(() => AcademicModule)   ← avoid circular dep with AcademicModule
  - forwardRef(() => CourseModule)
  - forwardRef(() => EnrollmentModule)
  - forwardRef(() => MoodleSyncModule)
  - forwardRef(() => ContentModule)
  - CacheModule (if Redis caching is used)
```

> Use `forwardRef()` where circular module dependencies may arise (common when multiple modules consume each other's services).
