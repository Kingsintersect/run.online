# Timetable & Calendar Module

Manages class schedules (weekly timetable slots), academic calendar (sessions and semesters), and Moodle-sourced calendar events (course events, Zoom meeting links). Exposes both read views per role and admin management endpoints.

---

## Scope

This module covers two closely related concerns that are surfaced together in the portal UI:

| Concern | Primary Model | Nature |
| ------- | ------------- | ------ |
| **Timetable** | `ClassSchedule` | Recurring weekly slots (day, time, venue, class type) tied to a `CourseOffering` and `Lecturer` |
| **Academic Calendar** | `AcademicSession`, `Semester` | Session and semester date ranges, registration windows |
| **Calendar Events** | `MoodleSyncCalendarEvent` | One-off events pulled from Moodle — class notices, Zoom meetings, deadlines |
| **Event Announcements** | `Announcement` (category = `"event"`) | Portal-side announcements surfaced in the calendar view |

---

## Models Owned

- **`ClassSchedule`** — the timetable record. Each row = one recurring weekly class slot.
- **`MoodleSyncCalendarEvent`** — read-only pull from Moodle; not writable via this module.
- **`Attendance`** — created/queried through class schedules (read-only via this module; write via Attendance sub-resource).

> `AcademicSession`, `Semester`, `CourseOffering`, `Announcement` are **owned by their respective modules** (Academic, Course, Content). This module only **reads** them.

---

## Endpoint Groups

1. [Class Schedules (Timetable)](#1-class-schedules-timetable)
2. [My Timetable (Role-aware)](#2-my-timetable-role-aware)
3. [Venue Availability](#3-venue-availability)
4. [Academic Calendar](#4-academic-calendar)
5. [Calendar Events (Moodle)](#5-calendar-events-moodle)
6. [My Calendar Events](#6-my-calendar-events)

---

## 1. Class Schedules (Timetable)

> Admin and staff manage class schedule records. Lecturers and students read them.

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/timetable/schedules` | List all class schedules (filterable by semesterId, offeringId, lecturerId, dayOfWeek, venue) | Admin, Staff |
| `GET` | `/timetable/schedules/:id` | Get a single class schedule by ID | Admin, Staff, Tutor |
| `POST` | `/timetable/schedules` | Create a new class schedule slot | Admin |
| `PUT` | `/timetable/schedules/:id` | Update a class schedule slot | Admin |
| `DELETE` | `/timetable/schedules/:id` | Delete a class schedule slot | Admin |
| `GET` | `/timetable/schedules/offering/:offeringId` | All schedule slots for a specific course offering | Admin, Staff, Tutor |
| `GET` | `/timetable/schedules/semester/:semesterId` | All schedule slots across all offerings in a semester | Admin, Staff |
| `GET` | `/timetable/schedules/lecturer/:lecturerId` | All schedule slots assigned to a specific lecturer | Admin, Staff |

### Query Parameters — `GET /timetable/schedules`

| Param | Type | Description |
| ----- | ---- | ----------- |
| `semesterId` | `number` | Filter by semester |
| `offeringId` | `number` | Filter by course offering |
| `lecturerId` | `number` | Filter by lecturer |
| `dayOfWeek` | `string` | Filter by day (e.g., `MONDAY`) |
| `venue` | `string` | Filter by venue name (partial match) |
| `classType` | `string` | Filter by class type (e.g., `LECTURE`, `LAB`, `TUTORIAL`) |
| `page` | `number` | Pagination |
| `limit` | `number` | Page size |

### Request Body — `POST /timetable/schedules`

| Field | Type | Required | Description |
| ----- | ---- | -------- | ----------- |
| `offeringId` | `number` | Yes | The `CourseOffering` this slot belongs to |
| `lecturerId` | `number` | Yes | The lecturer taking this slot |
| `dayOfWeek` | `string` | Yes | `MONDAY` \| `TUESDAY` \| `WEDNESDAY` \| `THURSDAY` \| `FRIDAY` \| `SATURDAY` \| `SUNDAY` |
| `startTime` | `string` | Yes | 24h time string `HH:MM` (e.g., `08:00`) |
| `endTime` | `string` | Yes | 24h time string `HH:MM` (e.g., `10:00`) |
| `venue` | `string` | Yes | Room/venue name (e.g., `LT-1`, `Lab Block A`) |
| `classType` | `string` | Yes | `LECTURE` \| `LAB` \| `TUTORIAL` \| `SEMINAR` |

### Business Rules — Schedules

- A venue cannot have two overlapping slots on the same day and time (venue conflict check).
- A lecturer cannot have two overlapping slots on the same day and time (lecturer conflict check).
- A `CourseOffering` must be in `OPEN` or `PLANNED` status to have schedules created.
- `startTime` must be before `endTime`.

---

## 2. My Timetable (Role-aware)

> Single endpoint that returns the calling user's timetable based on their role.

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/timetable/my` | Returns timetable for the calling user. Students → enrolled courses; Lecturers → assigned offerings. Accepts `semesterId` query param (defaults to active semester). | Student, Tutor |
| `GET` | `/timetable/student/:studentId` | Get timetable for a specific student | Admin, Staff |
| `GET` | `/timetable/lecturer/:lecturerId` | Get timetable for a specific lecturer | Admin, Staff |

### Query Parameters — `GET /timetable/my`

| Param | Type | Default | Description |
| ----- | ---- | ------- | ----------- |
| `semesterId` | `number` | Active semester | Which semester to load schedules for |
| `groupByDay` | `boolean` | `false` | Group results by `dayOfWeek` instead of flat list |

### Response Shape — `GET /timetable/my`

Returns an array of schedule slots, each enriched with:

- Course code, title, and credit units (from `CourseOffering → Course`)
- Lecturer name (from `Lecturer → User`)
- Day, start time, end time, venue, classType
- If `groupByDay = true`: grouped object keyed by `MONDAY` … `SUNDAY`

---

## 3. Venue Availability

> Used by admins when creating/editing schedules to check for conflicts at a venue.

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/timetable/venue-availability` | Check what slots at a given venue + day are already taken in a semester | Admin |
| `GET` | `/timetable/venues` | List all distinct venue names used in the current semester (for autocomplete) | Admin, Staff |

### Query Parameters — `GET /timetable/venue-availability`

| Param | Type | Required | Description |
| ----- | ---- | -------- | ----------- |
| `venue` | `string` | Yes | Venue name to check |
| `dayOfWeek` | `string` | Yes | Day to check |
| `semesterId` | `number` | Yes | Semester scope |
| `excludeScheduleId` | `number` | No | Exclude a specific schedule (used when editing) |

---

## 4. Academic Calendar

> Provides session and semester data — used to populate the calendar header, date ranges, and registration windows on the UI.

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/academic-calendar` | Get the active academic session + all its semesters with key dates | Any authenticated |
| `GET` | `/academic-calendar/sessions` | List all academic sessions (paginated) | Any authenticated |
| `GET` | `/academic-calendar/sessions/:id` | Get a session with all its semesters | Any authenticated |
| `GET` | `/academic-calendar/sessions/active` | Get the currently active academic session | Any authenticated |
| `GET` | `/academic-calendar/semesters/active` | Get the currently active semester | Any authenticated |
| `GET` | `/academic-calendar/events` | List portal-side calendar announcements (`category = "event"`) | Any authenticated |

### Response Shape — `GET /academic-calendar`

```
{
  session: { id, name, startDate, endDate },
  semesters: [
    {
      id, name, startDate, endDate, isActive,
      registrationStart, registrationEnd
    }
  ],
  currentSemester: { id, name, ... } | null
}
```

---

## 5. Calendar Events (Moodle)

> Moodle-sourced calendar events: course events, site-wide notices, and Zoom meeting links.  
> All records are **read-only** via the portal (written only by the Moodle Sync module).

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/calendar/events` | List all calendar events (filterable by eventType, courseOfferingId, date range, isVisible) | Admin, Staff |
| `GET` | `/calendar/events/:id` | Get a single calendar event | Any authenticated |
| `GET` | `/calendar/events/upcoming` | Events starting in the next N days (default: 14). Accepts `days` query param. | Any authenticated |
| `GET` | `/calendar/events/course/:courseOfferingId` | All events linked to a specific course offering | Student, Tutor, Admin |
| `PATCH` | `/calendar/events/:id/visibility` | Toggle `isVisible` for an event | Admin |

### Query Parameters — `GET /calendar/events`

| Param | Type | Description |
| ----- | ---- | ----------- |
| `eventType` | `string` | `course` \| `site` \| `user` \| `zoom` |
| `courseOfferingId` | `number` | Filter by course offering |
| `moodleSyncCourseId` | `number` | Filter by Moodle sync course record |
| `from` | `ISO date` | Start of date range (inclusive) |
| `to` | `ISO date` | End of date range (inclusive) |
| `isVisible` | `boolean` | Filter by visibility |
| `page` | `number` | Pagination |
| `limit` | `number` | Page size |

---

## 6. My Calendar Events

> Unified view for the authenticated user: their enrolled/teaching course events + site-wide events.

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/calendar/events/my` | Events for the calling user's courses (via enrollments or teaching assignments) + site-wide events. Accepts `from`, `to`, `days` params. | Student, Tutor |
| `GET` | `/calendar/events/my/upcoming` | Shortcut: next 14 days of events for the calling user | Student, Tutor |

### Response Shape — `GET /calendar/events/my`

Returns merged list of:
- **Course events** — events where `moodleSyncCourse` maps to an offering the user is enrolled in or teaches
- **Site events** — events where `moodleSyncCourseId` is null (site-wide)
- Each event: `id, eventType, name, description, startDate, endDate, meetingUrl, isVisible, courseCode, courseTitle`

---

## Response Envelope

All list endpoints return:

```json
{
  "data": [...],
  "meta": {
    "total": 120,
    "page": 1,
    "limit": 20,
    "totalPages": 6
  }
}
```

---

## Error Codes

| HTTP Status | Scenario |
| ----------- | -------- |
| `400` | Missing required field, time conflict, invalid time range |
| `403` | Insufficient role (e.g., student tries to create schedule) |
| `404` | Schedule, event, session, or semester not found |
| `409` | Venue conflict or lecturer double-booking |

---

## Related Modules

| Module | Relationship |
| ------- | ------------ |
| `AcademicModule` | Owns `AcademicSession`, `Semester` — read-only by this module |
| `CourseModule` | Owns `CourseOffering` — read-only by this module |
| `EnrollmentModule` | Owns `StudentEnrollment` — used to resolve a student's timetable |
| `MoodleSyncModule` | Owns `MoodleSyncCalendarEvent` — read-only by this module |
| `ContentModule` | Owns `Announcement` — `category = "event"` surfaced in calendar |
