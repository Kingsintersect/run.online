# Enrollment Drift Check — Design, Schema & API

**Status:** proposed design, 2026-09-14. Follow-up to this folder's README (§4 deferred
enrollments). Approved direction: per-course check + institution-wide background scan, a
persistent drift report, **portal wins**, every fix an explicit admin action.

---

## 1. Why enrollments need their own design

Reconcile (README §3.A) doesn't fit enrollments, for three reasons verified against the current
code and contract:

1. **Scale.** Reconcile's preview is synchronous — one Moodle call lists every category/course/
   user. Moodle only lists enrollments **per course** (`core_enrol_get_enrolled_users`), so a
   whole-institution preview is one call per synced course — hundreds of calls, too slow to wait
   on.
2. **Direction.** Reconcile assumes Moodle is right and updates the portal. Enrollment is the
   opposite: the portal is the authority (tuition verification triggers `onTuitionVerified()`,
   which creates the Moodle user and enrols them). A Moodle-side difference usually means **Moodle
   is wrong**.
3. **Data model.** Every enrollment sync row requires a portal `studentEnrollmentId`
   (`src/modules/moodle-sync/schemas/enrollment.schema.ts`), so a Moodle-only enrollment has
   nowhere to be recorded.

Today the portal only pushes enrollments (Push All Pending, per-row Push/Retry, Errors page). The
backend has a per-course `POST /moodle-sync/enrollments/pull/{moodleCourseId}`, but no screen uses
it.

## 2. What counts as drift

Only users enrolled in the Moodle course with the **student role** (`MOODLE_STUDENT_ROLE_ID`) are
compared. Teachers, managers and the sync bot account are ignored.

| Kind | Definition | Why it matters |
|---|---|---|
| `MISSING_IN_MOODLE` | An active portal `StudentEnrollment` whose sync row is `SYNCED`, but the student is **not** enrolled in the Moodle course | Someone removed them inside Moodle; the portal still says enrolled and the student silently loses access |
| `ONLY_IN_MOODLE` | A student-role enrollment in the Moodle course with **no** matching active portal `StudentEnrollment` for that course offering | Someone enrolled them by hand inside Moodle — course access with no portal enrollment and no fee record |

**Not drift (already covered):** enrollments whose sync row is `FAILED` or `PENDING`. Those are
exactly the "push didn't happen" cases the existing Errors page and Retry handle. The check
reports their counts (`failedPush`, `pendingPush`) for context but never creates drift items for
them, so nothing is double-counted.

## 3. Rules

- **The check never changes enrollments** — portal or Moodle. Its only write is the drift report.
- **No action creates a portal enrollment.** An `ONLY_IN_MOODLE` student is never auto-enrolled on
  the portal — admission and fees must go through the normal flow.
- **Removing someone from Moodle is a deliberate, reasoned action** (`unenrol`, reason required),
  never automatic.
- **Dismiss suppresses re-flagging.** A dismissed item isn't re-raised while the same condition
  persists (e.g. an approved auditor). If the condition clears, the item auto-resolves; if it
  recurs later, a fresh item is created.
- **Auto-clear.** Any `OPEN` or `DISMISSED` item whose condition no longer holds on a later
  check/scan becomes `RESOLVED` with resolution `AUTO_CLEARED`.

## 4. Schema changes

Additive only. New tables — the existing enrollment sync table is **not** changed. A drift item is
a report entry, not a mapping, so making `studentEnrollmentId` nullable on the sync table would
blur what that table means ("a portal enrollment mirrored to Moodle").

```sql
CREATE TYPE enrollment_drift_kind       AS ENUM ('MISSING_IN_MOODLE', 'ONLY_IN_MOODLE');
CREATE TYPE enrollment_drift_status     AS ENUM ('OPEN', 'RESOLVED', 'DISMISSED');
CREATE TYPE enrollment_drift_resolution AS ENUM ('RE_ENROLLED', 'UNENROLLED_IN_MOODLE',
                                                 'DISMISSED', 'AUTO_CLEARED');

CREATE TABLE moodle_enrollment_drift (
  id                     bigserial PRIMARY KEY,
  kind                   enrollment_drift_kind NOT NULL,
  status                 enrollment_drift_status NOT NULL DEFAULT 'OPEN',
  moodle_course_id       integer NOT NULL,
  course_offering_id     bigint NULL REFERENCES course_offerings(id),
  student_enrollment_id  bigint NULL REFERENCES student_enrollments(id),
  portal_user_id         bigint NULL REFERENCES users(id),
  moodle_user_id         integer NULL,
  snapshot               jsonb NOT NULL,   -- {studentName, matricNumber, email} at detection
  detected_at            timestamp NOT NULL,
  last_seen_at           timestamp NOT NULL,
  resolved_at            timestamp NULL,
  resolved_by            bigint NULL REFERENCES users(id),
  resolution             enrollment_drift_resolution NULL,
  resolution_note        text NULL,
  created_at             timestamp NOT NULL,
  updated_at             timestamp NOT NULL,
  CHECK (
    (kind = 'MISSING_IN_MOODLE' AND student_enrollment_id IS NOT NULL) OR
    (kind = 'ONLY_IN_MOODLE'    AND moodle_user_id        IS NOT NULL)
  )
);

-- At most one live (OPEN or DISMISSED) item per condition — this is what makes
-- dismiss suppress re-flagging.
CREATE UNIQUE INDEX one_live_drift_per_condition
  ON moodle_enrollment_drift (moodle_course_id, kind,
                              COALESCE(student_enrollment_id, 0),
                              COALESCE(moodle_user_id, 0))
  WHERE status IN ('OPEN', 'DISMISSED');

CREATE TABLE moodle_enrollment_drift_scans (
  id               bigserial PRIMARY KEY,
  status           varchar(12) NOT NULL,    -- RUNNING | COMPLETED | FAILED
  courses_total    integer NOT NULL,
  courses_checked  integer NOT NULL DEFAULT 0,
  started_by       bigint NULL REFERENCES users(id),   -- NULL when started by the scheduler
  started_at       timestamp NOT NULL,
  finished_at      timestamp NULL,
  error            text NULL
);
```

## 5. API contracts

All routes: bearer auth, `{data: ...}` envelope. Paths under `/moodle-sync/enrollments/drift`.

### Shared `DriftItem` shape

```jsonc
{
  "id": 81,
  "kind": "ONLY_IN_MOODLE",              // MISSING_IN_MOODLE | ONLY_IN_MOODLE
  "status": "OPEN",                      // OPEN | RESOLVED | DISMISSED
  "moodleCourseId": 77,
  "courseOfferingId": 301,               // null if the Moodle course isn't mapped
  "courseCode": "ECO101",
  "courseTitle": "Introduction to Economics",
  "studentEnrollmentId": null,           // set for MISSING_IN_MOODLE
  "portalUserId": 501,                   // set when the Moodle user maps to a portal account
  "moodleUserId": 88,                    // set for ONLY_IN_MOODLE
  "studentName": "Ada Okafor",
  "matricNumber": "RUN/2026/0142",       // null when there's no portal student record
  "email": "ada@example.com",
  "detectedAt": "2026-09-14T02:00:11Z",
  "lastSeenAt": "2026-09-14T02:00:11Z",
  "resolvedAt": null,
  "resolvedBy": null,
  "resolution": null,                    // RE_ENROLLED | UNENROLLED_IN_MOODLE | DISMISSED | AUTO_CLEARED
  "resolutionNote": null
}
```

### `POST /moodle-sync/enrollments/drift/check/{moodleCourseId}` — one course, synchronous

One Moodle call. Updates the drift report for that course (create / touch `lastSeenAt` /
auto-clear), then returns it.

```jsonc
// Response 200
{
  "data": {
    "moodleCourseId": 77,
    "courseOfferingId": 301,
    "courseCode": "ECO101",
    "courseTitle": "Introduction to Economics",
    "checkedAt": "2026-09-14T10:02:40Z",
    "summary": {
      "inSync": 118,
      "missingInMoodle": 2,
      "onlyInMoodle": 1,
      "failedPush": 3,          // existing FAILED sync rows — context, not drift
      "pendingPush": 0          // existing PENDING sync rows — context, not drift
    },
    "items": [ /* OPEN DriftItems for this course after the check */ ]
  }
}
```

Errors: 404 `COURSE_NOT_SYNCED` (no course mapping for that Moodle course).

### `POST /moodle-sync/enrollments/drift/scan` — every synced course, queued

```jsonc
// Response 202
{ "data": { "status": "RUNNING", "coursesTotal": 300, "coursesChecked": 0,
            "startedAt": "2026-09-14T10:05:00Z", "finishedAt": null, "error": null } }
```

Errors: 409 `SCAN_IN_PROGRESS`.

### `GET /moodle-sync/enrollments/drift/scan` — latest scan status

```jsonc
// Response 200 — status IDLE (with nulls) if no scan has ever run
{ "data": { "status": "COMPLETED", "coursesTotal": 300, "coursesChecked": 300,
            "startedAt": "2026-09-14T10:05:00Z", "finishedAt": "2026-09-14T10:11:42Z",
            "error": null } }
```

`status` ∈ `IDLE | RUNNING | COMPLETED | FAILED`. The frontend polls this every few seconds while
`RUNNING`.

### `GET /moodle-sync/enrollments/drift` — the report

Query: `status`, `kind`, `moodleCourseId`, `page` (default 1), `limit` (default 25, max 100).

```jsonc
{ "data": [ /* DriftItem */ ], "meta": { "total": 4, "page": 1, "limit": 25 } }
```

### `GET /moodle-sync/enrollments/drift/summary`

```jsonc
{ "data": {
    "open": { "missingInMoodle": 2, "onlyInMoodle": 1 },
    "dismissed": 5,
    "lastScanAt": "2026-09-14T10:11:42Z",     // null if never scanned
    "lastScanStatus": "COMPLETED"             // null if never scanned
} }
```

### Actions — each returns the updated `DriftItem`

| Route | Body | Allowed when | Effect |
|---|---|---|---|
| `POST .../drift/{id}/re-enroll` | — | `OPEN` + `MISSING_IN_MOODLE` | Re-pushes the portal enrollment to Moodle (existing push logic). → `RESOLVED`, `RE_ENROLLED` |
| `POST .../drift/{id}/unenrol` | `{ "reason": "..." }` | `OPEN` + `ONLY_IN_MOODLE` | Removes the student from the Moodle course. Portal unchanged. → `RESOLVED`, `UNENROLLED_IN_MOODLE` |
| `POST .../drift/{id}/dismiss` | `{ "reason": "..." }` | `OPEN` | → `DISMISSED`, reason stored in `resolutionNote` |
| `POST .../drift/{id}/reopen` | — | `DISMISSED` | → `OPEN`, resolution fields cleared |

`reason`: required, 5–500 characters.

Errors:
- 409 `DRIFT_NOT_OPEN` / `DRIFT_NOT_DISMISSED` — wrong status for the action
- 422 `WRONG_DRIFT_KIND` — e.g. `re-enroll` on an `ONLY_IN_MOODLE` item
- 422 `UNENROL_METHOD_UNSUPPORTED` — the student was enrolled by a Moodle method other than manual
  enrolment (e.g. cohort sync, self-enrolment); the message names the method so the admin can
  remove it in Moodle directly
- Moodle push failure on `re-enroll` → 502 `MOODLE_ERROR`, item stays `OPEN`

## 6. Moodle, scheduling, permissions

- **Moodle web-service functions:** `core_enrol_get_enrolled_users` (already used) plus
  **`enrol_manual_unenrol_users`** (new) — enable it on the `MOODLE_API_TOKEN` service.
- **Scheduled job (recommended):** `php artisan moodle:scan-enrollment-drift`, daily at 02:00, so
  the report is fresh each morning without anyone pressing a button.
- **Permissions:**
  - View report / summary / scan status: existing `moodle-sync.view`
  - Check a course, start a scan: existing `moodle-sync.pull`
  - Re-enroll: existing `moodle-sync.push`
  - Unenrol, dismiss, reopen: `moodle-sync.drift.resolve`. **Already created on
    production (id 113, module `moodle-sync`) and assigned to `super_admin` on
    2026-09-14.** The backend only needs to enforce it on these three routes.

## 7. Frontend call sites

(For the frontend plan, not the backend team.)

- `src/modules/moodle-sync/schemas/enrollment-drift.schema.ts`, types in `types/index.ts`.
- `moodle-sync.service.ts` — check, scan start/status, list, summary, and the four actions.
- `hooks/use-enrollment-drift.ts` (queries; scan status polls while `RUNNING`) and new mutations
  in `hooks/use-sync-mutations.ts`.
- `components/enrollments/enrollment-drift-panel.tsx` on the Enrollments page — summary, scan
  progress, filters, report, actions; plus a per-course check dialog and a reason dialog for
  dismiss/unenrol.
