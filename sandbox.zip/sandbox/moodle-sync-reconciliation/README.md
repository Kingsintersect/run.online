# Moodle Sync — Reconcile & Reset

**Status:** proposed design, 2026-09-14. Approved direction: **both** — reconciliation for the
identity-mapping modules, reset limited to the safe (cache-only) modules.

---

## 1. The problem

An admin ran **Pull all from Moodle** on categories, then restructured the categories inside
Moodle itself. The portal no longer matched Moodle, and there was no way to bring it back in
line.

What the current contract actually covers (verified against `bruno/moodle-sync/` and
`sandbox/schema-moodel-sync-refactor/api-v2.md`):

- `POST /moodle-sync/categories/pull` — "match by `idnumber`, flag anything unmatched."
  Response `{matched_by_idnumber, updated, needs_mapping}`.
- **Not documented anywhere:** whether a category **moved** to a new parent in Moodle is moved on
  the portal, and what happens to a category **deleted** in Moodle. There is no status for
  "removed in Moodle" — `STALE` means the opposite ("local changes not yet pushed").
- **No bulk reset endpoint exists for any module.** Only categories have a per-row
  `DELETE /moodle-sync/categories/{id}` (mapping only).
- Bulk pulls run on the Laravel queue with retries — so "wipe, then pull" is **not atomic**: a
  failed or slow job leaves the portal empty.

## 2. The governing rule: the portal owns the structure

The system is built portal-first — creating a faculty/program/level/semester on the portal
auto-pushes it to Moodle; creating a course offering auto-pushes the course; verifying tuition
creates the student in Moodle. **Structure changes belong on the portal's Academic Structure
page, then pushed.** Reconcile exists to recover from drift, not to make Moodle the place
structure is edited.

## 3. Two tools, split by what's safe

### A. Reconcile — categories, courses, users

These modules hold **links** other portal data depends on (Programs attach to the category tree
via `parentAcademicUnitId`; assessments/grades/calendar/enrollments all key off synced courses;
users link portal accounts to Moodle accounts and power course launch). They must never be
wiped. Instead:

1. **Preview** — a dry run against live Moodle returning a diff: to create / renamed / moved /
   removed in Moodle / needs mapping / unchanged. **Writes nothing.**
2. **Apply** — applies exactly the previewed diff (by `previewId`, short TTL):
   - creates new mappings, updates renamed ones, re-parents moved ones;
   - marks removed ones **`REMOVED_IN_MOODLE`** — never hard-deleted, so an admin can review
     each and then delete the mapping or relink it;
   - **never deletes linked portal entities** — no `AcademicUnit`, `Faculty`, `Program`,
     `CourseOffering` or `User` row is removed by reconcile.

Categories an admin already resolved keep matching, because Resolve writes `unit:{id}` back into
Moodle's `idnumber`.

### B. Reset — assessments, calendar, Moodle grades only

These are **pull-only caches**: nothing on the portal links to them, the scheduler refreshes them
every 30–60 minutes anyway, and Moodle grades are explicitly separate from the portal's official
`Grade` model (`moodle-sync-api.md`, Grade Sync note). Reset deletes the cached rows and can
re-pull **in the same queued job**, which removes the empty-portal window.

### Explicitly **not** resettable

| Module | Why |
|---|---|
| Categories | Portal structure; Programs and courses attach to it |
| Courses | Every assessment/grade/calendar/enrollment pull and student course launch depends on it |
| Users | Portal-originated accounts; re-pulling does not rebuild the links |
| Enrollments | Portal-originated (`StudentEnrollment`); the portal is the authority. Drift is handled by a separate check — see `ENROLLMENT_DRIFT.md` |
| Cohorts | Push-only — the portal is the source |

## 4. Not in this pass

- **Enrollments** — not reconciled. Moodle only lists enrollments per course, and the portal (not
  Moodle) is the authority, so it gets its own design: **`ENROLLMENT_DRIFT.md`** (per-course check,
  background scan, drift report, explicit fixes).
- **Relinking a `REMOVED_IN_MOODLE` course or user** to a different Moodle record — categories
  already have Resolve; courses/users get dismiss-only for now.
- **Scheduled reconciliation** — reconcile stays admin-triggered with a human reviewing the
  preview.

## 5. Files

- `SCHEMA_CHANGES.md` — the new status value and the preview store.
- `API_CONTRACTS.md` — preview/apply/reset request and response shapes, errors.
- `ENROLLMENT_DRIFT.md` — the enrollment drift check: design, schema and API in one doc.
