# API Contracts — Moodle Sync Reconcile & Reset

All routes: `Authorization: Bearer <token>`, **Admin** only, same `{data: ...}` envelope as the
rest of `/moodle-sync`.

---

## 1. Reconcile — `categories`, `courses`, `users`

`{module}` ∈ `categories | courses | users`. Any other value → 404 (the route does not exist).

### `POST /moodle-sync/{module}/reconcile/preview`

Dry run against live Moodle. **Writes no sync rows.** Synchronous — it compares, it doesn't import.

```jsonc
// Request: no body

// Response 200
{
  "data": {
    "previewId": "0b8f6f1e-3c1a-4a52-9f0e-2f7d6d9a1c44",
    "module": "categories",
    "expiresAt": "2026-09-14T10:15:00Z",
    "summary": {
      "toCreate": 3,
      "renamed": 1,
      "moved": 2,
      "removedInMoodle": 1,
      "needsMapping": 0,
      "unchanged": 38
    },
    "changes": [
      {
        "kind": "MOVED",                 // CREATE | RENAMED | MOVED | REMOVED_IN_MOODLE | NEEDS_MAPPING
        "syncId": 12,                    // null for CREATE
        "moodleId": 9,
        "name": "B.Sc. Sociology",
        "before": { "name": "B.Sc. Sociology", "parentName": "Social Sciences" },
        "after":  { "name": "B.Sc. Sociology", "parentName": "Part-Time Programmes" }
      },
      {
        "kind": "REMOVED_IN_MOODLE",
        "syncId": 31,
        "moodleId": 44,
        "name": "100 Level",
        "before": { "name": "100 Level", "parentName": "B.Sc. Economics" },
        "after": null
      }
    ]
  }
}
```

- `before`/`after` carry `parentName` for categories only; courses use `categoryName`, users use
  `role`. `unchanged` rows are counted, not listed.
- A category/course change is `RENAMED` + `MOVED` if both apply — emit two entries with the same
  `syncId`.

### `POST /moodle-sync/{module}/reconcile/apply`

```jsonc
// Request
{ "previewId": "0b8f6f1e-3c1a-4a52-9f0e-2f7d6d9a1c44" }

// Response 200
{
  "data": {
    "module": "categories",
    "applied": {
      "created": 3,
      "renamed": 1,
      "moved": 2,
      "markedRemoved": 1,
      "needsMapping": 0
    }
  }
}
```

**Guarantees:**
- Applies **only** what that preview listed.
- `REMOVED_IN_MOODLE` rows get `sync_status = REMOVED_IN_MOODLE` and `removed_in_moodle_at = now()`
  — **never deleted**.
- Never deletes an `AcademicUnit`, `Faculty`, `Department`, `Program`, `Level`, `Semester`,
  `CourseOffering` or `User`.
- A row previously `REMOVED_IN_MOODLE` whose Moodle record reappears returns to `SYNCED` and has
  `removed_in_moodle_at` cleared.

**Errors:**

```jsonc
// 409 — preview older than its TTL
{ "statusCode": 409, "error": "PREVIEW_EXPIRED",
  "message": "This preview expired. Run a new preview." }

// 409 — Moodle changed between preview and apply (moodle_hash mismatch)
{ "statusCode": 409, "error": "PREVIEW_STALE",
  "message": "Moodle changed since this preview was generated. Run a new preview." }

// 409 — already applied
{ "statusCode": 409, "error": "PREVIEW_ALREADY_APPLIED" }

// 404 — unknown previewId, or previewId belongs to a different module
{ "statusCode": 404, "error": "PREVIEW_NOT_FOUND" }
```

### List endpoints — new filter value

`GET /moodle-sync/categories|courses|users?status=REMOVED_IN_MOODLE` — returns rows flagged by a
reconcile.

### Dismissing a removed row

- Categories: existing `DELETE /moodle-sync/categories/{id}` (mapping only).
- **New, for parity:** `DELETE /moodle-sync/courses/{id}` and `DELETE /moodle-sync/users/{id}` —
  delete the **mapping row only** (never the `CourseOffering`/`User`). 204. Only allowed when
  `sync_status = REMOVED_IN_MOODLE` → otherwise 409 `MAPPING_STILL_ACTIVE`.

---

## 2. Reset — `assessments`, `calendar`, `grades` only

`{module}` ∈ `assessments | calendar | grades`. **No reset route exists for categories, courses,
users, enrollments or cohorts** — see README.md §3.

### `POST /moodle-sync/{module}/reset`

```jsonc
// Request
{ "repull": true }
```

- `repull: false` → deletes every cached row for the module synchronously.
  **Response 200:** `{ "data": { "module": "calendar", "deleted": 412, "repullQueued": false } }`
- `repull: true` → one queued job deletes **and** re-pulls, so the portal is never left empty
  between the two. **Response 202:** `{ "data": { "module": "calendar", "deleted": null, "repullQueued": true } }`

`grades` here means Moodle LMS grades (`/moodle-sync/grades`) — it never touches the portal's
official `Grade` model.

**Errors:** 409 `SYNC_IN_PROGRESS` if a pull/reset job for that module is already running.

---

## 3. Permissions

- **Reconcile** (preview + apply) reuses the existing `moodle-sync.pull` permission — it's a
  safer pull.
- **Reset** needs a **new** permission, `moodle-sync.reset`, because it deletes data. Please add
  it to the permission catalog and assign it to `super_admin` (and `admin` only if intended). The
  frontend gates the Reset button on it today, so until it exists only Super Admin (who bypasses
  every check) sees Reset.

---

## 4. Frontend call sites

(For the frontend plan, not the backend team.)

- `src/modules/moodle-sync/schemas/reconcile.schema.ts` — preview/apply/reset response schemas.
- `moodle-sync.service.ts` — `previewReconcile`, `applyReconcile`, `resetModule`.
- `use-sync-mutations.ts` — `usePreviewReconcile`, `useApplyReconcile`, `useResetModule`.
- `components/shared/reconcile-dialog.tsx` — preview diff grouped by kind, Apply button.
- `components/shared/reset-sync-dialog.tsx` — typed confirmation + "re-pull after reset" option.
- A **Reconcile with Moodle** button on the categories, courses and users pages; a **Reset**
  button on the assessments, calendar and grades pages.
- `sync-status-badge.tsx` — label/colour for `REMOVED_IN_MOODLE`.
