# Schema Changes — Moodle Sync Reconcile & Reset

Additive only. Model names follow `moodle-sync-api.md`; rename to match your real Laravel
migrations — the columns and semantics are what matter.

---

## 1. Sync status — new value

```diff
 enum SyncStatus {
   PENDING
   SYNCED
   FAILED
   STALE
+  REMOVED_IN_MOODLE   // the Moodle record this mapping points at no longer exists
 }
```

Applies to the category, course and user sync mapping tables only (the reconcilable modules).
Every existing row keeps its current value.

## 2. Sync mapping tables — one new column each

On `moodle_sync_categories`, `moodle_sync_courses`, `moodle_sync_users`:

```diff
+  removed_in_moodle_at  timestamp NULL   // set when reconcile marks REMOVED_IN_MOODLE;
+                                         // cleared if the record reappears on a later reconcile
```

Nullable, no backfill.

## 3. New table — `moodle_sync_reconcile_previews`

Holds a preview so **apply** can run exactly what the admin reviewed.

```sql
CREATE TABLE moodle_sync_reconcile_previews (
  id           uuid PRIMARY KEY,
  module       varchar(20) NOT NULL,     -- 'categories' | 'courses' | 'users'
  changes      jsonb NOT NULL,           -- the diff returned to the admin
  moodle_hash  varchar(64) NOT NULL,     -- hash of the Moodle snapshot the diff was computed from
  created_by   bigint NOT NULL REFERENCES users(id),
  expires_at   timestamp NOT NULL,       -- created_at + 15 minutes
  applied_at   timestamp NULL,
  created_at   timestamp NOT NULL
);
```

`moodle_hash` lets apply detect that Moodle changed after the preview (`PREVIEW_STALE`, see
`API_CONTRACTS.md`). Expired rows can be pruned by a daily job.

## 4. Summary

| Change | Breaking? |
|---|---|
| `SyncStatus` + `REMOVED_IN_MOODLE` | No |
| `removed_in_moodle_at` on 3 mapping tables | No |
| `moodle_sync_reconcile_previews` table | New |

Reset needs **no schema change** — it deletes rows from the existing assessment, calendar and
Moodle-grade sync tables.
