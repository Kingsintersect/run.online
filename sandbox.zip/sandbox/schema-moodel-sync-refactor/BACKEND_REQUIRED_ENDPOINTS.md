# Backend Handoff — Endpoints Needed for the Multi-Structure Refactor

This is the actionable, backend-facing companion to `README.md`, `SCHEMA_CHANGES.md`, and
`api-v2.md` in this folder — those three cover the full design (schema, rationale, complete API
reference). This document lists **only what the frontend is now built against and waiting on**:
every endpoint below already has a real frontend caller that 404s/degrades gracefully until it
ships. Nothing here needs frontend work — it's a pure backend build list.

Context: the goal is one codebase, deployable as a secondary school, a degree faculty, a
postgraduate school, a sandwich program, or a business school — each with its own structure depth,
terminology, and grading rules, all syncing to Moodle the same way. See `README.md` §1–§2 for the
full rationale and the "why" behind each schema change.

---

## 1. Course Launch (SSO) — 1 new endpoint

Per product direction, course content (materials, live classes, assignments) lives entirely on
Moodle — the portal's only job is to show a student which courses they're enrolled in and hand
them off to Moodle via single sign-on.

The "which courses" part needs **no new endpoint** — `GET /enrollments/student/:id` (already real)
already returns everything the frontend's card grid needs. Only the SSO hand-off itself is new:

### `GET /students/me/courses/{offeringId}/launch` (Student)

Mints a one-time-use Moodle auto-login URL scoped to that enrollment's course (e.g. via Moodle's
`auth_userkey` plugin, or an equivalent SSO mechanism) so the student lands directly in that
course, already authenticated.

**Response `200`:**
```ts
{ redirectUrl: string }
```

**Errors (all `409`):**
- Student not yet Moodle-synced (`MoodleSyncUser` missing/failed)
- Course not yet Moodle-synced (`MoodleSyncCourse` missing for this offering)
- Student not enrolled in this offering

The frontend does not pre-guess readiness from a sync-status flag — every enrolled course's card is
clickable, and a `409` surfaces as a toast ("This course isn't set up on Moodle yet — check back
soon"), matching this error contract directly.

**Frontend caller:** `src/modules/enrollment/services/enrollment.service.ts`'s
`launchMoodleCourse()`, `hooks/use-enrollment-mutations.ts`'s `useLaunchMoodleCourse()`, rendered by
`components/my-course-launch-card.tsx` on `/student/courses`.

<details>
<summary>History: an earlier two-endpoint proposal was superseded by the above</summary>

An earlier pass proposed `GET /moodle-sync/courses/my` + `POST /moodle-sync/sso/launch`. That's
superseded — the course list needed no dedicated endpoint (see above), so only the launch endpoint
survived, moved under `/students/me` and reworked to key on `offeringId` instead of
`moodleCourseId`, returning `redirectUrl` instead of `launchUrl`.
</details>

---

## 2. Academic Structure — `/academic-structure`

A generic, self-referential `AcademicUnit` tree that either mirrors a real
Faculty/Department/Program/Level/Semester row, or exists as a pure structural node with no backing
table (e.g. a secondary school's "Stream" or "Section"). Full contract: `api-v2.md`
§"Academic Structure". Schema: `SCHEMA_CHANGES.md` §2 and §4 (`AcademicUnitType`, `AcademicUnit`).

**Endpoints needed:**
- `GET /academic-structure/unit-types` — list node types (seed at least `FACULTY, DEPARTMENT,
  PROGRAM, LEVEL, SEMESTER`).
- `POST /academic-structure/unit-types` — create a custom node type (e.g. `COHORT`).
- `GET /academic-structure/units` — list nodes, filterable by `parentId`/`typeId`/`rootsOnly`.
- `GET /academic-structure/units/{id}` — one node + its immediate children.
- `POST /academic-structure/units` — create a node (structural or mirror — `linkedEntity: {type,
  id}` for a mirror node). `422` if `linkedEntity` is already mirrored elsewhere.
- `PATCH /academic-structure/units/{id}` — update `name`/`sortOrder`/`parentId`. `typeCode` and
  `linkedEntity` are immutable after creation.
- `DELETE /academic-structure/units/{id}` — cascades to children; does not delete the linked
  Faculty/Department/Program/Level/Semester row, and does not touch Moodle.

**Companion schema changes** (also needed for this to work end-to-end):
- `Department.facultyId` → nullable.
- `Program.departmentId` → nullable; add `programCategory` (enum, default `DEGREE`),
  `parentAcademicUnitId` (nullable FK), `gradingSchemeId` (nullable FK). All three are additive and
  default to today's behavior.
- `CourseType` enum: add `SUBJECT`, `RESEARCH_PROJECT`.

**Frontend caller:** `src/services/academicStructureApi.ts`, `src/hooks/useAcademicStructure.ts`,
rendered by the Structure Builder at `/admin/academics/academic-structure` and
`/manager/academics/academic-structure` (`src/modules/academics/_components/academic-structure/`).

---

## 3. Grading Schemes — `/grading-schemes`

Lets a Program opt into a grading scheme other than the institution's implicit default
credit-weighted GPA. Full contract: `api-v2.md` §"Grading Schemes". Schema: `SCHEMA_CHANGES.md` §2
and §4 (`GradingScheme`, `GradingSchemeType`, `GradeScale.gradingSchemeId`).

**Endpoints needed:**
- `GET /grading-schemes` — list schemes (with their `gradeScales`).
- `POST /grading-schemes` — create a scheme: `{name, schemeType, passMark?, caWeightPercent?,
  examWeightPercent?}`. `schemeType` ∈ `CREDIT_WEIGHTED_GPA | SIMPLE_AVERAGE | PASS_FAIL`.
- `POST /grading-schemes/{id}/scales` — add a `GradeScale` row scoped to that scheme: `{grade,
  minScore, maxScore, gradePoint?, description?}`.

**Companion schema change:** `GradeScale` gains a nullable `gradingSchemeId`; its unique constraint
moves from `grade` (global) to `[gradingSchemeId, grade]` (scoped). Every existing row keeps
`gradingSchemeId = null` and keeps working exactly as today — the already-real `GET /grade-scales`
endpoint is untouched.

**Frontend caller:** `src/modules/student-grades/services/grading-schemes.service.ts`,
`hooks/use-grading-schemes.ts`, rendered by the new "Grading Schemes" tab at
`/admin/grades/grading-schemes` and `/manager/grades/grading-schemes`
(`src/modules/student-grades/_components/shells/GradingSchemes.tsx`).

---

## 4. Moodle Category Sync rework — `/moodle-sync/categories` onto `academicUnitId`

Replaces the old fixed 5-entity-type scheme (`entityType`/`entityId` ∈ `faculty, department,
program, level, semester`) with a single `academicUnitId` FK into the tree from §2 above — one
entity type instead of five, any depth, any structure. Full contract: `api-v2.md`
§"Moodle Category Sync". Migration path for existing installs: `README.md` §4 and §10.

**Endpoints needed (replacing/extending the existing category endpoints):**
- `GET /moodle-sync/categories` — list mappings; each row now keyed by `academicUnitId` instead of
  `entityType`/`entityId`. Add a `needsMapping: boolean` and `syncError: string|null` field.
- `GET /moodle-sync/categories/needs-mapping` — **new.** List categories pulled from Moodle with no
  resolvable `idnumber`.
- `POST /moodle-sync/categories/push` — body becomes `{academicUnitId, parentMoodleCategoryId?}`
  (was `{entityType, entityId, parentMoodleCategoryId?}`).
- `POST /moodle-sync/categories/push-subtree/{rootUnitId}` — **replaces** the old
  `push-hierarchy/{facultyId}`. Any `AcademicUnit` node can root a subtree push now, not just a
  Faculty; pushes breadth-first.
- `POST /moodle-sync/categories/pull` — same as before; response gains `needs_mapping: number`.
- `POST /moodle-sync/categories/{id}/resolve` — **new.** Manually resolve a flagged row: either
  `{linkedEntity: {type, id}}` (link to a real Faculty/Department/Program/Level/Semester) or
  `{typeCode, parentId}` (keep as a structural node, fix its type/parent).

**Migration for existing installs** (see `README.md` §4 for full detail): mirror every existing
Faculty/Department/Program/Level/Semester row into `AcademicUnit`, resolve every existing
`MoodleSyncCategory` row's `(entityType, entityId)` to its new `academicUnitId`, then re-run
`moodle:backfill-category-idnumbers` (now writing `"unit:{id}"` instead of `"{entityType}:{entityId}"`).
No Moodle-side categories need recreating.

**Frontend caller:** `src/modules/moodle-sync/services/moodle-sync.service.ts` (category methods),
`hooks/use-sync-categories.ts` + `use-sync-mutations.ts`, rendered by
`components/categories/{category-tree,category-push-dialog,category-needs-mapping-panel,category-resolve-dialog}.tsx`
on `/admin/moodle-sync/categories`. Note: `unitName`/`unitTypeCode`/`parentId` on each row are
enriched **client-side** by the frontend (joining against `/academic-structure/units`) — the
backend only needs to return the bare `academicUnitId` mapping row; it doesn't need to denormalize
those display fields itself.

---

## 5. Student Results, branched by `programCategory` — `/students/me/results`

A SECONDARY_SCHOOL program needs a simple average + class position per term, not a credit-weighted
GPA. Full contract: `api-v2.md` §"GET /students/me/results". Schema: `SCHEMA_CHANGES.md` §4
(`TermResultSummary`).

### `GET /students/me/results` (Student)

Returns whichever shape matches the caller's own Program's `programCategory`:

**`programCategory: "DEGREE" | "POSTGRADUATE" | "DIPLOMA"` (credit-weighted):**
```ts
{
  programCategory: string;
  schemeType: "CREDIT_WEIGHTED_GPA";
  data: {
    cgpa: number;
    classOfDegree: string;
    semesters: { semesterId: number; semesterName: string; gpa: number; cgpa: number; totalCreditUnits: number }[];
  };
}
```

**`programCategory: "SECONDARY_SCHOOL"` (simple average):**
```ts
{
  programCategory: "SECONDARY_SCHOOL";
  schemeType: "SIMPLE_AVERAGE";
  data: {
    terms: {
      semesterId: number;
      semesterName: string;
      averageScore: number;
      positionInClass: number | null;
      totalStudentsInClass: number | null;
      subjects: { courseCode: string; courseTitle: string; totalScore: number; grade: string }[];
    }[];
  };
}
```

Note: the frontend does **not** currently call this endpoint for the credit-weighted case — that
path still uses the existing real `getStudentTranscript`/CGPA endpoints unchanged, since they
already work. Only the `SECONDARY_SCHOOL` branch is wired against this new endpoint. If/when the
backend ships it, the credit-weighted branch could be migrated over too, but that's not required
for this refactor to be complete.

**Frontend caller:** `src/modules/student-grades/services/grades.service.ts`'s `getMyTermResults()`,
`hooks/use-grades-data.ts`'s `useMyTermResults()`, rendered by `TermResultsView.tsx`, invoked from
`StudentResultsPage.tsx` only when the student's own Program has
`programCategory === "SECONDARY_SCHOOL"` (resolved via `useMyStudentId()` + `useProgram()`).

---

## Status

Every endpoint above has a real, wired-up frontend caller today — nothing is a placeholder or a
future intention. Each 404s (or, for §1 and §4's resolve action, returns whatever your router does
for an unimplemented route) until you ship it; the frontend already handles that gracefully
(loading states, error toasts, graceful empty states) rather than crashing. Ship in whatever order
suits you — none of the five have a dependency on each other completing first, except that §4
(category sync) reads more naturally once §2 (Academic Structure) exists, since categories are keyed
on `academicUnitId`.
