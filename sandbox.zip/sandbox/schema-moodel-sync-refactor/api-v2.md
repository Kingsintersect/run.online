# Multi-Structure Portal — API Reference (v2 additions)

Base path: `/api/v1`. Auth: `Authorization: Bearer <sanctum-token>` on every
route. `Admin` routes additionally require the `admin` middleware;
`Lecturer/Admin` routes require `lecturer_or_admin` (alias to your existing
role check).

This document covers **only the endpoints introduced or changed** by the
multi-structure restructure. Unaffected endpoints (payments, hostel,
admissions, notifications) keep their existing shape from before.

---

## Academic Structure — `/academic-structure`

### `GET /academic-structure/unit-types`
List available node types. — **Admin**

**Response `200`:**
```json
{
  "data": [
    { "id": 1, "code": "FACULTY", "label": "Faculty" },
    { "id": 6, "code": "SCHOOL", "label": "School" },
    { "id": 7, "code": "SECTION", "label": "Section" },
    { "id": 8, "code": "STREAM", "label": "Stream" },
    { "id": 9, "code": "TERM", "label": "Term" }
  ]
}
```

### `POST /academic-structure/unit-types`
Create a custom node type. — **Admin**

**Request:**
```json
{ "code": "COHORT", "label": "Cohort" }
```
| Field | Type | Required | Notes |
|---|---|---|---|
| `code` | string | yes | uppercase, max 30 chars, unique |
| `label` | string | yes | max 100 chars |

**Response `201`:** `{ "data": { "id": 10, "code": "COHORT", "label": "Cohort" } }`

---

### `GET /academic-structure/units`
List nodes. — **Admin**

**Query params:** `parentId` (int, list children of this node), `rootsOnly`
(bool, list only top-level nodes), `typeId` (int, filter by type).

**Response `200`:**
```json
{
  "data": [
    {
      "id": 1,
      "typeId": 7,
      "typeCode": "SECTION",
      "parentId": null,
      "name": "Senior Secondary",
      "sortOrder": 0,
      "linkedEntity": null,
      "isActive": true,
      "childCount": 3
    }
  ]
}
```

### `GET /academic-structure/units/{id}`
Get one node with its immediate children. — **Admin**

**Response `200`:** same shape as list item, plus:
```json
{ "children": [ { "id": 2, "typeCode": "STREAM", "name": "Science", "...": "..." } ] }
```

### `POST /academic-structure/units`
Create a node — either a pure structural node or a mirror node linked to a
real entity. — **Admin**

**Request (structural node):**
```json
{ "typeCode": "STREAM", "parentId": 1, "name": "Science", "sortOrder": 0 }
```

**Request (mirror node):**
```json
{ "typeCode": "PROGRAM", "parentId": 2, "name": "SS - Science", "linkedEntity": { "type": "program", "id": 200 } }
```

| Field | Type | Required | Notes |
|---|---|---|---|
| `typeCode` | string | yes | must exist in `academic_unit_types` |
| `parentId` | integer, nullable | no | omit for a root node |
| `name` | string, max 200 | yes | |
| `sortOrder` | integer | no | default 0 |
| `linkedEntity.type` | enum: `faculty\|department\|program\|level\|semester` | no | required if `linkedEntity` present |
| `linkedEntity.id` | integer | no | required if `linkedEntity` present; must exist and not already be mirrored |

**Response `201`:** created node (same shape as list item).
**Errors:** `422` if `linkedEntity` points at an entity already mirrored by
another node.

### `PATCH /academic-structure/units/{id}`
Update `name`, `sortOrder`, `parentId`. `typeCode` and `linkedEntity` are
immutable after creation. — **Admin**

**Request:**
```json
{ "name": "Science Stream", "parentId": 1 }
```

### `DELETE /academic-structure/units/{id}`
Deletes the node and cascades to children. Does **not** delete the linked
Faculty/Department/Program/Level/Semester row, and does **not** delete
anything on Moodle. — **Admin**

---

## Moodle Category Sync — `/moodle-sync/categories`

Replaces the earlier build's category endpoints — same prefix, generic-tree
backed.

### `GET /moodle-sync/categories`
List sync mappings. Query: `status` (`PENDING\|SYNCED\|FAILED\|STALE`). — **Admin**

### `GET /moodle-sync/categories/needs-mapping`
List categories pulled from Moodle with no resolvable `idnumber`. — **Admin**

**Response `200`:**
```json
{
  "data": [
    {
      "id": 12,
      "academic_unit_id": 55,
      "moodle_category_id": 9,
      "moodle_category_name": "B.Sc. Sociology",
      "needs_mapping": true,
      "sync_error": "No idnumber on Moodle category 'B.Sc. Sociology' — cannot determine which AcademicUnit this corresponds to..."
    }
  ]
}
```

### `POST /moodle-sync/categories/push`
Push a single `AcademicUnit` node. — **Admin**

**Request:** `{ "academicUnitId": 55 }`

**Response `201`:**
```json
{
  "data": {
    "id": 12,
    "academic_unit_id": 55,
    "moodle_category_id": 9,
    "moodle_category_name": "B.SC. SOCIOLOGY",
    "sync_status": "SYNCED",
    "sync_direction": "PUSH"
  }
}
```

### `POST /moodle-sync/categories/push-subtree/{rootUnitId}`
Push a node and its entire subtree, breadth-first. — **Admin**

**Response `201`:** `{ "data": [ /* array of created mappings, root first */ ] }`

### `POST /moodle-sync/categories/pull`
Pull all Moodle categories; match by `idnumber`, flag anything unmatched. — **Admin**

**Response `200`:**
```json
{ "data": { "matched_by_idnumber": 40, "updated": 2, "needs_mapping": 3 } }
```

### `POST /moodle-sync/categories/{id}/resolve`
Manually resolve a flagged category. Either link it to an existing entity,
or fix its type/parent as a pure structural node. — **Admin**

**Request (link to existing entity):**
```json
{ "linkedEntity": { "type": "program", "id": 55 } }
```

**Request (keep as structural node, fix type/parent):**
```json
{ "typeCode": "STREAM", "parentId": 1 }
```

**Response `200`:** the resolved mapping.

---

## Grading Schemes — `/grading-schemes`

### `GET /grading-schemes`
**Response `200`:**
```json
{
  "data": [
    {
      "id": 1, "name": "University 5-Point GPA", "scheme_type": "CREDIT_WEIGHTED_GPA",
      "pass_mark": null, "ca_weight_percent": null, "exam_weight_percent": null,
      "gradeScales": [ { "grade": "A", "min_score": "70.00", "max_score": "100.00", "grade_point": "5.00" } ]
    },
    {
      "id": 2, "name": "WAEC 9-Point Scale", "scheme_type": "SIMPLE_AVERAGE",
      "pass_mark": "40.00", "ca_weight_percent": 30, "exam_weight_percent": 70,
      "gradeScales": [ { "grade": "A1", "min_score": "75.00", "max_score": "100.00", "grade_point": null } ]
    }
  ]
}
```

### `POST /grading-schemes`
**Request:**
```json
{ "name": "WAEC 9-Point Scale", "schemeType": "SIMPLE_AVERAGE", "passMark": 40.00, "caWeightPercent": 30, "examWeightPercent": 70 }
```
| Field | Type | Required |
|---|---|---|
| `name` | string, unique, max 100 | yes |
| `schemeType` | enum: `CREDIT_WEIGHTED_GPA\|SIMPLE_AVERAGE\|PASS_FAIL` | yes |
| `passMark` | decimal(5,2), nullable | no |
| `caWeightPercent` | integer 0-100, nullable | no |
| `examWeightPercent` | integer 0-100, nullable | no |

**Response `201`:** created scheme.

### `POST /grading-schemes/{id}/scales`
**Request:**
```json
{ "grade": "A1", "minScore": 75.00, "maxScore": 100.00, "gradePoint": null, "description": "Excellent" }
```
| Field | Type | Required |
|---|---|---|
| `grade` | string, max 2 | yes |
| `minScore` | decimal(5,2) | yes |
| `maxScore` | decimal(5,2), ≥ minScore | yes |
| `gradePoint` | decimal(3,2), nullable | no |
| `description` | string, max 50, nullable | no |

**Response `201`:** created scale row.

---

## Grades — `/grades`

### `POST /grades`
Create/update a grade. Server computes `totalScore`, `gradeScaleId`, and
`gradePoint` (if applicable) via the student's Program's `GradingScheme` —
never accepted from the client. — **Lecturer/Admin**

**Request:**
```json
{ "studentId": 501, "courseId": 12, "semesterId": 20, "caScore": 28.00, "examScore": 55.00 }
```
| Field | Type | Required |
|---|---|---|
| `studentId` | integer, exists | yes |
| `courseId` | integer, exists | yes |
| `semesterId` | integer, exists | yes |
| `caScore` | decimal, nullable | no |
| `examScore` | decimal, nullable | no |

**Response `201`:**
```json
{
  "data": {
    "id": 900, "student_id": 501, "course_id": 12, "semester_id": 20,
    "ca_score": "28.00", "exam_score": "55.00", "total_score": "83.00",
    "grade_scale_id": 4, "grade_point": null, "status": "DRAFT",
    "gradeScale": { "grade": "A1", "grade_point": null }
  }
}
```

### `PATCH /grades/{id}`
Update scores and/or advance status to `SUBMITTED`/`APPROVED` (not
`PUBLISHED` — that only happens via `/grades/publish`). — **Lecturer/Admin**

**Request:**
```json
{ "examScore": 58.00, "status": "APPROVED" }
```

**Response `200`:** updated grade, same shape as create response.

### `POST /grades/publish`
Publish all `APPROVED` grades for a semester and recompute aggregates
(`CgpaHistory` or `TermResultSummary`, branching per student's scheme). — **Admin**

**Request:** `{ "semesterId": 20 }`

**Response `200`:**
```json
{ "publishedCount": 340, "recomputed": { "cgpaHistoryRows": 85, "termResultSummaryRows": 255 } }
```

---

## Student Results & Courses — `/students/me`

### `GET /students/me/results`
Returns whichever result shape matches the student's `programCategory`. — **Student**

**Response `200` (credit-weighted — Degree/Postgrad/Diploma):**
```json
{
  "programCategory": "DEGREE",
  "schemeType": "CREDIT_WEIGHTED_GPA",
  "data": {
    "cgpa": 4.21,
    "classOfDegree": "Second Class Upper",
    "semesters": [
      { "semesterId": 20, "semesterName": "First Semester", "gpa": 4.35, "cgpa": 4.35, "totalCreditUnits": 18 }
    ]
  }
}
```

**Response `200` (simple average — Secondary School):**
```json
{
  "programCategory": "SECONDARY_SCHOOL",
  "schemeType": "SIMPLE_AVERAGE",
  "data": {
    "terms": [
      {
        "semesterId": 88, "semesterName": "Second Term",
        "averageScore": 68.40, "positionInClass": 4, "totalStudentsInClass": 42,
        "subjects": [ { "courseCode": "MTH-SS2", "courseTitle": "Mathematics", "totalScore": 72.00, "grade": "B2" } ]
      }
    ]
  }
}
```

### `GET /students/me/results/{semesterId}/download`
Returns a generated PDF (`Content-Type: application/pdf`) — transcript for
credit-weighted programs, result sheet for simple-average programs. — **Student**

### `GET /students/me/courses`
**Response `200`:**
```json
{
  "data": [
    { "offeringId": 301, "course": { "code": "ECO101", "title": "Introduction to Economics" }, "semester": "First Semester", "moodleSynced": true }
  ]
}
```

### `GET /students/me/courses/{offeringId}/launch`
Mints a one-time Moodle SSO login URL and returns it for the frontend to
redirect to. — **Student**

**Response `200`:**
```json
{ "redirectUrl": "https://moodle.example.edu/auth/userkey/select.php?key=abc123&wantsurl=%2Fcourse%2Fview.php%3Fid%3D77" }
```

**Errors:**
- `409` — student not yet synced to Moodle (`MoodleSyncUser` missing/failed)
- `409` — course not yet synced to Moodle (`MoodleSyncCourse` missing)
- `409` — student not enrolled in this offering

---

## Data types reference

| Type name used above | Laravel/DB representation |
|---|---|
| `integer` | signed 64-bit, matches `unsignedBigInteger` FKs |
| `decimal(p,s)` | MySQL `DECIMAL(p,s)`, returned as a numeric string by default in JSON unless cast (`'decimal:2'` casts shown above return floats) |
| `string` | `VARCHAR`, length noted per field |
| `enum: A\|B\|C` | MySQL `ENUM` column; validated server-side with `Rule::in([...])` |
| `boolean` | `TINYINT(1)`, cast to real JSON `true`/`false` |
| date/time fields | ISO 8601 strings (`Y-m-d\TH:i:s.uP`) via Eloquent's default `DateTime` casting |
