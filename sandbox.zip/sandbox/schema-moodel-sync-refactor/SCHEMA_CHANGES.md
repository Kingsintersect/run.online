# Prisma Schema — Changes Only

Everything not listed here is **unchanged**. This is a diff, not a full
schema — see `schema.prisma` from the earlier message for the complete file.

---

## 1. Modified enums

### `CourseType` — 2 values added

```diff
 enum CourseType {
   GENERAL
   FACULTY
   DEPARTMENTAL
   ELECTIVE
+  SUBJECT          // secondary-school subject (WAEC/NECO context)
+  RESEARCH_PROJECT // thesis/dissertation/final-year project
 }
```

---

## 2. New enums

```prisma
enum ProgramCategory {
  DEGREE
  POSTGRADUATE
  CERTIFICATE
  DIPLOMA
  SECONDARY_SCHOOL
}

enum GradingSchemeType {
  CREDIT_WEIGHTED_GPA // Σ(gradePoint × creditUnits) / Σ(creditUnits)
  SIMPLE_AVERAGE       // unweighted mean — secondary school
  PASS_FAIL            // binary pass/fail against a threshold
}
```

---

## 3. Modified models

### `Department` — `facultyId` now nullable

```diff
 model Department {
   id          Int      @id @default(autoincrement())
-  facultyId   Int      @map("faculty_id")
+  facultyId   Int?     @map("faculty_id")
   name        String   @db.VarChar(200)
   ...
-  faculty   Faculty    @relation(fields: [facultyId], references: [id], onDelete: Cascade)
+  faculty   Faculty?   @relation(fields: [facultyId], references: [id], onDelete: Cascade)
   ...
+  academicUnit AcademicUnit? // mirror node for the generic Moodle-category tree
 }
```

### `Faculty` — one relation added

```diff
 model Faculty {
   ...
   departments Department[]
+  academicUnit AcademicUnit? // mirror node
   ...
 }
```

### `Program` — `departmentId` nullable; 3 fields added

```diff
 model Program {
   id                    Int      @id @default(autoincrement())
-  departmentId          Int      @map("department_id")
+  departmentId          Int?     @map("department_id")
+  programCategory       ProgramCategory @default(DEGREE) @map("program_category")
+  parentAcademicUnitId  Int?     @map("parent_academic_unit_id")
   name                  String   @db.VarChar(200)
   code                  String   @unique @db.VarChar(20)
   degreeType            String   @map("degree_type") @db.VarChar(30)
   durationYears         Int      @map("duration_years")
   description           String?  @db.Text
   admissionRequirements String?  @map("admission_requirements") @db.Text
   minCreditUnits        Int      @map("min_credit_units")
+  gradingSchemeId       Int?     @map("grading_scheme_id")
   isActive              Boolean  @default(true) @map("is_active")
   createdAt             DateTime @default(now()) @map("created_at")
   updatedAt             DateTime @updatedAt @map("updated_at")

-  department     Department      @relation(fields: [departmentId], references: [id], onDelete: Cascade)
+  department      Department?      @relation(fields: [departmentId], references: [id], onDelete: Cascade)
+  parentAcademicUnit AcademicUnit? @relation("ProgramParentUnit", fields: [parentAcademicUnitId], references: [id])
+  gradingScheme   GradingScheme?   @relation(fields: [gradingSchemeId], references: [id])
   programCourses  ProgramCourse[]
   students        Student[]
   admissions      Admission[]
   FeeTypes        FeeType[]
+  academicUnit    AcademicUnit? // mirror node

   @@index([departmentId])
+  @@index([programCategory])
+  @@index([parentAcademicUnitId])
   @@map("programs")
 }
```

### `Level` — one relation added

```diff
 model Level {
   ...
   courses    Course[]
   students   Student[]
   admissions Admission[]
   FeeTypes     FeeType[]
+  academicUnits AcademicUnit[] // a Level can be mirrored per-Program branch (not unique)

   @@map("levels")
 }
```

### `Semester` — one relation added

```diff
 model Semester {
   ...
   offerings       CourseOffering[]
   enrollments     StudentEnrollment[]
   grades          Grade[]
   cgpaHistory     CgpaHistory[]
+  termResults     TermResultSummary[]

   @@index([academicSessionId])
   @@map("semesters")
 }
```

### `Student` — one relation added

```diff
 model Student {
   ...
   enrollments       StudentEnrollment[]
   grades            Grade[]
   cgpaHistory       CgpaHistory[]
+  termResults       TermResultSummary[]
   invoices          Invoice[]
   ...
 }
```

### `GradeScale` — scoped to a scheme instead of globally unique

```diff
 model GradeScale {
   id          Int      @id @default(autoincrement())
-  grade       String   @unique @db.VarChar(2)
+  gradingSchemeId Int? @map("grading_scheme_id")
+  grade       String   @db.VarChar(2)
   minScore    Decimal  @map("min_score") @db.Decimal(5, 2)
   maxScore    Decimal  @map("max_score") @db.Decimal(5, 2)
   gradePoint  Decimal  @map("grade_point") @db.Decimal(3, 2)
   description String?  @db.VarChar(50)
   createdAt   DateTime @default(now()) @map("created_at")
   updatedAt   DateTime @updatedAt @map("updated_at")

+  gradingScheme GradingScheme? @relation(fields: [gradingSchemeId], references: [id])
   grades Grade[]

-  @@map("grade_scales")
+  @@unique([gradingSchemeId, grade])
+  @@map("grade_scales")
 }
```

> Note: `gradePoint` stays a required `Decimal` in the column definition
> above for diff-minimalism, but non-GPA schemes (WAEC) simply don't use
> it meaningfully — treat it as `0` or a placeholder for those rows if
> your migration tooling won't allow a mid-project nullable change here.
> If you'd rather make it properly optional for non-GPA scales, change it
> to `Decimal?` — this has no knock-on effect since `Grade.gradePoint` is
> already nullable.

### `MoodleSyncCategory` — breaking change (sync metadata only)

```diff
 model MoodleSyncCategory {
   id                     Int                 @id @default(autoincrement())
-  entityType             String              @map("entity_type") @db.VarChar(30)
-  entityId               Int                 @map("entity_id")
+  academicUnitId         Int                 @unique @map("academic_unit_id")
   moodleCategoryId       Int                 @unique @map("moodle_category_id")
   moodleCategoryName     String              @map("moodle_category_name") @db.VarChar(255)
   parentMoodleCategoryId Int?                @map("parent_moodle_category_id")
   syncStatus             MoodleSyncStatus    @default(PENDING) @map("sync_status")
   syncDirection          MoodleSyncDirection @map("sync_direction")
+  needsMapping           Boolean             @default(false) @map("needs_mapping")
   lastSyncAt             DateTime?           @map("last_sync_at")
   syncError              String?             @map("sync_error") @db.Text
   createdAt              DateTime            @default(now()) @map("created_at")
   updatedAt              DateTime            @updatedAt @map("updated_at")

-  @@unique([entityType, entityId])
+  academicUnit AcademicUnit @relation(fields: [academicUnitId], references: [id], onDelete: Cascade)
+
   @@index([syncStatus])
   @@map("moodle_sync_categories")
 }
```

---

## 4. New models (added in full)

```prisma
model AcademicUnitType {
  id    Int    @id @default(autoincrement())
  code  String @unique @db.VarChar(30) // "FACULTY","DEPARTMENT","PROGRAM","LEVEL","SEMESTER","SCHOOL","SECTION","STREAM","TERM", or custom
  label String @db.VarChar(100)

  units AcademicUnit[]

  @@map("academic_unit_types")
}

model AcademicUnit {
  id         Int      @id @default(autoincrement())
  typeId     Int      @map("type_id")
  parentId   Int?     @map("parent_id")
  name       String   @db.VarChar(200)
  sortOrder  Int      @default(0) @map("sort_order")
  metadata   Json?
  isActive   Boolean  @default(true) @map("is_active")
  createdAt  DateTime @default(now()) @map("created_at")
  updatedAt  DateTime @updatedAt @map("updated_at")

  type     AcademicUnitType @relation(fields: [typeId], references: [id])
  parent   AcademicUnit?    @relation("AcademicUnitTree", fields: [parentId], references: [id])
  children AcademicUnit[]   @relation("AcademicUnitTree")

  // Mirror-node backing relations — at most ONE set per row.
  facultyId    Int?        @unique @map("faculty_id")
  faculty      Faculty?    @relation(fields: [facultyId], references: [id], onDelete: Cascade)
  departmentId Int?        @unique @map("department_id")
  department   Department? @relation(fields: [departmentId], references: [id], onDelete: Cascade)
  programId    Int?        @unique @map("program_id")
  program      Program?    @relation(fields: [programId], references: [id], onDelete: Cascade)
  levelId      Int?        @map("level_id") // not unique — reused across Program branches
  level        Level?      @relation(fields: [levelId], references: [id])
  semesterId   Int?        @unique @map("semester_id")
  semester     Semester?   @relation(fields: [semesterId], references: [id], onDelete: Cascade)

  programParents Program[] @relation("ProgramParentUnit")

  moodleSyncCategory MoodleSyncCategory?

  @@index([typeId])
  @@index([parentId])
  @@index([levelId])
  @@map("academic_units")
}

model GradingScheme {
  id                Int               @id @default(autoincrement())
  name              String            @unique @db.VarChar(100)
  schemeType        GradingSchemeType @map("scheme_type")
  passMark          Decimal?          @map("pass_mark") @db.Decimal(5, 2)
  caWeightPercent   Int?              @map("ca_weight_percent")
  examWeightPercent Int?              @map("exam_weight_percent")
  isActive          Boolean           @default(true) @map("is_active")
  createdAt         DateTime          @default(now()) @map("created_at")
  updatedAt         DateTime          @updatedAt @map("updated_at")

  gradeScales GradeScale[]
  programs    Program[]

  @@map("grading_schemes")
}

model TermResultSummary {
  id                   Int      @id @default(autoincrement())
  studentId            Int      @map("student_id")
  semesterId           Int      @map("semester_id") // the "Term" in this context
  averageScore         Decimal  @map("average_score") @db.Decimal(5, 2)
  subjectCount         Int      @map("subject_count")
  positionInClass      Int?     @map("position_in_class")
  totalStudentsInClass Int?     @map("total_students_in_class")
  cumulativeAverage    Decimal? @map("cumulative_average") @db.Decimal(5, 2)
  createdAt            DateTime @default(now()) @map("created_at")

  student  Student  @relation(fields: [studentId], references: [id], onDelete: Cascade)
  semester Semester @relation(fields: [semesterId], references: [id])

  @@unique([studentId, semesterId])
  @@index([studentId])
  @@index([semesterId])
  @@map("term_result_summaries")
}
```

---

## 5. Nothing else changes

`User`, `Lecturer`, `Staff`, `Role`/`Permission`/`UserRole`,
`RefreshToken`, `PasswordReset`, `FeatureRegistry`/`FeatureFlag`,
`AcademicSession`, `Course`, `ProgramCourse`, `CourseOffering`,
`CourseOfferingLecturer`, `CoursePrerequisite`, `StudentEnrollment`,
`ClassSchedule`, `Attendance`, `Grade`, `CgpaHistory`,
`AdmissionApplication`, `ApplicationDocument`, `Admission`, `FeeType`,
`Invoice`, `Payment`, `PaymentTransaction`, `Hostel*`, `StudentDocument`,
`ClearanceType`, `StudentClearance`, `NotificationTemplate`,
`Notification`, `AuditLog`, `MoodleSyncUser`, `MoodleSyncCourse`,
`MoodleSyncEnrollment`, `MoodleSyncAssessment`, `MoodleSyncGrade`,
`MoodleSyncCalendarEvent`, `Announcement` — all identical to what you
already have.
