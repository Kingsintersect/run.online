# Multi-Structure Student Portal — Architecture & API Design

**Status: design document.** This covers the restructured Prisma schema, the
API surface, and the end-to-end workflow for a single, highly-customizable
portal codebase that can be deployed for:

- **Degree programs** (Faculty → Department → Program → Level → Semester)
- **Postgraduate programs** (PGD/Masters/PhD — same shape, different course codes + thesis)
- **Certificate / Diploma programs**
- **Secondary schools** (Section → Stream → Level → Term, WAEC-style grading)

...all from the same schema and the same controllers, with Moodle LMS
sync working identically regardless of which structure a given deployment
(or a given Program within one deployment) uses.

Nothing has been built yet. This is the proposal for review — schema first,
then API contracts, then the workflow it all serves.

---

## 1. Research grounding

Before redesigning anything, I checked what real Nigerian institutions
actually look like, so the schema fits reality rather than a guess:

| Structure type | What's actually true |
|---|---|
| **Degree (NUC/CCMAS)** | Faculty → Department → Program, with Level (100L–500L+) and Semester per session. 70% core / 30% institutional-elective courses. Grading: CA (30–40%) + Exam (60–70%) out of 100, mapped to a 5-point GPA scale. |
| **Postgraduate** | Typically organized under a **School of Postgraduate Studies** rather than the undergraduate Faculty tree — but structurally it's still *a Program with Levels and Semesters*, just with 700/800-level course codes and a heavily-weighted thesis/dissertation "course." Same 5-point GPA scale, usually with a higher minimum CGPA to graduate (e.g. 3.00 vs 1.00 for undergrad). |
| **Secondary school** | Six years: JSS1–3 (Junior), SS1–3 (Senior). At SS level, students split into a **Stream** — Science, Arts, or Commercial — which determines their subject list. Academic year = "Session," split into **First/Second/Third Term** (not "Semester"). Grading is WAEC/NECO's **9-point scale**: A1 (75–100) → F9 (<40), computed from 30% CA + 70% exam — **no credit-unit-weighted GPA at all**; performance is a simple average plus class position. |
| **Moodle** | The `idnumber` field on a category/course is Moodle's own documented mechanism for holding an external system's reference ID (see MDL-28518) — i.e. the fix already applied to your Moodle Sync module (`idnumber = "program:55"`) is the *intended* pattern, not a workaround. This generalizes cleanly to any tree shape. |

**What this means for the schema:** `Course`, `CourseOffering`,
`StudentEnrollment`, `AcademicSession`, `Semester`, and `Level` are already
shaped correctly for *all four* structure types — a "Term" is a `Semester`
row, a WAEC "subject" is a `Course` row, nothing there needs to change.
The three places that assumed one fixed shape are `MoodleSyncCategory`
(depth-guessing), `GradeScale` (one global scale), and the CGPA formula
(meaningless for non-credit-weighted grading). Everything else is either
unchanged or gets its constraints loosened, never tightened.

---

## 2. What changed — summary table

| Model | Change | Breaking? |
|---|---|---|
| `Department` | `facultyId` now nullable | No — loosens a constraint |
| `Program` | `departmentId` now nullable; **+ `programCategory`** enum (default `DEGREE`); **+ `parentAcademicUnitId`**; **+ `gradingSchemeId`** | No — additive + default preserves existing behavior |
| `CourseType` (enum) | **+ `SUBJECT`**, **+ `RESEARCH_PROJECT`** values | No — additive |
| `GradeScale` | **+ `gradingSchemeId`** (nullable); unique constraint changes from `grade` (global) to `[gradingSchemeId, grade]` (scoped) | No for existing rows (`gradingSchemeId = null` behaves exactly as today); yes at the DB constraint level (see migration notes) |
| `MoodleSyncCategory` | `entityType` + `entityId` **replaced** with a single `academicUnitId` FK to the new `AcademicUnit` tree | **Yes** — sync bookkeeping only, no academic data affected. Migration provided below. |
| `AcademicUnitType` | **New model** — lookup table of node types (Faculty, Department, Program, Level, Semester, Section, Stream, Term, ...) | New |
| `AcademicUnit` | **New model** — generic self-referential tree, optionally mirroring a real row (Faculty/Department/Program/Level/Semester) or existing as a pure structural node (Stream, Section) with no backing table | New |
| `GradingScheme` | **New model** — named grading configuration (scale type, pass mark, CA/exam weighting) that a `Program` opts into | New |
| `TermResultSummary` | **New model** — the non-credit-weighted equivalent of `CgpaHistory`, for WAEC-style term averages + class position | New |

**Nothing was removed.** Every table, column, and enum value that existed
before still exists with the same meaning. `Faculty`, `CgpaHistory`,
existing `GradeScale` rows, and every degree-program query continue to
work unchanged.

---

## 3. The generic Academic Unit tree — how it actually works

`AcademicUnit` exists for exactly one purpose: giving the Moodle sync
module (and any future "show me the whole structure" admin UI) a single,
uniform tree to walk — regardless of what shape a given Program's real
hierarchy takes.

**Two ways a node gets used:**

1. **Mirror node** — points at a real row via a unique backing FK
   (`facultyId`, `departmentId`, `programId`, `levelId`, or `semesterId`).
   Used for anything that already has a proper table — which is
   everything in a DEGREE or POSTGRADUATE structure.
2. **Pure structural node** — no backing FK at all. Used for a node type
   that has no dedicated table, e.g. a secondary school's "Stream"
   (Science/Arts/Commercial) or "Section" (Junior/Senior).

### Example: Degree program (unchanged operational tables, mirrored into the tree)

```
AcademicUnit (type=FACULTY, facultyId=12)         "Social Sciences"
└── AcademicUnit (type=DEPARTMENT, departmentId=8) "Sociology"
    └── AcademicUnit (type=PROGRAM, programId=55)  "B.Sc. Sociology"
        └── AcademicUnit (type=LEVEL, levelId=3)   "100 Level"
            └── AcademicUnit (type=SEMESTER, semesterId=20) "First Semester"
```

Every node here mirrors a real `Faculty`/`Department`/`Program`/`Level`/
`Semester` row. The operational tables (and everything that queries them —
CGPA calculation, invoicing, enrollment) never touch `AcademicUnit` at all.
It exists purely so Moodle sync has something uniform to push/pull.

### Example: Postgraduate program (same tables, different anchor)

```
AcademicUnit (type=SCHOOL, departmentId=<PG Studies Dept>) "School of Postgraduate Studies"
└── AcademicUnit (type=PROGRAM, programId=90)  "M.Sc. Economics"   [programCategory = POSTGRADUATE]
    └── AcademicUnit (type=LEVEL, levelId=12)  "PG Year 1"
        └── AcademicUnit (type=SEMESTER, semesterId=44) "First Semester"
```

`Program.departmentId` still points at a real `Department` row (you can
model "School of Postgraduate Studies" as a `Department` with
`facultyId = null`) — no schema gymnastics needed. The only new thing is
`programCategory = POSTGRADUATE`, which the grading engine and course-code
validation (700/800-level) read.

### Example: Secondary school (pure structural nodes — no Program/Department underneath)

```
AcademicUnit (type=SECTION, no backing FK)   "Senior Secondary"
└── AcademicUnit (type=STREAM, no backing FK) "Science"
    └── AcademicUnit (type=PROGRAM, programId=200) "SS - Science"   [programCategory = SECONDARY_SCHOOL]
        └── AcademicUnit (type=LEVEL, levelId=30)   "SS2"
            └── AcademicUnit (type=SEMESTER, semesterId=88) "Second Term"
```

Here, "Senior Secondary" and "Science" have **no dedicated tables** — they
only exist as `AcademicUnit` rows, because nothing else in the system
needs to query "all Streams" as a first-class relational concept. The
`Program` row ("SS - Science") is real (it's what a `Student.programId`
points at, and what subjects/courses attach to via `ProgramCourse`), and
it sets `parentAcademicUnitId` to the "Science" `AcademicUnit` node so the
tree above it is complete for Moodle push purposes.

**Why this is safe:** a JSS Program ("JSS - General," no Stream) can skip
the STREAM layer entirely and anchor straight under "Junior Secondary."
The tree depth is genuinely variable per branch — which is exactly what
broke the old depth-guessing logic, and exactly what a self-referential
tree with an explicit `type` on each node is designed to tolerate.

---

## 4. Moodle Sync redesign: one entity type instead of five

The `idnumber` fix already applied to `MoodleSyncCategory` generalizes
almost for free. Previously:

```
idnumber = "{entityType}:{entityId}"   // "program":55, "level":9, ...  (5 possible types)
```

Now:

```
idnumber = "unit:{academicUnitId}"     // always ONE type, any depth, any structure
```

This actually **simplifies** the Laravel sync service from the earlier
build — `pushCategoryEntity()` no longer needs to know about five entity
types, it just walks `AcademicUnit.children` recursively and pushes each
node with its `idnumber`. `pullCategories()` no longer branches on depth
at all — it always tries to match `idnumber` first, and only the
"no idnumber, can't safely guess" fallback (flag for manual mapping) is
still needed, now for *any* unrecognized node type, not just "nested."

### Migration for existing installs

If you've already pushed categories to Moodle under the old
`entityType`/`entityId` scheme (per the earlier fix), nothing needs to be
re-pushed. The migration:

1. For every existing `Faculty`, `Department`, `Program`, `Level`,
   `Semester` row, create a mirroring `AcademicUnit` row (`typeId` looked
   up from `AcademicUnitType`, `parentId` computed from the existing
   hierarchy, backing FK set).
2. For every existing `MoodleSyncCategory` row, look up the new mirror
   `AcademicUnit` by its old `(entityType, entityId)` pair, set
   `academicUnitId` to it, and drop the old columns.
3. Run `moodle:backfill-category-idnumbers` (already built) — it now
   writes `idnumber = "unit:{academicUnitId}"` instead of
   `"{entityType}:{entityId}"`, using the same non-destructive backfill
   logic as before.

No `moodle_category_id` mappings are lost; no Moodle-side categories need
recreating.

---

## 5. Grading redesign: pluggable schemes, not one global scale

```
GradingScheme "University 5-Point GPA"  (implicit — existing GradeScale rows, gradingSchemeId = null)
GradingScheme "WAEC 9-Point Scale"      (schemeType = SIMPLE_AVERAGE, caWeight=30, examWeight=70)
  |-- GradeScale A1  75-100
  |-- GradeScale B2  70-74
  |-- ...
  `-- GradeScale F9  0-39
```

A `Program.gradingSchemeId` (nullable) opts a program into a specific
scheme; `null` means "use the institution's default GPA scheme," which is
exactly today's behavior. `Grade.gradeScaleId` still points at whichever
`GradeScale` row matched the student's `totalScore`, now correctly scoped
to the right scheme instead of colliding with a global "A/B/C/D/F" table
that can't hold two different scales at once.

**Computation split, by `GradingSchemeType`:**

- `CREDIT_WEIGHTED_GPA` → existing formula, existing `CgpaHistory` table.
  Used by DEGREE, POSTGRADUATE, DIPLOMA by default.
- `SIMPLE_AVERAGE` → unweighted mean of subject scores + class position,
  written to the new `TermResultSummary` table. Used by SECONDARY_SCHOOL.
- `PASS_FAIL` → binary outcome against `GradingScheme.passMark`, no
  aggregate table needed beyond `Grade.status`. Used by some CERTIFICATE
  programs.

The **publish gate is unchanged** for all three: `Grade.status` still
walks `DRAFT → SUBMITTED → APPROVED → PUBLISHED`, and students only see a
grade (in any structure type) once it's `PUBLISHED`. This is already
exactly what "admin publishes grades so students can view them" needs —
no new model required for that part.

---

## 6. End-to-end student workflow, mapped to models and endpoints

This is your workflow from the request, with each step tied to the schema
and the API section below.

| Step | What happens | Models touched | Endpoint |
|---|---|---|---|
| 1. Register | User creates an account (email, username, password) | `User` | `POST /auth/register` |
| 2. Pay application/access fee | Amount and existence of this fee depend on the Program's `FeeType` scoping — some programs have none | `Invoice`, `Payment`, `FeeType` | `POST /invoices/application-fee`, `POST /payments/initiate` |
| 3. Fill application form, select program | `programId` on the application can be a program of any `programCategory` | `AdmissionApplication`, `ApplicationDocument` | `POST /admissions/applications` |
| 4. Admission officer reviews and grants admission | Status flow `SUBMITTED → UNDER_REVIEW → ADMITTED/REJECTED` | `AdmissionApplication`, `Admission` | `PATCH /admissions/applications/{id}/review`, `POST /admissions/{applicationId}/offer` |
| 5. Student accepts admission | `AdmissionStatus: OFFERED → ACCEPTED` | `Admission` | `POST /admissions/{id}/accept` |
| 6. Student pays acceptance fee | Another `FeeType`-scoped invoice | `Invoice`, `Payment` | `POST /invoices/acceptance-fee`, `POST /payments/initiate` |
| 7. Student pays tuition fee → auto-enrolled | Payment verification triggers `MoodleSyncService::onTuitionVerified()` — creates `Student` record if not yet created, pushes the user + enrollments to Moodle | `Invoice`, `Payment`, `Student`, `StudentEnrollment`, `MoodleSyncUser`, `MoodleSyncEnrollment` | `POST /payments/{id}/verify` (webhook or admin-triggered) |
| 8. Dashboard access | Student sees profile, invoices, enrolled courses | `Student`, `StudentEnrollment` | `GET /students/me/dashboard` |
| 9. List enrolled courses | | `StudentEnrollment`, `CourseOffering`, `Course` | `GET /students/me/courses` |
| 10. Click a course → SSO into Moodle | See Section 7 below | `MoodleSyncCourse`, `MoodleSyncUser` | `GET /students/me/courses/{offeringId}/launch` |
| 11. Admin customizes program structure, pushes to Moodle | Builds/edits the `AcademicUnit` tree for a Program, then pushes | `AcademicUnit`, `MoodleSyncCategory` | `POST /academic-structure/units`, `POST /moodle-sync/categories/push-hierarchy/{unitId}` |
| 12. Lecturer creates a course under the program, pushes to Moodle | Course + CourseOffering created on portal, or created directly in Moodle by the lecturer via SSO and pulled back | `Course`, `CourseOffering`, `MoodleSyncCourse` | `POST /courses`, `POST /course-offerings`, `POST /moodle-sync/courses/push/{id}` or `.../pull` |
| 13. Grading happens (in Moodle or on the portal) | Raw scores land in `Grade` as `DRAFT` | `Grade` | `POST /grades`, `PATCH /grades/{id}` |
| 14. Admin publishes grades | `Grade.status → PUBLISHED`; triggers CGPA/term-average recompute | `Grade`, `CgpaHistory` or `TermResultSummary` | `POST /grades/publish` |
| 15. Student views/downloads result | Reads only `PUBLISHED` grades; renders a PDF transcript/result-sheet | `Grade`, `CgpaHistory`/`TermResultSummary` | `GET /students/me/results`, `GET /students/me/results/{semesterId}/download` |

---

## 7. SSO into Moodle — how "click course → land in Moodle, logged in" works

Moodle's own multi-app integration story (per Moodle documentation and the
widely-used `auth_userkey` plugin pattern) is: the portal calls a Moodle
web-service function to mint a **one-time login token** for a specific
Moodle user, then redirects the browser to a Moodle URL carrying that
token. Moodle validates it, logs the user in, and redirects to the
requested course. No password is ever shared, and the token is single-use
and short-lived.

```
Student clicks a course card on the portal
        │
        ▼
GET /students/me/courses/{offeringId}/launch
        │
        ▼
Portal looks up MoodleSyncUser for this student
Portal looks up MoodleSyncCourse for this offering
        │
        ▼
Portal calls Moodle's user-key web service to mint a one-time token
for that moodleUserId
        │
        ▼
Portal returns { "redirectUrl": "https://moodle.example.edu/auth/userkey/...&wantsurl=/course/view.php?id=77" }
        │
        ▼
Frontend redirects the browser there — student lands inside the course, logged in
```

This requires the `auth_userkey` plugin (or equivalent) installed and
configured on the Moodle side — noted here as a dependency, not something
this portal codebase can configure remotely. Lecturers logging into
Moodle directly to create course content use the *same* mechanism from
a "Manage this course in Moodle" button on their dashboard.

---

## 8. Admin-driven structure customization workflow

```
Admin opens "Program Structure Builder"
        │
        ▼
GET /academic-structure/unit-types         → node types available (Faculty, Department,
                                              Program, Level, Semester, Section, Stream,
                                              Term, or any custom type the admin adds)
        │
        ▼
Admin builds the tree for a new Program category:
  POST /academic-structure/units           → create each node, set parentId
        │
        ▼
Admin links a node to a real Program (if applicable):
  PATCH /programs/{id}                     → set parentAcademicUnitId, programCategory
        │
        ▼
Admin pushes the whole branch to Moodle:
  POST /moodle-sync/categories/push-hierarchy/{rootUnitId}
        │
        ▼
Lecturers can now create CourseOfferings under this Program, push them,
or create courses directly in Moodle (via SSO) and pull them back:
  POST /course-offerings
  POST /moodle-sync/courses/push/{courseOfferingId}
  POST /moodle-sync/courses/pull
```

This is the same admin flow whether the structure is 5 levels deep
(Faculty→Semester) or 2 (Program→Semester for a standalone certificate) —
the Structure Builder UI just renders however many levels the admin
actually creates.

---

## 9. API design

Base path: `/api/v1`. Auth: `Authorization: Bearer <token>` on every route
except `/auth/*`. Roles referenced below (`Admin`, `Admissions Officer`,
`Lecturer`, `Student`, `Authenticated`) map onto the existing `Role`/
`Permission`/`UserRole` tables — no new auth model needed.

Only **new or changed** endpoints are detailed with full request/response
bodies below. Endpoints unaffected by this restructure (payments, hostel,
notifications, clearance, documents) keep their existing shape and aren't
repeated here. The Moodle Sync endpoints (categories/users/courses/
enrollments/assessments/grades/calendar) are documented in the separate
`moodle-sync-api.md` from the earlier build — only the parts that changed
because of `academicUnitId` are called out again here.

### 9.1 Academic Structure — `/academic-structure`

#### `GET /academic-structure/unit-types`
List available node types for the Structure Builder.

**Response `200`:**
```json
{
  "data": [
    { "id": 1, "code": "FACULTY", "label": "Faculty" },
    { "id": 2, "code": "DEPARTMENT", "label": "Department" },
    { "id": 3, "code": "PROGRAM", "label": "Program" },
    { "id": 4, "code": "LEVEL", "label": "Level" },
    { "id": 5, "code": "SEMESTER", "label": "Semester" },
    { "id": 6, "code": "SCHOOL", "label": "School" },
    { "id": 7, "code": "SECTION", "label": "Section" },
    { "id": 8, "code": "STREAM", "label": "Stream" },
    { "id": 9, "code": "TERM", "label": "Term" }
  ]
}
```

#### `POST /academic-structure/unit-types`
Create a custom node type (e.g. an institution invents a "Cohort" concept).

**Request:**
```json
{ "code": "COHORT", "label": "Cohort" }
```
| Field | Type | Required |
|---|---|---|
| `code` | string, uppercase, max 30 chars, unique | yes |
| `label` | string, max 100 chars | yes |

**Response `201`:** same shape as a list item above.

#### `GET /academic-structure/units`
List the tree (or a subtree). Query params: `parentId` (int, omit for
roots), `typeId` (int, filter), `programCategory` (string, filter by
category of any linked Program in the subtree).

**Response `200`:**
```json
{
  "data": [
    {
      "id": 1,
      "typeId": 7,
      "typeCode": "SECTION",
      "parentId": null,
      "name": "Senior Secondary",
      "sortOrder": 0,
      "linkedEntity": null,
      "childCount": 3
    }
  ]
}
```

#### `POST /academic-structure/units`
Create a node — either a mirror node (linked to a real entity) or a pure
structural node.

**Request:**
```json
{
  "typeCode": "STREAM",
  "parentId": 1,
  "name": "Science",
  "sortOrder": 0,
  "linkedEntity": null
}
```
To create a mirror node instead (e.g. mirroring an existing Program):
```json
{
  "typeCode": "PROGRAM",
  "parentId": 2,
  "name": "SS - Science",
  "linkedEntity": { "type": "program", "id": 200 }
}
```
| Field | Type | Required | Notes |
|---|---|---|---|
| `typeCode` | string | yes | must exist in `AcademicUnitType` |
| `parentId` | int, nullable | no | omit/null for a root node |
| `name` | string, max 200 chars | yes | |
| `sortOrder` | int | no | default 0 |
| `linkedEntity` | object `{type, id}` or `null` | no | `type` ∈ `faculty\|department\|program\|level\|semester`; validated to exist and not already mirrored elsewhere |

**Response `201`:** the created unit, same shape as the list item.

**Errors:** `422` if `linkedEntity.id` doesn't exist, or is already backing
a different `AcademicUnit` row (one entity ↔ one mirror node).

#### `PATCH /academic-structure/units/{id}`
Update name/sortOrder/parentId. Cannot change `typeCode` or `linkedEntity`
after creation (delete and recreate if the type was wrong).

#### `DELETE /academic-structure/units/{id}`
Deletes the node (cascades to children). Does **not** delete the linked
Faculty/Department/Program/Level/Semester row if it's a mirror node, and
does **not** delete anything from Moodle.

---

### 9.2 Programs — changed fields only

#### `PATCH /programs/{id}` — new fields accepted
```json
{
  "programCategory": "SECONDARY_SCHOOL",
  "departmentId": null,
  "parentAcademicUnitId": 3,
  "gradingSchemeId": 7
}
```
| Field | Type | Notes |
|---|---|---|
| `programCategory` | enum: `DEGREE\|POSTGRADUATE\|CERTIFICATE\|DIPLOMA\|SECONDARY_SCHOOL` | drives grading engine + course-code validation |
| `departmentId` | int, nullable | now optional |
| `parentAcademicUnitId` | int, nullable | required if `departmentId` is null and this program needs Moodle categorization |
| `gradingSchemeId` | int, nullable | `null` = institution default GPA scheme |

#### `GET /programs?programCategory=SECONDARY_SCHOOL`
Existing list endpoint, new filter param.

---

### 9.3 Grading Schemes — `/grading-schemes`

#### `GET /grading-schemes`
**Response `200`:**
```json
{
  "data": [
    {
      "id": 1,
      "name": "University 5-Point GPA",
      "schemeType": "CREDIT_WEIGHTED_GPA",
      "passMark": null,
      "caWeightPercent": null,
      "examWeightPercent": null,
      "isActive": true
    },
    {
      "id": 2,
      "name": "WAEC 9-Point Scale",
      "schemeType": "SIMPLE_AVERAGE",
      "passMark": 40.00,
      "caWeightPercent": 30,
      "examWeightPercent": 70,
      "isActive": true
    }
  ]
}
```

#### `POST /grading-schemes`
**Request:**
```json
{
  "name": "WAEC 9-Point Scale",
  "schemeType": "SIMPLE_AVERAGE",
  "passMark": 40.00,
  "caWeightPercent": 30,
  "examWeightPercent": 70
}
```
| Field | Type | Required |
|---|---|---|
| `name` | string, unique, max 100 | yes |
| `schemeType` | enum: `CREDIT_WEIGHTED_GPA\|SIMPLE_AVERAGE\|PASS_FAIL` | yes |
| `passMark` | decimal(5,2), nullable | no |
| `caWeightPercent` | int 0–100, nullable | no |
| `examWeightPercent` | int 0–100, nullable | no |

**Response `201`:** created scheme.

#### `POST /grading-schemes/{id}/scales`
Add a `GradeScale` row scoped to this scheme.

**Request:**
```json
{ "grade": "A1", "minScore": 75.00, "maxScore": 100.00, "gradePoint": null, "description": "Excellent" }
```
| Field | Type | Required |
|---|---|---|
| `grade` | string, max 2 chars | yes |
| `minScore` | decimal(5,2) | yes |
| `maxScore` | decimal(5,2) | yes |
| `gradePoint` | decimal(3,2), nullable | no — omit/null for non-GPA schemes |
| `description` | string, max 50, nullable | no |

**Response `201`:** created scale row.

---

### 9.4 Grades & Results — `/grades`, `/students/me/results`

#### `POST /grades` (Lecturer/Admin)
Unchanged shape — `studentId`, `courseId`, `semesterId`, `caScore`,
`examScore`. `totalScore`, `gradeScaleId`, and `gradePoint` (if
applicable) are computed server-side using the `Program`'s
`GradingScheme`, not supplied by the client.

**Request:**
```json
{ "studentId": 501, "courseId": 12, "semesterId": 20, "caScore": 28.00, "examScore": 55.00 }
```

**Response `201`:**
```json
{
  "data": {
    "id": 900,
    "studentId": 501,
    "courseId": 12,
    "semesterId": 20,
    "caScore": 28.00,
    "examScore": 55.00,
    "totalScore": 83.00,
    "gradeScale": { "grade": "A1", "gradePoint": null },
    "status": "DRAFT"
  }
}
```

#### `POST /grades/publish` (Admin)
Publishes all `APPROVED` grades for a semester, then triggers the
appropriate aggregate recompute.

**Request:**
```json
{ "semesterId": 20 }
```

**Response `200`:**
```json
{
  "publishedCount": 340,
  "recomputed": { "cgpaHistoryRows": 85, "termResultSummaryRows": 0 }
}
```

#### `GET /students/me/results` (Student)
Returns whichever result shape applies to the student's `programCategory`.

**Response `200` (DEGREE/POSTGRADUATE/DIPLOMA — CGPA-based):**
```json
{
  "programCategory": "DEGREE",
  "schemeType": "CREDIT_WEIGHTED_GPA",
  "data": {
    "cgpa": 4.21,
    "classOfDegree": "Second Class Upper",
    "semesters": [
      { "semesterId": 20, "semesterName": "First Semester", "gpa": 4.35, "cgpa": 4.35, "totalCreditUnits": 18 }
    ]
  }
}
```

**Response `200` (SECONDARY_SCHOOL — term average-based):**
```json
{
  "programCategory": "SECONDARY_SCHOOL",
  "schemeType": "SIMPLE_AVERAGE",
  "data": {
    "terms": [
      {
        "semesterId": 88,
        "semesterName": "Second Term",
        "averageScore": 68.40,
        "positionInClass": 4,
        "totalStudentsInClass": 42,
        "subjects": [
          { "courseCode": "MTH-SS2", "courseTitle": "Mathematics", "totalScore": 72.00, "grade": "B2" }
        ]
      }
    ]
  }
}
```

#### `GET /students/me/results/{semesterId}/download`
Returns a generated PDF (transcript for CGPA-based programs, result sheet
for term-average-based programs). `Content-Type: application/pdf`.

---

### 9.5 Course Launch (SSO) — `/students/me/courses`

#### `GET /students/me/courses` (Student)
**Response `200`:**
```json
{
  "data": [
    {
      "offeringId": 301,
      "course": { "code": "ECO101", "title": "Introduction to Economics" },
      "semester": "First Semester",
      "moodleSynced": true
    }
  ]
}
```

#### `GET /students/me/courses/{offeringId}/launch` (Student)
Mints a one-time Moodle login token and returns a redirect URL. See
Section 7.

**Response `200`:**
```json
{
  "redirectUrl": "https://moodle.example.edu/auth/userkey/select.php?key=abc123&wantsurl=%2Fcourse%2Fview.php%3Fid%3D77"
}
```

**Errors:**
- `409` — student's `MoodleSyncUser` doesn't exist yet (tuition not
  verified, or sync failed — check `moodle-sync/users/user/{userId}`)
- `409` — `MoodleSyncCourse` for this offering doesn't exist yet (course
  not pushed/pulled)

---

### 9.6 Admission workflow — unchanged shapes, listed for completeness

These already exist in your schema/likely-existing API and aren't changed
by this restructure — listed here only so the workflow table in Section 6
is fully traceable:

| Endpoint | Purpose |
|---|---|
| `POST /admissions/applications` | Submit `AdmissionApplication` |
| `PATCH /admissions/applications/{id}/review` | Officer sets `UNDER_REVIEW`/`ADMITTED`/`REJECTED` |
| `POST /admissions/{applicationId}/offer` | Creates `Admission` row, status `OFFERED` |
| `POST /admissions/{id}/accept` | Status `OFFERED → ACCEPTED` |
| `POST /invoices/application-fee`, `/invoices/acceptance-fee` | Creates `Invoice` scoped by the relevant `FeeType` |
| `POST /payments/initiate` | Creates `Payment`, returns gateway redirect |
| `POST /payments/{id}/verify` | Verifies with gateway; if `FeeType` is tuition, triggers `MoodleSyncService::onTuitionVerified()` |

---

## 10. Migration checklist (for whoever runs this)

1. **Backup the database.** `MoodleSyncCategory`'s shape change is
   destructive to that table's old columns (not to academic data).
2. Add `AcademicUnitType` + `AcademicUnit` tables. Seed `AcademicUnitType`
   with at least `FACULTY, DEPARTMENT, PROGRAM, LEVEL, SEMESTER`.
3. Add `GradingScheme` table. Seed one row: `"University 5-Point GPA"`,
   `schemeType = CREDIT_WEIGHTED_GPA`. Leave existing `GradeScale` rows'
   `gradingSchemeId` as `null` (they still work — see Section 5).
4. Add `TermResultSummary` table.
5. Alter `Department.facultyId`, `Program.departmentId` → nullable.
6. Alter `Program`: add `programCategory` (default `DEGREE`),
   `parentAcademicUnitId`, `gradingSchemeId`.
7. Alter `CourseType` enum: add `SUBJECT`, `RESEARCH_PROJECT`.
8. Alter `GradeScale`: add `gradingSchemeId`; change unique constraint
   from `grade` to `[gradingSchemeId, grade]`.
9. **Data migration script:** for every `Faculty`/`Department`/`Program`/
   `Level`/`Semester` row, insert a mirroring `AcademicUnit` row (see
   Section 4). Preserve parent/child relationships from the existing FKs.
10. **Data migration script:** for every `MoodleSyncCategory` row, resolve
    its old `(entityType, entityId)` to the new mirror `AcademicUnit`,
    set `academicUnitId`, then drop `entityType`/`entityId` columns.
11. Run `php artisan moodle:backfill-category-idnumbers` (updated to write
    `"unit:{id}"`) so existing Moodle categories get the new idnumber
    format without needing to be recreated.
12. Deploy the updated Laravel `MoodleSyncService` (simplified — one
    entity type instead of five, described in Section 4).
13. For a brand-new SECONDARY_SCHOOL deployment: seed `Level` rows
    (JSS1–3, SS1–3), an `AcademicUnitType` row for `SECTION`/`STREAM`/
    `TERM` if not already present, and the `WAEC 9-Point Scale`
    `GradingScheme` + its `GradeScale` rows.

---

## 11. What's still open (needs your input before implementation)

- **SSO plugin choice** — `auth_userkey` (or equivalent) needs to be
  installed on the Moodle side; confirm which plugin your Moodle instance
  will use, since the exact web-service function name depends on it.
- **Class-position computation for `TermResultSummary`** — ranking
  requires computing every student's average in the same class/Program
  cohort at publish time; confirm whether "class" means same
  Program+Level, or something narrower (e.g. same Program+Level+arm, if
  you also want to model class arms like "SS2 Science A" vs "SS2 Science B").
- **Course-code validation** (700/800-level for postgrad) — worth
  enforcing at the API layer, or just a UI hint? No schema blocker either
  way.
- **Structure Builder UI** — this document assumes admins interact with
  `AcademicUnit` via a tree-editor UI; happy to design that screen-by-screen
  if useful, but it's a frontend concern rather than a schema/API one.

This is the full proposal — schema, API contracts, and workflow. Let me
know what to adjust, and I'll build from there.

