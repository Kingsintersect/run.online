# Moodle Sync Module — Frontend Implementation Guide

> **Audience:** UI developer + Claude (Claude Code / claude.ai).
> **Purpose:** Single source of truth for implementing the `moodle-sync` frontend module.
> Read this in full before generating any code. It follows the rules in the repo's
> root `CLAUDE.md` — architecture, RBAC, naming, and structural conflict protocol all
> apply here without restatement.
>
> **Backend reference docs this is derived from:** `moodle_sync_workflow.md` (internal
> flow) and `moodle_sync_README.md` (backend module README, NestJS). This document is
> the **frontend counterpart** — it does not duplicate backend implementation detail,
> only what the UI layer needs to consume it correctly.

---

## 0. Implementation Status (read this first)

**Status update (2026-08-23): this module is fully real, not mock.** The section below is
kept for history — it described an earlier, dummy-store state of this module that no
longer applies. `src/modules/moodle-sync/services/moodle-sync.service.ts` calls real
`apiClient` endpoints under `/moodle-sync/*` for every resource (categories, users,
courses, enrollments, assessments, grades, calendar/Zoom), confirmed against ~40 real
`.bru` files in `bruno/moodle-sync/`. There are no remaining `// TODO: replace with →`
markers and no dummy/in-memory store anywhere in this module.

The "known duplication" this section used to describe is resolved: the separate
`src/modules/assessments/` mock module (admin sync-status page, student upcoming/
my-assessments pages) was retired and consolidated into this module — see
`sandbox/MISSING_BACKEND_APIS.md` §2.13. The Timetable module (`src/modules/timetable/`)
does not duplicate this module's Calendar/Zoom sync; that concern didn't materialize.

*(Original status note, superseded by the above — kept for context on how this module
started out.)* The frontend was originally built running entirely on an in-memory dummy
store, with every service method carrying a `// TODO: replace with →` comment naming the
real endpoint to switch to once the backend shipped. That migration is now complete.

Route placement deviates from §9 below in two ways, matching this repo's actual `app/`
layout rather than the generic scaffold this doc originally proposed:
- Admin pages live at `app/(dashboard)/admin/(routes)/moodle-sync/*` (not nested under
  `academics/`) — this matches the nav entry already present in `nav.config.ts`.
- Student pages live at `app/(dashboard)/student/moodle/*`, not `app/(root)/moodle/*` —
  in this codebase, `(root)` is the public marketing site, not an authenticated route
  group. This resolves Open Question #2 in §16.

Resolved open questions from §16:
1. **Permission granularity** — kept as a single `moodle-sync` resource with
   `view`/`push`/`pull`/`manage` actions, checked via `<PermissionGate>` per this repo's
   existing convention (e.g. `{ resource: "assessments", action: "sync" }` on the
   assessments sync-status page). Not split per sub-resource.
2. Resolved above (route placement).
3. **`apiClient` pagination/params convention** — not yet exercised for real, since every
   method is still dummy-backed; the `// TODO` comments above each method show the
   intended real call shape (`apiClient.get(url, { params })`), matching
   `src/lib/clients/apiClient.ts`'s `RequestOptions.params`.
4. **Toast/notification system** — uses `sonner`'s `toast`, the toast utility already used
   throughout the rest of the app (e.g. the admission-config CRUD page).
5. **"Last synced" display source** — derived client-side from the most recent
   `lastSyncAt` across the relevant list (see `CategoryPullPanel`'s `formatLastPulled`),
   since no dedicated "last cron run" endpoint exists yet.

Frontend contract additions the backend should be aware of (fields this UI needs that
weren't in the original response shapes in §4, marked inline in each schema file under
`src/modules/moodle-sync/schemas/`):
- `CategorySyncResponse`: added `entityName` (display) and `parentId` (for building the
  tree client-side); relaxed `moodleCategoryId`/`moodleCategoryName` to nullable so the
  tree can represent portal entities that exist but have never been pushed yet
  (`syncStatus: "PENDING"`).
- `UserSyncResponse`: added `name`, `email`, `portalRole` (display); relaxed
  `moodleUserId`/`moodleUsername` to nullable for the same not-yet-pushed case.
- `CourseSyncResponse`: added `courseCode`, `courseTitle`; relaxed the Moodle-side fields
  to nullable.
- `EnrollmentSyncResponse`: added `studentName`, `courseCode`; relaxed the Moodle-side
  fields to nullable.

---

## Table of Contents

1. [Module Summary](#1-module-summary)
2. [Directory Structure](#2-directory-structure)
3. [Domain Concepts (must-know before coding)](#3-domain-concepts-must-know-before-coding)
4. [Zod Schemas & Types](#4-zod-schemas--types)
5. [API Service Layer](#5-api-service-layer)
6. [React Query Hooks](#6-react-query-hooks)
7. [Query Key Factory](#7-query-key-factory)
8. [Zustand UI Store](#8-zustand-ui-store)
9. [Routes & Pages](#9-routes--pages)
10. [Components](#10-components)
11. [Auth & Permission Gating](#11-auth--permission-gating)
12. [Read-Only vs Actionable Resources](#12-read-only-vs-actionable-resources)
13. [Error Handling & Loading States](#13-error-handling--loading-states)
14. [Naming Conventions Recap](#14-naming-conventions-recap)
15. [Implementation Checklist](#15-implementation-checklist)
16. [Open Questions / Assumptions to Confirm](#16-open-questions--assumptions-to-confirm)

---

## 1. Module Summary

The `moodle-sync` module is the frontend surface for a NestJS backend module that
bidirectionally synchronizes academic data between the portal and a Moodle LMS instance.

**Synced entities:** Faculty/Program/Level/Semester ↔ Moodle Categories · Users
(Student/Lecturer/Staff) ↔ Moodle Users · CourseOffering ↔ Moodle Course ·
StudentEnrollment ↔ Moodle Enrollment · Assessments (pull-only) · Grades (pull-only) ·
Calendar/Zoom events (pull-only).

**Two audiences for this module's UI:**
- **Admin dashboard** — full push/pull control panels for categories, users, courses,
  enrollments; monitoring for assessments/grades/calendar.
- **Student-facing widgets** — read-only views: upcoming assessments, my grades
  (Moodle), upcoming sessions/Zoom links. These are pull-only, no action buttons.

This module lives entirely under `src/modules/moodle-sync/`, per the Global vs Module
scope rule in `CLAUDE.md` §4. Nothing here belongs in global `/lib`, `/hooks`, or
`/components` unless reused by 2+ modules.

---

## 2. Directory Structure

```
src/
├── modules/
│   └── moodle-sync/
│       ├── types/
│       │   └── index.ts                          # z.infer<> types only — no hand-written types
│       ├── schemas/
│       │   ├── common.schema.ts                   # SyncStatus, SyncDirection enums, shared query filters
│       │   ├── category.schema.ts                 # PushCategoryDto, category response, pull response
│       │   ├── user.schema.ts                      # push/pull user payloads + response
│       │   ├── course.schema.ts                    # push/pull course payloads + response
│       │   ├── enrollment.schema.ts                # enrollment sync records, errors
│       │   ├── assessment.schema.ts                # assessment list/upcoming response (read-only)
│       │   ├── grade.schema.ts                     # grade list/my response (read-only)
│       │   └── calendar.schema.ts                  # calendar event list/upcoming/detail (read-only)
│       ├── services/
│       │   └── moodle-sync.service.ts              # ALL 30 endpoints, via apiClient, one file
│       ├── hooks/
│       │   ├── query-keys.ts                       # typed key factory, namespaced per sub-resource
│       │   ├── use-sync-categories.ts               # list, detail
│       │   ├── use-sync-users.ts                    # list, detail, by-user
│       │   ├── use-sync-courses.ts                  # list, detail
│       │   ├── use-sync-enrollments.ts              # list, errors
│       │   ├── use-sync-assessments.ts              # list, by-course, upcoming
│       │   ├── use-sync-grades.ts                   # list, by-student, by-course, my
│       │   ├── use-sync-calendar.ts                 # list, by-course, upcoming, detail
│       │   └── use-sync-mutations.ts                # ALL push/pull/delete mutations, one file
│       ├── store/
│       │   └── moodle-sync-ui.store.ts              # active tab, filters, tree-expand state (UI only)
│       └── components/
│           ├── shared/
│           │   ├── sync-status-badge.tsx            # PENDING / SYNCED / FAILED / STALE
│           │   ├── sync-direction-badge.tsx         # PUSH / PULL / BIDIRECTIONAL
│           │   └── push-pull-toolbar.tsx            # generic action bar (push / pull / pull-all)
│           ├── categories/
│           │   ├── category-tree.tsx                # Faculty → Program → Level → Semester tree
│           │   ├── category-push-dialog.tsx
│           │   └── category-pull-panel.tsx
│           ├── users/
│           │   ├── user-sync-table.tsx
│           │   ├── user-push-dialog.tsx
│           │   └── user-bulk-push-toolbar.tsx
│           ├── courses/
│           │   ├── course-sync-table.tsx
│           │   └── course-bulk-push-toolbar.tsx
│           ├── enrollments/
│           │   ├── enrollment-sync-table.tsx
│           │   └── enrollment-errors-panel.tsx
│           ├── assessments/
│           │   ├── assessment-list.tsx              # admin/lecturer: by-course, read-only
│           │   └── upcoming-assessments-widget.tsx  # student-facing, read-only
│           ├── grades/
│           │   ├── grade-list.tsx                   # admin: by course/student, read-only
│           │   └── my-grades-widget.tsx              # student-facing, read-only
│           └── calendar/
│               ├── calendar-event-list.tsx
│               ├── calendar-event-detail.tsx         # includes Zoom link
│               └── upcoming-events-widget.tsx         # student-facing, read-only
│
└── app/
    ├── (dashboard)/
    │   └── admin/
    │       └── (routes)/
    │           └── moodle-sync/
    │               ├── page.tsx                      # overview dashboard (summary cards, quick links)
    │               ├── categories/
    │               │   └── page.tsx
    │               ├── users/
    │               │   └── page.tsx
    │               ├── courses/
    │               │   └── page.tsx
    │               ├── enrollments/
    │               │   ├── page.tsx
    │               │   └── errors/
    │               │       └── page.tsx
    │               ├── assessments/
    │               │   └── page.tsx
    │               ├── grades/
    │               │   └── page.tsx
    │               └── calendar/
    │                   └── page.tsx
    │
    └── (root)/
        └── moodle/
            ├── grades/
            │   └── page.tsx                          # student: "My Grades" (Moodle)
            ├── calendar/
            │   └── page.tsx                           # student: "Upcoming Sessions" + Zoom
            └── assessments/
                └── upcoming/
                    └── page.tsx                        # student: upcoming Moodle deadlines
```

**Route rationale:** `moodle-sync` (admin control panel) is kept separate from
`moodle` (student-facing read views) because they have entirely different audiences,
permissions, and interaction models. All `app/` files here are thin shells only —
they import module components and compose them, per `CLAUDE.md` §4.

---

## 3. Domain Concepts (must-know before coding)

### 3.1 Sync Direction

| Value | Meaning |
|---|---|
| `PUSH` | Portal → Moodle |
| `PULL` | Moodle → Portal |
| `BIDIRECTIONAL` | Synced both ways |

### 3.2 Sync Status

| Value | Meaning | UI Treatment |
|---|---|---|
| `PENDING` | Queued, not yet processed | Neutral/gray badge |
| `SYNCED` | Successfully synced | Green badge |
| `FAILED` | Sync failed — see `syncError` | Red badge, show error on hover/click |
| `STALE` | Local changes not yet pushed | Amber/warning badge |

### 3.3 Entity → Moodle Mapping (for category tree UI)

```
Portal                          Moodle LMS
──────                          ──────────
Faculty (SOCIAL SCIENCES)   ──▶  Top-level Category
  └── Program (ECONOMICS)  ──▶    Sub-category
      └── Level (LEVEL 100) ──▶     Sub-category
          └── Semester (1ST SEM) ──▶   Sub-category
              └── Course (ECO101) ──▶    Moodle Course
```

### 3.4 User Role Mapping

| Portal Entity | Moodle Role | Sync Trigger |
|---|---|---|
| Student | `student` | **Automatic** — tuition payment verification only. Never manually pushed by admin before payment. |
| Lecturer | `editingteacher` | Manual — admin push/pull |
| Staff | `manager` | Manual — admin push/pull |
| Admin | `manager` | Manual — admin push/pull |

> **UI implication:** the "push user" action should be **disabled or hidden** for
> student-role users in the user sync table, since students are synced automatically
> on tuition verification, not by manual admin action. Show status instead (e.g. "Awaits
> payment verification" if `PENDING` and role is student).

### 3.5 Automatic Triggers (informational — no UI action required, but UI should reflect state)

| Event | Effect on data the UI displays |
|---|---|
| Admin creates faculty/program/level/semester | Category auto-pushed to Moodle (if auto-sync enabled) |
| Admin creates course offering under a semester | Course auto-pushed to Moodle (if auto-sync enabled) |
| Tuition payment verified | Moodle user created + enrolled in all selected courses |
| Cron (30 min / 1 hr / 1 hr / 15 min) | Assessments, grades, calendar pulled automatically; failed syncs retried |

Because of the cron jobs, list views for Assessments/Grades/Calendar should be treated
as **eventually consistent** — consider a "last synced" timestamp display and a manual
refresh affordance, not just a one-time fetch.

---

## 4. Zod Schemas & Types

All schemas live in `src/modules/moodle-sync/schemas/`. Types are inferred, never
hand-written, per `CLAUDE.md` §4 (Validation).

### 4.1 `common.schema.ts`

```ts
import { z } from 'zod'

export const SyncStatusSchema = z.enum(['PENDING', 'SYNCED', 'FAILED', 'STALE'])
export const SyncDirectionSchema = z.enum(['PUSH', 'PULL', 'BIDIRECTIONAL'])

export const SyncQueryFiltersSchema = z.object({
  status: SyncStatusSchema.optional(),
  direction: SyncDirectionSchema.optional(),
  dateFrom: z.string().datetime().optional(),
  dateTo: z.string().datetime().optional(),
})
```

### 4.2 `category.schema.ts`

```ts
import { z } from 'zod'
import { SyncStatusSchema, SyncDirectionSchema } from './common.schema'

export const PushCategoryDtoSchema = z.object({
  entityType: z.enum(['faculty', 'department', 'program', 'level', 'semester']),
  entityId: z.number().int().positive(),
  parentMoodleCategoryId: z.number().int().positive().optional(),
})

export const CategorySyncResponseSchema = z.object({
  id: z.number(),
  entityType: z.string(),
  entityId: z.number(),
  moodleCategoryId: z.number(),
  moodleCategoryName: z.string(),
  parentMoodleCategoryId: z.number().nullable(),
  syncStatus: SyncStatusSchema,
  syncDirection: SyncDirectionSchema,
  lastSyncAt: z.string().datetime(),
})
```

### 4.3 `user.schema.ts`

```ts
import { z } from 'zod'
import { SyncStatusSchema, SyncDirectionSchema } from './common.schema'

export const MoodleRoleSchema = z.enum(['student', 'editingteacher', 'teacher', 'manager'])

export const UserSyncResponseSchema = z.object({
  id: z.number(),
  userId: z.number(),
  moodleUserId: z.number(),
  moodleUsername: z.string(),
  moodleRole: MoodleRoleSchema,
  syncStatus: SyncStatusSchema,
  syncDirection: SyncDirectionSchema,
  lastSyncAt: z.string().datetime(),
})

export const UserSyncQueryFiltersSchema = z.object({
  role: MoodleRoleSchema.optional(),
  status: SyncStatusSchema.optional(),
})
```

### 4.4 `course.schema.ts`

```ts
import { z } from 'zod'
import { SyncStatusSchema, SyncDirectionSchema } from './common.schema'

export const CourseSyncResponseSchema = z.object({
  id: z.number(),
  courseOfferingId: z.number(),
  moodleCourseId: z.number(),
  moodleCategoryId: z.number().nullable(),
  moodleShortName: z.string(),
  moodleFullName: z.string(),
  syncStatus: SyncStatusSchema,
  syncDirection: SyncDirectionSchema,
  lastSyncAt: z.string().datetime(),
})
```

### 4.5 `enrollment.schema.ts`

```ts
import { z } from 'zod'
import { SyncStatusSchema, SyncDirectionSchema } from './common.schema'

export const EnrollmentSyncResponseSchema = z.object({
  id: z.number(),
  studentEnrollmentId: z.number(),
  moodleCourseId: z.number(),
  moodleUserId: z.number(),
  syncStatus: SyncStatusSchema,
  syncDirection: SyncDirectionSchema,
  syncError: z.string().nullable(),
  lastSyncAt: z.string().datetime().nullable(),
})
```

### 4.6 `assessment.schema.ts` (read-only domain)

```ts
import { z } from 'zod'

export const AssessmentTypeSchema = z.enum(['assignment', 'quiz', 'forum'])

export const AssessmentResponseSchema = z.object({
  id: z.number(),
  assessmentType: AssessmentTypeSchema,
  name: z.string(),
  description: z.string().nullable(),
  dueDate: z.string().datetime().nullable(),
  maxGrade: z.number().nullable(),
  course: z.object({
    moodleShortName: z.string(),
    moodleFullName: z.string(),
    courseOffering: z.object({
      course: z.object({ code: z.string(), title: z.string() }),
    }),
  }),
})

export const AssessmentListResponseSchema = z.object({
  data: z.array(AssessmentResponseSchema),
})
```

### 4.7 `grade.schema.ts` (read-only domain)

```ts
import { z } from 'zod'

export const GradeResponseSchema = z.object({
  id: z.number(),
  itemName: z.string(),
  grade: z.number().nullable(),
  maxGrade: z.number().nullable(),
  feedback: z.string().nullable(),
  gradedAt: z.string().datetime().nullable(),
  course: z.object({
    moodleShortName: z.string(),
    moodleFullName: z.string(),
    courseOffering: z.object({
      course: z.object({ code: z.string(), title: z.string() }),
    }),
  }),
})

export const GradeListResponseSchema = z.object({
  data: z.array(GradeResponseSchema),
})
```

### 4.8 `calendar.schema.ts` (read-only domain)

```ts
import { z } from 'zod'

export const CalendarEventTypeSchema = z.enum(['course', 'site', 'user', 'zoom'])

export const CalendarEventResponseSchema = z.object({
  id: z.number(),
  eventType: CalendarEventTypeSchema,
  name: z.string(),
  description: z.string().nullable(),
  startDate: z.string().datetime(),
  endDate: z.string().datetime().nullable(),
  meetingUrl: z.string().url().nullable(),
  course: z.object({
    moodleShortName: z.string(),
    courseOffering: z.object({
      course: z.object({ code: z.string(), title: z.string() }),
    }),
  }).nullable(),
})

export const CalendarEventListResponseSchema = z.object({
  data: z.array(CalendarEventResponseSchema),
})
```

### 4.9 `types/index.ts`

```ts
import { z } from 'zod'
import * as CategorySchemas from '../schemas/category.schema'
import * as UserSchemas from '../schemas/user.schema'
import * as CourseSchemas from '../schemas/course.schema'
import * as EnrollmentSchemas from '../schemas/enrollment.schema'
import * as AssessmentSchemas from '../schemas/assessment.schema'
import * as GradeSchemas from '../schemas/grade.schema'
import * as CalendarSchemas from '../schemas/calendar.schema'
import * as CommonSchemas from '../schemas/common.schema'

export type SyncStatus = z.infer<typeof CommonSchemas.SyncStatusSchema>
export type SyncDirection = z.infer<typeof CommonSchemas.SyncDirectionSchema>
export type SyncQueryFilters = z.infer<typeof CommonSchemas.SyncQueryFiltersSchema>

export type PushCategoryDto = z.infer<typeof CategorySchemas.PushCategoryDtoSchema>
export type CategorySyncResponse = z.infer<typeof CategorySchemas.CategorySyncResponseSchema>

export type MoodleRole = z.infer<typeof UserSchemas.MoodleRoleSchema>
export type UserSyncResponse = z.infer<typeof UserSchemas.UserSyncResponseSchema>
export type UserSyncQueryFilters = z.infer<typeof UserSchemas.UserSyncQueryFiltersSchema>

export type CourseSyncResponse = z.infer<typeof CourseSchemas.CourseSyncResponseSchema>

export type EnrollmentSyncResponse = z.infer<typeof EnrollmentSchemas.EnrollmentSyncResponseSchema>

export type AssessmentType = z.infer<typeof AssessmentSchemas.AssessmentTypeSchema>
export type AssessmentResponse = z.infer<typeof AssessmentSchemas.AssessmentResponseSchema>

export type GradeResponse = z.infer<typeof GradeSchemas.GradeResponseSchema>

export type CalendarEventType = z.infer<typeof CalendarSchemas.CalendarEventTypeSchema>
export type CalendarEventResponse = z.infer<typeof CalendarSchemas.CalendarEventResponseSchema>
```

---

## 5. API Service Layer

**One file, `moodle-sync.service.ts`**, organized into commented sections matching the
backend controller's grouping. All calls go through `src/lib/clients/apiClient.ts` —
never raw `fetch`/`axios`, per `CLAUDE.md` §4.

```ts
import { apiClient } from '@/lib/clients/apiClient'
import type {
  PushCategoryDto, CategorySyncResponse,
  UserSyncResponse, UserSyncQueryFilters,
  CourseSyncResponse,
  EnrollmentSyncResponse,
  AssessmentResponse,
  GradeResponse,
  CalendarEventResponse,
} from '../types'

const BASE = '/moodle-sync'

export const moodleSyncService = {
  // ---------- Categories ----------
  listCategories: () => apiClient.get<CategorySyncResponse[]>(`${BASE}/categories`),
  getCategory: (id: number) => apiClient.get<CategorySyncResponse>(`${BASE}/categories/${id}`),
  pushCategory: (dto: PushCategoryDto) => apiClient.post<CategorySyncResponse>(`${BASE}/categories/push`, dto),
  pushHierarchy: (facultyId: number) => apiClient.post(`${BASE}/categories/push-hierarchy/${facultyId}`),
  pullCategories: () => apiClient.post(`${BASE}/categories/pull`),
  pullCategory: (moodleCategoryId: number) => apiClient.post(`${BASE}/categories/pull/${moodleCategoryId}`),
  deleteCategoryMapping: (id: number) => apiClient.delete(`${BASE}/categories/${id}`),

  // ---------- Users ----------
  listUsers: (filters?: UserSyncQueryFilters) => apiClient.get<UserSyncResponse[]>(`${BASE}/users`, { params: filters }),
  getUserMapping: (id: number) => apiClient.get<UserSyncResponse>(`${BASE}/users/${id}`),
  getUserMappingByUserId: (userId: number) => apiClient.get<UserSyncResponse>(`${BASE}/users/user/${userId}`),
  pushUser: (userId: number) => apiClient.post<UserSyncResponse>(`${BASE}/users/push/${userId}`),
  pushUsersBulk: (userIds: number[]) => apiClient.post(`${BASE}/users/push-bulk`, { userIds }),
  pullUsers: () => apiClient.post(`${BASE}/users/pull`),
  pullUser: (moodleUserId: number) => apiClient.post(`${BASE}/users/pull/${moodleUserId}`),

  // ---------- Courses ----------
  listCourses: () => apiClient.get<CourseSyncResponse[]>(`${BASE}/courses`),
  getCourse: (id: number) => apiClient.get<CourseSyncResponse>(`${BASE}/courses/${id}`),
  pushCourse: (courseOfferingId: number) => apiClient.post<CourseSyncResponse>(`${BASE}/courses/push/${courseOfferingId}`),
  pushCoursesBulk: (courseOfferingIds: number[]) => apiClient.post(`${BASE}/courses/push-bulk`, { courseOfferingIds }),
  pullCourses: () => apiClient.post(`${BASE}/courses/pull`),
  pullCourse: (moodleCourseId: number) => apiClient.post(`${BASE}/courses/pull/${moodleCourseId}`),

  // ---------- Enrollments ----------
  listEnrollments: (filters?: { status?: string }) => apiClient.get<EnrollmentSyncResponse[]>(`${BASE}/enrollments`, { params: filters }),
  listEnrollmentErrors: () => apiClient.get<EnrollmentSyncResponse[]>(`${BASE}/enrollments/errors`),
  pushEnrollment: (enrollmentId: number) => apiClient.post(`${BASE}/enrollments/push/${enrollmentId}`),
  pushAllEnrollments: () => apiClient.post(`${BASE}/enrollments/push-all`),
  pullEnrollments: (moodleCourseId: number) => apiClient.post(`${BASE}/enrollments/pull/${moodleCourseId}`),

  // ---------- Assessments (read-only for students; pull actions for admin) ----------
  listAssessments: (filters?: { courseId?: number; type?: string }) =>
    apiClient.get<{ data: AssessmentResponse[] }>(`${BASE}/assessments`, { params: filters }),
  listAssessmentsByCourse: (courseOfferingId: number) =>
    apiClient.get<{ data: AssessmentResponse[] }>(`${BASE}/assessments/course/${courseOfferingId}`),
  listUpcomingAssessments: () =>
    apiClient.get<{ data: AssessmentResponse[] }>(`${BASE}/assessments/upcoming`),
  pullAssessments: (moodleCourseId: number) => apiClient.post(`${BASE}/assessments/pull/${moodleCourseId}`),
  pullAllAssessments: () => apiClient.post(`${BASE}/assessments/pull-all`),

  // ---------- Grades (read-only for students; pull actions for admin) ----------
  listGrades: (filters?: { courseId?: number; userId?: number }) =>
    apiClient.get<{ data: GradeResponse[] }>(`${BASE}/grades`, { params: filters }),
  listGradesByStudent: (userId: number) => apiClient.get<{ data: GradeResponse[] }>(`${BASE}/grades/student/${userId}`),
  listGradesByCourse: (courseOfferingId: number) => apiClient.get<{ data: GradeResponse[] }>(`${BASE}/grades/course/${courseOfferingId}`),
  getMyGrades: () => apiClient.get<{ data: GradeResponse[] }>(`${BASE}/grades/my`),
  pullGrades: (moodleCourseId: number) => apiClient.post(`${BASE}/grades/pull/${moodleCourseId}`),
  pullAllGrades: () => apiClient.post(`${BASE}/grades/pull-all`),

  // ---------- Calendar (read-only for students; pull actions for admin) ----------
  listCalendarEvents: () => apiClient.get<{ data: CalendarEventResponse[] }>(`${BASE}/calendar`),
  listCalendarEventsByCourse: (courseOfferingId: number) =>
    apiClient.get<{ data: CalendarEventResponse[] }>(`${BASE}/calendar/course/${courseOfferingId}`),
  listUpcomingEvents: () => apiClient.get<{ data: CalendarEventResponse[] }>(`${BASE}/calendar/upcoming`),
  getCalendarEvent: (id: number) => apiClient.get<CalendarEventResponse>(`${BASE}/calendar/${id}`),
  pullCalendar: () => apiClient.post(`${BASE}/calendar/pull`),
  pullCalendarForCourse: (moodleCourseId: number) => apiClient.post(`${BASE}/calendar/pull/${moodleCourseId}`),
}
```

> Validate every response against its Zod schema at the service boundary (`schema.parse(response.data)`)
> before returning, so malformed backend payloads fail loudly instead of leaking bad shapes into hooks/components.

---

## 6. React Query Hooks

Never call `useQuery`/`useMutation` directly in pages — always abstract into hooks, per
`CLAUDE.md` §4. Split by sub-resource file, matching the folder structure in §2.

### 6.1 Example — `use-sync-categories.ts`

```ts
import { useQuery } from '@tanstack/react-query'
import { moodleSyncService } from '../services/moodle-sync.service'
import { moodleSyncKeys } from './query-keys'

export function useSyncCategories() {
  return useQuery({
    queryKey: moodleSyncKeys.categories(),
    queryFn: moodleSyncService.listCategories,
  })
}

export function useSyncCategory(id: number) {
  return useQuery({
    queryKey: moodleSyncKeys.category(id),
    queryFn: () => moodleSyncService.getCategory(id),
    enabled: !!id,
  })
}
```

### 6.2 Example — `use-sync-assessments.ts` (read-only pattern)

```ts
import { useQuery } from '@tanstack/react-query'
import { moodleSyncService } from '../services/moodle-sync.service'
import { moodleSyncKeys } from './query-keys'

export function useUpcomingAssessments() {
  return useQuery({
    queryKey: moodleSyncKeys.assessmentsUpcoming(),
    queryFn: moodleSyncService.listUpcomingAssessments,
    staleTime: 5 * 60 * 1000, // cron pulls every 30 min server-side; no need to poll aggressively
  })
}

export function useAssessmentsByCourse(courseOfferingId: number) {
  return useQuery({
    queryKey: moodleSyncKeys.assessmentsByCourse(courseOfferingId),
    queryFn: () => moodleSyncService.listAssessmentsByCourse(courseOfferingId),
    enabled: !!courseOfferingId,
  })
}
```

### 6.3 `use-sync-mutations.ts` — single file for all actionable mutations

All push/pull actions across Category/User/Course/Enrollment follow an identical
shape: fire the mutation → invalidate the relevant list query (+ errors query where
applicable). A shared factory avoids duplicating this boilerplate ~15 times, per
`CLAUDE.md` §9 (no duplicated logic).

```ts
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { moodleSyncService } from '../services/moodle-sync.service'
import { moodleSyncKeys } from './query-keys'

// ---------- Category mutations ----------
export function usePushCategory() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: moodleSyncService.pushCategory,
    onSuccess: () => qc.invalidateQueries({ queryKey: moodleSyncKeys.categories() }),
  })
}

export function usePushHierarchy() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (facultyId: number) => moodleSyncService.pushHierarchy(facultyId),
    onSuccess: () => qc.invalidateQueries({ queryKey: moodleSyncKeys.categories() }),
  })
}

export function usePullCategories() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: moodleSyncService.pullCategories,
    onSuccess: () => qc.invalidateQueries({ queryKey: moodleSyncKeys.categories() }),
  })
}

// ---------- User mutations ----------
export function usePushUser() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (userId: number) => moodleSyncService.pushUser(userId),
    onSuccess: () => qc.invalidateQueries({ queryKey: moodleSyncKeys.users() }),
  })
}

export function usePushUsersBulk() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (userIds: number[]) => moodleSyncService.pushUsersBulk(userIds),
    onSuccess: () => qc.invalidateQueries({ queryKey: moodleSyncKeys.users() }),
  })
}

export function usePullUsers() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: moodleSyncService.pullUsers,
    onSuccess: () => qc.invalidateQueries({ queryKey: moodleSyncKeys.users() }),
  })
}

// ---------- Course mutations ----------
export function usePushCourse() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (courseOfferingId: number) => moodleSyncService.pushCourse(courseOfferingId),
    onSuccess: () => qc.invalidateQueries({ queryKey: moodleSyncKeys.courses() }),
  })
}

export function usePullCourses() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: moodleSyncService.pullCourses,
    onSuccess: () => qc.invalidateQueries({ queryKey: moodleSyncKeys.courses() }),
  })
}

// ---------- Enrollment mutations ----------
export function usePushEnrollment() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (enrollmentId: number) => moodleSyncService.pushEnrollment(enrollmentId),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: moodleSyncKeys.enrollments() })
      qc.invalidateQueries({ queryKey: moodleSyncKeys.enrollmentErrors() })
    },
  })
}

export function usePushAllEnrollments() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: moodleSyncService.pushAllEnrollments,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: moodleSyncKeys.enrollments() })
      qc.invalidateQueries({ queryKey: moodleSyncKeys.enrollmentErrors() })
    },
  })
}

// ---------- Admin-only pull actions for read-only domains ----------
export function usePullAssessments() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (moodleCourseId: number) => moodleSyncService.pullAssessments(moodleCourseId),
    onSuccess: () => qc.invalidateQueries({ queryKey: [...moodleSyncKeys.all, 'assessments'] }),
  })
}

export function usePullAllAssessments() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: moodleSyncService.pullAllAssessments,
    onSuccess: () => qc.invalidateQueries({ queryKey: [...moodleSyncKeys.all, 'assessments'] }),
  })
}

export function usePullGrades() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (moodleCourseId: number) => moodleSyncService.pullGrades(moodleCourseId),
    onSuccess: () => qc.invalidateQueries({ queryKey: [...moodleSyncKeys.all, 'grades'] }),
  })
}

export function usePullCalendar() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: moodleSyncService.pullCalendar,
    onSuccess: () => qc.invalidateQueries({ queryKey: [...moodleSyncKeys.all, 'calendar'] }),
  })
}
```

> Add remaining mutations (`pullCategory`, `deleteCategoryMapping`, `pushUser`,
> `pullUser`, `pushCoursesBulk`, `pullCourse`, `pullEnrollments`, `pullAllGrades`,
> `pullCalendarForCourse`) following the exact same pattern — fire, then invalidate
> the owning list key (and `errors` key where the resource has one).

---

## 7. Query Key Factory

`query-keys.ts` — single factory, namespaced per sub-resource, following the pattern
already used in the `assessments` module (see `CLAUDE.md` §3 conventions).

```ts
import type { SyncQueryFilters, UserSyncQueryFilters } from '../types'

export const moodleSyncKeys = {
  all: ['moodle-sync'] as const,

  categories: () => [...moodleSyncKeys.all, 'categories'] as const,
  category: (id: number) => [...moodleSyncKeys.categories(), id] as const,

  users: (filters?: UserSyncQueryFilters) => [...moodleSyncKeys.all, 'users', filters] as const,
  user: (id: number) => [...moodleSyncKeys.all, 'users', id] as const,
  userByUserId: (userId: number) => [...moodleSyncKeys.all, 'users', 'user', userId] as const,

  courses: () => [...moodleSyncKeys.all, 'courses'] as const,
  course: (id: number) => [...moodleSyncKeys.courses(), id] as const,

  enrollments: (filters?: SyncQueryFilters) => [...moodleSyncKeys.all, 'enrollments', filters] as const,
  enrollmentErrors: () => [...moodleSyncKeys.all, 'enrollments', 'errors'] as const,

  assessments: (filters?: { courseId?: number; type?: string }) =>
    [...moodleSyncKeys.all, 'assessments', filters] as const,
  assessmentsByCourse: (courseOfferingId: number) =>
    [...moodleSyncKeys.all, 'assessments', 'course', courseOfferingId] as const,
  assessmentsUpcoming: () => [...moodleSyncKeys.all, 'assessments', 'upcoming'] as const,

  grades: (filters?: { courseId?: number; userId?: number }) =>
    [...moodleSyncKeys.all, 'grades', filters] as const,
  gradesByStudent: (userId: number) => [...moodleSyncKeys.all, 'grades', 'student', userId] as const,
  gradesByCourse: (courseOfferingId: number) => [...moodleSyncKeys.all, 'grades', 'course', courseOfferingId] as const,
  myGrades: () => [...moodleSyncKeys.all, 'grades', 'my'] as const,

  calendar: () => [...moodleSyncKeys.all, 'calendar'] as const,
  calendarByCourse: (courseOfferingId: number) => [...moodleSyncKeys.all, 'calendar', 'course', courseOfferingId] as const,
  calendarUpcoming: () => [...moodleSyncKeys.all, 'calendar', 'upcoming'] as const,
  calendarEvent: (id: number) => [...moodleSyncKeys.calendar(), id] as const,
} as const
```

**Always invalidate by key factory, never raw strings** — per `CLAUDE.md` §4.

---

## 8. Zustand UI Store

`moodle-sync-ui.store.ts` — **UI state only.** No synced data lives here; that's
exclusively React Query's cache, per `CLAUDE.md` §4/§5.

```ts
import { create } from 'zustand'

type MoodleSyncTab = 'categories' | 'users' | 'courses' | 'enrollments' | 'assessments' | 'grades' | 'calendar'

interface MoodleSyncUiState {
  activeTab: MoodleSyncTab
  setActiveTab: (tab: MoodleSyncTab) => void

  expandedCategoryIds: Set<number>
  toggleCategoryExpanded: (id: number) => void

  userTableFilters: { role?: string; status?: string }
  setUserTableFilters: (filters: { role?: string; status?: string }) => void

  enrollmentTableFilters: { status?: string }
  setEnrollmentTableFilters: (filters: { status?: string }) => void

  selectedUserIds: number[]
  toggleUserSelected: (id: number) => void
  clearSelectedUsers: () => void
}

export const useMoodleSyncUiStore = create<MoodleSyncUiState>((set) => ({
  activeTab: 'categories',
  setActiveTab: (tab) => set({ activeTab: tab }),

  expandedCategoryIds: new Set(),
  toggleCategoryExpanded: (id) =>
    set((state) => {
      const next = new Set(state.expandedCategoryIds)
      next.has(id) ? next.delete(id) : next.add(id)
      return { expandedCategoryIds: next }
    }),

  userTableFilters: {},
  setUserTableFilters: (filters) => set({ userTableFilters: filters }),

  enrollmentTableFilters: {},
  setEnrollmentTableFilters: (filters) => set({ enrollmentTableFilters: filters }),

  selectedUserIds: [],
  toggleUserSelected: (id) =>
    set((state) => ({
      selectedUserIds: state.selectedUserIds.includes(id)
        ? state.selectedUserIds.filter((x) => x !== id)
        : [...state.selectedUserIds, id],
    })),
  clearSelectedUsers: () => set({ selectedUserIds: [] }),
}))
```

---

## 9. Routes & Pages

All pages under `app/` are **thin shells** — import module components, compose,
nothing else. `useRoleGuard` at the top of every admin page.

| Route | Purpose | Guard |
|---|---|---|
| `/admin/moodle-sync` | Overview dashboard — summary cards per sub-resource, last cron run times | `useRoleGuard([ADMIN, SUPER_ADMIN])` |
| `/admin/moodle-sync/categories` | Category tree + push/pull controls | Admin |
| `/admin/moodle-sync/users` | User sync table, bulk push, pull | Admin |
| `/admin/moodle-sync/courses` | Course sync table, bulk push, pull | Admin |
| `/admin/moodle-sync/enrollments` | Enrollment sync table | Admin |
| `/admin/moodle-sync/enrollments/errors` | Failed enrollment syncs + retry | Admin |
| `/admin/moodle-sync/assessments` | Read-only list + admin pull controls | Admin |
| `/admin/moodle-sync/grades` | Read-only list + admin pull controls | Admin |
| `/admin/moodle-sync/calendar` | Read-only list + admin pull controls | Admin |
| `/moodle/grades` | Student: "My Grades" (Moodle) | `useRoleGuard([STUDENT])` or permission check |
| `/moodle/calendar` | Student: upcoming sessions + Zoom links | Student |
| `/moodle/assessments/upcoming` | Student: upcoming deadlines | Student |

### Example shell — `app/(dashboard)/admin/(routes)/moodle-sync/categories/page.tsx`

```tsx
'use client'

import { useRoleGuard } from '@/hooks/use-role-guard'
import { UserRole } from '@/types/roles'
import { CategoryTree } from '@/modules/moodle-sync/components/categories/category-tree'
import { CategoryPullPanel } from '@/modules/moodle-sync/components/categories/category-pull-panel'

export default function MoodleSyncCategoriesPage() {
  useRoleGuard([UserRole.ADMIN, UserRole.SUPER_ADMIN])

  return (
    <div className="space-y-6">
      <CategoryPullPanel />
      <CategoryTree />
    </div>
  )
}
```

### Example shell — `app/(root)/moodle/grades/page.tsx`

```tsx
'use client'

import { MyGradesWidget } from '@/modules/moodle-sync/components/grades/my-grades-widget'

export default function MyMoodleGradesPage() {
  return <MyGradesWidget />
}
```

---

## 10. Components

### 10.1 Shared

- **`sync-status-badge.tsx`** — takes `status: SyncStatus`, renders colored badge
  (see §3.2 for color mapping). On `FAILED`, wrap in a tooltip/popover showing
  `syncError` if the parent passes it.
- **`sync-direction-badge.tsx`** — takes `direction: SyncDirection`, small icon + label.
- **`push-pull-toolbar.tsx`** — generic action bar accepting `onPush`, `onPull`,
  `onPullAll` callbacks (any can be omitted) + loading states from the calling
  mutation hooks. Reused across categories/users/courses.

### 10.2 Category components

- **`category-tree.tsx`** — renders Faculty → Program → Level → Semester using
  `expandedCategoryIds` from the Zustand store. Each node shows `sync-status-badge`
  and a "Push" action (or "Push Hierarchy" at the Faculty root).
- **`category-push-dialog.tsx`** — form for `PushCategoryDto` (entity type, entity id
  select, optional parent Moodle category id). Uses `zodResolver(PushCategoryDtoSchema)`.
- **`category-pull-panel.tsx`** — single "Pull All Categories" action + last pulled
  timestamp.

### 10.3 User components

- **`user-sync-table.tsx`** — columns: name, email, portal role, `moodleRole`,
  `sync-status-badge`, last synced, action. **Push action disabled for students**
  per §3.4 — show status text instead.
- **`user-push-dialog.tsx`** — confirm dialog for single push (lecturer/staff/admin only).
- **`user-bulk-push-toolbar.tsx`** — uses `selectedUserIds` from Zustand store +
  `usePushUsersBulk`.

### 10.4 Course components

- **`course-sync-table.tsx`** — columns: course code/title, Moodle shortname,
  category, status, action.
- **`course-bulk-push-toolbar.tsx`** — same bulk-select pattern as users.

### 10.5 Enrollment components

- **`enrollment-sync-table.tsx`** — filterable by status via
  `enrollmentTableFilters` in the Zustand store.
- **`enrollment-errors-panel.tsx`** — dedicated view of `FAILED` records with
  `syncError` text and a retry button per row (`usePushEnrollment`).

### 10.6 Assessment components (read-only — see §12)

- **`assessment-list.tsx`** — admin/lecturer view, filterable by course/type. No
  push controls; only an optional "Pull" action gated to admin.
- **`upcoming-assessments-widget.tsx`** — student-facing, no admin controls at all.
  Sorted by `dueDate` ascending, empty state for no upcoming items.

### 10.7 Grade components (read-only — see §12)

- **`grade-list.tsx`** — admin view, by course or by student.
- **`my-grades-widget.tsx`** — student-facing, grouped by course, shows individual
  grade items. Include the note distinguishing these from the portal's own official
  Result grades (see backend doc §9 note) — display as a small info banner, e.g.
  "These are Moodle activity grades (assignments, quizzes). Your official results
  are available under Results."

### 10.8 Calendar components (read-only — see §12)

- **`calendar-event-list.tsx`** — admin view, filterable by course.
- **`calendar-event-detail.tsx`** — shows full event info; if `eventType === 'zoom'`,
  render a prominent "Join Meeting" button using `meetingUrl`.
- **`upcoming-events-widget.tsx`** — student-facing, sorted by `startDate` ascending.

---

## 11. Auth & Permission Gating

Per `CLAUDE.md` §5 — never hard-code role checks; always check permission, not role.

**Proposed permission resource:** `moodle-sync`, with actions:

| Action | Applies to |
|---|---|
| `view` | Read access to any sync list/detail (admin dashboard) |
| `push` | Trigger any push operation |
| `pull` | Trigger any pull operation |
| `manage` | Full control (push + pull + delete mappings + retry) |

```tsx
// Route-level (admin dashboard pages)
useRoleGuard([UserRole.ADMIN, UserRole.SUPER_ADMIN])

// Feature-level (inside pages/components)
<PermissionGate require={{ resource: 'moodle-sync', action: 'push' }}>
  <PushPullToolbar onPush={...} />
</PermissionGate>

<PermissionGate
  require={[
    { resource: 'moodle-sync', action: 'push' },
    { resource: 'moodle-sync', action: 'pull' },
  ]}
  mode="any"
  fallback={<AccessDenied />}
>
  <CategoryTree />
</PermissionGate>
```

Student-facing pages (`/moodle/grades`, `/moodle/calendar`,
`/moodle/assessments/upcoming`) should be gated by whatever permission/role already
governs student dashboard access in this codebase — **not** a new `moodle-sync`
permission, since students never touch sync operations, only read the resulting data.
Confirm existing convention before implementing (see §16).

---

## 12. Read-Only vs Actionable Resources

This distinction must be respected strictly in the UI — **never render push controls
for pull-only domains.**

| Resource | Push? | Pull? | Notes |
|---|---|---|---|
| Categories | ✅ | ✅ | Full bidirectional admin control |
| Users | ✅ | ✅ | Push disabled in UI for student role (see §3.4) |
| Courses | ✅ | ✅ | Full bidirectional admin control |
| Enrollments | ✅ | ✅ | Push individual or all-pending; pull by Moodle course |
| Assessments | ❌ | ✅ (admin only) | Students see read-only list; no admin push |
| Grades | ❌ | ✅ (admin only) | Students see read-only list; no admin push |
| Calendar | ❌ | ✅ (admin only) | Students see read-only list; no admin push |

Assessment/Grade/Calendar admin pages get a pull button and "last pulled at"
indicator; nothing else. Student-facing widgets for these three get **zero**
action controls — pure display, per the backend's read-only contract.

---

## 13. Error Handling & Loading States

- **List queries:** standard skeleton loaders matching table/tree row shape; error
  state shows a retry button calling `refetch()`.
- **Push/pull mutations:** disable the triggering button while `isPending`; on error,
  surface `syncError` (if present in response) via toast/inline alert — never swallow.
- **Enrollment errors panel:** this is the canonical place for surfacing `FAILED`
  syncs; other tables can show a compact status badge and defer full error text to
  this panel or a tooltip.
- **Bulk actions:** show per-item progress if the backend response supports it,
  otherwise a single aggregate result toast ("12 pushed, 2 failed — see Errors").
- **Cron-driven data (assessments/grades/calendar):** since these update outside
  user action, show a "last synced" timestamp pulled from the most recent record
  and a manual refresh icon button (`refetch()`), not just a static list.

---

## 14. Naming Conventions Recap

(Inherited from `CLAUDE.md` §8 — restated here for this module's file names.)

| Artifact | Convention | Example |
|---|---|---|
| Components | `kebab-case.tsx` | `category-tree.tsx` |
| Hooks | `use-*.ts` | `use-sync-categories.ts` |
| Service | `[domain].service.ts` | `moodle-sync.service.ts` |
| Module store | `[domain]-ui.store.ts` | `moodle-sync-ui.store.ts` |
| Query keys | `query-keys.ts` | — |
| Schemas & types | `index.ts` in `types/`, split files in `schemas/` | `category.schema.ts` |
| Pages | `page.tsx` | — |

---

## 15. Implementation Checklist

Use this as the build order — each step should be a self-contained, testable slice.

- [ ] `schemas/common.schema.ts` + `schemas/category.schema.ts`
- [ ] `types/index.ts` (category types only, extend as schemas are added)
- [ ] `services/moodle-sync.service.ts` — category section only
- [ ] `hooks/query-keys.ts` — category keys only
- [ ] `hooks/use-sync-categories.ts`
- [ ] `hooks/use-sync-mutations.ts` — category mutations only
- [ ] `store/moodle-sync-ui.store.ts` — `activeTab` + `expandedCategoryIds` only
- [ ] `components/categories/*` (tree, push dialog, pull panel)
- [ ] `components/shared/sync-status-badge.tsx`, `sync-direction-badge.tsx`, `push-pull-toolbar.tsx`
- [ ] `app/(dashboard)/admin/(routes)/moodle-sync/categories/page.tsx`
- [ ] **Repeat the same vertical-slice pattern for:** Users → Courses → Enrollments
- [ ] **Read-only slices (simpler — no push, no dialogs):** Assessments → Grades → Calendar
- [ ] Student-facing widgets: `upcoming-assessments-widget.tsx`, `my-grades-widget.tsx`, `upcoming-events-widget.tsx`
- [ ] Student-facing pages under `app/(root)/moodle/`
- [ ] Admin overview dashboard `app/(dashboard)/admin/(routes)/moodle-sync/page.tsx` (built last — aggregates all sub-resources)

---

## 16. Open Questions / Assumptions to Confirm

Resolve these before or during implementation — flagged so nothing gets silently
assumed into the codebase:

1. **Permission granularity** — is a single `moodle-sync` resource with
   `view/push/pull/manage` actions correct, or should this be split into
   per-sub-resource permissions (e.g. `moodle-sync-categories`, `moodle-sync-users`)
   for finer admin delegation?
2. **Student-facing route placement** — should `/moodle/grades`, `/moodle/calendar`,
   `/moodle/assessments/upcoming` live under a new `moodle` route group (as scaffolded
   here), or be nested inside the existing `assessments` module's routes? They are
   backed by entirely separate models/endpoints from the portal's own Assessment/Result
   domain, so keeping them separate was the default choice.
3. **Existing `apiClient` pagination/params convention** — confirm the exact shape
   `apiClient.get(url, { params })` expects, to match whatever pattern other modules
   (e.g. `assessments.service.ts`) already use, so list filters serialize consistently.
4. **Toast/notification system** — confirm which existing toast utility to use for
   mutation success/error feedback so this module doesn't introduce a second one.
5. **"Last synced" display source** — for cron-driven read-only resources, confirm
   whether the backend exposes a dedicated "last cron run" timestamp endpoint, or
   whether the UI should derive it from the most recent record's `lastSyncAt`/`gradedAt`/etc.