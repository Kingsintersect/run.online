# Moodle Sync Module — Backend Gaps Found In Production

> **Audience:** Backend developer (qhub_backend_api).
> **Status (2026-08-29):** Found while debugging live bug reports on the admin Moodle Sync
> pages. Items 1 and 4 are **confirmed** (live network inspection / live crash trace); items
> 2, 3, and 5 are inferred from a runtime crash or a live payload and should be verified
> against the actual database/response, not assumed. This is a different kind of doc from
> `MISSING_BACKEND_APIS.md` (endpoints that don't exist yet) — everything below is an
> **existing, working endpoint whose response is missing fields, occasionally malformed, or
> broader/thinner than what was originally documented**.
>
> **The frontend has already been built directly against the exact contract requested in
> each item below** — new fields are declared (as optional, since the current backend
> doesn't send them) in the relevant Zod schema, and the UI already renders them when
> present. Nothing further is required on the frontend once the backend ships each fix — the
> new fields just start appearing. See "Frontend status" under each item for what's live now
> and what happens automatically once the backend catches up.

---

## 1. `GET /moodle-sync/users` (and related mapping endpoints) don't return `name`/`email`/`portalRole`

**This was proposed, not confirmed, and is not actually built.** Per
`moodle_sync_UI_README.md`'s "Frontend Contract Additions" section, the frontend's
`UserSyncResponse` type adds `name`, `email`, `portalRole` on top of the original documented
shape in `moodle-sync-api.md` §"User Sync" (`id, user_id, moodle_user_id, moodle_username,
moodle_role, sync_status, sync_direction, last_sync_at` — no name/email/role). Confirmed live:
`GET /moodle-sync/users` returns rows with no name, email, or portal role at all, which is
why the admin UI's "Name / Email" and "Portal Role" columns rendered blank.

**Ask:** have `GET /moodle-sync/users`, `GET /moodle-sync/users/{id}`, and
`GET /moodle-sync/users/user/{userId}` join the mapped `users` row and include:

```json
{
  "data": {
    "id": 1,
    "user_id": 501,
    "name": "Jane Doe",
    "email": "jane.doe@example.com",
    "portal_role": "STAFF",
    "moodle_user_id": 88,
    "moodle_username": "jdoe",
    "moodle_role": "editingteacher",
    "sync_status": "SYNCED",
    "sync_direction": "PUSH",
    "last_sync_at": "2026-08-21T10:00:00Z"
  }
}
```

`portal_role` should be one of `STUDENT | TUTOR | STAFF | ADMIN` — the same bucket the
`moodle_role` mapping logic already uses internally to decide `student` vs
`editingteacher`/`teacher`/`manager`, so no new lookup should be needed to add it.

**The same gap almost certainly exists on three sibling endpoints**, proposed in the same
README section but never exercised against a live backend until now:
- `CategorySyncResponse` (`GET /moodle-sync/categories`) needs `entityName`, `parentId`.
- `CourseSyncResponse` (`GET /moodle-sync/courses`) needs `courseCode`, `courseTitle`.
- `EnrollmentSyncResponse` (`GET /moodle-sync/enrollments`) needs `studentName`, `courseCode`.

These three are not yet confirmed broken by a live user report the way Users was — flagging
them now so they get the same fix in one pass instead of three separate bug reports later.

**Frontend status (Users only):** `useSyncUsers()` in
`src/modules/moodle-sync/hooks/use-sync-users.ts` fetches every portal user via the
confirmed-live `GET /users` (paginated in batches of 100, since that endpoint caps `limit` —
see item 3) and joins them onto each sync row by `user_id`, filling `name`/`email`/
`portalRole` only when the sync record's own fields are empty. The moment the backend starts
sending real values for those three fields, this join becomes a no-op and can be deleted —
no behavior changes either way. Category/Course/Enrollment tables have **not** been given the
same treatment yet.

---

## 2. `GET /users` — a role entry can be missing its `slug`

While investigating item 1, a portal user's `roles` array (as declared in
`src/types/users.d.ts`: `{ id: number; name: string; slug: string }[]`) came back from a
live `GET /users` call with at least one role object where `slug` was `undefined`, causing
`roles[i].slug.trim()` to throw `Cannot read properties of undefined (reading 'trim')` in
the frontend. `name` was present on that same role object.

**Ask:** confirm whether `slug` is nullable on the `roles` relation, or whether this was a
specific role record created without one (e.g. seeded/legacy data missing the slugify step
newer roles get). If it's meant to always be non-null, backfill the missing slug(s) and add
a not-null constraint/validation so it can't happen again; if it's legitimately optional,
please update `user_README.md`'s response shape to mark it nullable so the frontend type
matches reality.

**Frontend status:** `derivePortalRole()` in `use-sync-users.ts` treats `slug` as
possibly-missing by design (falls back to `role.name`, treats a missing `roles` array as
empty) — this is correct, permanent defensive handling of third-party/external data, not a
temporary patch, and stays regardless of whether the backend backfills the data.

---

## 3. `GET /users` — `limit` query param is capped at 100, undocumented

Requesting `GET /users?limit=500` returns a `422` with `"The limit field must not be greater
than 100."`. This is reasonable API design, but it isn't mentioned anywhere in
`user_README.md` or `bruno/user/Users - List.bru`'s docs block (both just say "supports
`page`, `limit`"), so it's only discoverable by hitting the cap in production.

**Ask:** no behavior change needed — just document the actual max (100, or whatever the
real ceiling is) in `user_README.md` so frontend/integration work doesn't have to
rediscover it by trial and error.

**Frontend status:** `fetchAllPortalUsers()` in `use-sync-users.ts` pages through `GET
/users` in batches of 100 using the response's `meta.total` to know how many pages to fetch.
This is the correct, permanent way to consume a capped list endpoint — not something that
changes once the cap is documented.

---

## 4. `GET /moodle-sync/calendar*` — `event_type` isn't limited to the 4 documented values

`moodle-sync-api.md` §"Calendar & Zoom Sync" and `calendar.schema.ts`'s
`CalendarEventTypeSchema` document `event_type` as one of `zoom | course | site | user`.
Confirmed live: at least one real synced event came back with an `event_type` outside that
set, which crashed the admin Calendar & Zoom page (`Element type is invalid... Icon` — a
closed lookup map indexed directly by `event.eventType` returned `undefined`). This strongly
suggests Moodle's own native calendar event types (e.g. assignment-module types like
`due`/`open`/`close`, or `category`/`group`) are being passed straight through for at least
some events, rather than normalized into the 4-value set the API was designed around.

**Ask:** either (a) normalize every pulled event's `event_type` into the documented 4-value
set server-side before storing/returning it (mapping anything else to the closest fit, e.g.
`course` for module-specific course events), or (b) if passing through Moodle's native types
is intentional, update `moodle-sync-api.md` with the full real list of values this field can
take so the frontend can render all of them meaningfully instead of falling back to a
generic label.

**Frontend status:** `getEventTypeMeta()` in `src/modules/moodle-sync/lib/event-type-meta.ts`
is the single place all three calendar components (`calendar-event-list.tsx`,
`calendar-event-detail.tsx`, `upcoming-events-widget.tsx`) look up an event's icon/label/
color, falling back to a generic "Event" entry for anything outside the 4 known types. This
is correct, permanent handling of an LMS-controlled enum — a frontend should never assume a
third-party system's event taxonomy is closed — and stays regardless of (a) or (b). If the
backend picks (b), add the new values to `KNOWN_EVENT_TYPE_META` in that same file for a
proper icon/label instead of the generic fallback.

---

## 5. `POST /moodle-sync/users/pull` — `skipped` has no detail, `unmatched` is missing a real name and includes a service account

Live response example:

```json
{
  "data": {
    "matched": 1,
    "skipped": 3,
    "unmatched": [
      {
        "moodleUserId": 3,
        "username": "adedapooluwatosina@gmail.com",
        "email": "adedapooluwatosina@gmail.com",
        "moodleRole": "manager"
      },
      {
        "moodleUserId": 4,
        "username": "laravel_sync_bot",
        "email": "solomon@qverselearning.com",
        "moodleRole": "manager"
      }
    ]
  }
}
```

Three separate issues in this one payload:

**a) `skipped` is a bare count with no per-record detail.** An admin sees "3 skipped" and has
no way to find out who they are or why they were skipped (already matched? invalid role?
duplicate email?).

**b) `unmatched` entries carry no real human name.** Only `username`/`email`/`moodleRole` are
returned. For the first entry, `username` is just the email again — it tells the admin
nothing beyond what `email` already says. Moodle stores `firstname`/`lastname` natively on
every user.

**c) A service/integration account (`laravel_sync_bot`) is showing up as "unmatched."** That
username strongly suggests this is the backend's own service account for authenticating
against Moodle's API — not a real person who needs a portal account. Surfacing it in
`unmatched` invites an admin to go try to create a portal user for a sync bot, which will
never be correct.

**Ask — exact contract the frontend is already built against:**

```json
{
  "data": {
    "matched": 1,
    "skipped": 3,
    "skippedUsers": [
      {
        "moodleUserId": 7,
        "username": "j.okafor",
        "email": "j.okafor@example.com",
        "moodleRole": "manager",
        "reason": "Already matched to portal user #204"
      }
    ],
    "unmatched": [
      {
        "moodleUserId": 3,
        "username": "adedapooluwatosina@gmail.com",
        "email": "adedapooluwatosina@gmail.com",
        "moodleRole": "manager",
        "firstName": "Adedapo",
        "lastName": "Oluwatosina"
      }
    ]
  }
}
```

- Add `skippedUsers: []` — same shape as `unmatched` plus a `reason` string per record. Keep
  the existing `skipped` count too (the frontend uses it as a reliable total even before/if
  `skippedUsers` is populated).
- Add `firstName`/`lastName` (camelCase, matching every other field already returned by this
  endpoint) to each `unmatched` entry, sourced from Moodle's native `firstname`/`lastname`.
- Exclude the Moodle service/integration account(s) used by the sync job itself from all
  three buckets (`matched`/`skipped`/`unmatched`) before returning the payload — they aren't
  real users and shouldn't be reported as either synced or needing to be. This one has no
  frontend-visible field to key off of, so it can only be fixed server-side.

**Frontend status:** fully built against the contract above, today:
- `PullUsersResultSchema`/`UnmatchedMoodleUserSchema`/`SkippedMoodleUserSchema` in
  `src/modules/moodle-sync/schemas/user.schema.ts` already declare `skippedUsers`,
  `firstName`, and `lastName` (as optional, since the current backend omits them).
- The Users page has both an "Unmatched" and a "Skipped" button next to "Pull from Moodle",
  each disabled when there's nothing to show and enabled with a live count otherwise.
- `unmatched-users-modal.tsx` already renders `firstName`/`lastName` as the display name
  (falling back to `username` today, since the fields aren't sent yet).
- `skipped-users-modal.tsx` already renders the `skippedUsers` table when present; until the
  backend ships it, it shows the honest count-only message ("N users were skipped, but the
  sync API doesn't return per-user detail yet") instead of a broken/empty table.

Once the backend adds `skippedUsers`/`firstName`/`lastName` and excludes the service account,
every one of the above upgrades automatically — no frontend code changes needed.
