# Moodle Sync Module — API Reference (Laravel)

Bidirectional synchronization between the portal and Moodle LMS — program
categories, courses, users, enrollments, assessments, grades, calendar
events, and Zoom meetings.

Base path: **`/api/moodle-sync`**
Auth: `Authorization: Bearer <sanctum-token>` on every route. Routes marked
**Admin** additionally require the `admin` middleware.

---

## Sync Direction & Status

| Direction | Meaning |
|---|---|
| `PUSH` | Portal → Moodle |
| `PULL` | Moodle → Portal |
| `BIDIRECTIONAL` | Kept in sync both ways |

| Status | Meaning |
|---|---|
| `PENDING` | Queued, not yet processed |
| `SYNCED` | Successfully synced |
| `FAILED` | Sync failed — see `sync_error` |
| `STALE` | Local changes not yet pushed |

---

## Category Sync (Faculty → Program → Level → Semester)

| Method | Endpoint | Description | Auth |
|---|---|---|---|
| GET | `/moodle-sync/categories` | List category mappings (`?status=`, `?entity_type=`) | Admin |
| GET | `/moodle-sync/categories/{id}` | Get one mapping | Admin |
| POST | `/moodle-sync/categories/push` | Push one entity (faculty/department/program/level/semester) as a Moodle category | Admin |
| POST | `/moodle-sync/categories/push-hierarchy/{facultyId}` | Push a faculty and its full program → level → semester tree | Admin |
| POST | `/moodle-sync/categories/pull` | Pull all categories from Moodle | Admin |
| POST | `/moodle-sync/categories/pull/{moodleCategoryId}` | Pull one Moodle category (and refresh the tree) | Admin |
| DELETE | `/moodle-sync/categories/{id}` | Remove a mapping (does **not** delete on Moodle) | Admin |

**`POST /categories/push`** — body:
```json
{
  "entityType": "faculty",
  "entityId": 12,
  "parentMoodleCategoryId": null
}
```
`entityType` is one of `faculty`, `department`, `program`, `level`, `semester`.

**Response `201`:**
```json
{
  "data": {
    "id": 1,
    "entity_type": "faculty",
    "entity_id": 12,
    "moodle_category_id": 45,
    "moodle_category_name": "SOCIAL SCIENCES",
    "parent_moodle_category_id": null,
    "sync_status": "SYNCED",
    "sync_direction": "PUSH",
    "last_sync_at": "2026-08-21T10:00:00Z"
  }
}
```

---

## User Sync

| Method | Endpoint | Description | Auth |
|---|---|---|---|
| GET | `/moodle-sync/users` | List user mappings (`?role=`, `?status=`) | Admin |
| GET | `/moodle-sync/users/{id}` | Get one mapping | Admin |
| GET | `/moodle-sync/users/user/{userId}` | Get the Moodle mapping for a portal user | Admin |
| POST | `/moodle-sync/users/push/{userId}` | Push a lecturer/staff/admin to Moodle | Admin |
| POST | `/moodle-sync/users/push-bulk` | Push multiple users (`{"userIds":[1,2,3]}`) | Admin |
| POST | `/moodle-sync/users/pull` | Pull users (student/editingteacher/teacher/manager) from Moodle | Admin |
| POST | `/moodle-sync/users/pull/{moodleUserId}` | Pull one Moodle user | Admin |

> Students are **not** pushed through this endpoint — they're synced
> automatically by `onTuitionVerified()` when tuition payment is verified
> (see [Automatic Triggers](#automatic-triggers)).

**Response `201`** (push):
```json
{
  "data": {
    "id": 1,
    "user_id": 501,
    "moodle_user_id": 88,
    "moodle_username": "jdoe",
    "moodle_role": "editingteacher",
    "sync_status": "SYNCED",
    "sync_direction": "PUSH",
    "last_sync_at": "2026-08-21T10:00:00Z"
  }
}
```

---

## Course Sync

| Method | Endpoint | Description | Auth |
|---|---|---|---|
| GET | `/moodle-sync/courses` | List course mappings (`?status=`) | Admin |
| GET | `/moodle-sync/courses/{id}` | Get one mapping | Admin |
| POST | `/moodle-sync/courses/push/{courseOfferingId}` | Push a course offering to Moodle (pushes its semester's category hierarchy first if needed) | Admin |
| POST | `/moodle-sync/courses/push-bulk` | Push multiple offerings (`{"courseOfferingIds":[1,2]}`) | Admin |
| POST | `/moodle-sync/courses/pull` | Pull all courses from Moodle | Admin |
| POST | `/moodle-sync/courses/pull/{moodleCourseId}` | Pull one Moodle course | Admin |

**Response `201`** (push):
```json
{
  "data": {
    "id": 1,
    "course_offering_id": 301,
    "moodle_course_id": 77,
    "moodle_category_id": 48,
    "moodle_short_name": "ECO101-2026-1",
    "moodle_full_name": "Introduction to Economics",
    "sync_status": "SYNCED",
    "sync_direction": "PUSH",
    "last_sync_at": "2026-08-21T10:00:00Z"
  }
}
```

---

## Enrollment Sync

| Method | Endpoint | Description | Auth |
|---|---|---|---|
| GET | `/moodle-sync/enrollments` | List enrollment sync records (`?status=`) | Admin |
| GET | `/moodle-sync/enrollments/errors` | List `FAILED` enrollment syncs | Admin |
| POST | `/moodle-sync/enrollments/push/{enrollmentId}` | Push a single `StudentEnrollment` to Moodle | Admin |
| POST | `/moodle-sync/enrollments/push-all` | Queue a background job pushing all pending enrollments | Admin |
| POST | `/moodle-sync/enrollments/pull/{moodleCourseId}` | Pull enrolled users from a Moodle course | Admin |

`push-all` returns `202 Accepted` immediately; the work runs on the queue
(`App\Jobs\PushEnrollmentsJob`).

---

## Assessment Sync (Assignments, Quizzes) — Pull only

| Method | Endpoint | Description | Auth |
|---|---|---|---|
| GET | `/moodle-sync/assessments` | List synced assessments (`?course_offering_id=`, `?type=`) | Authenticated |
| GET | `/moodle-sync/assessments/course/{courseOfferingId}` | List assessments for one course | Authenticated |
| GET | `/moodle-sync/assessments/upcoming` | Upcoming assessments for the **current** user | Student |
| POST | `/moodle-sync/assessments/pull/{moodleCourseId}` | Pull assessments for one Moodle course | Admin |
| POST | `/moodle-sync/assessments/pull-all` | Queue a pull for all synced courses | Admin |

**`GET /assessments/upcoming` response `200`:**
```json
{
  "data": [
    {
      "id": 10,
      "assessment_type": "assignment",
      "name": "Assignment 1",
      "description": "Submit as PDF",
      "due_date": "2026-09-01T23:59:00Z",
      "max_grade": 100,
      "course": {
        "moodle_short_name": "ECO101-2026-1",
        "moodle_full_name": "Introduction to Economics",
        "course_offering": {
          "course": { "code": "ECO101", "title": "Introduction to Economics" }
        }
      }
    }
  ]
}
```

---

## Grade Sync — Pull only

| Method | Endpoint | Description | Auth |
|---|---|---|---|
| GET | `/moodle-sync/grades` | List all synced grades (`?course_offering_id=`, `?user_id=`) | Admin |
| GET | `/moodle-sync/grades/student/{userId}` | All Moodle grades for a student | Admin |
| GET | `/moodle-sync/grades/course/{courseOfferingId}` | All grades for a synced course | Admin |
| GET | `/moodle-sync/grades/my` | Authenticated student's Moodle grades | Student |
| POST | `/moodle-sync/grades/pull/{moodleCourseId}` | Pull grades for one Moodle course | Admin |
| POST | `/moodle-sync/grades/pull-all` | Queue a pull for all synced courses | Admin |

**`GET /grades/my` response `200`:**
```json
{
  "data": {
    "ECO101-2026-1": [
      {
        "id": 5,
        "item_name": "Assignment 1",
        "grade": 85,
        "max_grade": 100,
        "feedback": "Good work",
        "graded_at": "2026-08-15T09:00:00Z",
        "course": {
          "moodle_short_name": "ECO101-2026-1",
          "moodle_full_name": "Introduction to Economics",
          "course_offering": {
            "course": { "code": "ECO101", "title": "Introduction to Economics" }
          }
        }
      }
    ]
  }
}
```

> **Note:** These are Moodle LMS grades (assignments, quizzes, forums), read-only.
> Your portal's own official `Grade` model (Result module) stays independent —
> students see both.

---

## Calendar & Zoom Sync — Pull only

| Method | Endpoint | Description | Auth |
|---|---|---|---|
| GET | `/moodle-sync/calendar` | List all synced calendar events | Authenticated |
| GET | `/moodle-sync/calendar/course/{courseOfferingId}` | Events for one course | Authenticated |
| GET | `/moodle-sync/calendar/upcoming` | Upcoming events/Zoom meetings for the current user | Student |
| GET | `/moodle-sync/calendar/{id}` | Event detail (includes `meeting_url` if Zoom) | Authenticated |
| POST | `/moodle-sync/calendar/pull` | Pull calendar events from Moodle | Admin |
| POST | `/moodle-sync/calendar/pull/{moodleCourseId}` | Pull events for one course | Admin |

**`GET /calendar/upcoming` response `200`:**
```json
{
  "data": [
    {
      "id": 22,
      "event_type": "zoom",
      "name": "Week 3 Live Class",
      "description": null,
      "start_date": "2026-08-25T10:00:00Z",
      "end_date": "2026-08-25T11:00:00Z",
      "meeting_url": "https://zoom.us/j/123456789",
      "course": {
        "moodle_short_name": "ECO101-2026-1",
        "course_offering": {
          "course": { "code": "ECO101", "title": "Introduction to Economics" }
        }
      }
    }
  ]
}
```

---

## Automatic Triggers

| Event | What happens |
|---|---|
| Admin creates faculty/program/level/semester on portal | Push category to Moodle |
| Admin creates a course offering under a semester | Push course to Moodle (if `MOODLE_AUTO_SYNC_ENABLED=true`) |
| **Tuition payment verified** for a student | `MoodleSyncService::onTuitionVerified($userId)` creates the Moodle user and enrolls them in every selected course |
| Scheduled jobs (below) | Pull assessments, grades, calendar events |

## Scheduled Jobs

| Command | Frequency | Description |
|---|---|---|
| `php artisan moodle:sync-assessments` | Every 30 min | Pull assignments/quizzes from all synced courses |
| `php artisan moodle:sync-grades` | Hourly | Pull grade items from all synced courses |
| `php artisan moodle:sync-calendar` | Hourly | Pull calendar events + Zoom links |
| `php artisan moodle:retry-failed` | Every 15 min | Retry `FAILED` sync records (max 3 attempts, exponential backoff: 5s/30s/2min) |

---

## Moodle REST Functions Used

| Moodle API Function | Purpose |
|---|---|
| `core_course_create_categories` | Create categories (push hierarchy) |
| `core_course_get_categories` | List categories (pull hierarchy) |
| `core_course_create_courses` | Create courses (push) |
| `core_course_get_courses` | List courses (pull) |
| `core_course_get_courses_by_field` | Find course by shortname |
| `core_user_create_users` | Create users (push) |
| `core_user_get_users` | List/search users (pull) |
| `core_user_get_users_by_field` | Find user by email |
| `core_enrol_get_enrolled_users` | List enrolled users on a course (pull) |
| `enrol_manual_enrol_users` | Enroll users in courses |
| `mod_assign_get_assignments` | List assignments for courses |
| `mod_quiz_get_quizzes_by_courses` | List quizzes for courses |
| `gradereport_user_get_grade_items` | Get grade items for a course |
| `gradereport_user_get_grades_table` | Get a student's grades |
| `core_calendar_get_calendar_events` | Get calendar events |

Make sure your Moodle web-service token (`MOODLE_API_TOKEN`) has all of
the functions above enabled under **Site administration → Server → Web
services → External services**.

---

## Error Handling

Every push/pull records its outcome on the corresponding sync row:

```
sync_status = FAILED
sync_error  = "<exception message from Moodle or the HTTP layer>"
```

- Inspect failures: `GET /moodle-sync/enrollments/errors` (enrollment-specific)
  or filter any list endpoint with `?status=FAILED`.
- Fix the root cause (e.g. update `MOODLE_API_TOKEN`, fix a mapping) then either:
  - retry the specific record via its `push/{id}` endpoint, or
  - wait for `php artisan moodle:retry-failed` (runs every 15 min).
- Bulk (`push-all`, `pull-all`) operations run through Laravel's queue with
  3 retries and exponential backoff (5s → 30s → 2min) before landing in the
  failed_jobs table.

---

## Config Reference (`.env`)

```
MOODLE_BASE_URL=https://moodle.university.edu
MOODLE_API_TOKEN=abc123...
MOODLE_DEFAULT_CATEGORY_ID=1
MOODLE_STUDENT_ROLE_ID=5
MOODLE_TEACHER_ROLE_ID=3
MOODLE_MANAGER_ROLE_ID=1
MOODLE_AUTO_SYNC_ENABLED=true
MOODLE_SYNC_CRON_INTERVAL=60
```
