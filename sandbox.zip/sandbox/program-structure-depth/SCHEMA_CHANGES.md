# Schema Changes — Program Structure Depth

Diff against the current schema. Everything not listed is unchanged. Same disclaimer as
`sandbox/multi-program-platform/SCHEMA_CHANGES.md`: model/column names are taken from the audited
frontend types (`src/types/school.d.ts`, `src/types/users.d.ts`) and bruno contracts
(`bruno/academic/`), not read directly from the Prisma/backend source — rename to match your real
model names, the columns/relations and their nullability are what matter.

---

## 1. Modified model — `Course`

```diff
 model Course {
   id                    Int       @id @default(autoincrement())
   code                  String
   title                 String
   description           String?
   credit_units          Int
   course_type           CourseType
-  level_id              Int
+  level_id              Int?      // null for FOUNDATIONAL / CERTIFICATE program courses
   owning_department_id  Int?
   syllabus              String?
   curriculum_semester   Int?
   is_active             Boolean
   created_at            DateTime  @default(now())
   updated_at            DateTime  @updatedAt

-  level                 Level     @relation(fields: [level_id], references: [id])
+  level                 Level?    @relation(fields: [level_id], references: [id])
 }
```

Additive-safe: every existing Course row already has a `level_id`, so nothing existing changes
value. Only newly-created Foundational/Certificate course rows will have `level_id = null`.
`curriculum_semester` was already nullable — Foundational's 6/6 split just populates it as `1`/`2`
per course, same as Degree does today.

---

## 2. Modified model — `Student`

```diff
 model Student {
   id                Int       @id @default(autoincrement())
   user_id           Int
   matric_number     String
   program_id        Int
-  current_level_id  Int
+  current_level_id  Int?      // null for FOUNDATIONAL / CERTIFICATE students
+  current_cohort_id Int?      // populated only for CERTIFICATE students; see §3
   entry_mode        EntryMode
   mode_of_study     ModeOfStudy
   admission_date    DateTime
   graduation_date   DateTime?
   status            StudentStatus
   current_cgpa      Decimal?

-  level             Level     @relation(fields: [current_level_id], references: [id])
+  level             Level?    @relation(fields: [current_level_id], references: [id])
+  cohort            Cohort?   @relation(fields: [current_cohort_id], references: [id])
 }
```

**Validation (API layer, not DB constraint):** exactly one of `current_level_id` /
`current_cohort_id` is set, or both are null for Foundational (which has neither), determined by
the student's `program.programCategory` per the table in `README.md` §4.A. A `CHECK` constraint
enforcing this is possible but not required — the resolution already has to happen in application
code to pick the right one at admission-offer-acceptance time, so a DB-level check is belt-and-
braces, not load-bearing.

---

## 3. New model — `Cohort`

Certificate programs' replacement for Session/Semester/Level. Scoped to one `Program`, no
dependency on `AcademicSession`.

```prisma
model Cohort {
  id               Int          @id @default(autoincrement())

  programId        Int
  program          Program      @relation(fields: [programId], references: [id])

  code             String       // e.g. "ICAN-ATS-MAY-2026" — unique per program
  name             String       // e.g. "ICAN ATS — May 2026 Sitting"

  startDate        DateTime
  endDate          DateTime
  examWindowStart  DateTime?
  examWindowEnd    DateTime?
  capacity         Int?

  status           CohortStatus @default(OPEN)

  createdAt        DateTime     @default(now())
  updatedAt        DateTime     @updatedAt

  students         Student[]

  @@unique([programId, code])
}

enum CohortStatus {
  OPEN          // accepting enrollments
  IN_PROGRESS   // running, enrollment closed
  EXAM_WINDOW   // certification exam period open
  CLOSED        // sitting concluded
  CERTIFIED     // results/certificates issued
  CANCELLED
}
```

New model, no migration risk to existing data. Multiple `Cohort` rows for the same or different
Certificate `Program`s can be `OPEN`/`IN_PROGRESS` simultaneously — there is no "one active cohort"
constraint, unlike `AcademicSession`/`Semester`'s partial unique index. That's the entire point:
Certificate's real-world seasonality (concurrent, independently-timed sittings) doesn't fit the
Degree calendar model, so it gets its own.

---

## 4. Modified model — `AdmissionOffer`

Backs `POST /admissions/offers` and `POST /admissions/offers/bulk` (`bruno/academic/`,
`src/schemas/school.schema.ts:109-136`).

```diff
 model AdmissionOffer {
   id               Int      @id @default(autoincrement())
   admissionNumber  String
   programId        Int
-  levelId          Int
-  sessionId        Int
+  levelId          Int?
+  sessionId        Int?
+  cohortId         Int?
   ...

-  level            Level           @relation(fields: [levelId], references: [id])
-  session          AcademicSession @relation(fields: [sessionId], references: [id])
+  level            Level?          @relation(fields: [levelId], references: [id])
+  session          AcademicSession? @relation(fields: [sessionId], references: [id])
+  cohort           Cohort?         @relation(fields: [cohortId], references: [id])
 }
```

**API-layer validation**, resolved from `Program.programCategory` at offer-creation time — see
`API_CONTRACTS.md` §1 for the exact rule table and error shape. Every existing Degree/Postgraduate/
Diploma/Secondary-School offer already has both `levelId` and `sessionId` populated and is
unaffected.

---

## 5. Modified model — `Program` (optional, can ship separately)

```diff
 model Program {
   id                     Int             @id @default(autoincrement())
   departmentId           Int?
   name                   String
   code                   String
   degreeType             String
   durationYears          Int
   description            String?
   admissionRequirements  String?
   minCreditUnits         Int
   isActive               Boolean
   programCategory        ProgramCategory @default(DEGREE)
   parentAcademicUnitId   Int?
   gradingSchemeId        Int?
+  entryLevelId           Int?            // lowest Level a fresh admission offer can target; null = no restriction

+  entryLevel             Level?          @relation(fields: [entryLevelId], references: [id])
 }
```

Additive, nullable, defaults to today's unrestricted behavior. Only meaningful for
`DEGREE`/`PART_TIME`/`POSTGRADUATE`/`DIPLOMA`/`SECONDARY_SCHOOL` programs — ignored for
`FOUNDATIONAL`/`CERTIFICATE` since they don't use `levelId` at all. See `README.md` §4.D.

---

## 6. Modified model — `MoodleSyncCohort` (from `sandbox/multi-program-platform/`, corrected here)

That doc's version has `academicSessionId Int` as required, which doesn't hold for Certificate.
Once this doc's `Cohort` model exists, that model's contract should be:

```diff
 model MoodleSyncCohort {
   id                Int       @id @default(autoincrement())
   programId         Int
   program           Program   @relation(fields: [programId], references: [id])
-  academicSessionId Int
-  academicSession   AcademicSession @relation(fields: [academicSessionId], references: [id])
+  academicSessionId Int?
+  academicSession   AcademicSession? @relation(fields: [academicSessionId], references: [id])
   levelId           Int?
   level             Level?    @relation(fields: [levelId], references: [id])
+  cohortId          Int?
+  cohort            Cohort?   @relation(fields: [cohortId], references: [id])

   moodleCohortId    Int?
-  idnumber          String    @unique   // "program:{programId}:session:{academicSessionId}[:level:{levelId}]"
+  idnumber          String    @unique   // "program:{programId}:session:{academicSessionId}[:level:{levelId}]"
+                                          // OR "program:{programId}:cohort:{cohortId}" for Certificate
   name              String
   syncStatus        MoodleSyncStatus
   syncError         String?
   lastSyncAt        DateTime?
   createdAt         DateTime  @default(now())
   updatedAt         DateTime  @updatedAt

-  @@unique([programId, academicSessionId, levelId])
+  @@unique([programId, academicSessionId, levelId, cohortId])
 }
```

Only relevant if/when `sandbox/multi-program-platform/`'s Moodle-cohort-sync work (§C there) is
built for Certificate programs specifically. If that ships Degree/Part-Time/Foundational-only
first, this change can wait — flagging it now so it isn't missed later.

---

## 7. Summary

| Model | Change | Breaking? |
|---|---|---|
| `Course.level_id` | nullable | No |
| `Student.current_level_id` | nullable | No |
| `Student.current_cohort_id` | new, nullable | No |
| `Cohort` (+ `CohortStatus`) | new model | New |
| `AdmissionOffer.levelId` / `.sessionId` | nullable | No for existing data; API validation replaces the `NOT NULL` guarantee |
| `AdmissionOffer.cohortId` | new, nullable | No |
| `Program.entryLevelId` | new, nullable | No |
| `MoodleSyncCohort.academicSessionId` | nullable + `.cohortId` added | Only relevant once Certificate Moodle-cohort-sync is built |

Nothing existing is removed or renamed. Every existing Degree/Postgraduate/Diploma/Secondary-School
row keeps its current `levelId`/`sessionId` values and keeps working through the exact same
required-field validation it does today — the requirement just moves from the DB column to an
API-layer check keyed off `programCategory`.
