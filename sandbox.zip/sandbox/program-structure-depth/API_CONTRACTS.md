# API Contracts — Program Structure Depth

Full request/response contracts for the changes in `SCHEMA_CHANGES.md`. Existing
endpoints not listed here (Faculty/Department CRUD, Level CRUD, Session/Semester CRUD, Course CRUD
outside the field below, Program CRUD outside the field below) are unchanged.

---

## 1. `POST /admissions/offers` and `POST /admissions/offers/bulk` — category-conditional validation

### Request body (both endpoints, `bulk` wraps an array of these)

```jsonc
{
  "admissionNumber": "RUN/2026/00123",
  "programId": 55,
  "sessionId": 3,      // required for DEGREE/PART_TIME/POSTGRADUATE/DIPLOMA/SECONDARY_SCHOOL/FOUNDATIONAL; must be omitted/null for CERTIFICATE
  "levelId": 1,         // required for DEGREE/PART_TIME/POSTGRADUATE/DIPLOMA/SECONDARY_SCHOOL; must be omitted/null for FOUNDATIONAL/CERTIFICATE
  "cohortId": null       // required for CERTIFICATE; must be omitted/null otherwise
}
```

### Validation rule (resolved server-side from `Program.programCategory` for the given `programId`)

| `programCategory` | `sessionId` | `levelId` | `cohortId` |
|---|---|---|---|
| `DEGREE`, `PART_TIME`, `POSTGRADUATE`, `DIPLOMA`, `SECONDARY_SCHOOL` | required | required (and `>= Program.entryLevelId` if set — see `SCHEMA_CHANGES.md` §5) | must be null |
| `FOUNDATIONAL` | required | must be null | must be null |
| `CERTIFICATE` | must be null | must be null | required, and `Cohort.programId` must equal `programId`, and `Cohort.status` must be `OPEN` |

### Error response — wrong field for the category (422)

```json
{
  "statusCode": 422,
  "error": "INVALID_PROGRAM_STRUCTURE_FIELDS",
  "message": "Program 90 (CERTIFICATE) does not use levelId/sessionId — provide cohortId instead.",
  "details": {
    "programCategory": "CERTIFICATE",
    "rejectedFields": ["levelId", "sessionId"],
    "requiredFields": ["cohortId"]
  }
}
```

### Error response — cohort not open (422)

```json
{
  "statusCode": 422,
  "error": "COHORT_NOT_OPEN",
  "message": "Cohort 14 (ICAN-ATS-MAY-2026) is IN_PROGRESS and no longer accepting new offers.",
  "details": { "cohortId": 14, "status": "IN_PROGRESS" }
}
```

**Frontend note:** `src/schemas/school.schema.ts`'s `createAdmissionOfferSchema` /
`bulkCreateAdmissionOffersSchema` should mirror this table client-side once the program's category
is known (e.g. via a `.superRefine` keyed off a `programCategory` field looked up from the selected
`programId`), so the form only shows the relevant picker (Session+Level, or Cohort) instead of all
three — same UX pattern as the existing dynamic admission-form-field work in
`sandbox/multi-program-platform/`.

---

## 2. `Cohort` CRUD — new endpoints

Same conventions as the existing `bruno/academic/` Faculty/Department/Program endpoints (bearer
auth, standard pagination on list).

### `POST /academic/cohorts`

```jsonc
// Request
{
  "programId": 90,
  "code": "ICAN-ATS-MAY-2026",
  "name": "ICAN ATS — May 2026 Sitting",
  "startDate": "2026-02-01",
  "endDate": "2026-05-31",
  "examWindowStart": "2026-05-18",
  "examWindowEnd": "2026-05-22",
  "capacity": 150
}
```

```jsonc
// Response 201
{
  "id": 14,
  "programId": 90,
  "code": "ICAN-ATS-MAY-2026",
  "name": "ICAN ATS — May 2026 Sitting",
  "startDate": "2026-02-01",
  "endDate": "2026-05-31",
  "examWindowStart": "2026-05-18",
  "examWindowEnd": "2026-05-22",
  "capacity": 150,
  "status": "OPEN",
  "createdAt": "2026-01-10T09:00:00Z",
  "updatedAt": "2026-01-10T09:00:00Z"
}
```

**Validation:** `programId` must reference a `Program` with `programCategory = CERTIFICATE` — 422
`INVALID_PROGRAM_CATEGORY` otherwise. `code` unique per `programId`.

### `GET /academic/cohorts?programId=90&status=OPEN`

```jsonc
// Response 200
{
  "data": [ /* array of the Cohort shape above, + "enrolledCount": number */ ],
  "meta": { "page": 1, "perPage": 20, "total": 3 }
}
```

### `PATCH /academic/cohorts/{id}`

Same body shape as create, all fields optional. Separate, explicit status-transition endpoint
recommended over letting `PATCH` silently change `status`, to keep the exam-window lifecycle
auditable:

### `POST /academic/cohorts/{id}/transition`

```jsonc
// Request
{ "status": "EXAM_WINDOW", "reason": "Registration closed, exam period begins" }

// Response 200 — the updated Cohort, plus an audit row (same pattern as
// AdmissionCycle status transitions, if that already logs an audit trail)
```

**Valid transitions:** `OPEN → IN_PROGRESS → EXAM_WINDOW → CLOSED → CERTIFIED`, plus
`OPEN|IN_PROGRESS → CANCELLED` from either. Reject out-of-order transitions with 422
`INVALID_COHORT_TRANSITION`.

### `DELETE /academic/cohorts/{id}`

Only permitted while `status = OPEN` and `enrolledCount = 0` (mirrors the existing
Level-has-no-delete-once-referenced convention noted in `src/services/courseStructureApi.ts`) —
409 `COHORT_HAS_ENROLLMENTS` otherwise.

---

## 3. `Course` — `level_id` now optional in create/update payloads

### `POST /courses` / `PATCH /courses/{id}`

```jsonc
{
  "code": "GST101",
  "title": "Use of English",
  "creditUnits": 2,
  "courseType": "GENERAL",
  "levelId": null,          // now optional — omit or null for a course that will only ever
                             // be attached to a FOUNDATIONAL or CERTIFICATE program
  "owningDepartmentId": 4,
  "curriculumSemester": 1
}
```

No new validation beyond "if the course is being assigned to a Program via `ProgramCourse` whose
`programCategory` requires a level (Degree/Part-Time/Postgraduate/Diploma/Secondary-School), that
assignment call requires `levelId` to be non-null on the course being attached" — enforced at the
`ProgramCourse` assignment endpoint (existing endpoint, no shape change, just an added check),
not at bare `Course` creation time (a course can exist with `levelId = null` and get attached to a
Foundational program; the same course could theoretically also be reused for another Foundational
program without ever needing a level).

---

## 4. `Student` — `current_level_id` optional, `current_cohort_id` added

### `GET /students/{id}` (relevant fields only)

```jsonc
{
  "id": 4021,
  "matricNumber": "RUN/CERT/2026/0091",
  "programId": 90,
  "currentLevelId": null,
  "currentCohortId": 14,
  "modeOfStudy": "FULL_TIME",
  "entryMode": "DIRECT_ENTRY"
}
```

Populated exactly one of `currentLevelId` / `currentCohortId`, per the program's category (or
neither, for `FOUNDATIONAL`, which tracks progress via `sessionId`/`semesterId` on the enrollment
records instead — no per-student "level" concept to store). Resolution happens once, at
admission-offer-acceptance time, mirroring whichever of `levelId`/`cohortId` the accepted
`AdmissionOffer` carried.

---

## 5. Summary of frontend call sites that need updating once this ships

(For the frontend implementation plan, not the backend team — listed here for completeness.)

- `src/schemas/school.schema.ts` — `createAdmissionOfferSchema`,
  `bulkCreateAdmissionOffersSchema`: relax `levelId`/`sessionId` to optional, add `cohortId`,
  add category-conditional `.superRefine`.
- `src/types/school.d.ts` — `Course.level_id: number` → `number | null`.
- `src/types/users.d.ts` — `Student.current_level_id: number` → `number | null`; add
  `current_cohort_id: number | null`.
- New module surface: a `Cohort` CRUD screen, most naturally living in
  `src/modules/academics/_components/course-structure/` alongside the existing
  Faculty/Department/Program/Level panels, gated to show only for `programCategory = CERTIFICATE`
  programs.
- `src/services/courseStructureApi.ts` — new `cohortsApi` (`list`, `create`, `update`, `transition`,
  `delete`), same shape as the existing `programsApi`/`levelsApi`.
