# Program Structure Depth — Foundational & Certificate Programs

**Status:** proposed design, 2026-09-12. Answers a direct question raised while auditing the
academic structure against Redeemer's University's real program lineup. This folder is a
handoff package for the backend team, same format as `sandbox/multi-program-platform/`.

---

## 0. The question that triggered this

RUN runs three genuinely different program shapes:

| Program type | Real structure |
|---|---|
| Full-time & Part-time degree | Faculty → Department → Program → **Level** (100–500, or 200–500 for Part-Time direct entry) → Semester → Courses |
| Foundational / JUPEB | Session → Semester → Courses — **no Level layer** (one intensive year, 12 courses: 6 per semester + a General Studies course) |
| Certificate (CIPM, CIB, ATS/ICAN, partner awards) | Cohort/Batch → Modules/Courses → Certification exam window — **no Session, Semester, or Level at all**; seasonal, cohort-based, multiple sittings can run concurrently |

The question was: do we need a new "major program" key (mapping to Certificate / Postgraduate /
Degree / Business School / Part-Time) with actual programs (B.Sc. Computer Science, B.Sc.
Software Engineering) nested under it as "sub programs" — or does the system already support
this, or is there a better structure?

## 1. Short answer

**No new key is needed for the classification itself** — that part is already built and correct.
**What's actually missing is that Level (and, for Certificate, Session/Semester too) are hardcoded
as mandatory everywhere, with no way for a program to opt out of a layer it doesn't have.** That's
the real gap, and it's a schema/validation change, not a taxonomy change.

## 2. What already works — the "major/sub program" split you asked for already exists

`Program.programCategory` (enum: `DEGREE | POSTGRADUATE | CERTIFICATE | DIPLOMA |
SECONDARY_SCHOOL | FOUNDATIONAL | PART_TIME` — `src/types/school.d.ts:103-110`) **is** the major
program grouping. `Program.name` (e.g. "B.Sc. Sociology", "B.Sc. Computer Science") **is** the sub
program, already correctly nested under `Department` → `Faculty`. This was added recently by the
`sandbox/multi-program-platform/` work specifically to cover Degree/Foundational/Part-Time as
first-class categories.

Introducing a second, separate "majorProgram" entity on top of this would create two sources of
truth for the same classification (which category does this program belong to?) for no benefit —
rejected. Keep `programCategory` as the single switch; everything below should branch on it.

## 3. What's actually broken — structural depth is hardcoded, not conditional

Audited directly against the live types/schemas/bruno contracts (`src/types/school.d.ts`,
`src/types/users.d.ts`, `src/schemas/school.schema.ts`, `bruno/academic/`):

- **`Course.level_id`** — required, non-nullable (`src/types/school.d.ts:274-292`).
- **`Student.current_level_id`** — required, non-nullable (`src/types/users.d.ts:53`).
- **`createAdmissionOfferSchema.levelId`** and **`.sessionId`** — both required, unconditionally,
  for every program category (`src/schemas/school.schema.ts:109-136`).
- **`AcademicSession`/`Semester` are institution-wide singletons** — the real backend enforces
  "only one active session, one active semester, at a time" via a **partial unique DB index**
  (`sandbox/academic/academic_README.md`). That's fine for Degree/Part-Time/Foundational, which
  can all share one active session. It is a hard structural conflict with Certificate, where
  multiple cohorts (e.g. an ICAN May sitting and a CIB November sitting) need independent,
  overlapping start/end windows that don't fit inside "the one active session."

**Correction to an existing doc:** `sandbox/multi-program-platform/README.md` §3 claims
*"Program-specific structure depth ✅ Have — the generic `AcademicUnit` tree — a program can skip
layers it doesn't need."* This is only true for the **Moodle-category mirror tree**. Per
`sandbox/schema-moodel-sync-refactor/README.md` line 94, verbatim: *"CGPA calculation, invoicing,
enrollment... never touch `AcademicUnit` at all."* The operational data (Student, Course,
Enrollment, Grades, AdmissionOffer) still goes through the rigid Level/Session/Semester FKs
listed above, completely independent of whatever the cosmetic `AcademicUnit` tree looks like. Every
worked example in that doc (Degree, Postgraduate, even Secondary School) still keeps a Level under
Program — none of them actually test the "no Level" case. This doc closes that gap for real.

Also worth flagging: `sandbox/multi-program-platform/SCHEMA_CHANGES.md` §5's `MoodleSyncCohort`
model has `academicSessionId Int` as a **required** field, with the comment "a Certificate program
with no Level concept just omits it and gets one cohort per session" — that still assumes an
`AcademicSession` exists for Certificate, which contradicts the real requirement (no session
concept at all, independent overlapping sittings). Once the `Cohort` entity below ships, that
model's `academicSessionId` should become nullable and gain an optional `cohortId`, mutually
exclusive with `academicSessionId`+`levelId`.

## 4. The design

### A. Make Level conditional on `programCategory`, not remove it

`Level` stays exactly as-is (one flat, shared, immutable, university-wide list) — that part of the
model is fine for the categories that use it. What changes is that **nothing requires it
unconditionally anymore**:

- `Course.level_id` → nullable.
- `Student.current_level_id` → nullable.
- `AdmissionOffer.levelId` / `AdmissionOffer.sessionId` → nullable.

Validation moves from "the column is `NOT NULL`" to "the API checks it against the target
program's `programCategory`":

| `programCategory` | `sessionId` | `levelId` | `cohortId` |
|---|---|---|---|
| `DEGREE`, `PART_TIME`, `POSTGRADUATE`, `DIPLOMA`, `SECONDARY_SCHOOL` | required | required | must be null |
| `FOUNDATIONAL` | required | **must be null** | must be null |
| `CERTIFICATE` | must be null | must be null | required |

This is the same "governing rule" the multi-program-platform doc already established for its own
scoping fields (§2 there): a Degree program's admission offer, student record, and course rows
exercise the exact same shape they do today — this is purely additive, nothing about the Degree
path changes.

### B. New entity: `Cohort` — Certificate's replacement for Session/Semester/Level

Certificate programs don't progress through levels or share the institution's session calendar —
they run as intake batches timed around professional-body exam sittings (ICAN ~May/November,
etc.), and more than one can be in flight at once, for the same or different Certificate programs.
Trying to force this into `AcademicSession` (a global singleton) doesn't work. Give it its own
entity instead:

- `Cohort` — `programId`, `code`, `name`, `startDate`, `endDate`, `examWindowStart`,
  `examWindowEnd`, `capacity`, `status`. Scoped to one `Program`, no dependency on
  `AcademicSession`/`Semester`/`Level` at all. Full shape in `SCHEMA_CHANGES.md` §2.
- A Certificate student's `current_cohort_id` replaces `current_level_id` for that program
  category; their courses/modules are the same `ProgramCourse` list every other program uses
  (already flexible enough — see §5 below), just with `level_id = null` on each `Course` row.
- This also fixes the `MoodleSyncCohort` inconsistency noted in §3 — once `Cohort` exists as a
  real entity, `MoodleSyncCohort` can key off `cohortId` for Certificate instead of forcing an
  `academicSessionId`.

### C. Foundational needs no new entity

Per the spec, Foundational **does** use Session → Semester (one session, two semesters, 12 courses
split 6/6 plus a General Studies course) — it only skips the Level layer. Once (A) ships, this is
just: create the `AcademicSession`/`Semester` rows as normal, create the `Program` with
`programCategory = FOUNDATIONAL`, assign its 13 courses via the existing `ProgramCourse`
mechanism with `level_id = null` and `curriculum_semester` set to `1` or `2`. No schema changes
needed beyond (A).

### D. Secondary, smaller gap worth fixing alongside this: Part-Time's entry level range

Levels are one flat, shared, immutable list (`LevelsPanel.tsx`: *"University-wide levels shared
across all departments and programs... once created, a level can't be edited or removed"*) with no
concept of "which level does a fresh admission into this program start at." A Part-Time program
should only ever offer 200–500 as admission-offer levels (direct entry above 100), but nothing
today enforces that — an admin could accidentally create a Part-Time admission offer at 100 Level.

Proposed: add `Program.entryLevelId` (nullable FK to `CurriculumLevel`) — the lowest level a fresh
admission into this program can be offered. Null means "no restriction" (today's behavior,
Full-Time Degree default). `createAdmissionOfferSchema`'s conditional validation in §A's table
extends to: for `DEGREE`/`PART_TIME`/etc., if `program.entryLevelId` is set, `levelId >=
entryLevelId`. This is optional polish, not a blocker for the main design — can ship in the same
migration or later.

## 5. What this doesn't change

- `ProgramCategory` enum — already correct (`FOUNDATIONAL`, `PART_TIME`, `CERTIFICATE` all already
  present from the multi-program-platform work). No change needed.
- Faculty → Department → Program nesting — unchanged, already correct for all categories
  (Certificate programs still belong to a Department/Faculty for org-chart/reporting purposes,
  same as today).
- `ProgramCourse` (Program ↔ Course assignment) — unchanged, already flexible enough; Certificate
  and Foundational just populate it with `level_id = null` rows.
- Full-time and Part-time degree behavior — zero change; every field that becomes nullable stays
  required (enforced at the API layer) for these categories, so existing rows and existing
  workflows are unaffected.
- The Moodle-category `AcademicUnit` tree — unrelated concern, no change required by this doc.

## 6. Rollout order

1. **A (nullable Level/Session fields + category-conditional validation)** — unblocks Foundational
   entirely on its own; no dependency on B.
2. **B (`Cohort` entity)** — unblocks Certificate; depends on A's nullable `sessionId`/`levelId`
   shape existing on `AdmissionOffer`/`Student` so `cohortId` can slot in as the third,
   mutually-exclusive option.
3. **D (`Program.entryLevelId`)** — independent, can ship any time, including standalone.

## 7. Files in this folder

- `SCHEMA_CHANGES.md` — concrete diffs: nullable columns, new `Cohort` model, `CohortStatus` enum,
  `Program.entryLevelId`.
- `API_CONTRACTS.md` — updated `AdmissionOffer`/`Student`/`Course` contracts showing the
  category-conditional validation, plus new `Cohort` CRUD endpoints.
