# Notification Module — Implementation Workflow

This document explains the internal implementation flow for the Notification module. It is intended for developers building or maintaining this module.

---

## Module Dependencies

```
NotificationModule
├── PrismaService          (database access)
├── ConfigService          (email/SMS provider config from Settings)
├── BullModule / Queue     (async delivery via Redis)
├── MailService            (email delivery — Nodemailer/SendGrid/etc.)
└── SmsService             (SMS delivery — Twilio/Africa's Talking/etc.)
```

> **Important:** The Notification module is consumed by nearly ALL other modules. It does NOT depend on any business module.

---

## Notification Channels

| Channel | Storage | Delivery |
| ------- | ------- | -------- |
| `IN_APP` | Stored in `notifications` table | Read via API |
| `EMAIL` | Stored + sent via email provider | Async via queue |
| `SMS` | Stored + sent via SMS provider | Async via queue |
| `PUSH` | Stored + sent via push service | Async via queue |

---

## 1. Send Notification Flow

**Endpoint:** `POST /notifications` (or called internally by other services)

```
Service or Admin triggers notification
         │
         ▼
┌──────────────────────────────────────────────────┐
│  NotificationService.send(dto)                   │
│                                                  │
│  Step 1: Resolve template (if templateId given)  │
│  ┌────────────────────────────────────────────┐  │
│  │ Find NotificationTemplate by ID            │  │
│  │ Replace {{variables}} in subject & body:   │  │
│  │   "Dear {{firstName}}" → "Dear John"      │  │
│  │ If dto.subject/body provided → override    │  │
│  └────────────────────────────────────────────┘  │
│                                                  │
│  Step 2: Create Notification record              │
│  ┌────────────────────────────────────────────┐  │
│  │ - userId, subject, body, channel           │  │
│  │ - status: PENDING                          │  │
│  │ - sentAt: null                             │  │
│  └────────────────────────────────────────────┘  │
│                                                  │
│  Step 3: Dispatch to delivery queue              │
│  ┌────────────────────────────────────────────┐  │
│  │ If channel == IN_APP:                      │  │
│  │   → No queue needed, already stored        │  │
│  │   → Update status = SENT, sentAt = now     │  │
│  │                                            │  │
│  │ If channel == EMAIL:                       │  │
│  │   → Add to email queue (Bull)              │  │
│  │   → Queue worker sends via MailService     │  │
│  │                                            │  │
│  │ If channel == SMS:                         │  │
│  │   → Add to SMS queue (Bull)               │  │
│  │   → Queue worker sends via SmsService     │  │
│  │                                            │  │
│  │ If channel == PUSH:                        │  │
│  │   → Add to push queue (Bull)              │  │
│  │   → Queue worker sends via PushService    │  │
│  └────────────────────────────────────────────┘  │
│                                                  │
│  Return notification record                      │
└──────────────────────────────────────────────────┘
```

---

## 2. Queue Worker Processing

```
Queue receives notification job
         │
         ▼
┌──────────────────────────────────────────────────┐
│  NotificationProcessor.process(job)              │
│                                                  │
│  1. Load notification from DB                    │
│  2. Load user's contact info:                    │
│     - EMAIL → user.email                         │
│     - SMS → user.phoneNumber                     │
│     - PUSH → user's push token (if stored)       │
│                                                  │
│  3. Attempt delivery:                            │
│     ┌────────────────────────────────────────┐   │
│     │ EMAIL:                                 │   │
│     │   await mailService.send({             │   │
│     │     to: user.email,                    │   │
│     │     subject: notification.subject,     │   │
│     │     html: notification.body,           │   │
│     │   });                                  │   │
│     │                                        │   │
│     │ SMS:                                   │   │
│     │   await smsService.send({              │   │
│     │     to: user.phoneNumber,              │   │
│     │     message: notification.body,        │   │
│     │   });                                  │   │
│     └────────────────────────────────────────┘   │
│                                                  │
│  4. On success:                                  │
│     - Update status = SENT, sentAt = now         │
│                                                  │
│  5. On failure:                                  │
│     - Update status = FAILED                     │
│     - Log error                                  │
│     - Queue may retry (configurable: 3 retries)  │
└──────────────────────────────────────────────────┘
```

---

## 3. Template Variable Resolution

```ts
// Template: "Dear {{firstName}}, your {{documentType}} has been {{status}}."
// Variables: { firstName: "John", documentType: "transcript", status: "verified" }
// Result: "Dear John, your transcript has been verified."

resolveTemplate(template: string, variables: Record<string, string>): string {
  return template.replace(/\{\{(\w+)\}\}/g, (_, key) => variables[key] ?? '');
}
```

### Standard Variables Available

| Variable | Source |
| -------- | ------ |
| `{{firstName}}` | User.firstName |
| `{{lastName}}` | User.lastName |
| `{{email}}` | User.email |
| `{{matricNumber}}` | Student.matricNumber |
| `{{applicationNumber}}` | AdmissionApplication.applicationNumber |
| `{{invoiceNumber}}` | Invoice.invoiceNumber |

---

## 4. Reading Notifications (User)

**Endpoint:** `GET /notifications`

```
User fetches their notifications
         │
         ▼
┌──────────────────────────────────────────────────┐
│  NotificationService.findForUser(userId, filters)│
│  1. Query where userId = JWT userId              │
│     (NEVER return other users' notifications)    │
│  2. Filter by status, channel if provided        │
│  3. Paginate                                     │
│  4. Return with unreadCount in meta              │
└──────────────────────────────────────────────────┘
```

### Mark as Read

```
PATCH /notifications/:id/read
  → status = READ, readAt = now

PATCH /notifications/read-all
  → UPDATE notifications SET status = 'READ', readAt = now
    WHERE userId = :userId AND status IN ('SENT', 'PENDING')
```

---

## 5. Bulk Notification

**Endpoint:** `POST /notifications/bulk`

```
Admin sends notification to multiple users
         │
         ▼
┌──────────────────────────────────────────────────┐
│  NotificationService.sendBulk(dto)               │
│  1. For each userId in dto.userIds:              │
│     - Create Notification record                 │
│     - Queue for delivery                         │
│  2. Use createMany for DB efficiency             │
│  3. Add batch of jobs to queue                   │
│  4. Return { sent: count, errors: [...] }        │
└──────────────────────────────────────────────────┘
```

---

## 6. Internal Service API (for other modules)

Other modules don't call the REST endpoint — they inject `NotificationService`:

```ts
// In any service
@Injectable()
export class AdmissionService {
  constructor(private notification: NotificationService) {}

  async reviewApplication(id, dto) {
    // ... business logic ...

    // Send notification
    await this.notification.send({
      userId: application.userId,
      templateId: 'application_reviewed',  // or find by name
      channel: 'EMAIL',
      variables: {
        firstName: user.firstName,
        applicationNumber: application.applicationNumber,
        status: dto.status,
      },
    });
  }
}
```

---

## 7. Files to Create

```
src/modules/notification/
├── notification.module.ts
├── notification.controller.ts     # REST endpoints
├── notification.service.ts        # Business logic + send/sendBulk
├── notification.processor.ts      # Bull queue processor
├── dto/
│   ├── create-template.dto.ts
│   ├── send-notification.dto.ts
│   ├── bulk-notification.dto.ts
│   └── query-notification.dto.ts
├── providers/
│   ├── mail.service.ts            # Email delivery (Nodemailer/SendGrid)
│   └── sms.service.ts             # SMS delivery
└── notification.service.spec.ts
```

---

## 8. Cross-Module Integration Points

| Consumer Module | Events that trigger notifications |
| --------------- | --------------------------------- |
| **Auth** | Password reset email |
| **Admission** | Application received, status updated, admission offer |
| **Payment** | Invoice created, payment confirmed |
| **Result** | Grades published |
| **Clearance** | Clearance approved/rejected |
| **Document** | Document verified/rejected |
| **Hostel** | Room allocated |
