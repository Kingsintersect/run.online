# Notification Module

Manages notification templates and delivery of notifications to users across multiple channels (email, SMS, in-app, push).

## Models Owned

- **NotificationTemplate** — reusable notification templates with subject/body per channel
- **Notification** — individual notification records sent to users

---

## Endpoints

### Templates

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/notifications/templates` | List all notification templates | Admin |
| `GET` | `/notifications/templates/:id` | Get a template | Admin |
| `POST` | `/notifications/templates` | Create a notification template | Admin |
| `PATCH` | `/notifications/templates/:id` | Update a template | Admin |
| `DELETE` | `/notifications/templates/:id` | Deactivate a template | Admin |

### Notifications

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/notifications` | List notifications for the current user | Authenticated |
| `GET` | `/notifications/:id` | Get a notification | Authenticated (own) |
| `GET` | `/notifications/unread-count` | Get count of unread notifications | Authenticated |
| `POST` | `/notifications` | Send a notification to a user | Admin, System |
| `POST` | `/notifications/bulk` | Send notifications to multiple users | Admin, System |
| `PATCH` | `/notifications/:id/read` | Mark a notification as read | Authenticated (own) |
| `PATCH` | `/notifications/read-all` | Mark all notifications as read | Authenticated |

---

## Request & Response Types

### `POST /notifications/templates`

**Request Body (`CreateTemplateDto`):**

```ts
{
  name: string;              // unique, max 50 chars (e.g. "welcome_email")
  subject: string;           // max 200 chars, supports {{variables}}
  body: string;              // text, supports {{variables}}
  channel: "EMAIL" | "SMS" | "IN_APP" | "PUSH";
}
```

**Response: `201 Created`** — returns the created template.

---

### `POST /notifications`

**Request Body (`SendNotificationDto`):**

```ts
{
  userId: number;
  templateId?: number;        // use template for subject/body
  subject: string;            // max 200 chars (overrides template if provided)
  body: string;               // overrides template if provided
  channel: "EMAIL" | "SMS" | "IN_APP" | "PUSH";
}
```

**Response: `201 Created`**

```ts
{
  id: number;
  userId: number;
  subject: string;
  channel: string;
  status: "PENDING";
  createdAt: string;
}
```

---

### `POST /notifications/bulk`

**Request Body (`BulkNotificationDto`):**

```ts
{
  userIds: number[];
  templateId?: number;
  subject: string;
  body: string;
  channel: "EMAIL" | "SMS" | "IN_APP" | "PUSH";
}
```

**Response: `201 Created`**

```ts
{
  sent: number;
  errors: { userId: number; message: string }[];
}
```

---

### `GET /notifications`

**Query Parameters:**

```ts
{
  status?: "PENDING" | "SENT" | "FAILED" | "READ";
  channel?: "EMAIL" | "SMS" | "IN_APP" | "PUSH";
  page?: number;
  limit?: number;
}
```

**Response: `200 OK`**

```ts
{
  data: {
    id: number;
    subject: string;
    body: string;
    channel: string;
    status: string;
    sentAt: string | null;
    readAt: string | null;
    createdAt: string;
  }[];
  meta: { total: number; page: number; limit: number; unreadCount: number };
}
```

---

### `PATCH /notifications/:id/read`

**Response: `200 OK`**

```ts
{
  id: number;
  status: "READ";
  readAt: string;
}
```

---

## Notification Status Flow

```
PENDING → SENT → READ
        ↘ FAILED (retry)
```

---

## Notes for Developers

- Use Redis/Bull for queuing notification delivery. The `Notification` record is created with status `PENDING`, then a queue worker processes delivery and updates to `SENT` or `FAILED`.
- Templates support variable interpolation with `{{variable}}` syntax (e.g. `"Dear {{firstName}}, your result is ready"`). Resolve variables at send time.
- `IN_APP` notifications are stored and returned via the API. `EMAIL` and `SMS` are dispatched via external providers.
- The `GET /notifications` endpoint should only return the current user's notifications (filter by `userId` from JWT).
