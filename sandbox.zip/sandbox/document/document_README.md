# Document Module

Manages student document uploads, verification, and retrieval.

## Models Owned

- **StudentDocument** — uploaded documents per student with verification workflow

---

## Endpoints

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/documents` | List documents (filterable by student, type, status) | Admin, Staff |
| `GET` | `/documents/:id` | Get document details | Admin, Staff, Self |
| `GET` | `/documents/student/:studentId` | List all documents for a student | Admin, Staff, Self |
| `POST` | `/documents` | Upload a document for a student | Admin, Student (self) |
| `PATCH` | `/documents/:id` | Update document metadata | Admin |
| `DELETE` | `/documents/:id` | Delete a document | Admin, Student (self, if pending) |
| `PATCH` | `/documents/:id/verify` | Verify a document | Admin, Staff |
| `PATCH` | `/documents/:id/reject` | Reject a document | Admin, Staff |
| `GET` | `/documents/:id/download` | Download the document file | Admin, Staff, Self |

---

## Request & Response Types

### `POST /documents`

**Request: `multipart/form-data`**

```ts
{
  file: File;                    // the uploaded file
  studentId: number;
  documentType: string;         // e.g. "birth_certificate", "o_level", "jamb_result", "transcript", max 30 chars
}
```

**Response: `201 Created`**

```ts
{
  id: number;
  studentId: number;
  documentType: string;
  fileName: string;
  filePath: string;
  fileSize: number;
  mimeType: string;
  status: "pending";
  uploadedAt: string;
  createdAt: string;
}
```

---

### `GET /documents/student/:studentId`

**Query Parameters:**

```ts
{
  documentType?: string;
  status?: string;           // "pending", "verified", "rejected"
}
```

**Response: `200 OK`**

```ts
{
  data: {
    id: number;
    documentType: string;
    fileName: string;
    fileSize: number;
    mimeType: string;
    status: string;
    verifiedBy: number | null;
    verifiedAt: string | null;
    uploadedAt: string;
  }[];
}
```

---

### `PATCH /documents/:id/verify`

**Request Body (`VerifyDocumentDto`):**

```ts
{
  remarks?: string;
}
```

**Response: `200 OK`**

```ts
{
  id: number;
  status: "verified";
  verifiedBy: number;
  verifiedAt: string;
}
```

---

### `PATCH /documents/:id/reject`

**Request Body (`RejectDocumentDto`):**

```ts
{
  reason: string;            // required
}
```

**Response: `200 OK`**

```ts
{
  id: number;
  status: "rejected";
  verifiedBy: number;
  verifiedAt: string;
}
```

---

## Document Workflow

```
pending → verified
        ↘ rejected → (student re-uploads → pending)
```

---

## Notes for Developers

- Store files in object storage (e.g. S3, MinIO). Save the path in `filePath`.
- Validate file types (e.g. only PDF, JPG, PNG) and size limits in the controller.
- `verifiedBy` references the User ID of the admin/staff who verified.
- Documents are indexed by `documentType` for quick lookups.
- Students can only delete their own documents that are still in `pending` status.
