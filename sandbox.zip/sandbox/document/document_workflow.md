# Document Module — Implementation Workflow

This document explains the internal implementation flow for the Document module. It is intended for developers building or maintaining this module.

---

## Module Dependencies

```
DocumentModule
├── PrismaService          (database access)
├── StorageService         (file uploads to S3/MinIO)
├── AuditModule            (log uploads, verifications)
└── NotificationModule     (notify on verification/rejection)
```

---

## Document Lifecycle

```
┌─────────┐      ┌──────────┐
│ pending  │─────▶│ verified │
└────┬─────┘      └──────────┘
     │
     ▼
┌──────────┐      ┌─────────┐
│ rejected │─────▶│ pending  │  (student re-uploads)
└──────────┘      └─────────┘
```

---

## 1. Document Upload Flow

**Endpoint:** `POST /documents`

```
Student uploads a document (multipart/form-data)
         │
         ▼
┌──────────────────────────────────────────────────┐
│  DocumentController.upload(file, dto)            │
│  - @UseInterceptors(FileInterceptor('file'))     │
│  - Extract studentId from dto or JWT             │
│  - Validate request                              │
└────────────┬─────────────────────────────────────┘
             │
             ▼
┌──────────────────────────────────────────────────┐
│  DocumentService.uploadDocument(file, dto)        │
│                                                  │
│  Validation:                                     │
│  ┌────────────────────────────────────────────┐  │
│  │ 1. Validate file type:                     │  │
│  │    - Allowed: PDF, JPG, PNG                │  │
│  │    - Check MIME type AND file extension     │  │
│  │    - Invalid → 400                         │  │
│  │                                            │  │
│  │ 2. Validate file size:                     │  │
│  │    - Max: 5MB                              │  │
│  │    - Over limit → 400                      │  │
│  │                                            │  │
│  │ 3. Verify student exists                   │  │
│  │                                            │  │
│  │ 4. If Self: verify JWT user owns this      │  │
│  │    student record                          │  │
│  └────────────────────────────────────────────┘  │
│                                                  │
│  Upload:                                         │
│  ┌────────────────────────────────────────────┐  │
│  │ 1. Generate storage path:                  │  │
│  │    "documents/{studentId}/{uuid}_{name}"   │  │
│  │ 2. Upload to object storage (S3/MinIO)     │  │
│  │ 3. Create StudentDocument record:          │  │
│  │    - studentId, documentType               │  │
│  │    - fileName, filePath, fileSize, mimeType│  │
│  │    - status: "pending"                     │  │
│  └────────────────────────────────────────────┘  │
│                                                  │
│  Log via AuditService                            │
└──────────────────────────────────────────────────┘
```

---

## 2. Verification Flow

**Endpoint:** `PATCH /documents/:id/verify`

```
Admin/Staff verifies a document
         │
         ▼
┌──────────────────────────────────────────────────┐
│  DocumentService.verifyDocument(id, adminId, dto)│
│  1. Find document by ID                         │
│     - Not found → 404                            │
│  2. Check status == "pending"                    │
│     - Already verified → 400                     │
│  3. Update:                                      │
│     - status = "verified"                        │
│     - verifiedBy = adminId                       │
│     - verifiedAt = now                           │
│  4. Notify student: "Your document was verified" │
│  5. Log via AuditService                         │
└──────────────────────────────────────────────────┘
```

### Rejection Flow

```
Admin/Staff rejects a document
         │
         ▼
┌──────────────────────────────────────────────────┐
│  DocumentService.rejectDocument(id, adminId, dto)│
│  1. Find document by ID                         │
│  2. Check status == "pending"                    │
│  3. dto.reason is required                       │
│  4. Update:                                      │
│     - status = "rejected"                        │
│     - verifiedBy = adminId (who rejected)        │
│     - verifiedAt = now                           │
│  5. Notify student: "Your document was rejected. │
│     Reason: {reason}. Please re-upload."         │
│  6. Log via AuditService                         │
└──────────────────────────────────────────────────┘
```

**Re-upload:** Student deletes the rejected document and uploads a new one → status resets to "pending".

---

## 3. Download Flow

**Endpoint:** `GET /documents/:id/download`

```
User requests to download a document
         │
         ▼
┌──────────────────────────────────────────────────┐
│  DocumentService.downloadDocument(id, userId)    │
│  1. Find document by ID                         │
│  2. Authorization check:                        │
│     - Admin/Staff → allowed                      │
│     - Self (student owns it) → allowed           │
│     - Other → 403                                │
│  3. Generate pre-signed URL from storage         │
│     (or stream file directly)                    │
│  4. Return file stream or redirect to signed URL │
└──────────────────────────────────────────────────┘
```

---

## 4. Deletion Rules

```
┌──────────────────────────────────────────────────┐
│  Who can delete:                                 │
│  - Admin → any document, any status              │
│  - Student → only their own, only if "pending"   │
│    (verified documents cannot be deleted)         │
│                                                  │
│  On delete:                                      │
│  1. Delete file from object storage              │
│  2. Delete StudentDocument record from DB        │
│  3. Log via AuditService                         │
└──────────────────────────────────────────────────┘
```

---

## 5. Files to Create

```
src/modules/document/
├── document.module.ts
├── document.controller.ts        # All document routes
├── document.service.ts           # Business logic
├── dto/
│   ├── upload-document.dto.ts    # studentId, documentType
│   ├── verify-document.dto.ts    # remarks
│   ├── reject-document.dto.ts    # reason (required)
│   └── query-document.dto.ts     # filters
└── document.service.spec.ts
```

---

## 6. Cross-Module Integration Points

| Direction | Module | Interaction |
| --------- | ------ | ----------- |
| **Consumes** | UserModule | Student lookup |
| **Consumed by** | ClearanceModule | Document verification status for clearance |
| **Consumed by** | AdmissionModule | Application documents (separate model but same storage pattern) |
