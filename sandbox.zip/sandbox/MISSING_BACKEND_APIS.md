# Missing / Incomplete Backend APIs — Consolidated

> **CORRECTION (2026-09-10):** the "RESOLVED — every item shipped" claim below is **overstated**.
> A full frontend↔`bruno/` re-audit (`sandbox/API_INTEGRATION_AUDIT.md`) confirmed that §2.8
> (Director analytics), §2.9 (fee eligible-count), §2.11 (schedule contract duplication), §2.12
> (exam timetable), §2.13 (assessments consolidation), and §2.14 (Moodle CA bridge) describe work
> that was **never delivered** — no `.bru`, still 404ing. The live list of what's genuinely open is
> **`sandbox/API_GAPS_2026-09.md`**. The §2.x specs here remain the reference for *how* to build
> each — read them alongside that doc. Do not add new items to this file; use the new one.

> **STATUS (2026-08-28): RESOLVED — every item in this document has been shipped by the backend
> team.** This file is kept as a historical record of what was built and why (each section's
> rationale, schema, and endpoint contracts are still the reference for how these endpoints behave)
> — the "proposed"/"404s until shipped"/"pending backend" framing throughout the body no longer
> reflects reality. Frontend code comments that pointed here have been updated to say "confirmed
> live" / "now shipped" accordingly. Anything genuinely still outstanding will start a new,
> separate tracking doc rather than reopening this one.
>
> **Audience:** Backend developer (qhub_backend_api, Laravel).
> **Purpose:** A single, prioritized list of every real backend gap found during a full
> module-by-module frontend audit (2026-08-21). This consolidates four existing per-module docs
> (referenced, not duplicated) plus new gaps found while auditing every remaining module. Anything
> here has been confirmed against `bruno/` (the API contract), `sandbox/schema.prisma`, and the
> actual current frontend code — not just requested speculatively.
>
> Companion doc: `sandbox/API_INTEGRATION_AUDIT.md` has the full frontend-wiring status for every
> module, including items that are **frontend-only** gaps (no backend work needed) — those are not
> repeated here.

---

## Priority 1 — Blocks working features today

### 1.1 No endpoint for a logged-in student to resolve their own `Student.id`

**Blocks:** Clearance, Document, and Hostel student-facing dashboards (all three are otherwise fully
wired to real endpoints — this one lookup is the actual blocker).

`GET /auth/me` returns only `User` fields (id, email, name, etc.), and `GET /users/students/:id`
requires already knowing the `Student.id` — which a freshly authenticated student has no way to
obtain.

**Requested:** One of:
- `GET /users/students/me` — resolves the current JWT's Student record directly, or
- Add `studentId: number | null` to the `GET /auth/me` response for users who have a linked Student
  record.

Either unblocks all three modules identically since the frontend just needs the id once per session.

**Status update (2026-08-22):** `src/hooks/use-my-student-id.ts` has been rewired off the hardcoded
`null` stub — it now calls `usersApi.getMyStudent()` (`GET /users/students/me`, the first option
above), gated to only fire for `UserRole.STUDENT` sessions. Every consumer (student-grades, document,
hostel, clearance) will start resolving a real id the moment this endpoint ships; until then the
request 404s and `studentId` stays `null`, same behavior as before but from a real failed request
rather than a hardcoded value.

### 1.1b No endpoint for a logged-in tutor to resolve their own `Lecturer.id`

**Blocks:** The Tutor "My Assigned Courses" page (`/tutor/courses`) — same shape of gap as §1.1
above, one level up the role ladder. `GET /auth/me` returns only `User` fields, and
`GET /users/lecturers/:id` needs the caller to already know their own `Lecturer.id`.
`src/hooks/use-my-lecturer-id.ts` is wired against a proposed `GET /users/lecturers/me`
(mirroring the `GET /users/students/me` ask in §1.1) — 404s until the backend adds it.

**Requested:** `GET /users/lecturers/me` — resolves the current JWT's Lecturer record
directly (same shape as `Lecturers - Show.bru`). Once this ships, `/tutor/courses` (assigned
offerings via the existing `GET /courses/offerings?lecturerId=`) and any other
"my own lecturer record" screen work with zero further frontend changes.

### 1.2 Audit drill-down endpoints — confirm exact paths (frontend currently calls the wrong ones)

Not a backend gap per se, but worth a quick confirmation from whoever owns `bruno/audit` since the
frontend's calls don't match the documented contract at all (extra `/api` prefix, and the entity
route is missing a path segment):

- Frontend calls `/api/audit/users/:userId/logs` — bruno documents `/audit/logs/user/:userId`
  (`Logs - By User.bru`).
- Frontend calls `/api/audit/entity/:entityType/:entityId` — bruno documents
  `/audit/logs/entity/:entityType/:entityId` (`Logs - By Entity.bru`).

**Ask:** please confirm the bruno-documented paths are what's actually deployed (no backend change
expected) — the frontend fix is a one-line URL correction once confirmed.

---

## Priority 2 — Real, additive features with no backend support yet

### 2.1 Admission Cycle (open/close admissions per session)

Full schema + endpoint spec already written: see
**`sandbox/admission/missing_admission_cycle_apis.readme.md`**. Summary: two new models
(`AdmissionCycle`, `AdmissionCycleRequirement`), 9 new endpoints, and 4 new enforcement checks inside
`POST /admissions/applications`. **Status update (2026-08-21): the frontend's in-memory mock has been
removed** — `src/services/admissionSetupApi.ts` now calls these exact endpoints, so the "Admissions
Management" screen (`admin/academics/admissions`, `manager/academics/admissions`) currently 404s on
every request. This is now a blocking gap, not a cosmetic one.

### 2.2 Admission Step Registry (admin-configurable application form/process steps)

Full schema + endpoint spec already written: see
**`sandbox/admission/admission_features_workflow.md`**. Proposes an `AdmissionStepDefinition` model
plus `GET/POST/PATCH/DELETE /admissions/config/steps` and a `/reorder` endpoint. **Status update
(2026-08-21): the frontend's in-memory mock has been removed** — `src/services/admissionStepsApi.ts`
now calls these exact endpoints, so both the admin panel and the two student-facing pages
(`process-admission`, `admission-application-form`) currently 404 on load. This is a **second,
separate** gap from 2.1 above — different screen, different endpoint set — now also blocking.

### 2.3 `ApplicationAcademicRecord` — repeatable academic records on an application

Full schema + endpoint spec already written: see `admission_README.md`'s "⚠️ Frontend Contract
Changes Required" section (§1) — it specifies the exact `ApplicationAcademicRecord` Prisma model, the
nested `AdmissionApplication` response shape every application-review endpoint must return, and the
`academic_records[]` field within it. **The frontend already sends/renders this shape in
production** — `src/services/applicationReviewApi.ts` and the review-applications detail page
(`manager/review-applications/:id`) both read/write `academic_records[]` with zero fallback or mock
data, on the assumption the backend already matches §1 exactly. This is the single biggest
real gap in the Admission module: until `ApplicationAcademicRecord` and the full nested response
shape in §1 ship, every application list/detail/review/update call likely returns a shape the
frontend can't fully render.

### 2.4 Accept / Create Offer — now wired, both were frontend gaps not backend gaps

Two items flagged in the frontend audit as "endpoint exists, no UI caller" have both been built:

- **`PATCH /admissions/:id/accept`** — the "Accept Offer" button on the student's admission
  dashboard (`AdmissionStatusSection.tsx`) previously just called `onRefresh` and did nothing. It now
  calls this real endpoint via `admissionService.acceptAdmission()`.
- **`POST /admissions`** (create an offer from an approved application) — the officer's application
  detail page (`manager/review-applications/:id`) now has a "Create Admission Offer" action when an
  application's status is `approved`, calling this real endpoint via the new
  `src/services/admissionOfferApi.ts`. No backend work needed for either — both endpoints already
  exist and are documented in `admission_README.md`'s "Admissions" table.

One thing to confirm: there's no endpoint to check whether an application already has an offer
before submitting the create form, so the frontend relies on the backend's documented unique
constraint on `Admission.applicationId` to reject a duplicate — please confirm that constraint
returns a clean, catchable error (not a 500) so the toast shown to the officer stays meaningful.

### 2.5 Tuition partial-payment `amount` — please confirm, not build

`POST /fees/payments/tuition/initiate`'s only documented example body is `{method: "GATEWAY"}` with
no partial-payment example. The frontend's tuition-payment flow
(`admissionService.ts`'s `initiateTuitionPayment(amount)`, consumed by `TuitionPaymentSection.tsx`'s
installment plan) already sends `{method: "GATEWAY", amount}` defensively and has done so for a
while. Please confirm the backend's DTO actually accepts and honors `amount` for a partial/installment
tuition payment — if it currently ignores the field, either start accepting it or let us know so the
frontend's installment options can be removed rather than silently not working.

### 2.6 Curriculum-semester field on `Course`

Full schema + endpoint spec already written: see
**`sandbox/course/missing_curriculum_apis.readme.md`**. One nullable `curriculumSemester Int?`
column on `Course`, surfaced on every Course DTO/response. Additive, no migration/backfill needed.
The frontend's Curriculum Planner tab is already built against this and correctly shows every course
as "unassigned" until the field ships.

### 2.7 Result module — analytics + fee-gated publishing

Full schema + endpoint spec already written: see **`sandbox/result/missing_grade_apis.readme.md`**.
**Status update since that doc was written:** 5 of the 6 analytics endpoints now exist in
`bruno/result/` (Dashboard, Grade Distribution, Program Performance, CGPA Trends, Top Performers) —
**however**:

- **`GET /results/dashboard`'s actual response shape doesn't match what the frontend expects.**
  Bruno documents a flat object (`{totalGrades, publishedCount, approvedCount, pendingApprovals,
  draftCount, averageCGPA, highestCGPA, passRate}`), but the frontend's `GradeDashboardData` type
  expects a nested shape (`{stats, gradeDistribution, programPerformance, cgpaTrends,
  topPerformers}`) — as currently deployed, this will render broken/empty on the frontend. **Please
  confirm which shape is actually intended** — either the frontend needs deployment fixed to match
  the flat shape (reading each sub-collection from its own dedicated endpoint), or if a single
  aggregate endpoint returning the nested shape was the original intent, that needs building instead
  of (or in addition to) the current flat one.
- **`Grade.hasOutstandingFees` is still not present on any Grade response** (`List`/`Get`/`By
  Student`/`By Course`) — this is the one sub-item of the original doc still fully open. Without it,
  every grade reads as fee-cleared.
- The `withheld` count on `POST /results/grades/publish/:semesterId`'s response **has** shipped per
  `Grade - Publish.bru`'s docs — good, but it can't be trusted by the frontend until
  `hasOutstandingFees` also ships, since the two are meant to be consistent with each other.
- `GET /results/grades/grouped` is fully working end-to-end — no further action needed there.

### 2.8 Director module — full backend build

**No `bruno/director/` collection exists at all** — this is the only module in the entire audit with
zero backend contract. The module already ships its own proposed contract at
`src/app/(dashboard)/director/INTEGRATION.md` (7 endpoints: overview, enrollment-trend,
faculty-distribution, financial-summary, payments, statistical-report, grade-report). **Before
building these as new bespoke endpoints, please consider whether most can be composed from data the
Academic, Fee, and Result modules already expose** (faculty distribution ≈ Academic's
Faculty/Department/Program data joined with a student count; financial-summary/payments ≈ Fee's
`Reports - Summary`/`Invoices - List` grouped by faculty instead of fee type; statistical/grade
reports ≈ Result's Grade/CgpaHistory data). Only `enrollment-trend` (a genuine time-series aggregate)
looks like it needs a wholly new query. Recommend a scoping conversation before committing to 7 new
endpoints.

**Status update (2026-08-22) — Grade Reports only:** of the 7, only the Grade Reports tab
(`/director/grades`) has been fully speced and wired so far, following the recommendation above —
it's now designed as a **Result module** endpoint rather than a bespoke Director one. Full contract:
`sandbox/result/missing_grade_apis.readme.md` §8, `GET /results/reports/director-grade-summary`.
`src/modules/director/services/director.service.ts`'s `fetchGradeReport` now calls this real
(pending) endpoint via `apiClient` and the `Math.random()` grade-record generator has been removed;
until the backend ships it, this call 404s and the Grade Reports page shows its existing empty/error
state rather than fabricated numbers.

**Status update (2026-08-23) — Overview, Financial, Statistical now wired.** All `Math.random()`/seed
generators removed from `director.service.ts`. Composed from real endpoints wherever one already
exists, per the recommendation above; the genuine gaps get a designed contract rather than fabricated
numbers. Filtering follows the same choice already made for Grades: send `facultyName`/
`departmentName` display strings, ask the backend to accept them, rather than rebuilding
`DirectorFilterBar` around real FK dropdowns.

**Already real, now wired directly:**
- `GET /academic/faculties`, `GET /academic/programs` (`facultiesApi`/`programsApi` in
  `courseStructureApi.ts`) → Overview's Total Faculties / Active Programs counts (`isActive` filtered
  client-side over the real list — no new endpoint needed).
- `GET /users/students`, `GET /users/lecturers` (`usersApi.listStudents`/`listTutors`) → Statistical
  tab's student/tutor detail tables and real `meta.total` counts.
- `GET /fees/reports/outstanding` (confirmed shape, grouped by fee type — `payment_README.md`) →
  Financial tab's fee-type revenue breakdown, `totalOutstanding`. The old mock's `byFaculty` chart is
  renamed `byFeeType`/"Revenue by Fee Type" since no endpoint anywhere joins
  Invoice → Student → Program → Department → Faculty for a faculty-grouped revenue view — grouping by
  fee type is what's actually real.
- Graduation rate is now a genuine point-in-time ratio (`GRADUATED` students ÷ total, via
  `usersApi.listStudents({status:"GRADUATED"})`'s real count), not a fabricated "vs last year" trend —
  no historical snapshot exists anywhere to diff against, so the trend framing was dropped rather than
  faked (`DashboardMetric.change`/`changeLabel`/`trend` are now optional; cards with no real trend data
  just show the current value).

**Proposed extensions to already-real endpoints (built against, 404s/degrades until shipped):**
- `GET /users/stats` (already proposed, see the addendum below) — extend with:
  ```ts
  {
    data: {
      totalUsers, totalStudents, totalTutors, totalStaff, activeUsers, // existing proposal
      byFaculty: { facultyId: number; facultyName: string; students: number; tutors: number }[];
      studentsByLevel: { level: number; count: number }[];
      studentsByGender: { male: number; female: number };
      tutorsByDesignation: { designation: string; count: number }[];
    }
  }
  ```
  Backs Overview's faculty-distribution chart and Statistical's level/gender/designation breakdowns —
  none of these exist as an aggregate anywhere (every real endpoint found returns row-level lists, and
  paging through the full table client-side to aggregate doesn't scale, per the same principle already
  called out in `missing_grade_apis.readme.md`).
- `GET /users/students`, `GET /users/lecturers` — add `facultyName`/`departmentName` string filters
  (only `programId`/`departmentId` FKs and, for students, no faculty/department filter at all are
  confirmed today), and for students a direct numeric `level` filter alongside the existing
  `currentLevelId` FK.
- `GET /fees/reports/summary` — no response shape is documented anywhere (`bruno/fee/Reports -
  Summary.bru` has no example body). Proposed: `{ data: { totalExpected: string; totalCollected:
  string } }`, filterable additionally by `facultyName`/`departmentName`. Built defensively: if this
  comes back in an unexpected shape or fails, `totalExpected`/`totalCollected` fall back to summing the
  confirmed-real Outstanding endpoint's per-fee-type totals, so the tab still shows real numbers either
  way.
- `GET /fees/invoices` (admin list) — only the student-scoped `/fees/invoices/my` response shape is
  documented; the admin list's nesting isn't. Proposed, matching the `/users/students` nesting
  convention already requested below:
  ```ts
  {
    data: {
      id, amount, amountPaid, dueDate, status, paidAt,
      feeType: { name: string };
      session: { name: string } | null;
      student: {
        id, matricNumber, facultyName, departmentName, programName, level: number;
        user: { firstName: string | null; lastName: string | null };
      };
    }[];
    meta: { total, page, limit };
  }
  ```
  Plus `facultyName`/`departmentName`/`level` filters, alongside the confirmed `status`/`feeTypeId`/
  `sessionId`/`studentId`.

**Genuinely new aggregates (no composition possible, no endpoint anywhere today):**
- `GET /enrollments/trend?months=` → `{ data: { month: string; newEnrollments: number; totalActive:
  number }[] }`. Backs Overview's enrollment chart. `bruno/enrollment/*.bru` is entirely point-in-time/
  filtered lists — no time-series aggregate exists in the Enrollment module.
- `GET /fees/reports/collections-trend?months=` → `{ data: { month: string; collected: number;
  expected: number }[] }`. Backs Financial's monthly revenue chart. Same gap as enrollment-trend, in
  the Fee module.

### 2.11 Timetable module — two backend contracts for the same `ClassSchedule` table

Confirmed by a full audit (2026-08-22): `bruno/timetable/Schedules - *.bru` (`/timetable/schedules`,
full CRUD + by-offering/semester/lecturer reads + venue availability) and
`bruno/course/Schedule - *.bru` (`/courses/offerings/:id/schedules`, simpler CRUD — already
integrated in `src/services/courseOfferingApi.ts` for the Course Offering module's own schedule
tab) are **two independent, undocumented-as-duplicate REST surfaces over the identical
`ClassSchedule` Prisma model** (same table, same columns, no reconciliation between them). The
frontend now builds the Timetable module (`src/modules/timetable/`) against `/timetable/schedules`
as canonical — it's the richer contract (conflict detection docs, caching strategy, dedicated
role-aware "my timetable"/"by lecturer"/"by student" reads) — while `courseOfferingApi.ts` keeps
calling `/courses/offerings/:id/schedules` for the Course Offering screen's own schedule tab,
unchanged from earlier work. **Please pick one as the single source of truth** (likely
`/timetable/schedules`, given its richer spec) and either deprecate the other or make it a thin
proxy — right now a schedule created through one route is invisible to whichever screen reads
through the other, since nothing keeps them in sync beyond both reading the same table.

### 2.12 Exam Timetable — no backend concept exists at all

Real Nigerian university need (a separate exam schedule, distinct from the weekly class
timetable — different rooms/seating, invigilators, exam periods) has **zero backing** anywhere:
no `ExamTimetable`/`ExamSchedule`/`Venue`-with-capacity model in `schema.prisma`, no bruno
collection, not even a workflow doc — the only occurrence of "exam timetable" in any sandbox doc
is as example text for an `Announcement.category` value. This was **not** built this pass (it's a
new backend concept requiring a new Prisma model + endpoints, not a "wire up what's designed"
task) — flagging here as a real gap for a future module pass, pending a decision on scope.

### 2.13 Assessments consolidated onto `moodle-sync` — new endpoints needed there

**Status update (2026-08-22):** the mock `src/modules/assessments` module has been **retired
entirely**, not wired to the separate real `/assessments/*` namespace as originally planned. Per
product direction: `/assessments/*` and `/moodle-sync/assessments/*` both read/write the identical
`MoodleSyncAssessment` entity, and maintaining two frontend surfaces over one entity was judged an
unnecessary duplicate. The frontend now consolidates everything onto `src/modules/moodle-sync`,
which already owns the real, confirmed endpoints (`GET /moodle-sync/assessments`,
`.../course/:offeringId`, `.../upcoming`, `POST .../pull/:moodleCourseId`, `POST .../pull-all`).
**Please consider whether `/assessments/*` (bruno/assessments) should be deprecated/removed
backend-side now that no frontend code calls it** — that decision is yours; the frontend no longer
depends on it either way.

To fully replace what the retired module offered, the following are **new, needed on
`/moodle-sync/assessments/*`** (frontend already built and wired against these — 404s until
shipped):

- **`GET /moodle-sync/assessments/:id`** — full detail (same nested
  `course.courseOffering.course/semester/academicSession` shape the list endpoints already return,
  plus `isVisible`, `moodleSyncCourseId`, `moodleAssessmentId`, `lastSyncAt`, `createdAt`,
  `updatedAt`).
- **`GET /moodle-sync/assessments/my?type=&upcoming=&page=&limit=`** — Student only, scoped via
  `req.user`, paginated `{data, meta}` (distinct from the existing `/upcoming`, which only returns
  near-future items — this is the full list).
- **`PATCH /moodle-sync/assessments/:id/visibility`** `{isVisible: boolean}` — Admin or Lecturer.
  Response `{id, isVisible, updatedAt}`.
- **`DELETE /moodle-sync/assessments/:id`** — Admin. Portal-side only, doesn't touch Moodle.
  Response `{message}`.
- **`GET /moodle-sync/assessments/sync-status`** — Admin. `{summary: {totalCourses,
  totalAssessments, byStatus: {SYNCED, PENDING, FAILED, STALE}}, courses: [{courseOfferingId,
  courseCode, moodleCourseId, assessmentCount, lastSyncAt, failedCount}]}`.
- Extend the existing **`GET /moodle-sync/assessments`** list with optional `isVisible`, `upcoming`,
  `page`, `limit` query params (currently only `offeringId`/`type` are documented) — same endpoint,
  just richer filtering for the admin/tutor browse screens.
- No new "retry" endpoint needed — the frontend just re-calls the existing
  `POST /moodle-sync/assessments/pull/:moodleCourseId`, since pulls are upsert-based (idempotent).

### 2.14 Moodle CA → `Grade.caScore` bridge — one new endpoint, reusing existing Grade-write path

Real gap, now bridged (not deferred): previously, `Grade.caScore` (Results module) and
Moodle-synced assessment/grade data were two fully disconnected systems — confirmed via
`schema.prisma`, `Grade.caScore` has zero relation to `MoodleSyncAssessment`/`MoodleSyncGrade`, and
a lecturer had to manually type the CA score with no visibility into what Moodle already recorded.

**New endpoint needed:** **`GET /moodle-sync/assessments/ca-preview/:offeringId?semesterId=&caMax=`**
— Admin or the offering's Lecturer. For every student enrolled in that course offering, aggregates
their `MoodleSyncGrade` rows tied to that offering's assignments/quizzes (excluding `forum`-type
items, which aren't graded) into a proportional CA score:
`computedCaScore = round((Σ studentGrade / Σ maxGrade) × caMax)`, where `caMax` defaults to **40**
(this app's existing CA ceiling convention — see `caScore` max in
`src/modules/student-grades/_components/modals/grade-detail-modal.tsx` — but is overridable per
course via the query param, since not every course necessarily weights CA the same way). Response:

```ts
{
  data: {
    offeringId: number;
    semesterId: number;
    caMax: number;
    students: {
      studentId: number;
      studentName: string;
      studentMatric: string;
      sourceItemCount: number;   // how many Moodle grade rows contributed
      sourceTotal: number;       // Σ studentGrade across those rows
      sourceMax: number;         // Σ maxGrade across those rows
      computedCaScore: number;
    }[];
  };
}
```

This is intentionally **read-only** — no new Grade-writing endpoint was requested. The frontend
(`src/modules/student-grades/_components/BulkGradeForm.tsx`'s "Pull CA from Moodle" button) previews
these computed scores, lets the lecturer review/adjust each one inline, then saves them through the
**already-real** `POST /results/grades/bulk` (see `bruno/result/Grade - Bulk Create.bru`) — the same
single write path every other CA/Exam entry in this app already goes through, so there's no
duplicated or competing Grade-writing logic to keep in sync.

Native (non-Moodle) CA test/assignment authoring, student submission, and grading/feedback are
explicitly **not** part of this bridge and remain out of scope by design — per product direction,
those actions happen on the Moodle LMS itself, not in the qhub portal; the portal only needs to read
the results.

### 2.15 Student "My Courses" / SSO launch — see the multi-structure refactor doc

**Moved 2026-08-23.** Full detail (contract, errors, frontend callers, and the history of the
original two-endpoint proposal this superseded) now lives in
`sandbox/schema-moodel-sync-refactor/BACKEND_REQUIRED_ENDPOINTS.md` §1, alongside every other
endpoint from the same refactor pass. One endpoint needed: `GET /students/me/courses/{offeringId}/launch`.

### 2.16 Academic Structure tree + Grading Schemes — multi-institution-type refactor

**Moved 2026-08-23.** This codebase must deploy for *any* institution type — secondary schools,
degree faculties, postgraduate schools, sandwich programs, business schools — from one schema, one
set of controllers, and one Moodle sync implementation. Full detail for all five endpoint groups
this requires (Course Launch SSO, Academic Structure tree, Grading Schemes, the Moodle category
sync rework onto `academicUnitId`, and `programCategory`-branched student results) — including exact
request/response contracts, schema changes, migration notes, and frontend callers — now lives in its
own backend-facing doc: **`sandbox/schema-moodel-sync-refactor/BACKEND_REQUIRED_ENDPOINTS.md`**. The
companion design docs in that same folder (`README.md`, `SCHEMA_CHANGES.md`, `api-v2.md`) cover the
full rationale and reference API. Every endpoint listed there already has a real, wired-up frontend
caller — nothing is a placeholder.

### 2.9 Fee eligible-count preview

`GET /fees/types/eligible-count` — the frontend's "how many students would this fee type apply to"
live preview (`fee-type-scope-selector.tsx`) already calls this speculatively and degrades gracefully
(`retry: false`) if it 404s. No bruno file confirms this endpoint exists. Low priority — the UI
already handles its absence — but worth building if the eligible-count preview is a wanted feature.

### 2.10 Course Offering `enrolledCount` — real registrar need, no endpoint

Building the Course Offerings management screen (list/create/update/cancel offerings, assign
lecturers, set weekly schedule — all against real, already-documented endpoints) surfaced one gap
against what an actual Nigerian university registrar's office needs: seeing how full an offering is
(e.g. "45/60 filled") to decide whether to raise capacity or open a second stream. No endpoint
currently returns this — `GET /courses/offerings` and `GET /courses/offerings/:id` only return the
offering's own columns plus its nested `course`.

**Proposed:** add an `enrolledCount: number` field to every offering response (list and detail),
computed as `COUNT(StudentEnrollment) WHERE offeringId = :id AND status = 'ENROLLED'` (excluding
`DROPPED`/`WITHDRAWN`). The frontend (`src/services/courseOfferingApi.ts`) already reads this field
defensively (`enrolledCount ?? null`) and displays "Enrolled: —" until it's present, so this is a
pure additive change — no other response shape changes needed.

### 2.17 Pre-application Program Choice — new "Choice Program" admission process step

**Added 2026-08-27.** Full schema + endpoint spec already written: see
**`sandbox/REFACTOR_BACKEND_APIS.md`**. Summary: a new `AdmissionProgramChoice` model, one new
`POST /admission/program-choice` endpoint, and five new fields on the existing
`GET /admission/student` aggregate — so an applicant can pick their program/entry mode/study mode
*before* paying the application fee or starting a formal application, matching how a real
Nigerian university portal typically works. The frontend (`ChoiceProgramSection.tsx`,
`admissionStore.ts`'s order-driven `deriveStep`, `AdmissionStepIndicator.tsx`) is fully wired
against this designed contract already — `submitProgramChoice()` 404s and
`fetchStudentAdmission()` defensively defaults the five new fields to "not yet chosen" until it
ships. The application form's own "Program Selection" step has been removed (both from the live
wizard and the admin config panel) since asking twice would be redundant — see the doc's
"Interaction with the existing flow" section for why `POST /admissions/applications` itself needs
no changes.

---

## Priority 3 — Small, additive endpoint gaps (Auth/User module)

These are all small, additive gaps in an otherwise complete Auth/Role/Permission contract:

- **`POST /auth/roles/:id/duplicate`** — frontend calls this (a "Duplicate Role" action) but it
  doesn't exist in bruno. Proposed: same response as `Roles - Create`, with name suffixed
  `" (Copy)"`.
- **`GET /auth/permissions/:id`** and **`DELETE /auth/permissions/:id`** — frontend calls both, but
  bruno's own docs explicitly state Permissions currently support list+create only (Update was later
  added as a deviation; Show/Delete were not). Please confirm intent — either add these two, or the
  frontend needs its calls removed.
- **`GET /auth/roles/:roleId/users`** — needed to show real users assigned to a role in the "Users"
  tab of the Role Detail admin screen. **Status update (2026-08-21): the frontend's fake client-side
  data (`usersPool`/`roleUserMap` in `src/services/rolesApi.ts`) has been removed** —
  `userRolesApi.getUsersWithRole()` now calls this exact endpoint, so the "Users" tab currently 404s.
  The existing reverse-direction endpoint (`GET /auth/users/:userId/roles`, roles for a user) doesn't
  cover this — that one **is** now wired for real (see the User Management "Manage Roles" action).
  Proposed contract, paginated to match every other list endpoint in this API:

  ```ts
  // GET /auth/roles/:roleId/users?page=&limit=
  {
    data: {
      id: number;
      email: string;
      username: string;
      firstName: string | null;
      lastName: string | null;
      phoneNumber: string | null;
      isActive: boolean;
      roles: { id: number; name: string; slug: string }[];   // every role this user holds, not just roleId
    }[];
    meta: { total: number; page: number; limit: number };
  }
  ```

  Same shape as `Users - List.bru`'s response (per `user_README.md`), just filtered to users who
  hold `roleId`, with `roles[]` added so the admin can see a user's *other* roles too, not just the
  one being viewed.

---

## Priority 3 addendum — User module: endpoints the frontend is now built against (2026-08-21)

The User/Student/Lecturer/Staff admin UI (`src/services/usersApi.ts`) has been fully wired to the
real endpoints in `bruno/user/`. Along the way, three response-shape details turned out to have no
confirmed example anywhere in bruno or `user_README.md`, plus two features needed real backend
support that doesn't exist yet. Rather than leave the frontend guessing, it's now been **built
against the exact contract below** — please implement/confirm each one so the mapping that already
exists in `usersApi.ts` lines up with what ships:

1. **`GET /users` must include a `roles` array per user** — `{ id: number; name: string; slug:
   string }[]`. The README's own example response for this endpoint doesn't show one; the Users
   table needs it for role badges. If it's already there, no change needed — please just confirm.
2. **`GET /users/students`, `/users/lecturers`, `/users/staff` (and their `/:id` counterparts) must
   nest their relations**, not just return raw FK ids:
   - Students: `program: { id, name, code }`, `program.department: { id, name }`,
     `program.department.faculty: { id, name }`, `currentLevel: { id, name, numericValue }`.
   - Lecturers/Staff: `department: { id, name } | null`, `department.faculty: { id, name }`
     (lecturers only — staff departments don't need faculty nested).
   The frontend renders these as Programme/Department/Faculty/Level columns; if the real response is
   flat, please add the nesting rather than have the frontend do N+1 lookups per row.
3. **`POST /users/staff` must accept and honor an optional `roleId: number`** (`exists:roles,id`).
   `CreateStaffDto` per the README doesn't currently list one (the doc says the backend "assigns the
   appropriate staff role" on its own) — but the create-staff form lets an admin pick a role from the
   real `/auth/roles` list and now sends it as `roleId`. If the backend has its own fixed
   role-assignment logic instead, please say so explicitly so the role picker can be replaced with
   whatever that mechanism actually is, rather than silently doing nothing.

### New: `GET /users/stats`

Needed for the Users Summary dashboard's distribution charts. No client-side derivation (e.g.
paging through every list endpoint) — a dedicated aggregate:

```ts
// GET /users/stats — Admin only
{
  data: {
    totalUsers: number;
    totalStudents: number;
    totalTutors: number;
    totalStaff: number;
    activeUsers: number;
  }
}
```

**Extended by §2.8** with `byFaculty`/`studentsByLevel`/`studentsByGender`/`tutorsByDesignation` —
needed for the Director module's Overview/Statistical tabs. See §2.8 for the full extended shape;
also requests `facultyName`/`departmentName` filters on `GET /users/students`/`GET /users/lecturers`.

### Extend existing: `GET /courses/offerings` with a `lecturerId` filter

This belongs to the Course module (`bruno/course`), not User — flagging here because it's what
unblocks the User module's "Manage Courses" panel on the Tutors page (assign/unassign a lecturer to
a course offering). `POST /courses/offerings/:offeringId/lecturers` and
`DELETE /courses/offerings/:offeringId/lecturers/:lecturerId` already exist and are used as-is; what's
missing is a way to list which offerings a given lecturer is already assigned to. Proposed: add an
optional `lecturerId` query param to the existing list endpoint.

```ts
// GET /courses/offerings?semesterId=&sessionId=&lecturerId=
{
  data: {
    id: number;
    courseId: number;
    course: { code: string; title: string; creditUnits: number };
    academicSessionId: number;
    session: { name: string };
    semesterId: number;
    semester: { name: string };
    maxCapacity: number | null;
    status: "PLANNED" | "OPEN" | "CLOSED" | "CANCELLED";
    role?: "primary" | "assistant" | "tutorial";   // this lecturer's role — only when lecturerId is passed
    assignedAt?: string;                            // CourseOfferingLecturer.createdAt — only when lecturerId is passed
  }[];
  total: number;
}
```

When `lecturerId` is supplied, the result should be filtered to only offerings that lecturer is
assigned to (via `CourseOfferingLecturer`), with `role`/`assignedAt` populated from that join row.
Without it, behaves exactly as today (full/session/semester-filtered list, no `role`/`assignedAt`).
This also happens to specify, as a side effect, the base response shape for the unfiltered endpoint,
which wasn't confirmed by an example body anywhere either — please confirm the nested
`course`/`session`/`semester` objects match, or adjust the frontend mapper in `usersApi.ts` if the
real shape differs.

## Notes for the backend team

- Every gap above was found by tracing real, currently-deployed bruno request/response shapes
  against real frontend code — nothing here is speculative "nice to have," and items already covered
  by an existing per-module doc are referenced rather than re-specified to avoid drift between two
  copies of the same schema.
- Once any of these ship, please add/update the corresponding `.bru` file(s) so `bruno/` stays the
  single source of truth, per this collection's existing convention.
- A number of *frontend*-only gaps were also found during this audit (modules that are 100% mock
  despite already having a complete, matching bruno contract — User Management, Timetable,
  Assessments, Enrollment) — those need no backend work at all and are intentionally **not** listed
  here; see `sandbox/API_INTEGRATION_AUDIT.md` for the full picture.
