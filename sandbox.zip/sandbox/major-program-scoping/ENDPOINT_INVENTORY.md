# Per-Endpoint Inventory — Major-Program Scoping

Companion to `README.md`'s "F. Per-role dashboard data audit" (dashboard-*content*-level: what
each role's screens visually show) — this doc is endpoint-*level*: for every nav item on the 7
scoped roles' dashboards (Tutor, Admin, Dean, Director, HOD, Bursary, Staff, per A27), which
literal API endpoint(s) the screen behind it actually calls, and whether that endpoint is
currently major-program-scoped at all.

Traced directly from source (nav trees in `src/config/nav.config.ts`, page components, query/
mutation hooks, and the service files' literal `apiClient.get/post/patch/delete(...)` calls) —
not guessed, not tested live. Two nav trees cover all 7 roles: `hodNav = tutorNav` (literal
alias) and `deanNav = adminNav` (literal alias — Dean renders the same array under a parallel
`/admin/...` route tree, Admin under `/manager/...`; every page pair checked was byte-identical
between the two trees except where noted).

**Scoping key** used in every table below:
- ✅ **A4-scoped** — one of the 4 endpoints already confirmed server-side major-program-filtered
  (`sandbox/BACKEND_DEVIATIONS_2026-09-14.md` A4, resolved 2026-09-15): `GET /admissions/applications`,
  `GET /users/students`, `GET /fees/invoices`, `GET /courses/offerings`.
- ⚠️ **sent, unconfirmed** — the frontend already sends a `majorProgramId` query param (built
  ahead of the backend per CLAUDE.md §14), but server-side enforcement is not confirmed live (see
  A12/A13/A15 in `BACKEND_DEVIATIONS_2026-09-14.md`).
- ❌ **unscoped** — no `majorProgramId` param sent or supported at all today.
- — **n/a** — no API call (static/config content), or a self-scoped ("my own record") endpoint
  where major-program scoping doesn't apply.

Also relevant: `src/hooks/use-major-program-scope.ts`'s `useMajorProgramScope()` exists and now
(as of this session) has a `withinScope()` helper, but as of this doc nothing in the dashboard
nav or route guards actually *consumes* it to gate access — every endpoint below is scoped (or
not) purely by what the backend does with the `majorProgramId` param, never by anything the
frontend currently withholds.

---

## Admin & Dean — `adminNav` (22 items, shared)

Both roles render the identical `adminNav` array — Admin under `/manager/...`, Dean under a
parallel `/admin/...` tree. Every page pair is byte-identical **except** items 2 and 15, which
exist only under `/manager/...` (no `/admin/...` equivalent) — i.e. **Dean cannot reach Review
Applications or Clearance today, structurally, regardless of any RBAC fix**, since the route
itself doesn't exist under `/admin/`.

| # | Nav Item | Route(s) | Key Hooks | Endpoint(s) | Scoping |
|---|---|---|---|---|---|
| 1 | Dashboard | `/manager\|admin/dashboard` | `usePlatformDashboardData`/`useOperationsDashboardData` | `GET /users/stats`, `GET /academic/departments`, `GET /academic/faculties`, `GET /admissions/applications?status=pending`, `GET /auth/roles`, `GET /fees/reports/summary` | ✅ applications; ❌ rest |
| 2 | Review Applications | `/manager/review-applications` (Manager-only) | `applicationReviewQueryOptions` | `GET /admissions/applications` (+`majorProgramId`), `PATCH .../:id/review`, `POST .../bulk-review` | ✅ list; write endpoints per A28/A29 (new OUT_OF_SCOPE enforcement, this session) |
| 3 | Sessions | `/academics/academic-year` | `useAcademicSessions` et al. | `GET/POST/PATCH/DELETE /academic/sessions[...]`, `/academic/sessions/:id/semesters[...]` | ❌ |
| 4 | Admissions | `/academics/admissions` | `useAdmissionCycles`, `useAdmissionRequirements` | `GET/POST/PATCH/DELETE /admissions/cycles[...]`, `.../requirements[...]`, `GET /academic/programs` | ❌ |
| 5 | Course Structure | `/academics/course-structure` | `useFaculties`/`useDepartments`/`usePrograms`/`useMajorPrograms`/`useCohorts`/`useLevels` | `GET/POST/PATCH/DELETE /academic/faculties[...]`, `/academic/departments[...]`, `/academic/programs[...]`, `/academic/major-programs[...]`, `/academic/cohorts[...]`, `/academic/levels`, `/academic-structure/units[...]` | ❌ (this is the *source* of `majorProgramId` for everything else — not itself filtered by caller scope) |
| 6 | Academic Structure | `/academics/academic-structure` | `useUnitTypes`, `useAcademicUnits` | `GET/POST/PATCH/DELETE /academic-structure/unit-types`, `/academic-structure/units[...]` | ❌ |
| 7 | Courses | `/academics/courses-management` | `useCourses`, `useCourseOfferings`, `useCoursePrerequisites`, `useCurriculumPrograms` | `GET/POST/PATCH/DELETE /courses[...]`, `/courses/programs/:id[...]`, `/courses/offerings[...]` (+lecturers/schedules sub-routes), `/courses/:id/prerequisites[...]` | ✅ offerings list; ❌ courses/curriculum/prerequisites |
| 8 | Demographics | `/configurations/demographics` | `useCountries`/`useStates`/`useLocalGovernments` | `GET/POST/PATCH/DELETE /demographics/countries[...]`, `/demographics/states[...]`, `/demographics/local-governments[...]` | — (not program-scoped by design) |
| 9 | User Mgmt — Summary | `/users/summary` | `useUserStats` | `GET /users/stats` | ❌ |
| 10 | User Mgmt — Students | `/users/students` | `useStudents`, `useUpdateStudent`, `useStudentLookupByMatric` | `GET /users/students` (+`majorProgramId`), `GET .../matric/:no`, `PATCH .../:id` | ✅ list; write per A28/A29 |
| 11 | User Mgmt — Tutors | `/users/tutors` | `useTutors`, `useCreateTutor`, `useUpdateTutor` | `GET /users/lecturers` (+`majorProgramId`), `POST/PATCH /users/lecturers[...]` | ⚠️ sent, unconfirmed |
| 12 | User Mgmt — Staff | `/users/staff` | `useStaffList`, `useCreateStaff`, `useUpdateStaff` | `GET /users/staff` (**no majorProgramId param at all**), `POST/PATCH /users/staff[...]` | ❌ — confirmed no scoping param exists on this one |
| 13 | Documents | `/documents` | `useDocuments` | `GET/PATCH/DELETE /documents[...]`, `/documents/student/:id` | ❌ |
| 14 | Hostels | `/hostels` | `useHostels`, `useAllocations` | `GET/POST/PATCH/DELETE /hostels[...]`, `/hostels/allocations[...]` | ❌ |
| 15 | Clearance | `/manager/clearance` (Manager-only) | `useClearances`, `useClearanceTypes` | `GET /clearance`, `/clearance/types`, `PATCH .../:id/approve\|reject` | ❌ |
| 16 | Fee Management | `/finance/fees` | `useCollectionsSummary`, `useOverdueInvoices`, `useFeeTypes` | `GET /fees/reports/summary`, `/fees/invoices/overdue`, `/fees/types` (+`majorProgramId`), `/fees/invoices` (+`majorProgramId`), `POST .../waive\|cancel` | ✅ invoices list; ⚠️ types; write per A28/A29 |
| 17 | Grades — Summary | `/grades/summary` | `useGradesSummary`, `useCgpaTrendsData` | `GET /results/dashboard`, `/results/grades/distribution`, `/results/programs/performance`, `/results/cgpa/trends`, `/results/students/top-performers`, `/results/grade-scales` | ❌ |
| 18 | Grades — Results | `/grades/results` | `useGrades`, `useStudentTranscript` | `GET /results/grades`, `/results/grades/grouped`, `/results/grades/student/:id`, `/results/cgpa/student/:id` | ❌ |
| 19 | Grades — Publish | `/grades/publish-results` | `usePublishPreview`, `usePublishAction` | `GET /results/grades`, `POST /results/grades/publish/:semesterId` | ❌ |
| 20 | Grades — Grading Schemes | `/grades/grading-schemes` | `useGradingSchemes` | `GET/POST /grading-schemes[...]` | — (institution-wide by nature) |
| 21 | Announcements | `/announcements` | `useAllAnnouncements`, `usePublishedAnnouncements` | `GET/POST/PATCH/DELETE /content/announcements[...]` | — (institution-wide by nature; could gain an optional major-program targeting field later) |
| 22 | Notifications | `/notification` | `useNotificationTemplates`, `useSendNotification` | `GET/POST/PATCH/DELETE /notifications[...]`, `/notifications/templates[...]` | — (mostly self/recipient-scoped) |

**A13 confirmed exactly:** `usersApi.ts` sends `majorProgramId` on `GET /users/students` and
`GET /users/lecturers`, but **not** on `GET /users/staff` — Staff records have no scoping signal
at all today, frontend or backend.

---

## Tutor & HOD — `tutorNav` (9 items, shared; `hodNav = tutorNav`, same `/tutor/...` routes)

| # | Nav Item | Route | Key Hooks | Endpoint(s) | Scoping |
|---|---|---|---|---|---|
| 1 | Dashboard | `/tutor` | `useTutorDashboardData` (composes items 2 + timetable + notifications) | `GET /users/lecturers/me`, `GET /courses/offerings?lecturerId=`, `GET /timetable/schedules/offering/:id`, `GET /timetable/my`, `GET /notifications/unread-count` | — (self-scoped by lecturer id, not major-program) |
| 2 | Course Assignments | `/tutor/courses` | `useAssignedCourses`, `useSyncSchedule` | `GET /courses/offerings?lecturerId=`, `GET/POST/PUT/DELETE /timetable/schedules[...]` | — (lecturer-scoped, not major-program) |
| 3 | Assessments | `/tutor/assessments` | `useAssessmentsList` | `GET /assessments` (**no lecturerId/offeringId filter**), `PATCH /assessments/:id/visibility` | ❌ — no lecturer or major-program filter at all |
| 4 | Attendance | `/tutor/attendance` | `useMyTimetable`, `useEnrollmentsByOffering`, `useBulkRecordAttendance` | `GET /timetable/my`, `GET /enrollments/offering/:id`, `GET /enrollments/attendance/schedule/:id`, `POST /enrollments/attendance/bulk` | — (self-scoped via own timetable) |
| 5 | Timetable | `/tutor/timetable` | `useMyTimetable` | `GET /timetable/my` (server-resolves from session) | — (self-scoped) |
| 6 | Grading — Submit | `/tutor/grading/submit` | `useCourseOfferings` (list, **unscoped**), `useCaPreview`, `useBulkCreateGrades` | `GET /courses/offerings` (**no lecturerId param — unlike item 2's dedicated call**), `GET /results/grades`, `GET /assessments/ca-preview/:id`, `POST /results/grades/bulk` | ❌ — offering picker here is **all offerings system-wide**, not just this tutor's own |
| 7 | Grading — Grade Book | `/tutor/grading/book` | same offering picker as #6 | `GET /courses/offerings` (unscoped), `GET /results/grades/course/:id/semester/:id` | ❌ — same unscoped-picker issue as #6 |
| 8 | Notifications | `/tutor/notifications` | `useNotifications` | `GET /notifications`, `PATCH .../read-all`, `PATCH .../:id/read` | — (self-scoped) |
| 9 | Settings | `/tutor/settings` | `useMyLecturer`, `useUpdateTutor` | `GET /users/lecturers/me`, `PATCH /users/lecturers/:id` | — (self-scoped) |

**Real, concrete finding worth flagging separately:** items 6 and 7 (both Grading screens) pull
their course-offering picker from the **unfiltered** `GET /courses/offerings` — every offering in
the system, not scoped to the tutor's own assignments the way item 2's dedicated
`?lecturerId=` call is, and not scoped by major program either. A tutor can currently select and
grade *any* course's offering from this dropdown, not just their own. This is a real gap
independent of major-program scoping — worth its own line in `BACKEND_DEVIATIONS` or a follow-up
frontend fix (restrict the picker to the tutor's own assigned offerings, same as item 2 already
does), not something this doc is fixing, just recording.

---

## Director — `directorNav` (4 items)

| # | Nav Item | Route | Key Hooks | Endpoint(s) | Scoping |
|---|---|---|---|---|---|
| 1 | Dashboard | `/director/dashboard` | `useDirectorOverview` | `GET /users/stats`, `/academic/faculties`, `/academic/programs`, `/users/students?status=GRADUATED`, `/fees/reports/summary`, `/fees/reports/outstanding`, `/enrollments/trend` | ✅ students; ❌ rest |
| 2 | Student & Lectures | `/director/scholars` | `useDirectorStatistical` | `GET /users/students` (+`majorProgramId`), `GET /users/lecturers` (+`majorProgramId`), `GET /users/stats` | ✅ students; ⚠️ lecturers |
| 3 | Grade Reports | `/director/grades` | `useDirectorGrades` | `GET /results/reports/director-grade-summary` (+`majorProgramId`, sent speculatively per A15/A27 — **not confirmed live**), `/academic/sessions`, `/academic/semesters`, `/academic/major-programs`, `/results/grades`, `/results/grades/distribution` | ⚠️ grade-summary; ❌ rest |
| 4 | Financial Reports | `/director/financial-reports` | `useDirectorFinancial` | `GET /fees/reports/summary`, `/fees/reports/outstanding`, `/fees/reports/collections-trend`, `GET /fees/invoices` (+filters, no majorProgramId confirmed) | ❌ |

**Live-confirmed 403s** (per code comments in `director.service.ts`): `GET /fees/reports/summary`
and `GET /fees/reports/outstanding` currently 403 for DIRECTOR/BURSARY/DEAN roles live — this is
a *different*, pre-existing permissions bug, not a scoping gap; flagging since it directly blocks
half of Director's own Dashboard and Financial Reports screens today regardless of scoping work.

---

## Bursary — 2 nav items (both `/admin/finance/fees`, Dashboard and Fee Management are the same page)

| Nav Item | Route | Key Hooks | Endpoint(s) | Scoping |
|---|---|---|---|---|
| Dashboard / Fee Management | `/admin/finance/fees` | `useCollectionsSummary`, `useOverdueInvoices`, `useFeeTypes` | `GET /fees/reports/summary`, `/fees/invoices/overdue`, `/fees/types` (+`majorProgramId`) | ⚠️ types; ❌ rest |

**Real, live-confirmed finding:** `canSeeReports = role === SUPER_ADMIN \|\| role === ADMIN` only
— for a BURSARY session, `useCollectionsSummary`/`useOverdueInvoices` are called with
`enabled: false` and **never fire at all**. Only `useFeeTypes` actually hits the network for
Bursary. This matches the live 403s noted under Director above (`GET /fees/reports/summary`
403s for BURSARY too) — the frontend's own `enabled: false` gate is working around a real
backend permissions bug, not a scoping one. Worth its own `BACKEND_DEVIATIONS` line if not
already tracked (check for `sandbox/fee-management/bursary_403_bug_report.md`, referenced in
this codebase but its exact current status wasn't re-verified here).

---

## Staff — 4 nav items (shares the `/manager/dashboard` route with Admin/Dean, gets a narrower branch)

| Nav Item | Route | Key Hooks | Endpoint(s) | Scoping |
|---|---|---|---|---|
| Dashboard | `/manager/dashboard` (role-branches to `StaffDashboard`) | `useStaffDashboardData` | `GET /users/students?limit=1`, `GET /clearance?status=PENDING`, `GET /content/announcements?limit=3` | ✅ students (unused param at limit=1); ❌ rest |
| Students | `/manager/users/students` | `useStudents`, `useUpdateStudent`, `useStudentLookupByMatric` | Same as Admin/Dean item 10 above | ✅ list; write per A28/A29 |
| Clearance | `/manager/clearance` | `useClearances`, `useApproveClearance`, `useRejectClearance` | `GET /clearance`, `/clearance/types`, `PATCH .../:id/approve\|reject` | ❌ |
| Announcements | `/manager/announcements` | `useAllAnnouncements`, `usePublishedAnnouncements` | `GET /content/announcements[/all]`, `POST/PATCH/DELETE .../:id[...]` | — (institution-wide by nature) |

---

## Summary — biggest unscoped clusters, by how many roles/screens depend on them

1. **`/academic/*` structure endpoints** (faculties, departments, programs, sessions, cohorts,
   levels, major-programs, curriculum) — completely unscoped, touched by Admin/Dean's Sessions,
   Admissions, Course Structure, Academic Structure, and Courses nav items (5 of 22 items), plus
   indirectly informs every other screen's filters. This is also the *source* endpoint for
   `majorProgramId` itself — narrowing it by caller scope needs care (a scoped Admin still needs
   to read *their own* major program's structure, just not every other one's).
2. **`/results/*` grading/reports endpoints** — completely unscoped across all 6 Grades nav items
   (Admin/Dean) plus Director's Grade Reports and Tutor's two Grading screens. Zero `majorProgramId`
   support anywhere in this cluster except Director's single speculative send on
   `director-grade-summary`.
3. **`GET /users/staff`** — the only one of the three user-list endpoints (students/lecturers/staff)
   with *no* `majorProgramId` param at all, frontend or backend — confirmed via direct code read,
   not inferred.
4. **`GET /courses/offerings` used unscoped** on Tutor's two Grading screens — a real,
   independent gap (any tutor can grade any offering, not just their own), separate from
   major-program scoping but touching the same endpoint that *is* properly lecturer-scoped
   elsewhere (Course Assignments).
5. **Fee Types/Invoices/eligible-count already send `majorProgramId`** (A12/A13, sent speculatively) —
   closest cluster to being ready; just needs backend enforcement confirmed, no frontend change
   needed once it ships.
6. **Two live, pre-existing 403 bugs, unrelated to scoping** — `GET /fees/reports/summary` and
   `GET /fees/reports/outstanding` 403 for DIRECTOR/BURSARY/DEAN today, worth tracking separately
   so they aren't mistaken for a scoping symptom once scoping ships and someone re-tests these
   screens.
