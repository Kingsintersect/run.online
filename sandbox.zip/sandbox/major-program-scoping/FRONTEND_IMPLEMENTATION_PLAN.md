# Frontend Implementation Plan — Major-Program Scoping

Internal build plan for the frontend side of `README.md`/`SCHEMA_CHANGES.md`/`API_CONTRACTS.md`.
**Not needed by the backend team** — same split as `sandbox/multi-program-platform/` uses. This
covers what changes in the actual dashboards/interfaces per role once the backend ships the scope
model, so nothing gets built that silently assumes "one institution-wide everything" the way the
current codebase does today.

---

## 0. The governing rule, restated for UI

A single-major-program deployment must render **identically** to today — no scope picker, no
"switch program" selector, no extra step in any form — because `majorProgramScope` resolves to
exactly one value everywhere. Every UI piece below is conditional on `majorProgramScope.length > 1`
(or `"ALL"` for `SUPER_ADMIN`). If a component needs a `institution has multiple major programs`
branch that changes its *layout*, not just its data, the design is wrong — prefer resolving to "one
item, no picker shown" over "picker shown, disabled" for the single-program case.

## 1. `SUPER_ADMIN`

- **New screen: Major Programs management** — CRUD for `MajorProgram` (create/edit/deactivate),
  living in `src/modules/academics/_components/academic-structure/` alongside the existing
  Faculty/Department/Program panels. Only `SUPER_ADMIN` gets write access here (per
  `API_CONTRACTS.md` §6) — a scoped `ADMIN` should never see "create a new major program," since
  that's an institution-level decision, not something within any single scope.
  - Assigning `Program.majorProgramId` becomes a required field on `ProgramFormDialog.tsx`
    (currently only collects `programCategory` — needs a second select, populated from the new
    `MajorProgram` list).
- **User creation/role management** (`CreateUserModal.tsx`, `ManageRolesModal.tsx`) — gains a
  Major Program multi-select, shown once at least one selected role is not `STUDENT`/`SUPER_ADMIN`.
  `SUPER_ADMIN` is the only role that can assign scope to other users' grants, matching who is
  allowed to call `POST /roles/assign` with `major_program_ids` today's RBAC section of `CLAUDE.md`
  would gate this by permission, not by hardcoding to `SUPER_ADMIN` in the component — the UI's job
  is to hide the field when `usePermissions().can({resource:'roles', action:'assign-scoped'})` is
  false, matching `<PermissionGate>` convention, not a role check.
- Sees everything unscoped (`majorProgramScope: "ALL"`), so no filter chips/selectors appear
  anywhere in their own dashboards — this is the "full control" case `CLAUDE.md`'s route-ownership
  section already establishes for `SUPER_ADMIN`, unchanged.
- Institution-wide reports (Director-style dashboards, if `SUPER_ADMIN` has access to them) gain an
  optional "break down by major program" grouping toggle — a reporting nicety, not a gate.

## 2. `ADMIN` (scoped — e.g. an admissions officer for one program)

- **Admissions applicant list/queue** (`process-admission` module and wherever applicant review
  lives) — no explicit filter UI needed for a single-scoped admin (the backend already returns only
  their scope, per `API_CONTRACTS.md` §2); for a multi-scoped admin (rare, but the schema allows
  it), add a major-program tab/dropdown at the top of the list that narrows via the optional
  `?majorProgramId=` query param (§3 of `API_CONTRACTS.md`) — purely a convenience filter, the
  backend enforcement is what actually protects the data.
- **Grant/reject admission decision actions** — no UI change needed beyond the above; a 403
  `OUT_OF_SCOPE` response (should never actually be reachable if the list UI only ever shows
  in-scope applicants) should render the existing app-wide error-toast pattern, not a custom one.
- **Fee/invoice management screens** — same pattern: single-scoped admin sees only their program's
  fee types/invoices with no extra chrome; multi-scoped admin gets the same tab/dropdown pattern as
  applicants, for consistency.
- **Session/Semester management** (if this admin has permission to manage academic calendar) —
  the "create session" form needs the majorProgramId picker added (mirrors `SUPER_ADMIN`'s, but
  pre-selected/locked to the admin's own scope if they're not `SUPER_ADMIN`).

## 3. `STUDENT`

- No new screens, but every place that currently assumes **one global "current session/semester"**
  needs to resolve it through the student's own program's major-program scope instead:
  - Course registration window / registration-open banner.
  - Fee due-date display and payment prompts.
  - Timetable ("this week" / "this semester" views).
  - Results/transcript "current semester" context.
  - The likely current implementation is a single `useActiveSession()`-style hook assuming one
    global row — this needs to resolve "the active session for *my* program's major program"
    instead. Concretely: the student's `program.majorProgramId` determines which
    `AcademicSession` (`WHERE majorProgramId = X AND isActive = true`) applies to them — a query
    parameter change on the existing hook, not a new UI surface.
- Nothing about Certificate/Foundational-specific students changes here beyond what
  `program-structure-depth/` already covers (Cohort-based UI instead of Level/Session for
  Certificate students) — this doc doesn't add anything new on top of that for the student side.

## 4. `TUTOR` (lecturer)

- Can hold multiple scoped grants (one `UserRole` row per major program they teach in, per
  `SCHEMA_CHANGES.md` §3). Their course/offering list, gradebook, and roster screens need the same
  multi-scope tab/dropdown pattern as `ADMIN` — shown only when `majorProgramScope.length > 1`.
- `tutor-courses` module's query hooks need to pass through whichever major program is currently
  selected (or all, if the backend endpoint supports an unfiltered multi-scope list — matches
  `API_CONTRACTS.md` §3's "omitting the param returns everything in scope" behavior).

## 5. `HOD` / `DEAN`

- Explicitly **out of scope for this plan.** These roles are currently scoped by Department/Faculty
  (`hodUserId`/`deanUserId`), a different axis than major-program scoping — a Department can belong
  to a Faculty that spans multiple major programs (e.g., a "Business Administration" department
  might sit under a Faculty that contains both a `DEGREE`-shaped BSc and a `BUSINESS_SCHOOL`-scoped
  executive program). Reconciling department-scoping with major-program-scoping (does an HOD's
  authority follow their department across major programs, or stop at their major program's
  boundary?) is a real open question, but a different one from what this doc's design answers —
  flag it for a follow-up design pass once major-program scoping actually ships and the real
  cross-cutting cases show up, rather than guessing at a resolution now. Today's alias-to-Tutor-nav
  behavior for HOD stays unchanged by this plan.

## 6. `BURSARY` / `DIRECTOR`

- Reporting/analytics dashboards (revenue, enrollment counts, etc.) gain a "by major program"
  breakdown dimension in their existing charts/tables — additive, not a gate; these roles are
  likely to be unscoped (institution-wide) more often than `ADMIN`, so the default view stays
  aggregate with an optional drill-down, rather than requiring a program selection up front.

## 7. Shared infrastructure

- **New hook** `src/hooks/use-major-program-scope.ts` (`useMajorProgramScope()`) — reads
  `majorProgramScope` from the session/`app.store.ts`, exposes:
  - `scopedProgramIds: number[] | "ALL"`
  - `isMultiScoped: boolean` (drives whether any picker/tab UI renders at all)
  - `activeMajorProgramId: number | null` (the currently-selected filter, for multi-scoped users —
    persisted per-session in `app.store.ts`, not re-derived per page)
- **New shared component** `<MajorProgramFilterTabs />` (or a `<Select>` variant) — one
  implementation reused across Admissions/Fees/Tutor-courses/Session-management rather than four
  bespoke pickers, gated entirely by `isMultiScoped`.
- Every existing query-key factory (`query-keys.ts`) for scoped resources (applications, invoices,
  offerings, sessions) needs `activeMajorProgramId` folded into its key, so React Query cache
  entries don't collide across a multi-scoped user's program switches.

## 8. Rollout order (frontend side, once backend ships each phase)

1. `useMajorProgramScope()` + the shared filter component — build once, unblocks everything else.
2. Student-facing "resolve active session via my major program" fix — highest user-visible impact
   if skipped (a student in a program with its own calendar would otherwise see the wrong or no
   active session).
3. Admin/Tutor list-screen filter tabs — additive, ship per-module as each backend endpoint adds
   scope enforcement.
4. `SUPER_ADMIN` Major Program management screen + `ProgramFormDialog` field — can ship anytime
   after the backend's `MajorProgram` CRUD exists, independent of the rest.
5. User-creation/role-assignment scope picker — depends on `MajorProgram` list existing (step 4),
   otherwise there's nothing to populate the multi-select with.
