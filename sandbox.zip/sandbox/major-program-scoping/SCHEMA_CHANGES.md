# Schema Changes — Major-Program Scoping

Diff against the current schema plus `program-structure-depth/SCHEMA_CHANGES.md` (assumed already
applied — this doc doesn't repeat the `Cohort`/nullable-`Level` changes). Same disclaimer as the
prior docs: names are taken from audited frontend types/schemas/bruno contracts, not the live
Prisma source — rename to match your real models, the columns/relations/nullability are what
matter.

---

## 1. New model — `MajorProgram`

```prisma
model MajorProgram {
  id                    Int       @id @default(autoincrement())
  code                  String    @unique   // "DEGREE_PROGRAMMES", "PART_TIME_PROGRAMMES", ...
  name                  String               // "Part-Time Programmes"
  description           String?
  isActive              Boolean   @default(true)
  moodleRootCategoryId  Int?                 // set once the Moodle-sync root category is pushed

  programs              Program[]
  academicSessions      AcademicSession[]
  userRoles             UserRole[]

  createdAt             DateTime  @default(now())
  updatedAt             DateTime  @updatedAt
}
```

New model, no migration risk. Seed with one row per operational grouping (see `README.md` §4.A for
suggested initial codes matching the existing Moodle category screenshot).

```diff
 model Program {
   id                     Int             @id @default(autoincrement())
   departmentId           Int?
+  majorProgramId         Int?            // nullable during migration; API requires it on create going forward
+  majorProgram           MajorProgram?   @relation(fields: [majorProgramId], references: [id])
   name                   String
   ...
   programCategory        ProgramCategory @default(DEGREE)
   ...
 }
```

**Migration:** add the column nullable, backfill existing `Program` rows by mapping their current
`programCategory` to a seeded `MajorProgram` 1:1 as a starting point (e.g. every `CERTIFICATE`
row → `CERTIFICATE_PROGRAMMES`), then let admins re-assign any program that should actually belong
to a finer-grained major program (e.g. moving a `DEGREE` row into `BUSINESS_SCHOOL` once that major
program is created) — the backfill is a reasonable default, not a permanent 1:1 lock.

---

## 2. Modified model — `AcademicSession`

```diff
 model AcademicSession {
   id              Int      @id @default(autoincrement())
   name            String
   startDate       DateTime
   endDate         DateTime
   isActive        Boolean
+  majorProgramId  Int?     // null = institution-wide shared session (today's exact behavior)
+  majorProgram    MajorProgram? @relation(fields: [majorProgramId], references: [id])
 }
```

```diff
- CREATE UNIQUE INDEX one_active_session ON academic_sessions (is_active) WHERE is_active = true;
+ -- Two partial indexes: one for the shared/global session (majorProgramId IS NULL), one per
+ -- scoped major program. A single expression index handles both cases since NULL is never equal
+ -- to NULL in a unique index — Postgres already treats each NULL as distinct, so a plain
+ -- (major_program_id) unique-where-active index would incorrectly allow multiple concurrent
+ -- "global" active sessions. Use a coalesced sentinel instead:
+ CREATE UNIQUE INDEX one_active_session_per_scope
+   ON academic_sessions (COALESCE(major_program_id, -1)) WHERE is_active = true;
```

`Semester` needs no column change — it already scopes via `academicSessionId`, and inherits
whatever `majorProgramId` its parent session has. **Migration risk:** existing rows all have
`majorProgramId = null`, which continues to enforce "exactly one active global session" exactly as
today — the constraint only relaxes further once a row with a real `majorProgramId` is created.
Verify against a production data copy before applying, per `README.md` §6.

---

## 2a. Modified model — `FeeType` (added 2026-09-14, real gap found in use)

`FeeType` already scopes by `sessionId`/`programId`/`levelId` (all nullable — §3 of `README.md`
lists this as already live). That's enough to scope a fee to **one specific program** (set
`programId`), but there's no way to say "this fee applies to every program under this major
program" without a real column for it — leaving `programId` null today means "every student in the
entire institution," not "every student under Part-Time." A Certificate-programs tuition fee and a
Part-Time-programs tuition fee currently can't both be scoped to just their own major program's
students; the admin can only scope down to one exact program at a time, or not at all.

```diff
 model FeeType {
   id                 Int       @id @default(autoincrement())
   name               String
   description        String?
   category           FeeCategory
   amount             Decimal
   sessionId          Int?
   programId          Int?
   levelId            Int?
+  majorProgramId     Int?      // null = no major-program restriction (today's exact behavior)
+  majorProgram       MajorProgram? @relation(fields: [majorProgramId], references: [id])
   studentType        StudentType @default(ALL)
   isMandatory        Boolean   @default(true)
   allowInstallments  Boolean   @default(false)
   isActive           Boolean
   createdAt          DateTime  @default(now())
 }
```

**Resolution table** (same governing rule as everywhere else in this doc — most specific wins,
`null` at every level = institution-wide, unchanged from today):

| `majorProgramId` | `programId` | Applies to |
|---|---|---|
| `null` | `null` | Every student, institution-wide (today's exact behavior) |
| set | `null` | Every student in every program under that major program |
| (either) | set | Only that program's students — `programId` is already fully specific; when both are sent, the backend should validate `program.majorProgramId === majorProgramId` (or just derive/overwrite `majorProgramId` from the program server-side rather than trusting the client's value) |

`sessionId`/`levelId` keep composing exactly as they do today, independent of this — e.g.
"Part-Time tuition, Level 200, 2026/2027 session" sets `majorProgramId` + `levelId` + `sessionId`
together with `programId` left null.

**Migration risk:** none — additive, nullable, every existing row keeps `majorProgramId = null` and
keeps meaning exactly what it means today.

**Also needed:** `GET /fees/types/eligible-count` (the "how many students would this apply to"
preview, `MISSING_BACKEND_APIS.md` §2.9 — already flagged as low-priority/not-yet-shipped) should
accept the same `majorProgramId` filter, or the preview count will be wrong for a "whole major
program" fee once this ships.

---

## 2b. Modified model — `Faculty` (added 2026-09-15, real gap found in use)

Today a `Faculty` has no `majorProgramId` of its own — README.md §4.E documents its major-program
membership as **derived bottom-up**, through whichever Departments/Programs happen to sit under it
(`Faculty -> Department -> Program.majorProgramId`). That derivation is real and already works
(both `Department.facultyId` and `Program.majorProgramId` are confirmed live), but it has a gap:
a brand-new Faculty with no Departments/Programs under it yet has no major-program membership at
all, so it can't be grouped correctly — e.g. when reconciling a Moodle category that is itself a
Faculty-shaped node living directly under a major-program root (`Moodle-Sync Reconciliation` —
resolving "Natural Sciences" under the "PART-TIME PROGRAMS" Moodle category needs to say so
immediately, not wait until a Program is created under it).

```diff
 model Faculty {
   id            Int       @id @default(autoincrement())
   name          String
   code          String    @unique
   description   String?
   deanUserId    Int?
   email         String?
   phoneNumber   String?
+  majorProgramId Int?     // null = institution-wide (today's exact behavior)
+  majorProgram   MajorProgram? @relation(fields: [majorProgramId], references: [id])
   isActive      Boolean   @default(true)
   createdAt     DateTime  @default(now())
 }
```

**Resolution table:** same governing rule as everywhere else in this doc — a Faculty's *effective*
major-program membership is the direct `majorProgramId` when set, else the existing derived
bottom-up computation stays the fallback (a Faculty can still legitimately straddle several major
programs through different Departments — the direct field is an *additional*, more specific signal
for the common case of a Faculty that only ever serves one major program, not a replacement for
the derived case).

**Migration risk:** none — additive, nullable, every existing row keeps `majorProgramId = null` and
every screen that filters/derives Faculty membership today keeps working unchanged.

**Frontend:** built ahead 2026-09-15 — `Faculty.majorProgramId`/`CreateFacultyPayload.
majorProgramId` (`src/types/school.d.ts`), a Major Program field on `FacultyFormDialog.tsx`
(shown once there's more than one active major program), and `FacultiesPanel.tsx`'s filter now
checks the direct field first, falling back to the derived bottom-up map when it's null/undefined
— which is always, until this ships. An amber note in the form says so plainly.

---

## 2c. Modified model — `Department` (added 2026-09-16, found auditing the real Moodle category tree)

**The real gap this closes:** `Program` can already attach directly to a Faculty, skipping
Department, via `Program.parentAcademicUnitId` (§ n/a — already live, `resolveFacultyAcademicUnit()`
in `academicStructureApi.ts`). `Program` can also already attach directly to a *Major Program* the
same way, once `resolveMajorProgramAcademicUnit()` is wired into `ProgramFormDialog.tsx` (done
2026-09-16, no schema change needed — `Program` already had both `majorProgramId` and
`parentAcademicUnitId`). **`Department` has neither escape hatch.** It can only be created with a
real `facultyId`, so there is no way today to represent a Department that sits directly under a
Major Program with no Faculty in between — the exact shape the real Moodle category tree already
uses: `PART-TIME PROGRAMS` (major-program category) → `Natural Sciences` (a department-shaped
category, no faculty layer) → `B.Sc. Matths And Statistics` (a program). Today, resolving "Natural
Sciences" in the Moodle Sync dialog can only offer Entity Kinds that already have a home for it
(Faculty/Department/Program/Level/Semester/Major Program), and Department requires a `facultyId`
that doesn't exist for this node — there's no correct answer to give.

```diff
 model Department {
   id            Int       @id @default(autoincrement())
-  facultyId     Int
+  facultyId     Int?      // nullable — see parentAcademicUnitId below
   name          String
   code          String    @unique
   description   String?
   hodUserId     Int?
   email         String?
   phoneNumber   String?
+  majorProgramId       Int?     // null = institution-wide / derived (see resolution table)
+  majorProgram         MajorProgram? @relation(fields: [majorProgramId], references: [id])
+  parentAcademicUnitId Int?     // set instead of facultyId when this Department attaches directly
+                                 // to a Major Program's (or any other) AcademicUnit root, mirroring
+                                 // Program.parentAcademicUnitId exactly
+  parentAcademicUnit   AcademicUnit? @relation(fields: [parentAcademicUnitId], references: [id])
   isActive      Boolean   @default(true)
   createdAt     DateTime  @default(now())
 }
```

**Resolution table** — same shape as §2b's Faculty addition and `Program`'s existing
`departmentId`/`parentAcademicUnitId` pair:

| `facultyId` | `parentAcademicUnitId` | Meaning |
|---|---|---|
| set | `null` | Today's exact behavior — Department belongs to a Faculty, unchanged |
| `null` | set | Department attaches directly to whatever `AcademicUnit` `parentAcademicUnitId` points at (a Major Program's root node, for this use case) — no Faculty |
| `null` | `null` | Invalid — a Department needs exactly one anchor, same rule `Program` already enforces between `departmentId`/`parentAcademicUnitId` |
| set | set | Invalid — pick one, don't send both |

`Department.majorProgramId` follows the exact same **direct-field-first, derived-fallback** rule
§2b already established for Faculty: when set, it's authoritative; when null, effective major-program
membership derives from whichever Program rows sit under this Department
(`Department -> Program.majorProgramId`). Setting `majorProgramId` explicitly is expected any time
`parentAcademicUnitId` is used (a Department with no Faculty has no other way to derive membership
until a Program is created under it — same "brand-new Faculty with no children" gap §2b already
documents, worth avoiding a second time by requiring `majorProgramId` whenever `facultyId` is null).

**Migration risk:** low. `facultyId` moving from required to nullable is the one real breaking-shape
change — every existing row already has a real `facultyId`, so no data migration needed, only a
constraint relaxation, and existing reads/writes that only ever send `facultyId` keep working
unchanged. `majorProgramId`/`parentAcademicUnitId` are purely additive and nullable, same
zero-risk pattern as every other `majorProgramId` addition in this doc.

**Frontend:** not built yet — this is a documented proposal only, `sandbox/major-program-scoping/`.
Once this ships, the natural build (mirroring what already exists for `Program`) is: a
`parentAcademicUnitId`-based "directly under a Major Program" mode on `DepartmentFormDialog.tsx`
(parallel to `ProgramFormDialog.tsx`'s `majorProgram` prop, built 2026-09-16), reachable from
`MajorProgramsPanel.tsx` the same way "Add program directly here" is, and a `majorProgramId` field
on the Department form mirroring `ProgramFormDialog`'s existing one.

---

## 3. Modified model — `UserRole` (the RBAC grant/join row)

```diff
 model UserRole {
   userId          Int
   roleId          Int
   assignedBy      Int?
   assignedAt      DateTime  @default(now())
   expiresAt       DateTime?
+  majorProgramId  Int?      // null = unscoped (SUPER_ADMIN default; usable for any deliberately
+                             // institution-wide grant, e.g. a Registrar who legitimately spans all programs)
+  majorProgram    MajorProgram? @relation(fields: [majorProgramId], references: [id])

-  @@unique([userId, roleId])
+  @@unique([userId, roleId, majorProgramId])
 }
```

**Breaking at the constraint level, safe for data:** the old `[userId, roleId]` unique forbade a
user holding the same role twice. The new one scopes that uniqueness by major program, so the same
user can hold `TUTOR` scoped to two different major programs as two separate rows. Every existing
row gets `majorProgramId = null` on migration — **this is the one place where "null" needs an
explicit, deliberate meaning decision, not just "unaffected":**

- If existing role grants should keep their current *effectively unscoped* behavior (they can see
  everything today, nothing scopes them), leave them `null` and treat `null` as "see everything"
  **only** during a transition window, OR
- If enforcement (see `API_CONTRACTS.md` §2) should apply immediately, existing grants need an
  explicit backfill assigning each user's real major-program scope before the enforcement flag
  flips on — recommended, since silently treating pre-existing `null` rows as "sees everything"
  forever defeats the purpose of adding this column at all.

Pick one explicitly and document it in the migration — don't let it default silently either way.

**Decided 2026-09-16, answers the "null" question above for new rows going forward** (existing-row
backfill is still a separate migration decision): every *new* `UserRole` row for Tutor, Admin, Dean,
Director, HOD, Bursary, or Staff must be created with a non-null `majorProgramId` — the API layer
(§4 below) rejects creating one of these roles without it. `null` stays meaningful only for
`SUPER_ADMIN` (always) and the rare deliberate "Registrar spans every program" case this doc already
allowed for. See `README.md`'s "C/D — Revised 2026-09-16" section for the full instruction this
implements.

---

## 4. Modified — user-creation payload

Backs `POST /users` (`src/modules/user-management/schemas/index.ts:5-19`).

**Revised 2026-09-16 — singular and required for the seven scoped roles, not the optional array
originally proposed.** Full contract: `API_CONTRACTS.md` §5.

```diff
 model CreateUserRequest {
   email          String
   username       String
   password       String
   firstName      String?
   middleName     String?
   lastName       String?
   phoneNumber    String?
   roleIds        Int[]
+  majorProgramId Int?     // required when roleIds includes Tutor/Admin/Dean/Director/HOD/
+                          // Bursary/Staff — 422 if omitted for any of those. Omit (or must be
+                          // null) for Student/Applicant/Super Admin creation.
 }
```

No new table — resolves into one `UserRole` row per `(roleId, majorProgramId)` pair per §3, using
the existing role-assignment write path.

---

## 5. Summary

| Model | Change | Breaking? |
|---|---|---|
| `MajorProgram` | new model | New |
| `Program.majorProgramId` | new, nullable | No — backfillable from `programCategory` |
| `AcademicSession.majorProgramId` | new, nullable | No for data; unique-active-session constraint changes shape (see migration note) |
| `UserRole.majorProgramId` | new, nullable; uniqueness widened; **required (non-null) for new Tutor/Admin/Dean/Director/HOD/Bursary/Staff rows, decided 2026-09-16** | No for data; existing rows still need an explicit backfill/null-meaning decision (see §3) |
| User-creation payload | `+majorProgramId` (singular, required for the 7 scoped roles — revised 2026-09-16, was optional `majorProgramIds[]`) | No for `Student`/`Applicant`/`Super Admin`; new required-field validation for the other 7 roles |
| `Faculty.majorProgramId` | new, nullable | No — direct field, existing derived-fallback logic untouched |
| `Department.majorProgramId` / `.parentAcademicUnitId`, `.facultyId` now nullable | new, nullable; one constraint relaxed | No for data — every existing row already has a real `facultyId`; only the "must have one" constraint shape changes (§2c) |

Nothing existing is removed or renamed. Every current single-major-program deployment keeps
`majorProgramId = null` everywhere and sees no behavioral change until it deliberately creates a
second `MajorProgram` row and starts scoping grants to it.
