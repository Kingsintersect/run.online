# API Contracts — Major-Program Scoping

Full request/response contracts for `SCHEMA_CHANGES.md`. Existing endpoints not listed here are
unchanged.

---

## 1. `GET /auth/me` (or equivalent session/login response) — carries resolved scope

The frontend needs the caller's scope on every page load, not re-derived per-request. Add it
alongside the existing permission list:

```jsonc
// Response 200
{
  "id": 14,
  "email": "admissions.cert@run.edu.ng",
  "roles": [{ "id": 3, "name": "Admin", "slug": "admin" }],
  "permissions": [ /* existing flat resource+action list, unchanged */ ],
  "majorProgramScope": [
    { "id": 4, "code": "CERTIFICATE_PROGRAMMES", "name": "Certificate Programmes" }
  ]
  // SUPER_ADMIN gets: "majorProgramScope": "ALL" — a sentinel, not an enumerated list, since
  // new major programs created later must be visible immediately without re-granting anything.
}
```

**Frontend note:** `usePermissions()` stays unchanged (`can()`/`canAll()`/`canAny()` still answer
"can I do X at all"). A new `useMajorProgramScope()` hook reads `majorProgramScope` from this
response purely for UI purposes (default filter value, a "switch program" selector for a
multi-scoped lecturer, hiding a scope-picker entirely for a single-scoped admin). It is a mirror of
the server's enforcement below, never a substitute for it.

---

## 2. Scope enforcement on list/detail endpoints — the contract every program-scoped endpoint follows

Applies to: applicant/application lists, student lists, fee/invoice lists, course-offering lists,
and any other endpoint returning rows that belong to a `Program` (transitively, to a
`MajorProgram`).

**Rule:** resolve the caller's `majorProgramScope` (per §1) server-side from their active
`UserRole` rows (never trust a client-supplied scope filter as authorization — a client-passed
`majorProgramId` query param may narrow the result set for convenience, but must be intersected
with, never substituted for, the server-resolved scope). `SUPER_ADMIN` bypasses the filter
entirely. Every other caller's query becomes:

```sql
WHERE program.major_program_id IN (:callerScopeIds)
```

A caller with an empty scope (`majorProgramScope: []` — a role grant exists but no
`majorProgramId` was ever assigned) gets an empty result set, not an unfiltered one — "no scope
assigned" must never silently mean "see everything" outside of `SUPER_ADMIN`.

### Error response — caller attempts to act on an out-of-scope record (403)

```json
{
  "statusCode": 403,
  "error": "OUT_OF_SCOPE",
  "message": "You do not have access to applications for major program 'Part-Time Programmes'.",
  "details": { "requestedMajorProgramId": 2, "callerScope": [4] }
}
```

Return this on a direct-object access attempt (`GET/PATCH /admissions/applications/{id}` for an
application outside the caller's scope) rather than a bare 404 — a 404 here would make scope
violations indistinguishable from typos during integration testing; 403 with this shape makes them
obvious immediately. (If your security posture prefers not to reveal that a resource exists at all
to an out-of-scope caller, use 404 instead — a valid alternative, just be consistent about which
one you pick and document it for the frontend team.)

---

## 3. `POST /admissions/applications?majorProgramId=4` and similar list endpoints — optional narrowing param

```jsonc
// Request: GET /admissions/applications?majorProgramId=4&status=PENDING
```

`majorProgramId` here is a **convenience narrower** for a multi-scoped caller (e.g. a Registrar
scoped to all four major programs who wants to filter their view down to one) — omitting it returns
every record across the caller's full scope, not an error. Passing a `majorProgramId` outside the
caller's scope returns the §2 403, not a silently-empty list (silently-empty would look like "no
applicants" instead of "you asked for something you can't see," which hides a real bug in whatever
UI sent that request).

---

## 4. `POST /roles/assign` — scoped role assignment

Backs `AssignRolesPayload` (`src/types/roles.d.ts`).

```diff
 {
   "user_id": 14,
-  "role_ids": [3]
+  "role_ids": [3],
+  "major_program_ids": [4]   // optional; paired positionally with role_ids if lengths match and
+                              // per-role scoping is needed, otherwise applied to every role_id
+                              // (cross-product) — pick one convention and document it; the
+                              // cross-product is simpler to implement and sufficient unless a
+                              // single call needs to grant different scopes to different roles
+                              // in one request (rare — usually one role per call in the existing UI)
 }
```

```jsonc
// Response 200
{
  "userId": 14,
  "grants": [
    { "roleId": 3, "roleName": "Admin", "majorProgramId": 4, "majorProgramName": "Certificate Programmes" }
  ]
}
```

Omitting `major_program_ids` grants unscoped roles — today's exact behavior, unchanged. This is
the path `STUDENT`/`SUPER_ADMIN` creation keeps using.

---

## 5. `POST /users` — user creation with scope

**Revised 2026-09-16 — singular and required, not the optional array below.** Direct instruction:
Tutor, Admin, Dean, Director, HOD, Bursary, and Staff accounts must be scoped to exactly one major
program at creation time, not left optionally unscoped or multi-scoped. `STUDENT`/`APPLICANT`
accounts never take this field (their scope is derived, per `README.md` §D); `SUPER_ADMIN` accounts
never take it either (always unscoped). See `README.md`'s "C/D — Revised 2026-09-16" section for
the full reasoning.

```diff
 {
   "email": "admissions.cert@run.edu.ng",
   "username": "cert_admissions",
   "password": "...",
   "first_name": "Amaka",
   "last_name": "Nwosu",
-  "role_ids": [3]
+  "role_ids": [3],
+  "major_program_id": 4   // required when role_ids includes any of Tutor/Admin/Dean/Director/
+                          // HOD/Bursary/Staff; omitted (or must be null) for Student/Applicant/
+                          // Super Admin. 422 VALIDATION_ERROR if a scoped role is requested
+                          // without it, or if a Student/Applicant/Super Admin role is combined
+                          // with a non-null value.
 }
```

```jsonc
// 422 — a scoped role requested with no major_program_id
{
  "statusCode": 422,
  "error": "MAJOR_PROGRAM_REQUIRED",
  "message": "role 'admin' requires a major_program_id at creation.",
  "details": { "roleId": 3, "roleName": "admin" }
}
```

Resolves into one `UserRole` row (`role_id`, `major_program_id`) via the same §4 grant logic —
still not a separate scoping mechanism, just a stricter, singular shape for the common
one-person-one-scope case. Granting a *second* scope to an already-created account later (the rare
cross-major-program staff member) still goes through §4's array form, unchanged, since that's a
role-assignment action, not account creation.

<details>
<summary>Original design (superseded above) — optional, array-valued, for reference</summary>

```diff
 {
   "email": "admissions.cert@run.edu.ng",
   "username": "cert_admissions",
   "password": "...",
   "first_name": "Amaka",
   "last_name": "Nwosu",
   "role_ids": [3],
+  "major_program_ids": [4]
 }
```

Same cross-product resolution as §4 — this endpoint is a convenience that creates the user and
calls the §4 grant logic in one request, not a separate scoping mechanism.

</details>

---

## 6. `MajorProgram` CRUD — new endpoints

Same conventions as `bruno/academic/` Faculty/Department CRUD.

### `POST /academic/major-programs`

```jsonc
// Request
{ "code": "BUSINESS_SCHOOL", "name": "Business School", "description": "Executive & degree programmes run by the Business School" }

// Response 201
{ "id": 5, "code": "BUSINESS_SCHOOL", "name": "Business School", "description": "...", "isActive": true, "moodleRootCategoryId": null, "createdAt": "...", "updatedAt": "..." }
```

### `GET /academic/major-programs`

```jsonc
{ "data": [ /* MajorProgram rows, + "programCount": number, + "activeSessionId": number|null */ ] }
```

### `PATCH /academic/major-programs/{id}` / `DELETE /academic/major-programs/{id}`

Standard CRUD; `DELETE` blocked (409 `MAJOR_PROGRAM_HAS_PROGRAMS`) while any `Program` still
references it — same immutable-once-referenced convention `Level` already follows
(`src/services/courseStructureApi.ts`).

---

## 7. Frontend call sites that need updating once this ships

(For the frontend implementation plan, not the backend team.)

- `src/types/roles.d.ts` — `UserRole` gains `major_program_id`; new `MajorProgramScope` type
  (`{id, code, name}[] | "ALL"`) attached to the session/`me` response.
- `src/modules/user-management/schemas/index.ts` — `createUserSchema` gains optional
  `major_program_ids: z.array(z.number().int().positive()).optional()`; `CreateUserModal.tsx` gains
  a major-program multi-select, shown only when the selected role(s) are non-STUDENT/SUPER_ADMIN.
- New hook `src/hooks/use-major-program-scope.ts` (`useMajorProgramScope()`), mirroring
  `use-permissions.ts`'s shape — reads `majorProgramScope` from the auth/session store
  (`app.store.ts`), exposes `scopedProgramIds`, `isUnscopedSuperAdmin`, and a `withinScope(id)`
  helper for client-side UI convenience (never authorization).
- Every admin list screen that currently fetches applicants/students/fees/courses institution-wide
  (e.g. `src/modules/*/hooks/use-*.ts` query hooks) needs its query key and request to include the
  resolved scope — in practice this mostly means: stop assuming "list everything" and start passing
  through whatever the backend's scope-aware endpoint returns, since enforcement is server-side per
  §2 (the frontend doesn't need to build its own filter — it needs to stop being surprised when the
  backend returns a narrower list than before).
- New `MajorProgram` admin screen, most naturally in
  `src/modules/academics/_components/academic-structure/` alongside the existing structure-tree
  editor, gated to `SUPER_ADMIN` (creating/editing major programs is an institution-level decision,
  not something a scoped ADMIN should do to their own scope).

---

## 8. `FeeType` CRUD — `majorProgramId` (added 2026-09-14)

`POST /fees/types`, `PATCH /fees/types/{id}` and `GET /fees/types` all gain an optional
`majorProgramId` alongside the existing `sessionId`/`programId`/`levelId`, per the resolution table
in `SCHEMA_CHANGES.md` §2a.

```jsonc
// POST /fees/types — a tuition fee for every Part-Time program, Level 200, no specific program
{
  "name": "2026/2027 Tuition — Part-Time, Level 200",
  "category": "TUITION",
  "amount": 150000,
  "sessionId": 7,
  "majorProgramId": 3,
  "programId": null,
  "levelId": 4,
  "studentType": "ALL",
  "isMandatory": true
}

// Response 201 — echoes majorProgramId + a nested { id, name } like session/program/level already do
{ "data": { "id": 41, "majorProgramId": 3, "majorProgram": { "id": 3, "name": "Part-Time Programmes" }, "programId": null, "program": null, /* … */ } }
```

`GET /fees/types?majorProgramId=3` should return every fee type scoped to that major program
**plus** every institution-wide one (`majorProgramId: null`), matching how the frontend already
treats an institution-wide fee as applying under every major program tab (`fee-type-table.tsx`) —
i.e. the same "most specific + always-include-global" resolution used everywhere else in this doc,
not a strict equality filter.

`GET /fees/types/eligible-count` (the live-preview count, `MISSING_BACKEND_APIS.md` §2.9) should
accept the same `majorProgramId` param for the same reason — see `SCHEMA_CHANGES.md` §2a's closing
note.

## 9. `Faculty` CRUD — `majorProgramId` (added 2026-09-15)

`POST /academic/faculties` and `PATCH /academic/faculties/{id}` gain an optional `majorProgramId`;
`GET /academic/faculties` (list and detail) echo it back, per `SCHEMA_CHANGES.md` §2b.

```jsonc
// POST /academic/faculties — a faculty that only ever serves Part-Time students
{
  "name": "Faculty of Natural Sciences",
  "code": "FANS",
  "majorProgramId": 3
}

// Response 201 — echoes majorProgramId + a nested { id, name }, same pattern as every other
// majorProgramId-bearing resource in this codebase
{ "data": { "id": 12, "name": "Faculty of Natural Sciences", "code": "FANS", "majorProgramId": 3, "majorProgram": { "id": 3, "name": "Part-Time Programmes" }, /* … */ } }
```

Unlike `FeeType`/`Program`/`AcademicSession`, this is **not the only signal** for a Faculty's major-
program membership — a Faculty with no `majorProgramId` of its own can still legitimately belong to
one or more major programs through its Departments' Programs (`Program.majorProgramId`, already
live). `majorProgramId` here is an *additional*, more specific override for the common case of a
Faculty that only ever serves one major program (matching a Moodle category that already sits
directly under one major-program root) — it doesn't replace or invalidate the derived path.

`GET /academic/faculties?majorProgramId=3` should return every Faculty directly tagged with that
major program **plus** every Faculty derivable as belonging to it through a Department/Program
chain **plus** every Faculty with `majorProgramId: null` and no such derivable Program (genuinely
institution-wide) — the frontend currently does the derivation itself client-side
(`FacultiesPanel.tsx`) precisely because this filter doesn't exist server-side yet; once it does,
whether to keep doing it client-side or trust the server's answer is a judgment call for whoever
picks this up, not a blocker either way.

## 10. `Department` CRUD — `facultyId` becomes optional, `majorProgramId`/`parentAcademicUnitId` added (added 2026-09-16, proposed)

`POST /academic/departments` and `PATCH /academic/departments/{id}` gain optional `majorProgramId`
and `parentAcademicUnitId`; `facultyId` becomes optional (exactly one of `facultyId` or
`parentAcademicUnitId` required), per `SCHEMA_CHANGES.md` §2c.

```jsonc
// POST /academic/departments — today's exact shape, unchanged, still fully valid
{ "name": "Computer Science", "code": "CSC", "facultyId": 4 }

// POST /academic/departments — new: a department that sits directly under a Major Program's own
// root node, with no Faculty in between (the "Natural Sciences" under "PART-TIME PROGRAMS" case)
{
  "name": "Natural Sciences",
  "code": "NATSCI",
  "parentAcademicUnitId": 22,
  "majorProgramId": 3
}
// 422 if both facultyId and parentAcademicUnitId are sent, or neither is.

// Response 201 — echoes both new fields + nested objects, same pattern as every other
// majorProgramId-bearing resource in this codebase
{ "data": { "id": 9, "name": "Natural Sciences", "code": "NATSCI", "facultyId": null, "parentAcademicUnitId": 22, "majorProgramId": 3, "majorProgram": { "id": 3, "name": "Part-Time Programmes" }, /* … */ } }
```

Same derived-fallback relationship to `majorProgramId` that Faculty already has (§9): when a
Department's own `majorProgramId` is null, effective membership derives from its Programs
(`Department -> Program.majorProgramId`) — but a Department created via `parentAcademicUnitId`
(no Faculty) should be expected to set `majorProgramId` explicitly too, since there's no Faculty to
derive it from at all in that case, and it may have zero Programs under it for a while.

**Not built** — this whole section is a proposal, listed so the shape is agreed before anyone
builds either side of it.
