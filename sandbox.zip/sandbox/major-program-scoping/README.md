# Major-Program Scoping — Architecture & Rollout

**Status:** proposed design, 2026-09-12. Answers a direct question: should sessions/semesters,
admission cycles/steps/forms, fees, roles/permissions, user accounts, and Moodle sync all be
partitioned by "major program" instead of being institution-global? Builds on
`sandbox/multi-program-platform/` and `sandbox/program-structure-depth/` — read those first if you
haven't; this doc assumes their `ProgramCategory` enum and `Cohort` entity already exist.

---

## 1. The ask

RUN doesn't just run programs with different academic *shapes* (covered in
`program-structure-depth/`) — it runs them as near-independent operations: different admission
cycles, different admission officers, different fee schedules, potentially different academic
calendars, and staff who should only ever see their own program's applicants and students. The
question was whether to introduce a "major program" grouping key that everything — sessions,
admission config, fees, roles, user accounts, lecturer assignments, Moodle sync — gets classified
under, instead of being global across the whole institution.

## 2. Short answer

**Yes, this is achievable, and it's the right direction for the parts of the system that are
actually authorization boundaries. It should stay optional-override, not mandatory, for the parts
that are just configuration.** Two things to get right before writing any schema:

1. **`MajorProgram` is a new, first-class entity — not a rename of `ProgramCategory`.**
   `ProgramCategory` (`DEGREE | POSTGRADUATE | CERTIFICATE | DIPLOMA | SECONDARY_SCHOOL |
   FOUNDATIONAL | PART_TIME`, already live) describes **structural shape** — does this program use
   Level? Session-only? Cohort-only? (see `program-structure-depth/README.md`). `MajorProgram`
   describes **administrative scope** — who manages it, which admins/lecturers see it, which
   calendar and fee schedule it runs on. These are orthogonal. A "Business School" major program
   containing a `DEGREE`-shaped BSc in Business Administration is the exact case that proves they
   can't be the same field: Business School isn't a structural shape, it's an org boundary that
   happens to contain degree-shaped programs, same as Foundational or Certificate contain their
   own shapes.

2. **Scope config with nullable overrides (already the codebase's proven pattern); scope RBAC and
   data visibility with enforced, non-optional checks.** These are different problems wearing the
   same name:
   - A shared "Late Registration Penalty" fee type or a shared admission document-upload step
     should be allowed to stay institution-wide — forcing every config object to belong to exactly
     one major program with no shared/default option would mean duplicating identical config N
     times for N programs, for no benefit. Keep the existing `programCategory`/`programId`
     nullable-scope pattern (already live for `AdmissionStepDefinition` and `FeeType`) — null means
     "applies institution-wide," a specific value means "overridden for this program." This is
     already proven, low-risk, and exactly what you asked for as far as config goes.
   - Who can *see and act on* a given applicant/student/record is a security boundary, not a
     default. "Null scope = sees everything" is the wrong default for an ADMIN grant — it should
     mean "not yet assigned to any program, sees nothing" (except for `SUPER_ADMIN`, which per
     `CLAUDE.md` §"Role-Based Route Ownership" already has explicit total system-wide authority).
     This needs real enforcement, not a convenience default, because a missed scope check here is
     a data leak between programs, not a UX inconvenience.

## 3. What already supports this — verified against the live code, not assumed

| Capability | Status | Where |
|---|---|---|
| Config scoped by program/category, with resolution hierarchy | ✅ Have, live pattern to reuse | `AdmissionStepDefinition.programCategory`/`.programId` (`src/types/admissionConfig.d.ts:34-44`), resolved via `GET /admissions/config/steps/effective` |
| Fee scoping by session/program/level | ✅ Have | `FeeType.sessionId`/`.programId`/`.levelId`, all nullable (`fee-type.schema.ts:7-19`) |
| Fee scoping by *major program* (e.g. "every Part-Time program" without picking one program) | ❌ Gap — found 2026-09-14, **`SCHEMA_CHANGES.md` §2a** | `FeeType` has no `majorProgramId`; only "one specific program" or "everyone" are expressible today |
| Arbitrary-depth, regroupable structure tree (for Moodle categories) | ✅ Have | The generic `AcademicUnit` tree + `linkedEntity` (`src/types/school.d.ts:138-176`) — already used to attach a Program directly under a Faculty with no Department, via `parentId`, not a hardcoded FK |
| One designated authority per org unit | ✅ Have (concept only) | `Faculty.deanUserId`, `Department.hodUserId` — real precedent for "this org unit has a named responsible person," but never consulted by any permission check |
| Non-student user tied to an org unit | ✅ Have (metadata only) | `Staff.department_id`, `Tutor.department_id` (required on Tutor) — again, profile metadata, not read by RBAC |
| RBAC grant scoped to an org-unit instance | ❌ Gap — **this doc, §4.C** | `Role`/`Permission`/`UserRole`/`AssignRolesPayload` (`src/types/roles.d.ts`) are 100% flat and global — no scope column exists |
| User account scoped to a major program at creation | ❌ Gap — **this doc, §4.D** | `createUserSchema` (`src/modules/user-management/schemas/index.ts:5-19`) collects only `role_ids`, nothing else |
| Session/Semester scoped by major program | ❌ Gap — **this doc, §4.B** | Enforced as institution-wide singletons via a partial unique DB index; no scope column exists at all |
| `MajorProgram` as a first-class entity | ❌ Gap — **this doc, §4.A** | Doesn't exist; `programCategory` is the closest thing and isn't the right fit (see §2.1) |

Two real, proven patterns to extend; two genuine gaps with no existing scaffolding
(RBAC and Session/Semester); one new entity to introduce.

## 4. The design

### A. New entity: `MajorProgram`

```
MajorProgram: id, code, name, description, isActive, moodleRootCategoryId (nullable)
```

Seed one row per operational grouping RUN actually runs — likely a close match to the screenshot's
top-level Moodle categories: `DEGREE_PROGRAMMES`, `PART_TIME_PROGRAMMES`,
`FOUNDATIONAL_JUPEB_PROGRAMMES`, `CERTIFICATE_PROGRAMMES`, plus room to add `POSTGRADUATE_SCHOOL`
or `BUSINESS_SCHOOL` later without touching the `ProgramCategory` enum at all. `Program` gains a
`majorProgramId` FK (nullable during migration, required going forward via API validation — same
additive-migration approach as every prior schema change in these docs). Full diff:
`SCHEMA_CHANGES.md` §1.

A program's `majorProgramId` and `programCategory` are independent: Business School's BSc Business
Admin is `majorProgramId = BUSINESS_SCHOOL, programCategory = DEGREE`; a JUPEB program is
`majorProgramId = FOUNDATIONAL_JUPEB_PROGRAMMES, programCategory = FOUNDATIONAL`. Nothing stops two
different major programs from both containing `DEGREE`-shaped programs — that's expected, not an
edge case.

### B. Sessions/Semesters — scoped, not removed

`AcademicSession` gains a nullable `majorProgramId`. The "only one active session at a time"
partial unique index changes from a single global constraint to one scoped per major program:

```sql
-- before
CREATE UNIQUE INDEX one_active_session ON academic_sessions (is_active) WHERE is_active = true;
-- after
CREATE UNIQUE INDEX one_active_session_per_major_program
  ON academic_sessions (major_program_id) WHERE is_active = true;
```

A `majorProgramId = null` row keeps today's exact behavior (one shared institution-wide session) —
so an institution that never creates a program-scoped session sees no change at all, per the
existing "single-program is the degenerate case" governing rule. An institution that *does* want
Undergraduate and Postgraduate running independent calendars creates two `AcademicSession` rows,
one per `majorProgramId`, each independently activatable. `Semester` inherits its scope from its
parent `AcademicSession` — no separate column needed. Certificate major programs don't participate
in this at all — they stay on the `Cohort` track from `program-structure-depth/`, which has no
"one active" constraint by design. Full diff: `SCHEMA_CHANGES.md` §2.

### C. RBAC — add scope to the grant, not to the role

**Do not multiply roles** (no `ADMIN_DEGREE`/`ADMIN_CERTIFICATE`/`ADMIN_PART_TIME` enum values).
That breaks the clean role→dashboard mapping in `CLAUDE.md`'s route-ownership table, doesn't scale
past a fixed set of programs known in advance, and conflates *what an ADMIN can do* (permissions)
with *which records they can do it to* (scope) — two things that should vary independently.

Instead, add scope columns to the existing grant row, `UserRole` (`src/types/roles.d.ts:31-37`,
the `user_id ↔ role_id` join table):

```diff
 UserRole {
   user_id: number
   role_id: number
   assigned_by: number | null
   assigned_at: string
   expires_at: string | null
+  major_program_id: number | null   // null = institution-wide (SUPER_ADMIN default; also usable
+                                     // for any role an admin deliberately wants unscoped)
 }
```

Same `Permission` set for every ADMIN everywhere (unchanged — "what can an ADMIN do" doesn't
change). What changes is *which records* an ADMIN's queries return: **three admins, one row each**
— `(user 12, role ADMIN, major_program DEGREE)`, `(user 13, role ADMIN, major_program PART_TIME)`,
`(user 14, role ADMIN, major_program CERTIFICATE)` — same permission set, three different scopes.
A lecturer who teaches across two major programs simply gets two `UserRole` rows (same
`role_id = TUTOR`, two different `major_program_id` values) — no new join table needed, this table
already supports one-user-many-roles, it just needs to also support one-user-one-role-many-scopes
by not being unique on `(user_id, role_id)` alone anymore (drop that constraint if it exists;
uniqueness becomes `(user_id, role_id, major_program_id)`).

**Enforcement — the part that actually matters:** `major_program_id = null` must default to "sees
nothing scoped," not "sees everything," for every role except `SUPER_ADMIN` (which is already
explicitly total-control per `CLAUDE.md`). Every backend endpoint returning
program-scoped data (applicant lists, student lists, fee records, course lists) must intersect its
query with the caller's set of `major_program_id` values from their active `UserRole` rows. This
has to happen server-side, in one shared authorization layer (a guard/middleware resolving "the
caller's scoped major-program IDs" once per request), not repeated ad hoc per controller — that's
where a missed scope filter turns into a real cross-program data leak instead of a UI bug. Full
contract: `API_CONTRACTS.md` §2.

Frontend changes are additive: `usePermissions()`'s `can()` stays exactly as-is (still answers "can
this user do X at all"); a new `useScopedMajorPrograms()` hook reads the caller's scope (returned
alongside their permissions on login/`me`) purely to drive UI — which major program's data a
dropdown/filter defaults to, whether to show a "switch program" selector for a multi-scoped
lecturer. The frontend scope is a convenience mirror of the server's enforcement, never a
substitute for it.

### D. User accounts — scope assigned at role-grant time, not as a profile field

`createUserSchema` (`src/modules/user-management/schemas/index.ts:5-19`) gains an optional
`major_program_ids: number[]` alongside the existing `role_ids: number[]` — when both are provided,
each `role_id` is granted scoped to each `major_program_id` (cross-product, or a paired list if the
UI wants one scope per role rather than every-role-every-scope; either resolves to `UserRole` rows
per §C). Omitting it grants unscoped roles (today's behavior, unchanged) — this stays how STUDENT
and SUPER_ADMIN accounts are created; only STAFF/ADMIN/TUTOR account creation needs the new field
surfaced in the UI. Full contract: `API_CONTRACTS.md` §3.

Students don't need a new field at all — a student's major program is already derivable
transitively via `student.program_id → Program.majorProgramId`, once (A) ships. No denormalization
required for correctness; add a denormalized `Student.major_program_id` later only if a specific
query's performance demands it.

### C/D — Revised 2026-09-16: single, mandatory scope at creation, not optional multi-scope

**Direct instruction, supersedes §C/§D's "optional, many" framing for staff-type roles (Tutor,
Admin, Dean, Director, HOD, Bursary, Staff — every role except `STUDENT`/`APPLICANT`/`SUPER_ADMIN`,
expanded from §D's original "only STAFF/ADMIN/TUTOR" list):**

> "The tutors should be scoped to one major program at the point of creation, the admin role too,
> should be scoped to one major program at the point of creation... the dean, director, and other
> roles follow suit."

The `UserRole.major_program_id` schema from §C is unchanged and already supports this as a special
case — it was already nullable and per-row, so "exactly one, required" is just a stricter API-level
rule on top of the same column, not a schema change:

- **Required, not optional**, for the roles listed above — account creation (`POST /users`, per
  §5 below) must reject (422) omitting `major_program_id` for any of these roles. Contrast with
  `STUDENT`/`APPLICANT` (never scoped this way — a student's scope is derived transitively via
  `Program.majorProgramId`, §D unchanged) and `SUPER_ADMIN` (always unscoped, `null`, total control
  per `CLAUDE.md`'s route-ownership table).
- **Exactly one, not many** — §C's original design allowed a lecturer teaching across major
  programs to hold multiple `UserRole` rows (one per scope). That flexibility is **not being
  removed from the schema** (still just multiple rows, same table, same constraint shape), but it's
  **not what's being asked for right now** — the concrete ask is one scope per person at creation
  time. If a real cross-major-program staff member turns up later, granting them a second `UserRole`
  row (same mechanism §C already describes) still works without any further schema change — this
  addendum just narrows what the *creation flow* requires up front, not what the table can hold.
- **Consequence for `POST /users`'s payload** (§5 below, updated): `major_program_ids: number[]`
  becomes `major_program_id: number` (singular, required for these roles) — simpler than the
  cross-product array the original design proposed, matching "one scope, one role, one person" as
  the actual creation-time shape. `POST /roles/assign` (§4) keeps the array form for the rarer case
  of granting an *additional* scope to an existing account later.

---

### F. Per-role dashboard data audit — what actually needs `majorProgramId` filtering (added 2026-09-16)

Live-tested every non-`SUPER_ADMIN`, non-`STUDENT`/`APPLICANT` role this session (one real account
each, real login, real dashboard) — this is what each role's dashboard actually shows today,
**entirely unscoped**, and needs `WHERE major_program_id IN (:callerScope)` applied to per §C's
enforcement rule once `UserRole.major_program_id` ships. Not guessed — this is the real nav/data
each dashboard rendered, confirmed live.

**Important, concrete finding, verified live 2026-09-16 — A4's confirmed enforcement does not
reach dashboards at all.** This file's own A4 entry (`BACKEND_DEVIATIONS_2026-09-14.md`) already
marks scope enforcement ✅ RESOLVED for four specific list endpoints (Applications/Students/
Invoices/Offerings). To find out whether that extends any further, a fresh Dean account
(`qa_dean_scoped`, user id 36) was created via `POST /auth/users` **with a real, non-null
`majorProgramIds: [2]` (Part-Time Programmes) grant from the moment of creation** — not the
generic, unscoped "Add User" flow the rest of this table's accounts went through — then logged
into for real. Result: **identical dashboard, identical full nav (Admission, Academic Sessions,
User Management, Finance, Grades Management, Reports), same "PLATFORM CONTROL" framing** as the
completely unscoped Dean tested earlier. A real, live `majorProgramId` grant currently makes zero
visible difference. Two separate reasons, both real gaps, neither optional:

1. **The frontend has nothing to consume even if the backend sent it.** `API_CONTRACTS.md` §1's
   `useMajorProgramScope()` hook (reading `majorProgramScope` off the login/`me` response) was
   designed in this doc but was never built — there is no code anywhere in this frontend today that
   reads a caller's scope and conditionally hides a nav section or narrows a dashboard's data
   request based on it. Every dashboard currently just renders its full nav unconditionally.
2. **Whether the *data underneath* is actually filtered is still unconfirmed either way** — the
   scoped Dean's dashboard stat cards (Platform Users, Role Policies, Faculties, Departments) showed
   a loading ellipsis rather than resolved numbers in this test, which could mean those specific
   summary-stat endpoints don't yet accept/respect a scope at all (plausible — they're dashboard
   aggregate endpoints, not the four A4 already covers), or could just be a timing artifact of the
   screenshot. Needs a slower, deliberate re-check, not assumed either way from one fast pass.

This sharpens the actual ask: A4's pattern (server-side `WHERE major_program_id IN (:callerScope)`,
already proven to work for 4 resource types) needs to be **extended to every other program-scoped
endpoint** the table below names — it is not a matter of "turning on" something that already works
everywhere, and the frontend needs `useMajorProgramScope()` (or equivalent) actually built and wired
into nav/dashboard rendering, not just designed.

| Role | Dashboard route | Nav sections seen live | Data that needs scoping |
|---|---|---|---|
| **Tutor** | `/tutor` | Course Assignments, Assessments, Attendance, Timetable, Grading | Assigned courses, course offerings, attendance records, grade books — all currently keyed off the tutor's own `Lecturer` record with no major-program filter visible in the UI layer (can't confirm from the frontend alone whether the backend already scopes any of this — flag for the backend team to confirm per course/offering) |
| **HOD** | `/tutor` (shares Tutor's dashboard entirely today — a separate, pre-existing, deliberate stopgap, not part of this scoping work) | Same as Tutor | Same as Tutor, plus (once HOD gets its own dashboard) department-level student/course rosters |
| **Dean** | `/manager/dashboard` | Admission (Review Applications), Academic Sessions (Sessions, Admissions, Course Structure, Academic Structure, Courses, Demographics), **User Management**, Finance (Fee Management), Grades Management (Summary Charts, Results, Publish Results, Grading Schemes), Reports (Announcements, Notifications) | Everything in every section above — confirmed live this session that Dean currently gets the **exact same** nav and "Platform Users: 25 / Role Policies: 11" framing as `Admin`, including full User Management. This is the single highest-risk item in this table: unscoped, a Dean can see/manage every user and every record institution-wide, not just their own major program. Needs explicit confirmation from you (flagged in the QA doc, not yet answered) on whether Dean's User Management access itself should even survive scoping, or be removed from Dean's nav entirely and reserved for `SUPER_ADMIN`/scoped `Admin` only |
| **Director** | `/director/dashboard` | Scholars (Student & Lecturers), Academic Reports (Grade Reports), Finances (Financial Reports) | Enrollment trends, faculty distribution, grade reports, financial reports — all currently rendered as institution-wide aggregates ("University-wide summary") with no major-program breakdown or filter at all |
| **Bursary** | `/admin/finance/fees` | Fee Management (Fee Types, Invoices, Collections Report, Overdue Report) | Fee types and invoices already have `majorProgramId`/`programId` scoping columns live (A12) — the gap here is RBAC enforcement, not schema: a Bursary account should only ever see/manage fee types and invoices for their own major program, but nothing today stops them querying every fee type institution-wide |
| **Staff** | `/manager/dashboard` (shares the route with Dean/Admin, but already renders different, narrower, role-appropriate content — confirmed live, this part already works correctly) | Records (Students, Clearance), Campus (Announcements) | Student records and clearance queue — needs scoping to the staff member's own major program's students only |
| **Admin** (the `admin` role — distinct from `SUPER_ADMIN`) | `/manager/dashboard` | Identical to Dean (see above) | Same as Dean — this is the role §C/§D's original design already called out as needing scoping; confirmed live it currently sees everything institution-wide |

**What "reconstruct the data layer" concretely means, endpoint by endpoint, is not yet fully
mapped** — the table above is a dashboard-level audit (what's *visible*), not yet a full inventory
of every underlying API endpoint each nav item calls. That deeper inventory (every students list,
every course-offering list, every fee/invoice list, every report endpoint, cross-referenced against
§2's enforcement rule) is real, substantial follow-up work — flagged here rather than guessed at,
so it doesn't ship as a shallow pass that missed half the actual endpoints.

### E. Moodle sync — no new sync mechanism needed

The generic `AcademicUnit` tree (`src/types/school.d.ts:138-176`) already supports exactly this:
add one new `AcademicUnitType` row (`code: "MAJOR_PROGRAM"`), create one root `AcademicUnit` node
per `MajorProgram` row, and reparent each Faculty's existing `AcademicUnit` node underneath the
correct major-program root (matching the screenshot's existing top-level "CERTIFICATE PROGRAMS" /
"FOUNDATIONAL/JUPEB PROGRAMS" / "PART-TIME PROGRAMS" Moodle categories exactly). This is
data/config work using machinery that already exists — no schema change needed beyond what
`schema-moodel-sync-refactor/` already shipped for the tree itself.

## 5. What this doesn't change

- `ProgramCategory` and everything in `program-structure-depth/` — unchanged, and still the axis
  that determines Level/Session/Cohort usage. `MajorProgram` is additive alongside it.
- Permission definitions themselves (`allPermissions`, `rolePermissionMap` per `CLAUDE.md` §5) —
  unchanged. Scoping is a filter on top of the existing permission model, not a replacement for it.
- Single-tenant deployment model — still one instance per institution, per `CLAUDE.md` §1. This is
  intra-institution partitioning by program, not multi-tenancy across institutions (same
  distinction `multi-program-platform/README.md` §0 already drew — this doc extends that reasoning
  to RBAC/calendar instead of just admission config).
- Any institution that only ever runs one major program: creates one `MajorProgram` row, every
  `UserRole`/`AcademicSession` stays scoped to it (or left `null`, equivalent), zero new UI surfaces
  a single-program admin would ever need to touch.

## 6. Rollout order and risk

1. **A (`MajorProgram` entity + `Program.majorProgramId`)** — lowest risk, foundational, unblocks
   everything else conceptually even before enforcement ships.
2. **E (Moodle major-program root categories)** — self-contained, cosmetic, can ship immediately
   after A using existing tree machinery.
3. **B (Session/Semester scoping)** — medium risk: touches a core constraint every enrollment,
   grading-period, and fee-due-date check implicitly relies on. Test the constraint migration
   against a copy of production data before applying it.
4. **C + D (RBAC scoping + user creation)** — highest risk and highest effort: requires auditing
   *every* existing list/detail endpoint for program-scoped resources (applicants, students, fees,
   courses, offerings) and adding the server-side scope filter to each one. Budget this as its own
   project, not a quick add-on — a missed endpoint here is a genuine access-control bug, not a
   cosmetic gap. Recommend shipping C+D behind a feature flag, enforced for newly-created role
   grants first, with a migration plan for existing unscoped grants (default them to `null` =
   `SUPER_ADMIN`-only-unscoped, everyone else must be explicitly assigned a scope before the flag
   flips on).
   - **Priority flagged 2026-09-16 — this is the piece under active time pressure right now.** §F's
     dashboard audit is the starting point for "every existing list/detail endpoint" above — it's
     honest that it's a dashboard-level pass, not yet the full per-endpoint inventory that audit
     calls for, but it's real (live-tested, not guessed) and names the single highest-risk item
     found so far: Dean currently has Admin-equivalent access, unscoped, including full User
     Management. That one item alone is worth prioritizing ahead of a full sweep if C+D has to ship
     incrementally under time pressure — it's the one place today's unscoped state already reads as
     more than "not scoped yet," it reads as "broader access than intended."

## 7. Files in this folder

- `SCHEMA_CHANGES.md` — concrete diffs: new `MajorProgram` model, `Program.majorProgramId`,
  `AcademicSession.majorProgramId` + the relaxed unique-active-session constraint,
  `UserRole.major_program_id` + relaxed uniqueness, `createUserSchema` addition.
- `API_CONTRACTS.md` — the scope-resolution/enforcement contract for list endpoints, the updated
  role-assignment and user-creation payloads, and the `me`/login response shape carrying the
  caller's resolved scope for the frontend to consume.
- `FRONTEND_IMPLEMENTATION_PLAN.md` — internal build plan for how the Student, Admin, Tutor,
  HOD/Dean, Bursary/Director, and Super Admin interfaces each need to change to consume this scope
  model once the backend ships it (not needed by the backend team).
- `ENDPOINT_INVENTORY.md` — added 2026-09-17: the full per-endpoint companion to §F's
  dashboard-level audit above — every nav item on all 7 scoped roles' dashboards, traced to its
  literal API endpoint(s) and whether that endpoint is scoped today. This is the "full per-endpoint
  inventory" §6 point 4 above said was still owed; it's now done.

## 8. Frontend build status — 2026-09-17

§6's "highest-risk item" (Dean's unscoped User Management access) and the shared plumbing needed
for everything else are now built — see `BACKEND_DEVIATIONS_2026-09-14.md`'s **A30** for the full
list of what shipped, the one architecture correction it surfaced (`CLAUDE.md` §5 didn't match the
real RBAC system — fixed), and 3 new backend gaps found while tracing every endpoint. Short version:
the shared `useMajorProgramScope()` hook, real filter tabs on the 4 A4-resolved endpoints, the
user-creation scope field, and Dean's fix are done. Full dashboard-level narrowing for the other 6
roles is still blocked on the backend extending scope enforcement beyond those 4 endpoints — not
guessed at or faked client-side, per this doc's own governing rule in §0.
