# Clearance Module

Manages the student clearance process — students request clearance from various checkpoints (e.g. library, bursary, department), and authorized approvers clear them.

## Models Owned

- **ClearanceType** — types of clearance checkpoints (e.g. "Library", "Bursary", "Department")
- **StudentClearance** — per-student clearance requests and approvals

---

## Endpoints

### Clearance Types

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/clearance/types` | List all clearance types | Authenticated |
| `POST` | `/clearance/types` | Create a clearance type | Admin |
| `PATCH` | `/clearance/types/:id` | Update a clearance type | Admin |
| `DELETE` | `/clearance/types/:id` | Deactivate a clearance type | Admin |

### Student Clearances

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/clearance` | List clearances (filterable by student, type, status) | Admin, Staff |
| `GET` | `/clearance/:id` | Get clearance details | Admin, Staff, Self |
| `GET` | `/clearance/student/:studentId` | Get all clearances for a student | Admin, Self |
| `POST` | `/clearance` | Request clearance for a student | Admin, Student (self) |
| `POST` | `/clearance/student/:studentId/request-all` | Request all clearance types at once | Admin, Student (self) |
| `PATCH` | `/clearance/:id/approve` | Approve a clearance request | Approver, Admin |
| `PATCH` | `/clearance/:id/reject` | Reject a clearance request | Approver, Admin |
| `GET` | `/clearance/student/:studentId/status` | Get clearance summary (all types, cleared or not) | Admin, Self |

---

## Request & Response Types

### `POST /clearance/types`

**Request Body (`CreateClearanceTypeDto`):**

```ts
{
  name: string;            // unique, max 50 chars (e.g. "Library", "Bursary")
  description?: string;
}
```

**Response: `201 Created`** — returns the created clearance type.

---

### `POST /clearance`

**Request Body (`RequestClearanceDto`):**

```ts
{
  studentId: number;
  clearanceTypeId: number;
}
```

**Response: `201 Created`**

```ts
{
  id: number;
  studentId: number;
  clearanceTypeId: number;
  status: "PENDING";
  requestedAt: string;
  clearanceType: { name: string };
}
```

---

### `PATCH /clearance/:id/approve`

**Request Body (`ApproveClearanceDto`):**

```ts
{
  comments?: string;
}
```

**Response: `200 OK`**

```ts
{
  id: number;
  status: "APPROVED";
  approverId: number;
  approvedAt: string;
  comments: string | null;
}
```

---

### `PATCH /clearance/:id/reject`

**Request Body (`RejectClearanceDto`):**

```ts
{
  comments: string;         // required — reason for rejection
}
```

**Response: `200 OK`**

```ts
{
  id: number;
  status: "REJECTED";
  approverId: number;
  approvedAt: string;
  comments: string;
}
```

---

### `GET /clearance/student/:studentId/status`

**Response: `200 OK`**

```ts
{
  studentId: number;
  totalRequired: number;
  totalCleared: number;
  isFullyCleared: boolean;
  clearances: {
    clearanceType: { id: number; name: string };
    status: "PENDING" | "APPROVED" | "REJECTED";
    approverId: number | null;
    approvedAt: string | null;
    comments: string | null;
  }[];
}
```

---

## Clearance Workflow

```
PENDING → APPROVED
        ↘ REJECTED → (re-request → PENDING)
```

---

## Notes for Developers

- Unique constraint: `[studentId, clearanceTypeId]` — a student can only have one clearance record per type. To re-request after rejection, update the existing record.
- `approverId` references the User ID of whoever approved/rejected.
- "Request all" should create `StudentClearance` records for every active `ClearanceType` in a single transaction.
- The summary endpoint aggregates all clearance types and checks whether each has been cleared.
- Clearance is typically required before graduation or transcript issuance.
