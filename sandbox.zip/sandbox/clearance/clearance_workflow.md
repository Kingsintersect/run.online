# Clearance Module — Implementation Workflow

This document explains the internal implementation flow for the Clearance module. It is intended for developers building or maintaining this module.

---

## Module Dependencies

```
ClearanceModule
├── PrismaService          (database access)
├── UserModule             (student lookup)
├── AuditModule            (log clearance decisions)
├── NotificationModule     (notify students of clearance status)
├── PaymentModule          (bursary clearance may check outstanding invoices)
└── DocumentModule         (document clearance may check verified documents)
```

---

## Clearance Concept

Clearance is a multi-checkpoint process typically required before graduation or transcript issuance. Each checkpoint (Library, Bursary, Department, etc.) is an independent approval.

```
┌──────────────────────────────────────────┐
│  Student's Clearance Dashboard           │
│                                          │
│  ✅ Library          — APPROVED          │
│  ✅ Bursary          — APPROVED          │
│  ⏳ Department       — PENDING           │
│  ❌ Student Affairs  — REJECTED          │
│  ⏳ ICT              — PENDING           │
│                                          │
│  Status: NOT FULLY CLEARED (3/5)         │
└──────────────────────────────────────────┘
```

---

## 1. Setup: Clearance Types

**Endpoint:** `POST /clearance/types`

```
Admin defines the clearance checkpoints
         │
         ▼
Typical clearance types:
  - "Library"           → Library staff approves
  - "Bursary"           → Finance staff checks outstanding fees
  - "Department"        → HOD or dept secretary
  - "Student Affairs"   → Student affairs office
  - "ICT"               → ICT department
  - "Health Center"     → Medical clearance
  - "Hostel"            → Hostel warden
```

---

## 2. Request Clearance Flow

### Individual Request

**Endpoint:** `POST /clearance`

```
Student requests clearance for one type
         │
         ▼
┌──────────────────────────────────────────────────┐
│  ClearanceService.requestClearance(dto)           │
│  1. Verify student exists and is ACTIVE          │
│  2. Verify clearanceTypeId exists                │
│  3. Check for existing record:                   │
│     @@unique([studentId, clearanceTypeId])         │
│     - APPROVED → 400 "Already cleared"           │
│     - PENDING → 400 "Already requested"          │
│     - REJECTED → Update to PENDING (re-request)  │
│  4. Create StudentClearance:                     │
│     - status: PENDING                            │
│     - requestedAt: now                           │
│  5. Notify approver(s) for this type             │
└──────────────────────────────────────────────────┘
```

### Request All at Once

**Endpoint:** `POST /clearance/student/:studentId/request-all`

```
Student requests all clearance types at once
         │
         ▼
┌──────────────────────────────────────────────────┐
│  ClearanceService.requestAll(studentId)           │
│  1. Get all active ClearanceType records         │
│  2. For each type:                               │
│     - Check if student already has a record      │
│     - If no record → create PENDING              │
│     - If REJECTED → update to PENDING            │
│     - If PENDING/APPROVED → skip                 │
│  3. Transaction: create all at once              │
│  4. Notify relevant approvers                    │
│  5. Return created/updated records               │
└──────────────────────────────────────────────────┘
```

---

## 3. Approval/Rejection Flow

**Endpoint:** `PATCH /clearance/:id/approve`

```
Approver clears a student
         │
         ▼
┌──────────────────────────────────────────────────┐
│  ClearanceService.approveClearance(id, dto)       │
│  1. Find clearance record                        │
│  2. Verify status == PENDING                     │
│     - Not PENDING → 400                          │
│  3. (Optional) Auto-checks:                      │
│     ┌────────────────────────────────────────┐   │
│     │ "Bursary" type:                        │   │
│     │   Check student has no PENDING invoices │   │
│     │   (via PaymentModule)                  │   │
│     │                                        │   │
│     │ "Library" type:                        │   │
│     │   Check no outstanding library fines   │   │
│     └────────────────────────────────────────┘   │
│  4. Update:                                      │
│     - status = APPROVED                          │
│     - approverId = currentUserId                 │
│     - approvedAt = now                           │
│     - comments = dto.comments                    │
│  5. Notify student: "Library clearance approved" │
│  6. Check if ALL types are now APPROVED          │
│     - If yes → Notify: "Fully cleared!"          │
│  7. Log via AuditService (action: "APPROVE")     │
└──────────────────────────────────────────────────┘
```

---

## 4. Clearance Summary

**Endpoint:** `GET /clearance/student/:studentId/status`

```
┌──────────────────────────────────────────────────┐
│  ClearanceService.getClearanceSummary(studentId)  │
│  1. Get all active ClearanceType records         │
│  2. Get all StudentClearance for this student    │
│  3. Map each type to its clearance status:       │
│     - Has record? → use its status               │
│     - No record? → "NOT_REQUESTED"               │
│  4. Calculate:                                   │
│     - totalRequired = active types count         │
│     - totalCleared = APPROVED count              │
│     - isFullyCleared = (totalCleared ==          │
│       totalRequired)                             │
│  5. Return summary object                        │
└──────────────────────────────────────────────────┘
```

---

## 5. Re-Request After Rejection

When a clearance is REJECTED, the student can re-request. The existing record is updated (not deleted + recreated) because of the unique constraint `[studentId, clearanceTypeId]`:

```ts
// In requestClearance:
const existing = await this.prisma.studentClearance.findUnique({
  where: {
    studentId_clearanceTypeId: {
      studentId: dto.studentId,
      clearanceTypeId: dto.clearanceTypeId,
    },
  },
});

if (existing) {
  if (existing.status === 'APPROVED') throw conflict;
  if (existing.status === 'PENDING') throw conflict;
  // REJECTED → reset to PENDING
  return this.prisma.studentClearance.update({
    where: { id: existing.id },
    data: {
      status: 'PENDING',
      approverId: null,
      approvedAt: null,
      comments: null,
    },
  });
}
```

---

## 6. Files to Create

```
src/modules/clearance/
├── clearance.module.ts
├── clearance.controller.ts        # All clearance routes
├── clearance.service.ts           # Business logic
├── dto/
│   ├── create-clearance-type.dto.ts
│   ├── request-clearance.dto.ts
│   ├── approve-clearance.dto.ts
│   ├── reject-clearance.dto.ts
│   └── query-clearance.dto.ts
└── clearance.service.spec.ts
```

---

## 7. Cross-Module Integration Points

| Direction | Module | Interaction |
| --------- | ------ | ----------- |
| **Consumes** | PaymentModule | Check outstanding invoices for Bursary clearance |
| **Consumes** | DocumentModule | Check verified documents |
| **Consumes** | UserModule | Student lookup |
| **Consumed by** | (Graduation flow) | "Is student fully cleared?" check |
