# Frontend ↔ Backend API Integration Audit

> **Date:** 2026-09-10 (full re-audit — supersedes the 2026-08-21 version, which is preserved
> in git history)
> **Scope:** Every `.bru` under `bruno/` (~330 endpoints, ~25 collections) traced to its
> frontend caller, across all 32 service files under `src/services/**`, `src/modules/*/services/**`,
> `src/lib/**`, and `src/app/**/services/**`.
> **Method:** Read-only. Every `apiClient.{get,post,put,patch,delete}` call site was matched to a
> `.bru` by method + path. No code changed.
> **Companion doc:** `sandbox/API_GAPS_2026-09.md` — the items that need a backend or product
> decision (director analytics endpoints, the `/assessments` vs `/moodle-sync/assessments`
> contract split, the un-built transcript download). It supersedes
> `sandbox/MISSING_BACKEND_APIS.md`, whose "RESOLVED — everything shipped" header is overstated
> (its §2.8–§2.14 specs describe work never delivered — those specs are still the reference for
> *how* to build each item).

---

## What changed since 2026-08-21

The four modules the old audit listed as **❌ Not wired** are now integrated:

| Module | Aug-21 | Now |
|---|---|---|
| Enrollment + Attendance | 0/12 | **12/12** — full service, hooks, and a student Course-Registration UI |
| User Management (Users/Students/Lecturers/Staff) | 0/17 mock | **~19/24** — `usersApi.ts` is real, incl. CSV bulk import |
| Timetable + Calendar | 0/25 mock | **~18/25** — real `timetable.service.ts` |
| Assessments (student/tutor views) | 0/12 mock | wired against `/moodle-sync/assessments/*` (see Part D) |

Other fixes confirmed landed: `POST /auth/logout` now called; audit drill-down URLs corrected;
`use-my-student-id` resolves a real id via `GET /users/students/me`; Configuration envelope bug
fixed; Course "Registry" and "Program Mapping" tabs now real (`courseManagementApi.ts`).

---

## Executive summary

| Module | `.bru` | Wired | Status |
|---|---|---|---|
| Content (Announcements) | 8 | 8 | ✅ |
| Clearance | 12 | 12 | ✅ |
| Document | 9 | 9 | ✅ |
| Hostel | 20 | 20 | ✅ |
| Demographics | 15 | 15 | ✅ |
| Portal-settings (Flags / Registry) | 5 | 5 | ✅ |
| Configuration (Settings) | 6 | 6 | ✅ (old envelope bug fixed) |
| Academic Structure (Units) | 7 | 7 | ✅ |
| Enrollment + Attendance | 12 | 12 | ✅ |
| Course (Course/Offering/Prereq/ProgramCourse/Schedule) | 24 | 24 | ✅ — but schedule path is duplicated (Part D2) |
| Moodle-Sync | ~50 | ~44 | ⚠️ 3 reads unwired; **5 assessment endpoints called with no `.bru`** (A8) |
| Clearance/Document/Hostel student views | — | — | ✅ (unblocked — `use-my-student-id` is real now) |
| Notification | 12 | 11 | ⚠️ page is real; **header bell + dashboard card still mock** |
| Fee | 27 | ~24 | ⚠️ 1 invented endpoint; payment-get unwired |
| Result / Grades | 26 | ~20 | ⚠️ grade-scale CRUD + 2 reads unwired; dashboard-envelope risk (A1) |
| Academic (Faculty/Dept/Program/Level/Session/Semester) | 30 | ~24 | ⚠️ eligible-deans + `academic/*/active` dead (Part D3) |
| Timetable + Calendar + Academic-Calendar | 25 | ~18 | ⚠️ 5 read endpoints unwired |
| Admission (lifecycle/cycles/steps/docs) | ~40 | ~28 | ⚠️ bulk-review, track, doc list/download unwired |
| Auth / Roles / Permissions | 30 | ~26 | ⚠️ +3 invented endpoints; no change-password UI |
| User (Users/Students/Lecturers/Staff) | 24 | ~19 | ⚠️ onboarding + resend-invite + find-by-matric unwired |
| Audit | 5 | 4 | ⚠️ +2 invented endpoints; single-record fetch unwired |
| Student (`/students/me/*`) | 4 | 2 | ⚠️ `my/courses` + result **download** unwired |
| **Assessments (`/assessments/*`)** | 12 | **0** | ❌ superseded by `/moodle-sync/assessments/*` — contract needs a decision |
| **Director** | 0 `.bru` | — | ❌ 3 fabricated endpoints; no `bruno/director/` exists |

**Legend:** ✅ production-ready · ⚠️ mixed / gaps · ❌ not integrated / needs a decision

---

## Part A — Contract mismatches (frontend diverges from an existing `.bru`)

### A1 — Grades analytics dashboard may render empty
`src/modules/student-grades/services/grades.service.ts:645` `getDashboardData()` reads `res.data`
(expects `{ data: GradeSummaryStats }`). The file's own header comment (lines ~20-26) states the
confirmed contract is a **flat** body. `bruno/result/Analytics - Dashboard.bru` has no example body,
so the envelope is genuinely undocumented. If the backend returns flat, `res.data` is `undefined`
and the admin grades dashboard silently shows nothing.
**Action:** capture one live `GET /results/dashboard` response, then align the code and the `.bru`.

### A2 — Director module calls 3 endpoints that don't exist in the contract
`src/modules/director/services/director.service.ts`:
- `GET /enrollments/trend` (line ~272)
- `GET /fees/reports/collections-trend` (line ~316)
- `GET /results/reports/director-grade-summary` (line ~511)

No `.bru`, no `sandbox/` doc. The module ships its own `src/app/(dashboard)/director/INTEGRATION.md`
"contract". `Promise.allSettled` + `.catch` fallbacks keep the dashboard from crashing, but these
tiles are blank in production. **Tracked in `API_GAPS_2026-09.md` §1.**

### A3–A5 — Auth: 3 frontend endpoints with no `.bru`
- `src/services/rolesApi.ts:58` — `POST /auth/roles/:id/duplicate`
- `src/services/rolesApi.ts:190` — `GET /auth/roles/:roleId/users` (contract has no "users by role")
- `src/services/rolesApi.ts:126` — `DELETE /auth/permissions/:id` (`bruno/auth/` documents
  Permissions as Create / List / Update only — no delete)

### A6 — Fee: `GET /fees/types/eligible-count`
`src/modules/fee-management/services/fee-management.service.ts:103` — a live "how many students would
this fee apply to" preview. No `.bru` in the `Fee Types` collection.

### A7 — Audit: `GET /audit/export` + `POST /audit/log`
`src/app/(dashboard)/admin/(routes)/audit/services/audit.api.ts:132,157`. Neither is in
`bruno/audit/`. Export currently falls back to a client-side CSV builder; `POST /audit/log` is dead
code (audit rows are system-generated).

### A8 — Assessments: frontend was on the wrong path — **FIXED 2026-09-10**
Live verification showed `/assessments/*` is the **complete, working** contract (list, `/my`,
`/upcoming`, `/:id`, `/course/:id`, `/course/:id/upcoming` all `200`; `/:id/visibility`,
`DELETE /:id`, `/sync/*` `403` for a student = exist, role-gated). `/moodle-sync/assessments/*` is
the **incomplete** one and `404`s on `/my`, `/:id`, `/:id/visibility`, `DELETE /:id`, `/sync/*` —
which is why the student "All assessments" tab and the detail page were broken and the sync-status
table was shape-mismatched.

`moodle-sync.service.ts` assessment methods repointed to `/assessments/*` with a normalizer
(list rows are flat `course:{code,title,semesterName}`; `/:id` is deep
`course.courseOffering.{...}`). Only `GET /assessments/ca-preview/:offeringId` is genuinely
missing backend-side (`API_GAPS_2026-09.md` §2, `MISSING §2.14`).

### A9 — `POST /admission/program-choice`
`src/app/(admission)/services/admissionService.ts:182`. `.bru` exists
(`Admission - Submit Program Choice.bru`) but this is the un-shipped pre-application "Choice
Program" flow — historically 404s. **Fully specified already in
`sandbox/REFACTOR_BACKEND_APIS.md`** — not duplicated in the new gaps doc, just cross-linked.

---

## Part B — Mock / placeholder data still in the tree

> **Status update — 2026-09-10 pass 2.** The notification bell / dashboard card and the student
> settings page are now real. `src/modules/finances/**` does not exist (already removed — the
> audit entry was stale). Only the Director `Math.random` fallback remains, and that's by design
> until A2 ships.

| Where | What | Note |
|---|---|---|
| ~~`Header.tsx` notification bell~~ | ~~mock `useNotificationStore`~~ | **RESOLVED** — real `/notifications`, mock store deleted |
| ~~`student/dashboard` "Notifications" card~~ | ~~same mock store~~ | **RESOLVED** |
| ~~`student/settings` profile / password~~ | ~~`localStorage` / `updateUser` only~~ | **RESOLVED** — password → `POST /auth/change-password`; profile phone + contact address → `PATCH /users/students/:id` (`useUpdateMyProfile`); identity fields now read-only; only bio/avatar stay this-device (no backend field) |
| `src/modules/director/**` | `Math.random()`-seeded students/tutors/payments when the 3 non-contract endpoints 404 | by design — see A2 / `BACKEND_HANDOFF.md` A1 |
| Notification preference toggles (`student/settings`) | SMS / push / email-category switches persist to `localStorage` | no backend endpoint documented for per-user notification preferences; leave until one exists |

---

## Part C — `.bru` endpoints not yet integrated (contract exists, no caller)

> **Status update — 2026-09-10 integration sweep (phases 1–7).** Most of the list below has
> since been wired. Now integrated: `POST /auth/change-password`; `GET /academic/faculties/eligible-deans`;
> `PATCH /users/lecturers/me/onboarding`; `POST /users/lecturers/:id/resend-invite`;
> `GET /users/students/matric/:matricNumber`; `GET /timetable/schedules/{lecturer,semester}/:id`;
> `POST`/`PATCH`/`DELETE /results/grade-scales/:id`; `GET /results/grades/course/:c/semester/:s`;
> the whole `/assessments/*` collection (repointed off `/moodle-sync/assessments/*` + normalizer);
> `POST /admissions/applications/bulk-review`; `GET /admissions/applications/:id/documents` +
> `.../download`; `GET /admissions/applications/track/:number`; `GET /audit/logs/:id`;
> `GET /moodle-sync/users/unmatched`; `GET /students/me/courses`; the Header/dashboard/settings
> `/notifications/*` wiring; `DELETE /auth/roles/:roleId/permissions/:permissionId` (the role-edit
> sync now reconciles — adds *and* detaches); `POST /admissions/bulk` (batch "Create offers" on the
> review table); `GET /academic-calendar/events` + `GET /academic-calendar/sessions/:id`
> (student Calendar page / admin session cards); `GET /calendar/events/course/:id` (student Calendar
> course filter); `GET /results/grades/course/:c/semester/:s` (tutor course grade book);
> `GET /results/grades/:id` (grade modal refresh); `GET /notifications/:id` (reading pane);
> `GET /fees/payments/:id` (payment detail modal); `PATCH /users/students/:id` (student self-profile).
> A1 resolved (analytics reads now envelope-tolerant). **Nothing FE-side is left** — the remainder is
> backend-only, tracked in `sandbox/BACKEND_HANDOFF.md`.

### auth
- `POST /auth/change-password` — student Settings → Security form is mock (Part B).
- `DELETE /auth/roles/:roleId/permissions/:permissionId` (Role Permissions – Detach) — frontend
  re-assigns the whole permission set instead of detaching one.

### user
- `GET /users/students/matric/:matricNumber` (Find By Matric)
- `PATCH /users/lecturers/me/onboarding` — the tutor first-login checklist from
  `sandbox/user/tutor_onboarding_workflow.md`. No UI.
- `POST /users/lecturers/:lecturerId/resend-invite` — no button in `TutorList`.
- `DELETE /users/:id` — intentional; the app soft-deactivates via `PATCH /users/:id { isActive }`.

### academic
- `GET /academic/faculties/eligible-deans` — dean-assignment dropdown not wired.
- `GET /academic/sessions/active`, `GET /academic/semesters/active`, `GET /academic/semesters/:id`
  — dead (see Part D3).

### timetable / calendar
- `GET /timetable/schedules/lecturer/:lecturerId` (Schedules – By Lecturer)
- `GET /timetable/schedules/semester/:semesterId` (Schedules – By Semester)
- `GET /calendar/events/course/:offeringId` (Calendar Events – By Course)
- `GET /academic-calendar/sessions/:sessionId` (Session Get)
- `GET /academic-calendar/events` (Academic Calendar – Events)

### student (`bruno/student/`)
- `GET /students/me/courses` (My Courses) — the app derives "my courses" from
  `GET /enrollments/student/:id` instead.
- `GET /students/me/results/:semesterId/download` — **no transcript / result-sheet PDF download
  exists anywhere in the student UI.** Tracked in `API_GAPS_2026-09.md` §4 (frontend build item —
  endpoint is ready).

### result
- `GET /results/grades/:id` (Grade – Get)
- `GET /results/grades/course/:courseId/semester/:semesterId` (Grade – By Course And Semester)
- `POST /results/grade-scales`, `PATCH /results/grade-scales/:id`, `DELETE /results/grade-scales/:id`
  — grade-scale **CRUD** unwired; only `GET` list is used.

### notification
- `GET /notifications/:id` (single notification).

### fee
- `GET /fees/payments/:paymentId` (Payments – Get).
- `POST /fees/payments/webhook` — backend-only, N/A.

### admission
- `POST /admissions/bulk` (Admissions – Bulk Create)
- `POST /admissions/applications/bulk-review` (Applications – Bulk Review)
- `GET /admissions/applications/track/:applicationNumber` (public application tracking — no UI)
- `GET /admissions/applications/:id/documents` (Application Documents – List)
- `GET /admissions/applications/:id/documents/:docId/download` (Application Documents – Download)

### audit
- `GET /audit/logs/:id` (Get By ID) — the list and drill-downs work; single-record fetch doesn't.

### moodle-sync
- `GET /moodle-sync/courses/my` (Course Sync – My)
- `GET /moodle-sync/users/unmatched` (User Sync – Unmatched)
- `POST /moodle-sync/sso/launch` — superseded by `GET /students/me/courses/:offeringId/launch`.

### assessments (`/assessments/*`) — the entire 12-endpoint collection
`GET /assessments`, `/assessments/:id`, `/assessments/my`, `/assessments/upcoming`,
`/assessments/course/:id`, `/assessments/course/:id/upcoming`, `POST /assessments/sync/:id`,
`/assessments/sync-all`, `GET /assessments/sync/status`, `POST /assessments/sync/:id/retry`,
`PATCH /assessments/:id/visibility`, `DELETE /assessments/:id`.
None are called. The frontend implements the same feature against `/moodle-sync/assessments/*`.
**Tracked in `API_GAPS_2026-09.md` §2 — the backend must declare which path is canonical.**

---

## Part D — Contract-level duplication (two `.bru` sets for one feature)

### D1 — Assessments
`bruno/assessments/*` (`/assessments/*`) and `bruno/moodle-sync/Assessment Sync - *`
(`/moodle-sync/assessments/*`) describe the same feature. Frontend uses the moodle-sync path.

### D2 — Class schedules
`bruno/course/Schedule - *` (`/courses/offerings/:id/schedules`, `/courses/schedules/:id`) and
`bruno/timetable/Schedules - *` (`/timetable/schedules/*`) both address `ClassSchedule` rows. The
app calls **both**: `courseOfferingApi.schedulesApi` uses the course paths;
`timetable.service.ts` uses the timetable paths. Two React-Query caches for the same data → a
schedule edited through one surface can look stale in the other.

### D3 — "Active term" lookups
`/academic/sessions/active` + `/academic/semesters/active` (academic module) vs
`/academic-calendar/sessions/active` + `/academic-calendar/semesters/active` (timetable module).
Frontend uses the `academic-calendar` pair; the `academic/*` pair has zero callers.

### D4 — Calendar events
`/calendar/events/*` (timetable) and `/moodle-sync/calendar/*` (moodle-sync) are both fully wired
(`calendarService` and `moodleSyncService` respectively). This one is probably intentional — Moodle
calendar sync vs the portal's own academic calendar — but worth confirming.

---

## Part E — Live verification (2026-09-10, authenticated as a student)

A `403` from a student token means the endpoint **exists** and is role-gated; a `404` means it
isn't built.

**Confirmed LIVE — just need a frontend caller / UI:**
`GET /assessments/*` (whole collection) · `GET /students/me/courses` · `GET /notifications/unread-count`
(returns real `{unreadCount}`) · `GET /notifications/:id` (403) · `GET /academic/faculties/eligible-deans`
· `GET /academic/sessions/active` · `GET /academic/semesters/active` · `GET /academic-calendar/events`
· `GET /academic-calendar/sessions/:id` · `GET /calendar/events/course/:id` ·
`GET /users/students/matric/:x` (403) · `GET /results/grades/course/:c/semester/:s` (403) ·
`GET /audit/logs/:id` (403) · `GET /timetable/schedules/lecturer/:id` (403) ·
`GET /timetable/schedules/semester/:id` (403) · `GET /moodle-sync/courses/my` ·
`GET /moodle-sync/users/unmatched` (403) · `POST /admissions/bulk` (405 on GET = route exists, POST-only)

**Confirmed NOT built (`404`):**
- `GET /students/me/results/:semesterId/download` — transcript / result-sheet PDF
- `GET /enrollments/trend`, `GET /fees/reports/collections-trend`,
  `GET /results/reports/director-grade-summary` — the 3 Director aggregates
- `GET /fees/types/eligible-count`
- `GET /assessments/ca-preview/:offeringId` (and `/moodle-sync/...` variant) — Moodle CA→Grade bridge
- `GET /fees/payments/:id` — 404 for id 1 (could be no-such-record; re-verify with a real payment id)
- `GET /results/grades/:id` — 404 for id 1 (ditto — may just be not-visible-to-student)
- `GET /admissions/applications/track/:num` — 404 for a fake number (re-verify with a real one)

Everything in the first group is a **frontend build item**, not a backend gap.

---

## Companion docs

- `sandbox/API_GAPS_2026-09.md` — new. The items above that need a backend or product decision.
- `sandbox/REFACTOR_BACKEND_APIS.md` — the pre-application "Choice Program" endpoint (A9), already
  specced.
- `sandbox/admission/admission_BACKEND_GAPS.md`, `sandbox/moodle_sync/moodle_sync_BACKEND_GAPS.md`,
  `sandbox/academic/missing_faculty_department_apis.readme.md`,
  `sandbox/course/missing_course_offering_enrichment.readme.md`,
  `sandbox/course/missing_curriculum_apis.readme.md`,
  `sandbox/admission/missing_admission_cycle_apis.readme.md`,
  `sandbox/result/missing_grade_apis.readme.md` — per-feature backend specs, still valid.
- `sandbox/MISSING_BACKEND_APIS.md` — its header says "RESOLVED — every item shipped", but its own
  body (§2.8, §2.9, §2.11–§2.14) still describes genuinely unshipped work. `API_GAPS_2026-09.md`
  restates the parts that are actually still open; the specs in those §2.x sections remain the
  reference for what to build.
