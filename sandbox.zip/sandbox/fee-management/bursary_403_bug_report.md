# Backend Bug Report — BURSARY/DIRECTOR (and DEAN) 403 on report endpoints

**Found:** 2026-09-12, during a full-app browser QA pass across every role.
**Severity:** High for BURSARY, **Critical for DIRECTOR** — DIRECTOR's
entire toolkit (Dashboard, Scholars, Grade Reports, Financial Reports — all
4 of its pages) is non-functional against the live backend; every data
endpoint those pages call 403s for a DIRECTOR token.
**Status:** Frontend-side workaround shipped (graceful "—"/"Unavailable"
states and visible error banners instead of silently-fabricated zeros, no
more unlabeled console 403 spam). Directly tested and ruled out a
permission-assignment fix (see below) — granting BURSARY and DIRECTOR the
exact permissions their own catalog entries claim to require changed
nothing; every endpoint in this report still 403s. The authorization bug
is server-side and out of this project's scope to fix (`CLAUDE.md` §13) —
this doc is the handoff.

## Symptom

Two endpoints reject requests from roles that should clearly be allowed to
call them:

- `GET /fees/reports/summary`
- `GET /fees/invoices/overdue`

Both return `403 { "message": "You are not allowed to perform this action." }`
for a **BURSARY** token — the role whose entire function is fee/finance
management, on its own dedicated dashboard (`/admin/finance/fees`,
`FeeManagementOverview` component). Confirmed live with a real BURSARY
login, not inferred.

**DEAN** gets the same 403 on the same two endpoints.

## Why this isn't a permission-assignment problem — tested directly, not just inferred

The obvious fix would be "grant the missing permission." Circumstantial
evidence argued against it (ADMIN succeeds *without* `financial-summary.view`;
DEAN has it and still gets rejected):

| Role | Has `financial-summary.view`? | Actually works? |
|---|---|---|
| ADMIN | **No** | ✅ Works |
| DEAN | **Yes** | ❌ 403s |
| BURSARY | No (at the time) | ❌ 403s |
| SUPER_ADMIN | Yes | ✅ Works |

**2026-09-12, follow-up — tested directly, not inferred:** with the user's
explicit go-ahead, granted BURSARY the two permissions it was actually
missing (`financial-summary.view` id 45, `financial-transactions.view` id
46) and DIRECTOR the two it was missing (`users.view` id 35,
`enrollment.view.all` id 94) via the live `POST /auth/roles/:id/permissions`
API. Confirmed both grants landed (BURSARY went from 9→11 permissions,
DIRECTOR 13→15). Then re-tested every previously-403'ing endpoint for both
roles with fresh logins:

| Role | Endpoint | Had the matching permission after the grant? | Still 403? |
|---|---|---|---|
| BURSARY | `/fees/reports/summary` | Yes (`financial-summary.view`) | **Yes, still 403** |
| BURSARY | `/fees/invoices/overdue` | Yes (`financial-summary.view`) | **Yes, still 403** |
| DIRECTOR | `/users/stats` | Yes (`users.view`) | **Yes, still 403** |
| DIRECTOR | `/enrollments/trend` | Yes (`enrollment.view.all`) | **Yes, still 403** |
| DIRECTOR | `/fees/reports/summary` | Yes (`financial-summary.view`) | **Yes, still 403** |
| DIRECTOR | `/fees/reports/outstanding` | Yes (`financial-summary.view`) | **Yes, still 403** |
| DIRECTOR | `/users/students` | Yes (`students.view`, already held) | **Yes, still 403** |
| DIRECTOR | `/users/lecturers` | Yes (`tutors.view`, already held) | **Yes, still 403** |
| DIRECTOR | `/results/reports/director-grade-summary` | Yes (`grade-reports.view`, already held) | **Yes, still 403** |

Every single one still fails, despite each role now holding the exact
permission its own catalog entry says should unlock that endpoint. This
conclusively rules out the permission system as the gate on any of these
routes — it isn't a missing-assignment problem at all, on any of the
endpoints this bug covers. **No further RBAC change from this side can fix
this** — it needs an actual code change in the backend's authorization
check. The two permission grants above are harmless and arguably correct
to keep (BURSARY/DIRECTOR should have them on principle), but they did not
and cannot resolve the bug.

## Most likely root cause

Every route above appears to check the caller's role directly against a
hard-coded allow-list (something like `role in ['admin', 'super_admin']`)
instead of checking a permission at all — the opposite of how the rest of
this system's RBAC is designed (every other endpoint this project has
probed this session gates correctly by permission, not role), and now
directly confirmed rather than inferred (see the permission-grant test
above: holding the exact matching permission changes nothing). Whoever
owns these controller actions should add `BURSARY`/`DEAN`/`DIRECTOR` (as
appropriate per endpoint) to whatever role check is actually being made,
or better, switch each one to check the permission its own catalog entry
already claims to gate it — `financial-summary.view`, `users.view`,
`enrollment.view.all`, `students.view`, `tutors.view`, `grade-reports.view`
— like the rest of this system's endpoints already do.

## DIRECTOR — the same bug, much wider

Confirmed live with a real DIRECTOR login that **every** data endpoint its
4 pages call 403s:

| Page | Endpoints called | Result |
|---|---|---|
| Dashboard | `/users/stats`, `/users/students?status=GRADUATED`, `/enrollments/trend`, `/fees/reports/summary`, `/fees/reports/outstanding` | All 403 |
| Scholars | `/users/students`, `/users/lecturers`, `/users/stats` | All 403 |
| Grade Reports | `/results/reports/director-grade-summary` | 403 |
| Financial Reports | `/fees/reports/summary`, `/fees/reports/outstanding`, `/fees/reports/collections-trend` | All 403 |

DIRECTOR's documented permissions (`students.view`, `tutors.view`,
`grade-reports.view`, `results.view.all`, `financial-summary.view`,
`fee-management.view`) map almost one-to-one to what these endpoints
should need — the same evidence as BURSARY above rules out a missing-
permission explanation. This is the same hard-coded-role-allow-list bug,
just affecting nearly every endpoint DIRECTOR touches instead of two.

**Worse than a plain 403 page:** the director module's service layer
(`src/modules/director/services/director.service.ts`) already wraps every
fetch in `Promise.allSettled` and falls back to `0`/`[]`/`{}` on failure —
a defensive pattern, but one that had the side effect of making every
403'd value indistinguishable from a genuine zero. Before this session's
fix, the Dashboard showed "0 Total Students" and "₦0.0M Total Revenue" as
if that were real data — actively misleading for a role whose whole job is
executive oversight, worse than an obvious error would have been.

## Frontend changes made in the meantime

To stop this from being a live, user-facing error (raw console 403s, a
dashboard that never finishes loading two stat cards):

- `src/modules/fee-management/hooks/use-fee-reports.ts` — `useCollectionsSummary`
  gained an `enabled` param (default `true`, existing callers unaffected).
- `src/modules/fee-management/hooks/use-invoices.ts` — `useOverdueInvoices`
  gained the same.
- `src/hooks/useAdminDashboard.ts` / `useManagerDashboard.ts` — the shared
  ADMIN/DEAN dashboard now only fires these (plus `/users/stats` and
  `/auth/roles`, which have the identical DEAN-403 problem) for
  `SUPER_ADMIN`/`ADMIN`.
- `src/modules/fee-management/components/admin/fee-management-overview.tsx`
  (BURSARY's own dashboard, also used by ADMIN/DEAN) — same gate, plus an
  explicit "Unavailable" label on the affected stat cards instead of an
  infinite loading skeleton, so a BURSARY or DEAN user sees an honest state
  rather than a page that looks broken or stuck.

- `src/modules/director/services/director.service.ts`,
  `src/modules/director/types/director.types.ts`,
  `src/modules/director/store/director.store.ts` — `DashboardOverview`,
  `FinancialSummary`, and `StatisticalReport` all gained a `hasLoadErrors`
  flag that's `true` when any of their underlying sub-fetches failed. The
  store now surfaces that as the pages' existing error banners (which
  previously never fired, since the inner `allSettled` calls never let a
  rejection propagate up to the outer try/catch). The Dashboard's metric
  cards and the Financial Reports page's KPI cards now show "—" for any
  figure whose source data failed, instead of a fabricated 0/₦0.00/0%.

None of this restores the actual data — it just stops the symptom from
looking like real data, or like a frontend bug. BURSARY still cannot see
its own collections summary or overdue-invoice report, and DIRECTOR still
cannot see anything on any of its 4 pages, until the backend authorization
check is fixed.
