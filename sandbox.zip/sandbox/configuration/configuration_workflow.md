# Configuration Module — Implementation Workflow

This document explains the internal implementation flow for the Configuration module. It is intended for developers building or maintaining this module.

---

## Module Dependencies

```
ConfigurationModule
├── PrismaService          (database access)
├── CacheService / Redis   (cache frequently accessed settings)
└── (no cross-module service imports)
```

> The Configuration module is a **foundational module**. It provides key-value settings to other modules via `ConfigurationService`. It does not depend on any business module.

---

## Core Concept

Since each deployment serves one university, all configuration (university name, logo, academic policies, payment gateway keys, etc.) is stored in a flat `settings` table grouped by category.

```
┌──────────────────────────────────────────┐
│  settings table                          │
│                                          │
│  group: "university"                     │
│  ├── university_name = "ODL University"  │
│  ├── university_logo = "/images/logo.png"│
│  ├── university_motto = "Knowledge..."   │
│  └── university_email = "info@odl.edu"   │
│                                          │
│  group: "payment"                        │
│  ├── payment_gateway = "paystack"        │
│  ├── payment_gateway_key = "sk_..."      │
│  ├── application_fee = "10000"           │
│  ├── acceptance_fee = "30000"            │
│  └── tuition_fee = "195000"              │
│                                          │
│  group: "academic"                       │
│  ├── max_credit_units = "24"             │
│  ├── min_attendance_pct = "75"           │
│  └── grading_system = "5.0"             │
│                                          │
│  group: "moodle"                         │
│  ├── moodle_base_url = "https://..."     │
│  ├── moodle_api_token = "abc..."         │
│  └── moodle_student_role_id = "5"        │
│                                          │
│  group: "system"                         │
│  ├── maintenance_mode = "false"          │
│  └── app_version = "1.0.0"              │
└──────────────────────────────────────────┘
```

---

## 1. CRUD Operations

### Create Setting

**Endpoint:** `POST /configuration/settings`

```
Admin creates a new setting
         │
         ▼
┌──────────────────────────────────────────────────┐
│  ConfigurationService.create(dto)                │
│  1. Check key uniqueness                         │
│     - Duplicate → 409                            │
│  2. Create Setting record:                       │
│     - key, value (text), group                   │
│  3. Invalidate cache for this key                │
│  4. Return created setting                       │
└──────────────────────────────────────────────────┘
```

### Update Setting

**Endpoint:** `PATCH /configuration/settings/:id`

```
Admin updates a setting value
         │
         ▼
┌──────────────────────────────────────────────────┐
│  ConfigurationService.update(id, dto)            │
│  1. Find by ID → 404 if not found               │
│  2. Update value and/or group                    │
│  3. Invalidate cache for this key                │
│  4. Return updated setting                       │
└──────────────────────────────────────────────────┘
```

### Get by Key

**Endpoint:** `GET /configuration/settings/key/:key`

```
Admin or internal service looks up a setting
         │
         ▼
┌──────────────────────────────────────────────────┐
│  ConfigurationService.getByKey(key)              │
│  1. Check Redis cache first                      │
│     - Cache hit → return cached value            │
│  2. Cache miss → query DB                        │
│  3. Store in Redis (TTL: 5 min or configurable)  │
│  4. Return setting                               │
└──────────────────────────────────────────────────┘
```

---

## 2. Internal Service API (for other modules)

Other modules inject `ConfigurationService` to read settings:

```ts
@Injectable()
export class ConfigurationService {
  constructor(
    private prisma: PrismaService,
    private cache: CacheService,  // Redis-based
  ) {}

  /**
   * Get a setting value by key. Returns the raw string value.
   * The caller is responsible for type coercion.
   */
  async get(key: string): Promise<string | null> {
    // Check cache
    const cached = await this.cache.get(`setting:${key}`);
    if (cached !== null) return cached;

    // Query DB
    const setting = await this.prisma.setting.findUnique({
      where: { key },
    });

    if (setting) {
      await this.cache.set(`setting:${key}`, setting.value, 300); // 5 min TTL
    }

    return setting?.value ?? null;
  }

  /**
   * Get a setting as a number.
   */
  async getNumber(key: string): Promise<number | null> {
    const val = await this.get(key);
    return val !== null ? Number(val) : null;
  }

  /**
   * Get a setting as a boolean.
   */
  async getBoolean(key: string): Promise<boolean> {
    const val = await this.get(key);
    return val === 'true' || val === '1';
  }

  /**
   * Get all settings for a group.
   */
  async getGroup(group: string): Promise<Record<string, string>> {
    const settings = await this.prisma.setting.findMany({
      where: { group },
    });
    return Object.fromEntries(settings.map(s => [s.key, s.value]));
  }
}
```

### Usage in Other Modules

```ts
// PaymentService
const appFee = await this.config.getNumber('application_fee'); // 10000
const gateway = await this.config.get('payment_gateway');       // "paystack"

// MoodleService
const moodleUrl = await this.config.get('moodle_base_url');
const token = await this.config.get('moodle_api_token');

// EnrollmentService
const maxCredits = await this.config.getNumber('max_credit_units'); // 24
```

---

## 3. Caching Strategy

```
Write path:
  Create/Update setting → DB write → invalidate cache key

Read path:
  Request → check Redis → if miss → query DB → populate Redis (5 min TTL)
```

- **TTL**: 5 minutes by default. Settings change infrequently.
- **Invalidation**: On create/update/delete, explicitly delete the cache key.
- **Group queries**: Cache individually by key, not by group (groups can be large).

---

## 4. Naming Convention

Use `group_snake_case_name` for keys:

```
university_name          ← group: "university"
university_logo
payment_gateway_key      ← group: "payment"
payment_application_fee
academic_max_credit_units ← group: "academic"
moodle_base_url          ← group: "moodle"
system_maintenance_mode  ← group: "system"
```

---

## 5. Seeding Default Settings

On first deployment, seed essential settings:

```ts
// prisma/seed.ts (or a migration hook)
const defaults = [
  { key: 'university_name', value: 'ODL University', group: 'university' },
  { key: 'application_fee', value: '10000', group: 'payment' },
  { key: 'acceptance_fee', value: '30000', group: 'payment' },
  { key: 'tuition_fee', value: '195000', group: 'payment' },
  { key: 'max_credit_units', value: '24', group: 'academic' },
  { key: 'min_attendance_pct', value: '75', group: 'academic' },
];

for (const setting of defaults) {
  await prisma.setting.upsert({
    where: { key: setting.key },
    update: {},
    create: setting,
  });
}
```

---

## 6. Files to Create

```
src/modules/configuration/
├── configuration.module.ts        # exports ConfigurationService
├── configuration.controller.ts    # CRUD REST endpoints
├── configuration.service.ts       # get/set/cache logic
├── dto/
│   ├── create-setting.dto.ts
│   ├── update-setting.dto.ts
│   └── query-setting.dto.ts
└── configuration.service.spec.ts
```

---

## 7. Cross-Module Integration Points

| Consumer Module | Settings consumed |
| --------------- | ----------------- |
| **Payment** | `application_fee`, `acceptance_fee`, `tuition_fee`, `payment_gateway`, `payment_gateway_key` |
| **MoodleSyncModule** | `moodle_base_url`, `moodle_api_token`, `moodle_student_role_id`, `moodle_teacher_role_id`, `moodle_manager_role_id`, `moodle_auto_sync_enabled`, `moodle_sync_cron_interval` |
| **Enrollment** | `max_credit_units` |
| **Result** | `grading_system` |
| **All** | `maintenance_mode` (if implemented as middleware) |
