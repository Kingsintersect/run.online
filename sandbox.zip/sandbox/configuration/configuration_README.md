# Configuration Module

Manages application-wide settings as key-value pairs. Since each deployment serves one university, configuration (name, logo, motto, academic policies, payment config, etc.) is stored in a flat `settings` table grouped by category.

## Models Owned

- **Setting** — key-value config entries grouped by `group` (e.g. `"university"`, `"academic"`, `"payment"`, `"system"`)

---

## Endpoints

### Settings

| Method | Endpoint | Description | Auth |
| ------ | -------- | ----------- | ---- |
| `GET` | `/configuration/settings` | List all settings (optionally filter by group) | Admin |
| `GET` | `/configuration/settings/:id` | Get a single setting by ID | Admin |
| `GET` | `/configuration/settings/key/:key` | Get a setting by its unique key | Admin |
| `POST` | `/configuration/settings` | Create a new setting | Admin |
| `PATCH` | `/configuration/settings/:id` | Update an existing setting | Admin |
| `DELETE` | `/configuration/settings/:id` | Delete a setting | Admin |

---

## Request & Response Types

### `GET /configuration/settings`

**Query Parameters:**

```ts
{
  group?: string;   // Filter by group (e.g. "university", "academic")
  page?: number;    // Pagination page (default: 1)
  limit?: number;   // Items per page (default: 20)
}
```

**Response: `200 OK`**

```ts
{
  data: {
    id: number;
    key: string;        // e.g. "university_name"
    value: string;      // stored as text, parse as needed
    group: string;      // e.g. "university"
    createdAt: string;  // ISO 8601
    updatedAt: string;
  }[];
  meta: { total: number; page: number; limit: number };
}
```

---

### `GET /configuration/settings/:id`

**Response: `200 OK`**

```ts
{
  id: number;
  key: string;
  value: string;
  group: string;
  createdAt: string;
  updatedAt: string;
}
```

---

### `POST /configuration/settings`

**Request Body (`CreateSettingDto`):**

```ts
{
  key: string;       // unique, max 100 chars
  value: string;     // text
  group: string;     // max 50 chars
}
```

**Response: `201 Created`** — returns the created setting object.

---

### `PATCH /configuration/settings/:id`

**Request Body (`UpdateSettingDto`):**

```ts
{
  value?: string;
  group?: string;
}
```

**Response: `200 OK`** — returns the updated setting object.

---

### `DELETE /configuration/settings/:id`

**Response: `204 No Content`**

---

## Notes for Developers

- The `key` field is globally unique. Use a naming convention like `group_snake_case_name` (e.g. `university_name`, `payment_gateway_key`).
- Values are stored as `TEXT`. The application layer should handle type coercion (e.g. parse `"true"` → boolean, `"5000"` → number).
- Consider caching settings in Redis since they change infrequently.
